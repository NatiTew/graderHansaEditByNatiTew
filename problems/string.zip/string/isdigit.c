#include <stdio.h>
#include <ctype.h>

int  main ( void ) {
	char c1 , c2 , c3 , c4 , c5 , c6 , c7 , c8;
	c1 = '7'; c2 = '&'; c3 = '#'; c5='F'; c6='K';c7='\f';c8=',';

	printf ("\n 1:Test isdigit: %c is %s digit.", c1, isdigit(c1)? "a" : "not a");
	printf ("\n 2:Test isalpha: %c is %s letter.", c2, isalpha(c2) ? "a" : "not a");
	printf ("\n 3:Test isalnum: %c is %s digit or a letter. ", c3, isalpha(c3)? "a" : "not a");
	printf ("\n 4:Test isxdigit: %c is %s hexadecimal digit.", c5, isxdigit(c5)? "a": "not a");
	printf ("\n 5:Test isxdigit: %c is %s hexadecimal digit.", c6, isxdigit(c6)? "a": "not a");
	if (iscntrl(c7)) 
		printf ("\n 6:Test iscntrl: It is a control character.");
	else
		printf ("\n 7:Test iscntrl: It is not a control character.");
	printf ("\n 8:Test ispunct: %c is %s punctuation character.", c8, ispunct(c8)? "a" : "not a");
	return(0);
}

