#include <stdio.h>
#include <ctype.h>

int  main ( void ) {
	char  c='S';
	int   result=0;
	int   i=0;
	char  buf[] = "He is a nice girl. \n";

	putc(c , stdout);

	while (result != EOF && buf[i] != '\0') {
		result = putchar(buf[i]);
		i = i++;
	}
	return(0);
}

