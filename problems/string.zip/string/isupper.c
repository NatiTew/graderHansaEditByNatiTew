#include <stdio.h>
#include <ctype.h>

int  main ( void ) {
	char  c1,c2,c3,c4;
	c1 = 'B'; c2 = 'd';

	printf ("\n Test isupper : ");
	printf ("\n 1: %c is %s uppercase letter. ", c1, isupper(c1)? "an": "not an");
	printf ("\n 2: %c is %s uppercase letter. ", 'f', isupper('f')? "an": "not an");
	printf ("\n Test islower:");
	printf ("\n 3: %c is %s lowercase letter.", c2, islower(c2)? "an": "not an");
	printf ("\n %c converted to lowercase is %c ", '&', tolower('&'));
	printf ("\n Test toupper: ");
	printf ("\n 5: %c converted to uppercase is %c ", c2, toupper(c2));
	printf ("\n Test toupper: ");
	printf ("\n 6: %c converted to uppercase is %c ", '3', toupper('3'));

	return(0);
}

