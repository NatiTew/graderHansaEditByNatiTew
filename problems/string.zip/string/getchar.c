#include <stdio.h>
#include <ctype.h>

int  main ( void ) {
	char  ch;
	char buf[81];
	int  i=0;
	
	while (i < 80) {
		ch = getchar();
		if ((ch == EOF) || (ch == '\n'))
			break;
		buf[i] = (char) ch;
		i++;
	}
	buf[i] = '\0';
	printf ("%s\n",buf);
	return(0);
}

