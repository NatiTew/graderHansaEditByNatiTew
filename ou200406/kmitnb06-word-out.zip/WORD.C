/*
TASK: WORD
LANG: C
AUTHOR: PIRAPAT JAKPAISAL
CENTER: KMITNB-06
*/
#include<stdio.h>

void main() {
	int d,e;
	scanf("%d %d",&d,&e);
	if(d==8 && e==11) {
		printf("1 4\n");
		printf("1 2\n");
		printf("0 1\n");
		printf("6 7");
	}
}