/*
TASK: SKYLINE
LANG: C
AUTHOR: Prayook Jatesiktat
CENTER: mahidol04
*/
#include<stdio.h>
#include<stdlib.h>
void main()
{
  int n,i,sky[256],in[256],l,h,r,last=0,j;
  for(i=0;i<256;i++)
  {
     sky[i]=0;
     in[i]=0;
  }
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
     scanf("%d%d%d",&l,&h,&r);
     for(j=l;j<=r;j++)
     {
	if(h>sky[j])
	  sky[j]=h;
     }
     for(j=l;j<r;j++)
     {
	if(h>in[j])
	  in[j]=h;
     }
  }
  for(i=1;i<256;i++)
  {
     if(i==1)
     {
	printf("1 %d ",sky[i]);
	last=sky[i];
     }
     else
     {
	while(sky[i]==last&&in[i]==last)
	{
	   i++;
	   if(i==256)
	   {
	     exit(1);
	   }
	}
	if(sky[i]>last&&in[i-1]==sky[i])
	  printf("%d %d ",i,sky[i]);
	else if(sky[i]<last&&in[i-1]==sky[i])
	  printf("%d %d ",i-1,sky[i]);
	else
	{
	  printf("%d %d ",i-1,in[i-1]);
	  printf("%d %d ",i,sky[i]);
	}
	last=sky[i];
     }
  }
}