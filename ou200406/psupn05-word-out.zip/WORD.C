/*
TASK: WORD
LANG: C
AUTHOR: Veerakorn Poonsilp
CENTER: PSUPN05
*/
#include<stdio.h>
#include<string.h>
void main(){
 int m,n,i,j,row,col,k,chk,check,l,c,item;
 char table[25][25]={NULL},word[100][15]={NULL};
 scanf("%d%d",&m,&n);
 for(i=0;i<m;i++){
    scanf("%s",&table[i]);
 }
 scanf("%d",&k);
 for(i=0;i<k;i++){
    scanf("%s",&word[i]);
 }
 for(c=0;c<k;c++){
    for(i=0;i<m;i++){
       chk=0;
       l=0;
       for(j=0;j<n;j++){
	  if(word[c][l]==table[i][j]){
	    l++;
	    if(l==1){
	       row=i;
	       col=j;
	    }
	  }else{
	    if(strlen(word[i])==l){
	      chk=1;
	      break;
	    }else{
	      l=0;
	    }
	  }
       }
       if(chk==1){
	 printf("%d %d\n",row,col);
	 break;
       }
    }
    if(chk==1){
      continue;
    }
    for(j=0;j<m;j++){
       chk=0;
       l=0;
       for(i=0;i<n;i++){
	  if(word[c][l]==table[i][j]){
	    l++;
	    if(l==1){
	       row=i;
	       col=j;
	    }
	  }else{
	    if(strlen(word[i])==l){
	      chk=1;
	      break;
	    }else{
	      l=0;
	    }
	  }
       }
       if(chk==1){
	 printf("%d %d\n",row,col);
	 break;
       }
    }
    if(chk==1){
      continue;
    }
    l=0;
    j=0;
    chk=0;
    check=0;
    for(j=0;j<n;j++){
    item=j;
    l=0;
    check=0;
    while(j<n){
       if(word[c][check]==table[l][j]){
	 if(check==0){
	   row=l;
	   col=j;
	 }
	 check++;
       }
       if(strlen(word[c])==check){
	  chk=1;
	  break;
       }
	 l++;
	 j++;
    }
    if(chk==1){
      printf("%d %d\n",row,col);
      break;
    }
    }
    if(chk==1){
      continue;
    }
    chk=0;
    for(l=0;l<n;l++){
    item=j;
    j=0;
    check=0;
    while(j<n){
       if(word[c][check]==table[l][j]){
	 if(check==0){
	   row=l;
	   col=j;
	 }
	 check++;
       }
       if(strlen(word[c])==check){
	  chk=1;
	  break;
       }
	 l++;
	 j++;
    }
    if(chk==1){
      printf("%d %d\n",row,col);
      break;
    }
    }
    if(chk==1){
      continue;
    }
 }
}