/*
TASK: BEE
LANG: C
AUTHOR: NATTHANON THAMSIRARAK
CENTER: TU14
*/
#include<stdio.h>

int bee(int,int,int);
void main()
{
	int input,round=0,arr[100][2];
	while(1)
	{
		scanf("%d",&input);
		if(input==-1)
			break;
		if(input>0)
			arr[round][0] = bee(input-1,0,1);
		else
			arr[round][0] = 1;
		arr[round][1] = bee(input,0,1);
		round++;
	}
	for(input=0;input<round;input++)
		printf("%d %d\n",arr[input][0],arr[input][1]);

}


int bee(int day,int work,int all)
{
	if(day>0)
	{
		return bee(day-1,all,work+all+1);
	}
	return work+all+1;
}