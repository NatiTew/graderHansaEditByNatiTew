/*
TASK: DICE
LANG: C
AUTHOR: Aniwat Kusantear
CENTER: KHONKAEN05
*/
#include<stdio.h>
int dice[6],temp[6];
void inputdice(void)
{
	//input for dice
	dice[0]=1;
	dice[1]=2;
	dice[2]=3;
	dice[3]=5;
	dice[4]=4;
	dice[5]=6;
}
void forF(void)//Forward
{
	int k;
	//copydice
	for(k=0;k<6;k++)
		temp[k]=dice[k];
	dice[0]=temp[3];
	dice[1]=temp[0];
//        dice[2]=temp[2];
	dice[3]=temp[5];
//	dice[4]=temp[4];
	dice[5]=temp[1];
}
void forB(void)//Backward
{
	int k;
	//copydice
	for(k=0;k<6;k++)
		temp[k]=dice[k];
	dice[0]=temp[1];
	dice[1]=temp[5];
//        dice[2]=temp[2];
	dice[3]=temp[0];
//	dice[4]=temp[4];
	dice[5]=temp[3];
}
void forL(void)//Left
{
	int k;
	//copydice
	for(k=0;k<6;k++)
		temp[k]=dice[k];
	dice[0]=temp[4];
//	dice[1]=temp[1];
	dice[2]=temp[0];
//	dice[3]=temp[3];
	dice[4]=temp[5];
	dice[5]=temp[2];
}
void forR(void)//right
{
	int k;
	//copydice
	for(k=0;k<6;k++)
		temp[k]=dice[k];
	dice[0]=temp[2];
//	dice[1]=temp[1];
	dice[2]=temp[5];
//	dice[3]=temp[3];
	dice[4]=temp[0];
	dice[5]=temp[4];
}
void forC(void)//clockwise
{
	int k;
	//copydice
	for(k=0;k<6;k++)
		temp[k]=dice[k];
//	dice[0]=temp[0];
	dice[1]=temp[4];
	dice[2]=temp[1];
	dice[3]=temp[2];
	dice[4]=temp[3];
//	dice[5]=temp[5];
}
void forD(void)//counter clockwise
{
	int k;
	//copydice
	for(k=0;k<6;k++)
		temp[k]=dice[k];
//	dice[0]=temp[0];
	dice[1]=temp[2];
	dice[2]=temp[3];
	dice[3]=temp[4];
	dice[4]=temp[1];
//	dice[5]=temp[5];
}
int main(void)
{
	int num,i,m;
	char ch[6][1001];
	scanf("%d",&num);
	//input string
	for(i=0;i<num;i++){
		rewind(stdin);
		scanf("%[^\n]",ch[i]);
	}
	//round dice
	for(m=1;m<=num;m++){
		inputdice();
		i=-1;
		while(ch[m-1][i+1]!='\0'){
			i++;
			switch(ch[m-1][i]){
				case 'F': forF();break;
				case 'B': forB();break;
				case 'L': forL();break;
				case 'R': forR();break;
				case 'C': forC();break;
				case 'D': forD();break;
				default: break;
			}//endcase
		}//end while round string
		//output
		printf("%d ",dice[1]);
	}//end for round dice
	return 0;
}