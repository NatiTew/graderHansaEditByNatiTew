/*
TASK: SKYLINE
LANG: C
AUTHOR: Sarun Gulyanon
CENTER: tu02
*/

#include<stdio.h>




main()
{
	int n,l,h,r;
	int i,j,temp;
	int max=0;
	int line[300];

	scanf("%d",&n);
	for(i=0;i<299;i++)
	{
		line[i] = 0;
	}
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d",&l,&h,&r);
		if(l>r)
		{
			temp = l;
			l = r;
			r = temp;
		}
		if(max < r)
		{
			max = r;
		}
		for(j=l;j<r;j++)
		{
			if(line[j] < h)
			{
				line[j] = h;
			}
		}
	}
	for(j=0;j<=max;)
	{
		for(;line[j] == line[j+1] && j<= max;j++);
		j++;
		if(j > max)break;
		printf("%d ",j);
		printf("%d ",line[j]);
	}
	return 0;
}