/*
TASK: BEE
LANG: C
AUTHOR:Peerapong Thongpubet
CENTER: WU-02
*/

#include <stdio.h>

void y(int r[]){
	int w=r[1],t=r[0];
	r[1]=w+t+1;
	r[0]=w;
}

void main()
{
	int i,r[2]={0,1},year=3;
	while (year!=-1){
		scanf("%d",&year);
		r[0]=0;
		r[1]=0;
		for(i=0;i<=year;i++)
		y(r);
		printf("%d %d\n",r[1],r[0]+r[1]+1);
	}
}