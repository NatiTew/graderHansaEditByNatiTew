/*
TASK: SEGMENT
LANG: C
AUTHOR: Sarun Gulyanon
CENTER: tu02
*/

#include<stdio.h>

char arr[3][4][50];

long read(int x,int y)
{
	if(arr[x][1][y+2] == '|' && arr[x][2][y+2] == '|')
	{
		if(arr[x][0][y+1] == '_' )
		{
			if(arr[x][1][y] == '|')
			{
				if(arr[x][1][y+1] == '_' )
				{
					if(arr[x][2][y] == '|' )
					{
						return 8;
					}
					else
					{
						return 9;
					}
				}
				else
				{
					return 0;
				}
			}
			else
			{
				if(arr[x][1][y+1] == '_')
				{
					return 3;
				}
				else
				{
					return 7;
				}
			}
		}
		else
		{
			if(arr[x][1][y] == '|' )
			{
				return 4;
			}
			else
			{
				return 1;
			}
		}
	}
	else if(arr[x][2][y+2] == '|')
	{
		if(arr[x][2][y] == '|')
		{
			return 6;
		}
		else
		{
			return 5;
		}
	}
	else if(arr[x][1][y+2] == '|')
	{
		return 2;
	}
return 0;
}

main()
{
	long ans[3];
	int max[2];
	int i,j;
	ans[0] = 0;
	ans[1] = 0;
	scanf("%d",&max[0]);
	scanf("%d",&max[1]);
	gets(arr[0][0]);
	for(i=0;i<2;i++)
	{
		for(j=0;j<3;j++)
		{
			gets(arr[i][j]);
			//scanf("%s",arr[i][j]);
		}
	}

	for(i=0;i<2;i++)
	{
		for(j=0;j<max[i];j++)
		{
			ans[i] += read(i,j*4);
			if(j+1 < max[i])
			{
				ans[i] *=10;
			}
		}
	}
	printf("%ld",ans[0] + ans[1]);
	return 0;
}