/*
TASK: MAXSEQ
LANG:C
AUTHOR: Tawan Sangsue
CENTER: NU04
*/

#include<stdio.h>
#define MAX 2500

int main(void)
{
	int n;
	int num[MAX];
	int count = 0,sum = 0,tmpsum = 0,cntnum = 0,tmpcntnum = 0;
	int tmpmax[MAX];
	int i,j,k,l;

	scanf("%d",&n);

	while(count<n)
	{
		scanf("%d",&num[count]);
		count++;
	}

	for(i=2;i<=n;i++)
	{
		for(j=0;j<=count-i;j++)
		{
			sum = 0;
			for(k=j;k<j+i;k++)
			{
				sum = sum + num[k];
			}
			if(tmpsum<sum)
			{
				tmpsum = sum;
				cntnum = 0;
				for(l=j;l<k;l++)
				{
					tmpmax[cntnum] = num[l];
					cntnum++;
				}
				if(tmpcntnum<cntnum)
				{
					tmpcntnum = cntnum;
				}
			}
		}
	}
	if(tmpsum>0)
	{
		sum = 0;
		for(i=0;i<tmpcntnum;i++)
		{
			printf("%d ",tmpmax[i]);
			sum = sum+tmpmax[i];
		}
		printf("\n%d",sum);

	}
	else
	{
		printf("Empty sequence");
	}
	return(0);

}