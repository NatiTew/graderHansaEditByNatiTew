/*
TASK:DICE.C
LANG:C
AUTHOR:Sorawit Paiboonrattanakorn
CENTER: mahidol05
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
      int i,j,n,len,f,b,l,r,u,d,temp;
      char a[1001];
      scanf("%d",&n);
//      t=(int*)malloc(n*sizeof(int ));
      for(i=0;i<n;i++)
      {
	f=2;
	b=5;
	l=3;
	r=4;
	u=1;
	d=6;
	scanf("%s",a);
	len=strlen(a);
	for(j=0;j<len;j++)
	{
		switch(a[j])
		{
			case 'F':
				temp=f;
				f=u;
				u=b;
				b=d;
				d=temp;
				break;
			case 'L':
				temp=u;
				u=r;
				r=d;
				d=l;
				l=temp;
				break;
			case 'R':
				temp=u;
				u=l;
				l=d;
				d=r;
				r=temp;
				break;
			case 'B':
				temp=f;
				f=d;
				d=b;
				b=u;
				u=temp;
				break;
			case 'C':
				temp=f;
				f=r;
				r=b;
				b=l;
				l=temp;
				break;
			case 'D':
				temp=f;
				f=l;
				l=b;
				b=r;
				r=temp;
				break;
		}
	}
	//t[i]=f;
	printf("%d ",f);
      }
//      for(i=0;i<n;i++)  printf("%d ",t[i]);
      return 0;
}
