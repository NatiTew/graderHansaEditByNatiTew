/*
TASK: SKYLINE
LANG: C
AUTHOR: Peerasak Rattanamanee
CENTER: PSUPN04
*/
#include<stdio.h>
void main()
{
	int count=0,exs[3][3]={0},i,build,bmax=0,max=0,j,k,temp;
	scanf("%d",&build);
	while(build!=count)
	{
		for(i=0;i<3;i++)
		{
			scanf("%d",&exs[count][i]);
		}
		count++;
	}
	k=0;
	for(i=1;i<=count;i++)
		for(j=0;j<count;j++)
		{
			max=(max>exs[j][0])?max:exs[j][0];
			bmax=(bmax>exs[j][2])?bmax:exs[j][2];
			if(exs[j][0]>exs[j+1][0])
			{
				for(k=0;k<3;k++)
				{
					temp=exs[j][k];
					exs[j][k]=exs[j+1][k];
					exs[j+1][k]=temp;
				}
			}
		}
/*
	for(i=0;i<count;i++)
	{
		for(j=0;j<count;j++)
			printf("%d ",exs[i][j]);
		printf("\n");
	}
*/
	for(i=0;i<count;i++)
	{
		for(j=0;j<=max;j++)
		{
			if(exs[i][0]==j)
			{
				printf("%d,%d,",exs[i][0],exs[i][1]);
			}
		}
	}
	/*for(i=0;i<count;i++)
		for(j=0;j<=bmax;j++)
	*/
	printf("%d,0",bmax);
}