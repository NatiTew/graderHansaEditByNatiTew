/*
TASK: BEE
LANG: C
AUTHOR: NAKARA KITTISIRIKUL
CENTER: tu05
*/
#include<stdio.h>
#define queen 1
main()
{
	long arr[25][3],count,in;
	arr[0][0] = 1; arr[0][1] = 0; arr[0][2] = 2;
	for(count = 1; count <= 24;count++)
	{
		arr[count][0] = arr[count-1][2];
		arr[count][1] = arr[count-1][0];
		arr[count][2] = arr[count][0] + arr[count][1] + queen;
	}
	while(1)
	{
		scanf("%ld",&in);
		if(in == -1)
			break;
		printf("%ld %ld\n",arr[in][0],arr[in][2]);
	}
	return 0;
}