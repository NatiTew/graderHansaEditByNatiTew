/*
TASK: MAXSEQ
LANG: C
AUTHOR: Passarit Atiworraman
CENTER: tu10
*/

#include<stdio.h>

#define MAX 2501

long a[MAX];

int main()
{
    long input,x,y,i,j,sum,max=-50;
    scanf("%ld",&input);
    for(x=0;x<input;x++)
	scanf("%ld",&a[x]);
    for(x=0;x<input;x++)
    {
	sum = 0;
	sum += a[x];
	if(sum > max)
	{
	    i = x;
	    j = x;
	    max = sum;
	}
	for(y=x+1;y<input;y++)
	{
	    sum += a[y];
	    if(sum > max)
	    {
		i = x;
		j = y;
		max = sum;
	    }
	}
    }
    if(max < 0)
    {
	printf("Empty sequence");
	return 0;
    }
    for(x=i;x<=j;x++)
	printf("%ld ",a[x]);
    printf("\n%ld",max);
    return 0;
}
