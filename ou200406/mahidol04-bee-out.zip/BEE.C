/*
TASK: BEE
LANG: C
AUTHOR: Prayook Jatesiktat
CENTER: mahidol04
*/
#include<stdio.h>
#include<stdlib.h>
void main()
{
   long y,sol=0,work=1,i,tmp;
   while(1)
   {
     scanf("%ld",&y);
     if(y==-1)
       break;
     sol=0;
     work=1;
     for(i=0;i<y;i++)
     {
	tmp=work;
	work=sol+work+1;
	sol=tmp;
     }
     printf("%ld %ld\n",work,work+sol+1);
   }
}