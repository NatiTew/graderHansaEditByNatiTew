/*
TASK: BEE
LANG: C
AUTHOR: Passakorn Phannachitta
CENTER: BUU03
*/
#include <stdio.h>

int main(void)
{
	long work,mil;
	long tmpwork,tmpmil;
	int  i,j,year = 0;

	scanf("%d",&year);

	while(year != -1) {

		work  = 1;
		mil   = 0;

		for(i=0 ; i<year ; i++) {
			tmpwork = work;
			tmpmil  = mil;

			work += mil+work-tmpwork+1;
			mil  += tmpwork-tmpmil;
		}
		printf("%ld %ld\n",work,work+mil+1);
		scanf("%d",&year);
	}

	return 0;
}