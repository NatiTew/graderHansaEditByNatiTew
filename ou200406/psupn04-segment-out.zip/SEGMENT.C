/*
TASK: SEGMENT
LANG: C
AUTHOR: Peerasak Rattanamanee
CENTER: PSUPN04
*/
#include<stdio.h>
void main()
{
	long fst,scnd;
	int all,i,j,k,count;
	char *str,garbage;
	str=(char *)malloc(300000);
	scanf("%ld%ld%c",&fst,&scnd,&garbage);
	all=((fst+1)*3)*3;
	for(j=0;j<=all;j++)
	{
			scanf("%c",&str[j]);
	}
/*	i=0;
	for(j=0;j<=all;j++)
	{
		table[i][j+k%(i+1)]=str[j];
		if(str[j]=='\t')
			for(k=0;k<8;k++)
				table[i][k]=32;
		if(str[j]=='\n')
			i++;
	}*/
	printf("So Difficult\n");
	printf("T_T");
}