/*
TASK: SEGMENT
LANG: C
AUTHOR: GAIPEACH SUCHARTKULVIT
CENTER: ASSUMPTION COLLEGE SRIRACHA - buu01
*/
#include <stdio.h>
#include <string.h>

char ch[10][15]={" _ | ||_|","     |  |"," _  _||_ "," _  _| _|","   |_|  |",
				 " _ |_  _|"," _ |_ |_|"," _   |  |"," _ |_||_|"," _ |_| _|"};
char in[2][3][60];

int chk(int n,int p)
{
	char check[15];
	int i,j,k;
	for(i=0,k=0;i<3;i++)
	{
		for(j=0+(n*4);j<3+(n*4);j++,k++)
		{
			check[k]=in[p][i][j];
		}
	}
	check[k]='\0';
	for(i=0;i<10;i++)
	{
		if(0==strcmp(check,ch[i]))
			return i;
	}
	return -1;
}
int main(void)
{
	int n1[20]={0},n2[20]={0},re[25]={0};
	int n,m;
	int i,j,count=0;
	char tmp;
	scanf("%d %d",&n,&m);
	for(i=0;i<3;i++)
	{
		scanf("%c",&tmp);
		for(j=0;j<(n*4-1);j++)
		{
			scanf("%c",&in[0][i][j]);
		}
		in[0][i][j]='\0';
	}
	for(i=0;i<3;i++)
	{
		scanf("%c",&tmp);
		for(j=0;j<(m*4-1);j++)
		{
			scanf("%c",&in[1][i][j]);
		}
		in[1][i][j]='\0';
	}
	for(i=0;i<n;i++)
		n1[n-i-1]=chk(i,0);
	for(i=0;i<m;i++)
		n2[m-i-1]=chk(i,1);
	if(m>n)
		n=m;
	for(i=0;i<n;i++)
	{
		re[i]+=(n1[i]+n2[i]);
		if(re[i]/10>0)
		{
			re[i+1]++;
			re[i]%=10;
			if(i==n-1)
				count=1;
		}
	}
	if(count==0)
		i--;
	for(;i>=0;i--)
		printf("%d",re[i]);
	return 0;
}