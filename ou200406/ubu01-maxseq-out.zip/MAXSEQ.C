/*
TASK: MAXSEQ
LANG: C
AUTHOR: RIVINWIT AKKARANGSRI
CENTER: UBON
*/
#include<stdio.h>

long plus(short* a,int i,int j){
	long sum=0;
	while(i<=j){
		sum+=a[i];
		i++;
	}
	return sum;
}
int main(){
	short a[2500];
	long ans=0;
	int start,end;
	long temp;
	int n,i,j;

	//--Input
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	//--process
	for(i=0;i<n;i++){
		for(j=0;j<n+1-i;j++){
			temp=plus(a,j,j+i-1);     //plus from j to j+i-1
			if(temp>ans){
				ans=temp;
				start=j;
				end=j+i-1;
			}
		}
	}
	//--print
	if(ans<=0){printf("Empty sequence");return 0;}
	while(start<=end){
		printf("%d",a[start]);
		if(start!=end)
			printf(" ");
		start++;
	}
	printf("\n");
	printf("%ld\n",ans);
	return 0;

}