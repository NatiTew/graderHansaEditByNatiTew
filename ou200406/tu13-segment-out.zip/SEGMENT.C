/*
TASK: SEGMENT
LANG: C
AUTHOR: Supawan Phuangphairoj
CENTER: tu13
*/

#include<stdio.h>
#include<math.h>

char num[5][5200],z;
long one=0,two=0;

int che(int j)
{
	if(num[0][j+1]==' '&&num[1][j]==' ')
		return 1;
	if(num[1][j]==' '&&num[2][j+2]==' ')
		return 2;
	if(num[1][j]==' '&&num[1][j+1]=='_')
		return 3;
	if(num[2][j+1]==' '&&num[1][j+1]=='_')
		return 4;
	if(num[1][j+2]==' '&&num[2][j]==' ')
		return 5;
	if(num[1][j+2]==' ')
		return 6;
	if(num[2][j+1]==' ')
		return 7;
	if(num[1][j+1]==' ')
		return 0;
	if(num[2][j]==' ')
		return 9;
	else
		return 8;
}
void cha(int i)
{       int p,j,x;
	p = i-1;
	if(z==0)
	{	for(j=0;j<(i*3)+(i-1);j+=4)
		{	x = che(j);
			one += x*pow(10,p);
			p--;}         }
	else
	{	for(j=0;j<(i*3)+(i-1);j+=4)
		{	x = che(j);
			two += x*pow(10,p);
			p--;}         }
	return;
}

void sc(int i)
{       int j;
	for(j=0;j<3;j++)
	{
		gets(num[j]);}
	cha(i);
	return;
}

int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	//z = getchar();
	z = 0;
	sc(n);
 //	z = getchar();
	z=1;
	sc(m);
	printf("%ld",one+two);
	return 0;
}