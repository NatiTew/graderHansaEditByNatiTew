/*
TASK: BEE
LANG: C
AUTHOR: WACHIRA SUPPASATEAN
CENTER: UBU-02
*/
#include <stdio.h>

typedef struct _BEE
{
	long worker;
	long soldier;
}BEE;

void Grow( BEE *bee , int year)
{
	int i;
	long worker, soldier;
	BEE tmp;
	tmp.worker = 1;
	tmp.soldier = 0;

	for( i=0; i<year; i++ )
	{
		worker =  tmp.worker + tmp.soldier + 1;
		soldier = tmp.worker;

		tmp.worker = worker;
		tmp.soldier = soldier;
	}
	bee->soldier =  tmp.soldier;
	bee->worker = tmp.worker;
}

int main( void )
{
	int year[24];
	int nYear = 0;
	int i;
	BEE bee;

	scanf( "%d", &year[nYear] );
	while( year[nYear]!=-1 )
	{
		nYear++;
		scanf( "%d", &year[nYear] );
	}

	for( i=0; i<nYear; i++ )
	{
		Grow( &bee, year[i] );
		printf("%ld %ld\n", bee.worker, bee.worker+bee.soldier+1 );
	}

	return 0;
}