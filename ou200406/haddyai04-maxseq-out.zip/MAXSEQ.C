/*
TASK: MAXSEQ
LANG: C
AUTHOR: Rawipas Ungtrakul
CENTER: haddyai04
*/
#include<stdio.h>

void main()
{
 int num,i,x[2501],front,rear,fmax,rmax;
 long int max,res;

 scanf("%d",&num);
 max=-128;
 for(i=0;i<2501;i++)
 {
  x[i]=0;
 }

 for(i=0;i<num;i++)
 {
  scanf("%d",&x[i]);
 }

 for(front=0;front<num;front++)
 {
  for(rear=0;rear<num;rear++)
  {
   res=0;
   for(i=front;i<=rear;i++)
   {
    res=res+x[i];
   }
   if(res>max)
   {
    max=res;
    fmax=front;
    rmax=rear;
   }
  }
 }

 if(max>0)
 {
  for(i=fmax;i<=rmax;i++)
  {
   printf("%d ",x[i]);
  }
  printf("\n%ld",max);
 }
 else printf("Empty sequence");
}