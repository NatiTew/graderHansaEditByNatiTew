/*
TASK: SKYLINE
LANG: C
AUTHOR: NATCHANON ANGSUTORN
CENTER: MAHIDOL01
*/

#include<stdio.h>

int n;
int data[3000][3];
int max;
int h_tmp=0;

int findmax(int pos){
	int i;
	int maxh=0;

	for(i=0;i<n;i++){
		if(pos>=data[i][0] && pos<data[i][2]){
			if(data[i][1]>maxh){
				maxh=data[i][1];
			}
		}
	}

	return maxh;
}

int main(){
	int i;
	int maxh;

	scanf("%d",&n);

	for(i=0;i<n;i++){
		scanf("%d %d %d",&data[i][0],&data[i][1],&data[i][2]);
		if(data[i][2]>max){
			max=data[i][2];
		}
	}

	//process

	for(i=0;i<max;i++){
		maxh=findmax(i);

		if(maxh!=h_tmp){

			printf("%d %d ",i,maxh);
			h_tmp=maxh;

		}
	}

	printf("%d 0",max);

	return 0;
}