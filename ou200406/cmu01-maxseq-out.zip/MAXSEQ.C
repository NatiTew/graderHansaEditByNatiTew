/*
TASK: MAXSEQ
LANG: C
AUTHOR: Sorawit Boonyathee
CENTER: cmu01
*/

#include <stdio.h>

int main()
{
	int num[2500],count;
	int n,i,j,max,min;
	int hi,hj;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&num[i]);
		if(i==0)	min=num[i];
		else if(num[i]<min)	min=num[i];
	}
	max=min;
	for(i=0;i<n;i++)
	{
		count=0;
		count+=num[i];
		for(j=i+1;j<n;j++)
		{
			count+=num[j];
			if(count>max)
			{
				hi=i;
				hj=j;
				max=count;
			}
		}
	}
	if(max<=0)
	{
		printf("Empty sequence");
	}else
	{
		for(i=hi;i<=hj;i++)
		{
			printf("%d ",num[i]);
		}
		printf("\n%d",max);
	}
	return 0;
}