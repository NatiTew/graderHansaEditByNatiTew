/*
TASK: MAXSEQ
LANG: C
AUTHOR: Lumpsum Tongsinoot
CENTER: psupn03
*/
#include <stdio.h>
#include <stdlib.h>
void main()
{
	int num[2500]={0},n,i,max1=-127,numx[2500]={0},max2,sum,l,z=0,j;
	scanf("%d",&n);
	for (i=0;i<n;i++)
	{
		scanf("%d",&num[i]);
		max1=max(max1,num[i]);
	}
	if(max1<1)
	{
		printf ("Empty sequence");
		exit(0);
	}
	max2=num[0];
	numx[0]=num[0];
	for (l=1;l<=n;l++)
{	for (i=1;i<n-3;i++)
	{
		sum=0;
		if(num>=0)
		{
			for (j=i;j<i+l;j++)
				sum=sum+num[j];
			if(sum>max2)
			{
				max2=sum;
				for (j=0;j<=l;j++)
				{
					numx[j]=num[i+j];
					z=l;
				}
			}
		}
	}
}
	if (max2<1)
	{
		printf ("Empty sequence");
		exit (0);
	}
	for (i=0;i<z;i++)
		printf ("%d ",numx[i]);
	printf ("\n");
	printf ("%d",max2);
}