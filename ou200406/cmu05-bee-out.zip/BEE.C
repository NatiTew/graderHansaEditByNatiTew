/*
TASK: BEE
LANG: C
AUTHOR: Pongsakorn Jaiban
CENTER: CMU05
*/

#include<stdio.h>

int main(void)
{
	long solb,jobb,newsolb,newjobb,i;
	int yr;
	scanf("%d",&yr);
	while(yr!=-1)
	{
	jobb=1;
	solb=0;
	newsolb=0;
	newjobb=0;
		for(i=0;i<yr;i++)
		{
			newjobb=solb;
			newjobb=jobb+newjobb;
			newsolb=jobb;
			newjobb++;
			solb=newsolb;
			newsolb=0;
			jobb=newjobb;
			newjobb=0;
		}
		printf("%ld %ld\n",jobb,solb+jobb+1);
		scanf("%d",&yr);
	}
	return 0;
}