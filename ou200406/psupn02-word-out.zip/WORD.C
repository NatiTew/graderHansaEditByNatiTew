/*
TASK: WORD
LANG: C
AUTHOR: METHA WANGTHAMMANG
CENTER: PSUPN02
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main()
{
int size[2]={0},len,nword,cbk=0,sum=0,i,j,k,ci,po[2]={0};
char  table[30][30]={32};
char *word;
word = malloc(sizeof(char)*30);
scanf("%d %d",&size[0],&size[1]);
for(i=0;i<size[0];i++)
	{
	scanf("%s",table[i]);
	strlwr(table[i]);
	}
scanf("%d",&nword);
//for(i=0;i<size[0];i++)
//	printf("%s\n",table[i]);
for(ci=0;ci<nword;ci++)
	{
	scanf("%s",word);
	strlwr(word);
	len=strlen(word);
	for(i=0;i<size[0];i++)
		{
		for(j=0;j<size[1];j++)
			{
			if(table[i][j]==word[0])
				{
				//start 1 left to right
				for(k=0;k<len;k++)
					{
					if(table[i][j+k]==word[k])
						sum++;
					else
						break;
					}
				if(sum==len)
					{
					po[0]=i;
					po[1]=j;
					cbk=1;
					sum=0;
					break;
					}
				else
					sum=0;
				///end 1left to right

				//start 2 right to left
				for(k=0;k<len;k++)
					{
					if(table[i][j-k]==word[k])
						sum++;
					else
						break;
					}
				if(sum==len)
					{
					po[0]=i;
					po[1]=j;
					cbk=1;
					sum=0;
					break;
					}
				else
					sum=0;
				//end 2 right to left

				//start 3 up to down
				for(k=0;k<len;k++)
					{
					if(table[i+k][j]==word[k])
						sum++;
					else
						break;
					}
				if(sum==len)
					{
					po[0]=i;
					po[1]=j;
					cbk=1;
					sum=0;
					break;
					}
				else
					sum=0;
				//end 3 up to down

				//start 4 down to up
				for(k=0;k<len;k++)
					{
					if(table[i-k][j]==word[k])
						sum++;
					else
						break;
					}
				if(sum==len)
					{
					po[0]=i;
					po[1]=j;
					cbk=1;
					sum=0;
					break;
					}
				else
					sum=0;

				//end 4 down to up

				//start 5 tayang up  left to right
				for(k=0;k<len;k++)
					{
					if(table[i-k][j+k]==word[k])
						sum++;
					else
						break;
					}
				if(sum==len)
					{
					po[0]=i;
					po[1]=j;
					cbk=1;
					sum=0;
					break;
					}
				else
					sum=0;

				//end 5 tayang up left to right


				// start 6 tayang up right to left
				for(k=0;k<len;k++)
					{
					if(table[i-k][j-k]==word[k])
						sum++;
					else
						break;
					}
				if(sum==len)
					{
					po[0]=i;
					po[1]=j;
					cbk=1;
					sum=0;
					break;
					}
				else
					sum=0;
				// end 6 tayang up right to left

				//start 7 tayang down left to right

				for(k=0;k<len;k++)
					{
					if(table[i+k][j+k]==word[k])
						sum++;
					else
						break;
					}
				if(sum==len)
					{
					po[0]=i;
					po[1]=j;
					cbk=1;
					sum=0;
					break;
					}
				else
					sum=0;

				//end 7 tayang down left to right

				// start 8 tayang  down right to left
				for(k=0;k<len;k++)
					{
					if(table[i+k][j-k]==word[k])
						sum++;
					else
						break;
					}
				if(sum==len)
					{
					po[0]=i;
					po[1]=j;
					cbk=1;
					sum=0;
					break;
					}
				else
					sum=0;

				// end 8 tayang  down right to left




				}//end if table[i][j]==word[0]
			if(cbk==1)
				break;
			}//end for j
		if(cbk==1)
			break;
		}//end for i
	cbk=0;
	printf("%d %d\n",po[0],po[1]);
	}//end for ci

}