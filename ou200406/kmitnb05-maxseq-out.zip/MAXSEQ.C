/*
TASK: MAXSEQ
LANG: C
AUTHOR: ISARAPONG JIROJWONG
CENTER: KMITNB05
*/


#include<stdio.h>
#include<stdlib.h>


void set_arr(int input[]);


int main()
{
	int arr[80],max,loop1,loop2,loop3;
	char input[80],tmp[5];

	int max_group=0,first,last,size,tmp_num;

	scanf("%d",&max);
	if(max>2500||max<1)
		return 0;

	set_arr(arr);
	for(loop2=0;loop2<80;loop2++)
		input[loop2]='\0';

	loop2=0;
	flushall();
	gets(input);
	for(loop1=0;loop1<max;loop1++)
	{
		for(loop3=0;tmp[loop3]!='\0';loop3++)
			tmp[loop3]='\0';
			loop3=0;
		for(loop3=0;input[loop2]!=32;loop2++,loop3++)
		{
			tmp[loop3]=input[loop2];
		}
		arr[loop1]=atoi(tmp);
		if(arr[loop1]<-127||arr[loop1]>127)
			return 0;
		loop2+=1;
	}


	for(size=max;size>0;size--)
	{

		for(loop1=0;loop1<max-size+1;loop1++)
		{
			tmp_num=0;
			for(loop2=loop1;loop2<loop1+size;loop2++)
			{
				tmp_num+=arr[loop2];
			}
			if(tmp_num>0&&tmp_num>max_group)
				{
					first=loop1;
					last=loop2;
					max_group=tmp_num;
				}
		}
	}
	tmp_num=0;
	if(max_group>0)
	{
		for(loop1=first;loop1<last;loop1++)
		{
			printf("%d ",arr[loop1]);
			tmp_num+=arr[loop1];
		}
		printf("\n%d",tmp_num);
	}
	else
		printf("Empty sequence");

	return 0;
}


void set_arr(int input[])
{
	int loop;
	for(loop=0;loop<80;loop++)
		input[loop]=0;
}