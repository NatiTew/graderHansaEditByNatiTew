/*
TASK: SKYLINE
LANG: C
AUTHOR: Nuttakorn Benjamasutin (Assumption)
CENTER: tu03
*/

#include <stdio.h>

#define MAX 3001
#define MAXLR 257

int dat[MAX];
int main()
{
	int n;
	int i, j, from, to, h;
	scanf("%d",&n);
	for(i=1; i<=n; i++)
	{
		scanf("%d %d %d",&from,&h,&to);
		for(j=from; j<to; j++)
			if(dat[j] < h) dat[j]=h;
	}
	printf("1 ");
	for(i=2; i<MAXLR; i++)
	{
		if(dat[i] != dat[i-1]) printf("%d %d ", dat[i-1], i);
	}
	printf("0 ");
	return 0;
}