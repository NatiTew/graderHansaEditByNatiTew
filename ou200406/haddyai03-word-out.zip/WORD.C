/*
TASK: WORD
LANG: C
AUTHOR: Poohmai Chaikeaw
CENTER: HADDYAI03
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
int m,n;
char word[26][26];
int chk(char sword[]);
int cul(char sword[],int i,int j,int cur);
void main()
{
int k,i,j;
char sword[16],ch;
scanf("%d %d",&m,&n);
if((n<1)||(n>25)||(m>25)||(m<1))
printf("1 <= m,n <= 25");
else
  {
   for(i=0;i<m;i++)
     {
	scanf("%s",word[i]);

     }
   for(i=0;i<m;i++)
   for(j=0;j<n;j++)
   word[i][j]=tolower(word[i][j]);

   scanf("%d",&k);
   if((k<0)||(k>100)) printf("( 1<= k <=100 )");
   else
   {
    for(i=0;i<k;i++)
     {
     scanf("%s",sword);
     for(j=0;j<strlen(sword);j++)
     sword[j]=tolower(sword[j]);
     chk(sword);
     }
   }
  }
}

int chk(char sword[])
{
int i,j,cur=0,tempi,tempj;
for(i=0;i<m;i++)
  {
  for(j=0;j<n;j++)
   {
      if(word[i][j]==sword[cur])
      {
      tempi=i;
      tempj=j;

      do
	{
	cur++;
	cur=cul(sword,i,++j,cur);
	}while(cur!=0);
      if(j-2==strlen(sword)){ printf("%d %d\n",tempi,tempj); return(1);}
      else { i=tempi; j=tempj;cur=0;}

	    do
	{
	cur++;
	cur=cul(sword,i,--j,cur);
	}while(cur!=0);
      if(j+2==strlen(sword)){ printf("%d %d\n",tempi,tempj); return(1);}
      else { i=tempi; j=tempj;cur=0;}
	    do
	{
	cur++;
	cur=cul(sword,++i,j,cur);
	}while(cur!=0);
      if(i-2==strlen(sword)){ printf("%d %d\n",tempi,tempj); return(1);}
      else { i=tempi; j=tempj;cur=0;}
	    do
	{
	cur++;
	cur=cul(sword,--i,j,cur);
	}while(cur!=0);
      if(i+1==0){ printf("%d %d\n",tempi,tempj); return(1);}
      else { i=tempi; j=tempj;cur=0;}

	    do
	{
	cur++;
	cur=cul(sword,--i,--j,cur);
	}while(cur!=0);
      if(i+1==0){ printf("%d %d\n",tempi,tempj); return(1);}
      else { i=tempi; j=tempj;cur=0;}
	    do
	{
	cur++;
	cur=cul(sword,++i,++j,cur);
	}while(cur!=0);
      if(j-2==strlen(sword)){ printf("%d %d\n",tempi,tempj); return(1);}
      else { i=tempi; j=tempj;cur=0;}
	    do
	{
	cur++;
	cur=cul(sword,--i,++j,cur);
	}while(cur!=0);
      if(i+1==0){ printf("%d %d\n",tempi,tempj); return(1);}
      else { i=tempi; j=tempj;cur=0;}
	    do
	{
	cur++;
	cur=cul(sword,++i,--j,cur);
	}while(cur!=0);
      if(i-1==strlen(sword)){ printf("%d %d\n",tempi,tempj); return(1);}
      else { i=tempi; j=tempj;cur=0;}
      }

   }
  }
}
int cul(char sword[],int i,int j,int cur)
{
      if(word[i][j]==sword[cur])
	{
	return(cur);
	}
      else
	{
	return(0);
	}
}