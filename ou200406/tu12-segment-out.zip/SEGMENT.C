/*
TASK: SEGMENT
LANG: C
AUTHOR: Kraipitch Tassanasaengsoon
CENTER: TU12
*/

# include <stdio.h>
# include <string.h>

# define Max 100

void Modify(unsigned long*,int);

char math[5][Max];
int digit,digit2;

void main()
{
	int c,c2;
	unsigned long a=0,b=0;
	scanf("%d %d",&digit,&digit2);
	for( c=0 ; c < 3 ; ++c )
		for( c2=0 ; c2 < digit*4 ; ++c2 )
			scanf("%c",&math[c][c2]);
	Modify(&a,digit);
	for( c=0 ; c < 3 ; ++c )
		for( c2=0 ; c2 < digit2*4 ; ++c2 )
			scanf("%c",&math[c][c2]);
	Modify(&b,digit2);
	printf("%lu",a+b);
}

void Modify(unsigned long* temp,int end)
{
	int c;
	unsigned long ten;
	for( c=end , ten=1 ; c >= 1 ; --c , ten*=10 )
	{
		if( math[1][c*4-1] == '|' && math[2][c*4-1] == '|' )
		{
			if( math[0][c*4-2] == '_' && math[1][c*4-2] == '_' && math[2][c*4-2] == '_' )
			{
				if( math[1][c*4-3] == '|' && math[2][c*4-3] == '|' )
					*temp+=8*ten;
				else if( math[1][c*4-3] == '|' ) *temp+=9*ten;
				else *temp+=3*ten;
			}
			else if( math[0][c*4-2] == '_' && math[2][c*4-2] == '_' )
				continue;
			else if( math[0][c*4-2] == '_' ) *temp+=7*ten;
			else if( math[1][c*4-2] == '_' ) *temp+=4*ten;
			else *temp+=ten;
		}
		else if( math[1][c*4-1] == '|' ) *temp+=2*ten;
		else if( math[2][c*4-1] == '|' )
		{
			if( math[2][c*4-3] == '|' )	*temp+=6*ten;
			else *temp+=5*ten;
		}
	}
}