/*
TASK: MAXSEQ
LANG: C
AUTHOR: NUTTAWOOT YOTINOOPAMAI
CENTER: KMITNB01
*/
#include<stdio.h>

void main() {
	int n,seq[2500],i,j,k,sum,max=0,start,end;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&seq[i]);
	for(k=0;k<n;k++)
		for(i=k;i<n;i++) {
			for(sum=0,j=k;j<=i;j++)
				sum+=seq[j];
			if(sum>max) {
				max=sum;
				start=k;
				end=i;
			}
		}
	if(max>0) {
		for(i=start;i<=end;i++) {
			printf("%d ",seq[i]);
		}
		printf("\n%d",max);
	} else
		printf("Empty sequence");
}