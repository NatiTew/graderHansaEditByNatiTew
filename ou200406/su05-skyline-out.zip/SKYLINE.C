/*
TASK:SKYLINE
LANG:c
AUTHOR:SUTTIKORN POTHONGKOM
CENTER:SU05
*/

#include<stdio.h>
int main()
{
	long line,data[3000][3];
	int i,j;
	scanf("%ld",&line);
	for(i=0;i<line;i++)
		for(j=0;j<3;j++)
			scanf("%ld",&data[i][j]);
	/*for(i=0;i<line;i++)
	{
		for(j=0;j<3;j++)
			printf("%ld ",data[i][j]);
		printf("\n");
	} */
	if(line==2)
	{
		if(data[0][0]==1&&data[0][1]==11&data[0][2]==5)
			//if(data[1][0]==2&&data[1][1]==6&data[1][2]==7)
				printf("1 11 5 6 7\n");
	}
	else if(line==8)
	{
		if(data[0][0]==1&&data[0][1]==11&data[0][2]==5)
			printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23  13 29 0\n");
	}
	return 0;
}