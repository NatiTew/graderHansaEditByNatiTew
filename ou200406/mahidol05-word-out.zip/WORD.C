/*
TASK:WORD
LANG:C
AUTHOR:Sorawit Paiboonrattanakorn
CENTER:mahidol05
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

int main()
{
	char a[26][26],ch[16];
	int len,m,n,i,j,k,z,boolean,p,q,l;
	//FILE *fp;
	//fp=fopen("in.in","w");
	///freopen("in.in","r",stdin);
	scanf("%d %d",&m,&n);
	//fscanf(fp,"%d %d\n",&m,&n);
	for(i=0;i<m;i++)
	{
		scanf("%s",a[i]);
		for(j=0;j<n;j++)
		{
			//scanf("%c",&a[i][j]);
			a[i][j]=tolower(a[i][j]);
		}
		//a[i][j]='\0';
		//scanf("%c",&ch[0]);
	}
	scanf("%d",&k);
	for(z=0;z<k;z++)
	{
		scanf("%s",ch);
		len=strlen(ch);
		for(j=0;j<len;j++)
		{
			ch[j]=tolower(ch[j]);
		}
		boolean=0;
		for(i=0;i<m&&!boolean;i++)
		{
			for(j=0;j<n&&!boolean;j++)
			{
				boolean=1;
				if(ch[0]==a[i][j])
				{
					p=i;
					q=j;
					for(l=0;l<len&&boolean;l++)
					{
						if(a[p][q+l]!=ch[l]||q+l>=n)
						{
							boolean=0;
						}
					}
					if(boolean)
					{
						printf("%d %d\n",p,q);
						break;
					}
					boolean=1;
					for(l=0;l<len&&boolean;l++)
					{
						if(a[p-l][q]!=ch[l]||p-l<0)
						{
							boolean=0;
						}
					}
					if(boolean)
					{
						printf("%d %d\n",p,q);
						break;
					}
					boolean=1;
					for(l=0;l<len&&boolean;l++)
					{
						if(a[p][q-l]!=ch[l]||q-l<0)
						{
							boolean=0;
						}
					}
					if(boolean)
					{
						printf("%d %d\n",p,q);
						break;
					}
					boolean=1;
					for(l=0;l<len&&boolean;l++)
					{
						if(a[p+l][q]!=ch[l]||p+l>=m)
						{
							boolean=0;
						}
					}
					if(boolean)
					{
						printf("%d %d\n",p,q);
						break;
					}
					boolean=1;
					for(l=0;l<len&&boolean;l++)
					{
						if(a[p+l][q+l]!=ch[l]||q+l>=n&&p+l>=m)
						{
							boolean=0;
						}
					}
					if(boolean)
					{
						printf("%d %d\n",p,q);
						break;
					}
					boolean=1;
					for(l=0;l<len&&boolean;l++)
					{
						if(a[p-l][q-l]!=ch[l]||p-l<0&&q-l<0)
						{
							boolean=0;
						}
					}
					if(boolean)
					{
						printf("%d %d\n",p,q);
						break;
					}
					boolean=1;
					for(l=0;l<len&&boolean;l++)
					{
						if(a[p-l][q+l]!=ch[l]||q+l>=n&&p-l<0)
						{
							boolean=0;
						}
					}
					if(boolean)
					{
						printf("%d %d\n",p,q);
						break;
					}
					boolean=1;
					for(l=0;l<len&&boolean;l++)
					{
						if(a[p+l][q-l]!=ch[l]||q-l<0&&p+l>=m)
						{
							boolean=0;
						}
					}
					if(boolean)
					{
						printf("%d %d\n",p,q);
						break;
					}
				}
				else
				{
					boolean=0;
				}
			}
		}
	}
//	printf("\n");
//	fclose(fp);
	return 0;
}