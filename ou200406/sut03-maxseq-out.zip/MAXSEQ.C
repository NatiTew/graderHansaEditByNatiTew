/*
TASK: MAXSEQ
LANG: C
AUTHOR: Nunwarin Chantarutai
CENTER: sut03
*/

#include<stdio.h>
#include<string.h>

int num[2500],n,track[2500],track2[2500],maxc=0,max=0,sum,tik,count=0,tikk[2500]={0};

void think(int);

int main()
{
  int i;
  scanf("%d",&n);
  for(i=0;i<n;i++)
    scanf("%d",&num[i]);
  for(i=0;i<n;i++)
  {
    sum = num[i];
    tik = i+1;
    track[count] = num[i];
    think(i+1);
  }
  if(max<=0)
   printf("Empty sequence");
   else
   {
  for(i=0;i<=maxc;i++)
   printf("%d ",track2[i]);
  printf("\n%d",max);
  }
  return 0;
}

void think(int nn)
{
 if(nn>=tik&&nn<n&&tikk[nn]!=1)
 {
   sum+=num[nn];
   tikk[nn] = 1;
   count++;
   track[count]=num[nn];
   if(sum>max){max = sum;memcpy(track2,track,sizeof(track));maxc=count;}
   think(nn+1);
   sum-=num[nn];
   track[count]=0;
   tikk[nn] = 0;
   count--;
   think(nn-1);
 }
}