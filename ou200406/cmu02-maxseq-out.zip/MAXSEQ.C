/*
TASK: MAXSEQ
LANG: C
AUTHOR: Songkiet Kunopakarnphan
CENTER: cmu02
*/

#include<stdio.h>

int main()
{
	int a=0,i,j,n,num[2500]={NULL},tod,max=0,m,ans[2500]={NULL},lans;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		if(n-i==1)
		{
			scanf("%d",&num[i]);
		}else scanf("%d ",&num[i]);
	}
	for(i=0;i<n;i++)
	{
		tod=num[i];
		for(j=i+1;j<n;j++)
		{
			tod=tod+num[j];
			if(tod>max)
			{
				a=0;
				lans=0;
				max=tod;
				for(m=i;m<=j;m++)
				{
					ans[a]=num[m];
					a++;
					lans++;
				}
			}
		}
	}
	if(max>0)
	{
		for(i=0;i<lans;i++)
			printf("%d ",ans[i]);
		printf("\n%d",max);
	}else printf("Empty sequence");
	return 0;
}