/*
TASK: DICE
LANG: C
AUTHOR: Nopphorn Pitaksuebpon
CENTER: buu06
*/
#include <stdio.h>
#include <string.h>

int main(void)
{
   int i,n,j,temp[4],on,fr,lf,ba,ri,dow;
   char get[1000];
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
      scanf("%s",get);
      on=1;
      fr=2;
      lf=3;
      ba=5;
      ri=4;
      dow=6;
      for(j=0;j<strlen(get);j++)
      if(get[j]=='F')
      {
	 temp[0]=fr;
	 temp[1]=dow;
	 temp[2]=on;
	 temp[3]=ba;
	 on=temp[3];
	 fr=temp[2];
	 dow=temp[0];
	 ba=temp[1];
      }
      else if(get[j]=='B')
      {
	 temp[0]=fr;
	 temp[1]=dow;
	 temp[2]=on;
	 temp[3]=ba;
	 on=temp[0];
	 fr=temp[1];
	 dow=temp[3];
	 ba=temp[2];
      }
      else if(get[j]=='L')
      {
	 temp[0]=lf;
	 temp[1]=dow;
	 temp[2]=on;
	 temp[3]=ri;
	 on=temp[3];
	 lf=temp[2];
	 dow=temp[0];
	 ri=temp[1];
      }
      else if(get[j]=='R')
      {
	 temp[0]=lf;
	 temp[1]=dow;
	 temp[2]=on;
	 temp[3]=ri;
	 on=temp[0];
	 lf=temp[1];
	 dow=temp[3];
	 ri=temp[2];
      }
      else if(get[j]=='C')
      {
	 temp[0]=lf;
	 temp[1]=fr;
	 temp[2]=ba;
	 temp[3]=ri;
	 fr=temp[3];
	 lf=temp[1];
	 ba=temp[0];
	 ri=temp[2];
      }
      else if(get[j]=='D')
      {
	 temp[0]=lf;
	 temp[1]=fr;
	 temp[2]=ba;
	 temp[3]=ri;
	 fr=temp[0];
	 lf=temp[2];
	 ba=temp[3];
	 ri=temp[1];
      }
      printf("%d ",fr);
   }
   printf("\n");
   return 0;
}