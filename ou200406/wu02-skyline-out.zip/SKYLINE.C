/*
TASK: SKYLINE
LANG: C
AUTHOR: Peerapong Thonpubet
CENTER: WU-02
*/
#include<stdio.h>

void main(){
	int c[258];
	int j,k,i,n,l,r,h,nh,max=0;

	scanf("%d",&n);
	//setskyline
	for(i=0;i<258;i++)
			c[i]=0;

	for(i=0;i<n;i++){
		scanf("%d %d %d",&l,&h,&r);
		for(j=l;j<=r;j++){
			if(h>c[j]) c[j]=h;
		}
	}
	nh=0;
	i=1;
	for(i=1;i<257;i++)
		if(c[i]) max=i;
	i=1;
	while(i<257)
		if(c[i]!=nh){
			if(max+1==i)
				printf("%d %d ",max,c[i]);

			else
				printf("%d %d ",i,c[i]);

			nh=c[i];
			i++;
		}
		else i++;
}