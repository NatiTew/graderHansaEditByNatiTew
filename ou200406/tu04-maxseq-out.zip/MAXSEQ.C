/*
TASK: MAXSEQ
LANG: C
AUTHOR: Saranyu Koothanapath
CENTER: tu04
*/
#include<stdio.h>
int start=0,end=0;
long max=0;
int main()
{
	int n=0;
	int i=0;
	long temp=0;
	int tstart=0;
	int list[2600];
	scanf("%d",&n);
	temp=0;
	for(i=0;i<n;++i)
	{
		scanf("%d",&list[i]);
		if(temp+list[i]>list[i])
		{
			temp+=list[i];
			if(temp>max)
			{
				max=temp;
				start=tstart;
				end=i;
			}
		}
		else
		{
			tstart=i;
			temp=list[i];
			if(temp>max)
			{
				max=temp;
				start=tstart;
				end=i;
			}
		}
	}
	if(max>0)
	{

		for(;start<=end;++start)
		{
			printf("%d ",list[start]);
		}
		printf("\n%ld",max);
	}
	else
	{
		printf("Empty sequence");
	}
	return 0;
}
