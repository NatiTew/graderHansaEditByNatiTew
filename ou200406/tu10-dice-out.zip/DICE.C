/*
TASK: DICE
LANG: C
AUTHOR: Passarit Atiworraman
CENTER: tu10
*/

#include<stdio.h>
#include<string.h>

#define MAX 1025

char str[MAX];
int a[6];

void swap(int *a,int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

int main()
{
    int input,x,y,len;
    scanf("%d",&input);
    for(x=0;x<input;x++)
    {
	a[0] = 1;
	a[1] = 2;
	a[2] = 3;
	a[3] = 5;
	a[4] = 4;
	a[5] = 6;
	scanf("%s",str);
	len = strlen(str);
	for(y=0;y<len;y++)
	{
	    if(str[y] == 'F')
	    {
		swap(&a[0],&a[1]);
		swap(&a[0],&a[5]);
		swap(&a[0],&a[3]);
	    }
	    else if(str[y] == 'B')
	    {
		swap(&a[0],&a[1]);
		swap(&a[1],&a[3]);
		swap(&a[1],&a[5]);
	    }
	    else if(str[y] == 'L')
	    {
		swap(&a[0],&a[4]);
		swap(&a[4],&a[5]);
		swap(&a[2],&a[5]);
	    }
	    else if(str[y] == 'R')
	    {
		swap(&a[0],&a[2]);
		swap(&a[2],&a[4]);
		swap(&a[2],&a[5]);
	    }
	    else if(str[y] == 'C')
	    {
		swap(&a[1],&a[4]);
		swap(&a[2],&a[4]);
		swap(&a[3],&a[4]);
	    }
	    else if(str[y] == 'D')
	    {
		swap(&a[1],&a[2]);
		swap(&a[2],&a[3]);
		swap(&a[3],&a[4]);
	    }
	}
	printf("%d ",a[1]);
    }
    return 0;
}

