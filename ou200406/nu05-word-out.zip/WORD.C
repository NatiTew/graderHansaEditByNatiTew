/*
TASK: WORD
LANG: C
AUTHOR: NATCHAPON ANANTARAMPORN
CENTER: NU05
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main(void)
{
  int m,n,k;
  char word[25][25]={NULL},find[100][15]={NULL};
  int i,j,l,o;
  int chk=0,ch=0,a=0,b=0,ch1=0,c=0,d=0;
  scanf("%d %d",&m,&n);
  for(i=0;i<m;i++){
    scanf("%s",&word[i]);}
  scanf("%d",&k);
  for(i=0;i<k;i++){
    scanf("%s",&find[i]);}

  for(i=0;i<k;i++){
  for(o=0;o<strlen(find[i])-1;o++)
  {
    for(j=0;j<m;j++){
      for(l=0;l<n;l++){
	if(chk==0)
	{
	  if(find[i][o]==word[j][l])
	  {
	    chk++;
	    a=j;
	    b=l;
	    c=j;
	    d=l;
	    if((find[i][o+1]==word[j-1][l-1])&&(ch1!=1))
	      ch=1;
	    else if((find[i][o+1]==word[j-1][l])&&(ch1!=2))
	      ch=2;
	    else if((find[i][o+1]==word[j-1][l+1])&&(ch1!=3))
	      ch=3;
	    else if((find[i][o+1]==word[j][l-1])&&(ch1!=4))
	      ch=4;
	    else if((find[i][o+1]==word[j][l+1])&&(ch1!=5))
	      ch=5;
	    else if((find[i][o+1]==word[j+1][l-1])&&(ch1!=6))
	      ch=6;
	    else if((find[i][o+1]==word[j+1][l])&&(ch1!=7))
	      ch=7;
	    else if((find[i][o+1]==word[j+1][l+1])&&(ch1!=8))
	      ch=8;
	  }
	}
	else
	{
	  if(ch==1)
	  {
	    if(find[i][o]==word[c-1][d-1])
	    {
	      chk++;
	      c--;
	      d--;
	      j=m;
	    }
	    else
	    {
	      chk=0;
	      ch1=1;
	      o=0;
	    }
	  }
	  if(ch==2)
	  {
	    if(find[i][o]==word[c-1][d])
	    {
	      chk++;
	      c--;
	      j=m;
	    }
	    else
	    {
	      chk=0;
	      ch1=2;
	      o=0;
	    }
	  }
	  if(ch==3)
	  {
	    if(find[i][o]==word[c-1][d+1])
	    {
	      chk++;
	      c--;
	      d++;
	      j=m;
	    }
	    else
	    {
	      chk=0;
	      ch1=3;
	      o=0;
	    }
	  }
	  if(ch==4)
	  {
	    if(find[i][o]==word[c][d-1])
	    {
	      chk++;
	      d--;
	      j=m;
	    }
	    else
	    {
	      chk=0;
	      ch1=4;
	      o=0;
	    }
	  }
	  if(ch==5)
	  {
	    if(find[i][o]==word[c-1][d+1])
	    {
	      chk++;
	      d++;
	      j=m;
	    }
	    else
	    {
	      chk=0;
	      ch1=5;
	      o=0;
	    }
	  }
	  if(ch==6)
	  {
	    if(find[i][o]==word[c+1][d-1])
	    {
	      chk++;
	      c++;
	      d--;
	      j=m;
	    }
	    else
	    {
	      chk=0;
	      ch1=6;
	      o=0;
	    }
	  }
	  if(ch==7)
	  {
	    if(find[i][o]==word[c+1][d])
	    {
	      chk++;
	      c++;
	      j=m;
	    }
	    else
	    {
	      chk=0;
	      ch1=7;
	      o=0;
	    }
	  }
	  if(ch==8)
	  {
	    if(find[i][o]==word[c+1][d+1])
	    {
	      chk++;
	      c++;
	      d++;
	      j=m;
	    }
	    else
	    {
	      chk=0;
	      ch1=8;
	      o=0;
	    }
	  }
	}
      }
    }
  }
    printf("%d %d\n",a,b);
    a=0;
    b=0;
    c=0;
    d=0;
    chk=0;
    ch1=0;
  }
  return 0;
}