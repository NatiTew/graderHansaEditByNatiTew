/*
TASK:SEQMENT
LANG:C
AUTHOR:Sorawit Paiboonrattanakorn
CENTER:mahidol05
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
	int a,b,tt[10],ar[3][3],y,z,i,j,k;
	long double r[2];
	char ch[4][81];
//	freopen("s.in","r",stdin);
	r[0]=r[1]=0;
	scanf("%d %d",&a,&b);
	//ch[0][0]=getc(stdin);
	for(i=0;i<3;i++)
	{
		gets(ch[i]);
	}
	k=0;
	for(z=0;z<a*4-1;z=z+4)
	{
		for(i=z;i<z+3;i++)
		{
			for(j=z;j<z+3;j++)
			{
				ar[i-z][j-z]=ch[i][j];
			}
		}
		if(ar[0][1]=='_')
		{
			if(ar[1][0]=='|')
			{
				if(ar[1][2]=='|')
				{
					if(ar[1][1]=='_')
					{
						if(ar[2][0]=='|')
						{
							tt[k]=8;
						}
						else
						{
							tt[k]=9;
						}
					}
					else
					{
						tt[k]=0;
					}
				}
				else
				{
					if(ar[2][0]=='|')
					{
						tt[k]=6;
					}
					else
					{
						tt[k]=5;
					}
				}
			}
			else
			{
				if(ar[2][2]=='|')
				{
					if(ar[1][1]=='_')
					{
						tt[k]=7;
					}
					else
					{
						tt[k]=3;
					}
				}
				else
				{
					tt[k]=2;
				}
			}
		}
		else
		{
			if(ar[1][1]=='_')
			{
				tt[k]=4;
			}
			else
			{
				tt[k]=1;
			}
		}
		k++;
	}
	for(i=0;i<a;i++)
	{
		r[0]=r[0]*10+tt[i];
	}
	//b
	for(i=0;i<3;i++)
	{
		gets(ch[i]);
	}
	k=0;
	for(z=0;z<b*4-1;z=z+4)
	{
		for(i=z;i<z+3;i++)
		{
			for(j=z;j<z+3;j++)
			{
				ar[i-z][j-z]=ch[i][j];
			}
		}
		if(ar[0][1]=='_')
		{
			if(ar[1][0]=='|')
			{
				if(ar[1][2]=='|')
				{
					if(ar[1][1]=='_')
					{
						if(ar[2][0]=='|')
						{
							tt[k]=8;
						}
						else
						{
							tt[k]=9;
						}
					}
					else
					{
						tt[k]=0;
					}
				}
				else
				{
					if(ar[2][0]=='|')
					{
						tt[k]=6;
					}
					else
					{
						tt[k]=5;
					}
				}
			}
			else
			{
				if(ar[2][2]=='|')
				{
					if(ar[1][1]=='_')
					{
						tt[k]=7;
					}
					else
					{
						tt[k]=3;
					}
				}
				else
				{
					tt[k]=2;
				}
			}
		}
		else
		{
			if(ar[1][1]=='_')
			{
				tt[k]=4;
			}
			else
			{
				tt[k]=1;
			}
		}
		k++;
	}
	for(i=0;i<b;i++)
	{
		r[1]=r[1]*10+tt[i];
	}
	printf("%.0Ld",r[0]+r[1]);
	return 0;
}