/*
TASK: BEE
LANG: C
AUTHOR: PIYAWAT MATRAKOOL
CENTER: mahidol06
*/
#include<stdio.h>
int f(int a)
{
 if(a==0||a==1)
  return 1;
 else return f(a-1)+f(a-2);
}
int main()
{
 int n[24],m=1,i,j,k;
 scanf("%d",&n[0]);
 for(k=1;k<24;k++)
  {
   scanf(" %d",&n[k]);
   if(n[k]==-1)
    break;
  }

 for(j=0;j<k;j++)
  {
   m=1;
   for(i=1;i<n[j]+1;i++)
    {
     m=f(i)+m;
    }
   printf("%d %d\n",m,m+f(i));
  }
 return 0;
}