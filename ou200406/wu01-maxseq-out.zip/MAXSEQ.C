/*
TASK: MAXSEQ
LANG: C
AUTHOR: JIRANUN JARATRAKANWONG
CENTER: WU01
*/

#include<stdio.h>
void main()
{
	int n,num[3000],i=0,j=0,sum=0,max=0,lak=0,k,ansn[2000],rlak;
	char *s;
	scanf("%d",&n);
	gets(s); gets(s);

	do{
		if(s[i+1]==' '){
			num[j]=(s[i]-'0');
			i+=2;
		}
		else if(s[i+2]==' '){
			if(s[i]=='-')
				num[j]=-(s[i+1]-'0');
			else
				num[j]=((s[i]-'0')*10)+(s[i+1]-'0');
			i+=3;
		}
		else if(s[i+3]==' '){
			if(s[i]=='-')
				num[j]=-(((s[i+1]-'0')*10)+(s[i+2]-'0'));
			else
				num[j]=100+((s[i+1]-'0')*10)+(s[i+2]-'0');
			i+=4;
		}else if(s[i+4]==' '){
			num[j]=-(100+((s[i+2]-'0')*10)+(s[i+3]-'0'));
			i+=5;
		}
	j++;
	}while(j!=n);
	for(i=0;i<n;i++){
		for(j=i;j<n;j++){
			sum=0;
			lak=0;
			for(k=i;k<j;k++){
				sum+=num[k];
				lak++;
			}
		if(sum>max){
			max=sum;
			for(k=0;k<lak;k++){
				ansn[k]=num[k+i];
				}
			rlak=lak;
			}
		}
	}
	if(max==0) printf("Empty sequence");
	else {
		for(i=0;i<rlak;i++){
			printf("%d ",ansn[i]);
		}
		printf("\n%d",max);
	}
}
