/*
TASK: MAXSEQ
LANG: C
AUTHOR: Kraipitch Tassanasaengsoon
CENTER: TU12
*/

# include <stdio.h>

# define Max 2550

int n,input[Max],ans[Max];

void main()
{
	int c,c2,c3,p;
	long max,sum;
	scanf("%d",&n);
	for( c=1 ; c <= n ; c++ ) scanf("%d",&input[c]);
	for( c=1 , max=0 , sum=0 ; c <= n ; c++ , sum=0 )
		for( c2=c ; c2 <= n ; c2++ )
		{
			sum+=input[c2];
			if( sum > max )
			{
				max=sum;
				for( c3=c , p=0 ; c3 <= c2 ; c3++ ) ans[++p]=input[c3];
			}
		}
	if( max == 0 ) printf("Empty sequence");
	else
	{
		for( c=1 ; c <= p ; c++ ) printf("%d ",ans[c]);
		printf("\n%ld",max);
	}
}
