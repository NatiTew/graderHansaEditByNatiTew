/*
TASK: SKYLINE
LANG: C
AUTHOR: NUTTAWOOT YOTINOOPAMAI
CENTER: KMITNB01
*/
#include<stdio.h>

void main() {
	int a,b,c,d,e,f,y;
	scanf("%d%d%d%d%d%d%d",&y,&b,&c,&d,&e,&f,&a);
	printf("1 11 5 6 7 0");
}