/*
TASK:MAXSEQ
LANG:C
AUTHOR:SUTTIKORN POTHONGKOM
CENTER:SU05
*/
#include<stdio.h>
int main()
{
	int max=-32767,i,sum,n,num[127],empty,x,y,z;
	scanf("%d\n",&n);
	for(i=0;i<n;i++)
		scanf("%d",&num[i]);
	for(i=0;i<n-2;i++)
	{
		sum=num[i]+num[i+1]+num[i+2];
		if(max<sum)
		{
			max=sum;
			x=i;
			y=i+1;
			z=i+2;
		}
	}
	if(max<=0)   printf("Empty sequence\n");
	else	printf("%d %d %d\n%d\n",num[x],num[y],num[z],max);


	return 0;
}