/*
TASK: MAXSEQ
LANG: C
AUTHOR: PIRAPAT JAKPAISAL
CENTER: KMITNB-06
*/
#include<stdio.h>
#include<stdlib.h>
int main() {
	int address,sum,total,max=0,a[2501],i,flag=1;
	scanf("%d",&total);
	if(total>2500 || total<1)
		flag=0;
	for(i=0;i<total;i++) {
		scanf("%d",&a[i]);
		if(a[i]>127 || a[i]<(-127))
			flag=0;
	}
	for(i=0;i<total-2;i++) {
		sum=a[i]+a[i+1]+a[i+2];
		if(sum>max) {
			max=sum;
			address=i;
		}
	}
	if(max>0 && flag) {
		printf("%d %d %d",a[address],a[address+1],a[address+2]);
		printf("\n");
		printf("%d",max);
	} else if(flag)
		printf("Empty sequence");
	return 0;
}