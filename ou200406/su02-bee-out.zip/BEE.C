/*
TASK: BEE
LANG: C
AUTHOR: Thitipong Sansanayuth
CENTER: SU02
*/
#include<stdio.h>
int main()
{
	long y[25],i=0,c=0,beew=1,bees=0,qu=1,sum[25];
	int n[24];
	do
	{
		scanf("%ld",&n[c]);
		c++;
	}while(n[c-1]!=-1);
	sum[0]=2;
	y[0]=1;
	for(i=0;i<24;i++)
	{
		bees=beew;
		beew=sum[i];
		sum[i+1]=beew+bees+qu;
		y[i+1]=beew;
	}
	for(i=0;i<c-1;i++)
	{
		if(n[i]!=-1) printf("%ld %ld\n",y[n[i]],sum[n[i]]);
	}
	return 0;
}