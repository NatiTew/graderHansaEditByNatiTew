/*
TASK : WORD
LANG: C
AUTHOR: Lumpsum Tongsinoot
CEHTER: psupn03
*/
#include <stdio.h>
#include <string.h>
void main ()
{
	char str[25][25],sh[100][25],s[25];
	int n1,n2,n3,i,j,c,l,ch,z;
	scanf ("%d",&n1);
	scanf ("%d",&n2);
	for (i=0;i<n1;i++)
	{
		scanf ("%s",s);
		strcpy(str[i],strlwr(s));
	}
	scanf ("%d",&n3);
	for (i=0;i<n3;i++)
	{
		scanf ("%s",s);
		strcpy(sh[i],strlwr(s));
	}
	for (z=0;z<n3;z++)
	for (i=0;i<n1;i++)
		for (j=0;j<n2;j++)
		{
			if (sh[z][0]==str[i][j])
			{
				c=0;
				ch=n2;
				for (l=0;l<ch;l++)
				{
					if (sh[z][l]==str[i][j+l])
						c++;
					else
					     {	c=0;
						break;   }
				}
				if (c==strlen(sh[z]))
				{
					printf ("%d %d\n",i,j);
					ch=0;
					c=0;
					i=j=1000;					i=j=1000;
				}
				for (l=0;l<ch;l++)
				{
					if (sh[z][l]==str[i][j-l])
						c++;
					else
					{	c=0;
						break;}
				}
				if (c==strlen(sh[z]))
				{
					printf ("%d %d\n",i,j);
					ch=0;
					c=0;

					i=j=1000;
				}
				for (l=0;l<ch;l++)
				{
					if (sh[z][l]==str[i+l][j])
						c++;
					else
					{	c=0;
						break; }
				}
				if (c==strlen(sh[z]))
				{
					printf ("%d %d\n",i,j);
					ch=0;
					c=0;

					i=j=1000;
				}
				for (l=0;l<ch;l++)
				{
					if (sh[z][l]==str[i-l][j])
						c++;
					else
					{	c=0;
						break;  }
				}
				if (c==strlen(sh[z]))
				{
					printf ("%d %d\n",i,j);
					ch=0;
					c=0;

					i=j=1000;
				}
				for (l=0;l<ch;l++)
				{
					if (sh[z][l]==str[i+l][j+l])
						c++;
					else
					{ c=0;
						break;      }
				}
				if (c==strlen(sh[z]))
				{
					printf ("%d %d\n",i,j);
					ch=0;
					c=0;

					i=j=1000;
				}
				for (l=0;l<ch;l++)
				{
					if (sh[z][l]==str[i-l][j-l])
						c++;
					else
					{	c=0;
						break;    }
				}
				if (c==strlen(sh[z]))
				{
					printf ("%d %d\n",i,j);
					ch=0;
					c=0;

					i=j=1000;
				}
				for (l=0;l<ch;l++)
				{
					if (sh[z][l]==str[i-l][j+l])
						c++;
					else
					{	c=0;
						break;  }
				}
				if (c==strlen(sh[z]))
				{
					printf ("%d %d\n",i,j);
					ch=0;
					c=0;

					i=j=1000;
				}
				for (l=0;l<ch;l++)
				{
					if (sh[z][l]==str[i+l][j-l])
						c++;
					else
					{	c=0;
						break;  }
				}
				if (c==strlen(sh[z]))
				{
					printf ("%d %d\n",i,j);
					ch=0;
					c=0;

					i=j=1000;
				}
			}
		}
}