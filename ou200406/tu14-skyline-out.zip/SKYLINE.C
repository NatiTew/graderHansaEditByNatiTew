/*
TASK: SKYLINE
LANG: C
AUTHOR: NATTHANON THAMSIRARAK
CENTER: TU14
*/
#include<stdio.h>

void main()
{
	int input,start,high,end,loop,loop2,arr[256],keep;
	for(loop=0;loop<256;loop++)
	{
		arr[loop]=0;
	}
	scanf("%d",&input);
	for(loop=0;loop<input;loop++)
	{
		scanf("%d%d%d",&start,&high,&end);
		for(loop2=start;loop2<=end;loop2++)
		{
			if(high > arr[loop2])
			{
				arr[loop2]=high;
			}
		}
	}
	keep=0;
	for(loop=0;loop<20;loop++)
	{
		if(keep != arr[loop])
		{
			keep=arr[loop];
			if(keep < arr[loop])
			printf("%d %d ",loop,arr[loop]);
			else
			printf("%d %d ",arr[loop-1],loop-1);
		}
	}
}