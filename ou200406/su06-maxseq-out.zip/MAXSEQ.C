/*
TASK: MAXSEQ
LANG: C
AUTHOR: Pongdanai Chayarun
CENTER: SU
*/
#include<stdio.h>
int num[2500]={0},ans[2500]={0};
int main()
{ int size,i,j,sum=0,max=-2000,k,f;
 scanf("%d",&size);
 for(i=0;i<size;i++)scanf("%d",&num[i]);
 for(i=0;i<size;i++)
 {  for(j=i;j<size;j++)
    { sum+=num[j];
      if(sum>max)
      { max=sum;
	 for(k=i;k<=j;k++)ans[k-i]=num[k];
	 k=k-i-1;
	 while(ans[k++]!=0)ans[k]=0;
      }
    }
    sum=0;
 }
 i=0;
 if(max>0)
 {while(ans[i]!=0){printf("%d ",ans[i]);i++;}
  printf("\n%d",max);
  }
  else printf("Empty sequence");
return 0;
 }
