/*
TASK: SEGMENT
LANG: C
AUTHOR: NATCHANON ANGSUTORN
CENTER: MAHIDOL01
*/

#include<stdio.h>

int n[2];
char m[3][40];
char n1[3][3]={"   ","  |","  |"};
char n2[3][3]={" _ "," _|","|_ "};
char n3[3][3]={" _ "," _|"," _|"};
char n4[3][3]={"   ","|_|","  |"};
char n5[3][3]={" _ ","|_ "," _|"};
char n6[3][3]={" _ ","|_ ","|_|"};
char n7[3][3]={" _ ","  |","  |"};
char n8[3][3]={" _ ","|_|","|_|"};
char n9[3][3]={" _ ","|_|"," _|"};
char n0[3][3]={" _ ","| |","|_|"};
double number[2]={0,0};

int makem(){
	int i,j;

	for(i=0;i<3;i++){
		for(j=0;j<40;j++){
			m[i][j]=' ';
		}
	}

	return 0;
}

double powz(int a,int b){
	int i;
	int sum=1;

	for(i=0;i<b;i++){
		sum*=a;
	}

	return sum;
}

int pp(int k){
	int i,j,l,p;

	for(l=0;l<n[k];l++){
		for(p=0;p<10;p++){
			for(i=0;i<3;i++){
				for(j=0;j<3;j++){
					if(p==0){
						if(n0[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(0* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}
					}
					else if(p==1){
						if(n1[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(1* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
					else if(p==2){
						if(n2[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(2* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
					else if(p==3){
						if(n3[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(3* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
					else if(p==4){
						if(n4[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(4* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
					else if(p==5){
						if(n5[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(5* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
					else if(p==6){
						if(n6[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(6* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
					else if(p==7){
						if(n7[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(7* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
					else if(p==8){
						if(n8[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(8* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
					else if(p==9){
						if(n9[i][j]==m[i][(4*l)+j]){
							if(i==2 && j==2){
								number[k]+=(9* powz(10 , (n[k]-l)-1 ) );
								p=9;
							}
						}
						else{
							i=2;
							j=2;
						}

					}
				}
			}
		}
	}
	return 0;
}

int main(){
	int i,j,k;
	char ch;

	scanf("%d %d",&n[0],&n[1]);

	for(k=0;k<2;k++){
		makem();

		for(i=0;i<3;i++){
			for(j=0;j< (3*n[k])+(n[k]-1) ;j++){
				scanf("%c",&ch);

				if(ch!='\n'){
					m[i][j]=ch;
				}
				else{
					j--;
				}
			}
		}

		pp(k);

	}

	printf("%.0lf",number[0]+number[1]);

	return 0;
}