/*
TASK: DICE
LANG: C
AUTHOR: Theerapat Chawannakul
CENTER: SU - su04
*/

#include<stdio.h>

struct dic{
	char face[2];
	int num;

}dice[6];

int main(){
	char str[6][1001];
	int i,j,k;
	int nd;

	scanf("%d",&nd);
	for(i=0;i<nd;i++) scanf("%s",str[i]);
	for(j=0;j<nd;j++){


		dice[0].face[0]='T';
		dice[0].num=1;
		dice[1].face[0]='F';
		dice[1].num=2;
		dice[2].face[0]='L';
		dice[2].num=3;
		dice[3].face[0]='B';
		dice[3].num=5;
		dice[4].face[0]='R';
		dice[4].num=4;
		dice[5].face[0]='D';
		dice[5].num=6;

		for(k=0;str[j][k]!='\0';k++){
			for(i=0;i<6;i++){
				if(str[j][k]=='F'){

					switch(dice[i].face[0]){
						case 'B' : dice[i].face[0]='T';
							   break;
						case 'D' : dice[i].face[0]='B';
							   break;
						case 'T' : dice[i].face[0]='F';
							   break;
						case 'F' : dice[i].face[0]='D';
							   break;
						default  : break;
					}

				}
				else if(str[j][k]=='B'){
					for(i=0;i<6;i++){
						switch(dice[i].face[0]){
							case 'T' : dice[i].face[0]='B';
								   break;
							case 'B' : dice[i].face[0]='D';
								   break;
							case 'F' : dice[i].face[0]='T';
								   break;
							case 'D' : dice[i].face[0]='F';
								   break;
							default  : break;
						}
					}


				}
				else if(str[j][k]=='R'){
					for(i=0;i<6;i++){
						switch(dice[i].face[0]){
							case 'L' : dice[i].face[0]='D';
								   break;
							case 'D' : dice[i].face[0]='R';
								   break;
							case 'R' : dice[i].face[0]='T';
								   break;
							case 'T' : dice[i].face[0]='L';
								   break;
							default  : break;
						}
					}

				}
				else if(str[j][k]=='L'){
					for(i=0;i<6;i++){
						switch(dice[i].face[0]){
							case 'L' : dice[i].face[0]='T';
								   break;
							case 'T' : dice[i].face[0]='R';
								   break;
							case 'R' : dice[i].face[0]='D';
								   break;
							case 'D' : dice[i].face[0]='L';
								   break;
							default  : break;
						}
					}
				}
				else if(str[j][k]=='D'){
					for(i=0;i<6;i++){
						switch(dice[i].face[0]){
							case 'F' : dice[i].face[0]='R';
								   break;
							case 'L' : dice[i].face[0]='F';
								   break;
							case 'B' : dice[i].face[0]='L';
								   break;
							case 'R' : dice[i].face[0]='B';
								   break;
							default  : break;
						}
					}
				}
				else if(str[j][k]=='C'){
					for(i=0;i<6;i++){
						switch(dice[i].face[0]){
							case 'F' : dice[i].face[0]='L';
								   break;
							case 'L' : dice[i].face[0]='B';
								   break;
							case 'B' : dice[i].face[0]='R';
								   break;
							case 'R' : dice[i].face[0]='F';
								   break;
							default  : break;
						}
					}
				}
			}
		}
		for(i=0;i<6;i++){
			if(dice[i].face[0]=='F'){
				printf("%d",dice[i].num);
				if(j!=nd-1)printf(" ");
			}
		}
	}


	return 0;
}

