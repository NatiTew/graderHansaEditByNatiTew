/*
TASK: SKYLINE
LANG: C
AUTHOR: NAKARA KITTISIRIKUL
CENTER: tu05
*/
#include<stdio.h>
#define max 300
main()
{
	int skyline[max],count,n,tl,th,tr,count2,sPos = 0,ePos = 0;
	for(count = 0; count <= max; count++)
		skyline[count] = 0;

	scanf("%d",&n);

	for(count = 0; count < n; count++)
	{
		scanf("%d%d%d",&tl,&th,&tr);
		if(count == 0)
		{
			sPos = tl;
			ePos = tr;
		}
		else
		{
			if(tl < sPos)
				sPos = tl;
			if(tr > ePos)
				ePos = tr;
		}
		for(count2 = tl; count2 < tr; count2++)
			if(skyline[count2] < th)
				skyline[count2] = th;
	}

	th = 0;
	for(count = sPos; count <= ePos; count++)
	{
		if(skyline[count] != th)
		{
			printf("%d %d ",count,skyline[count]);
			th = skyline[count];
		}
	}
	return 0;
}