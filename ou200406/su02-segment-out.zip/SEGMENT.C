/*
TASK: SEGMENT
LANG: C
AUTHOR: Thitipong Sansanayuth
CENTER: SU02
*/
#include<stdio.h>
int main()
{
	char num[9][3][3];
	scanf()
}