/*
TASK: SEGMENT
LANG: C
AUTHOR: Sirawit Phutrakul
CENTER: BUU
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int chkseg(int mark[3][3]) {
	int num;
	switch(mark[0][1]) {
		case 1: switch(mark[1][0]) {
					case 1: switch(mark[1][1]) {
								case 1: switch(mark[2][0]) {
											case 1: /*6 || 8*/
													switch(mark[1][2]) {
														case 1: num = 8; break;
														case 0: num = 6; break;
													}
													break;
											case 0: /*5 || 9*/
													switch(mark[1][2]) {
														case 1: num = 9; break;
														case 0: num = 5; break;
													}
													break;
										}
										break;
								case 0: num = 0; break;
							}
							break;
					case 0: switch(mark[2][0]) {
								case 1: num = 2; break;
								case 0: switch(mark[1][1]) {
											case 1: num = 3; break;
											case 0: num = 7; break;
										}
										break;
							}
							break;
				}
				break;
		case 0: switch(mark[1][0]) {
					case 1: num = 4; break;
					case 0: num = 1; break;
				}
				break;
	}
	return num;
}
int plus(int *unit ,char **seg[] ,unsigned long *sum) {
	unsigned long num[2];
	float tmp;
	int i ,j ,k ,l ,m   ,x ,y ,chk;
	int mark[3][3];
	for(i=0;i<2;i++) {
		num[i] = 0;
		for(j=0;j<unit[i];j++) {
			for(k=0;k<3;k++) {
				y = k;
				for(l=0,m=j*4;l<3;l++,m++) {
					x = l;
					switch(seg[i][k][m]) {
						case '|':
						case '_': mark[y][x] = 1; break;
						case ' ': mark[y][x] = 0; break;
					}
				}
			}
			num[i] *= 10;
			num[i] += chkseg(mark);
		}
	}
	tmp = num[0] + num[1];
	if(tmp > (pow(2,32)-1))
		chk = 0;
	else {
		chk = 1;
		*sum = tmp;
	}
	return chk;
}
int main(void) {
	int unit[2] ,i ,j ,chk;
	char **seg[2];
	unsigned long sum;
	scanf("%d %d",&unit[0],&unit[1]);
	for(i=0;i<2;i++) {
		seg[i] = (char **)malloc(sizeof(char *)*3);
		for(j=0;j<3;j++) {
			seg[i][j] = (char *)malloc(sizeof(char)*(unit[i]*4));
			flushall();
			gets(seg[i][j]);
		}
	}
	chk = plus(unit,seg ,&sum);
	if(chk)
		printf("%ld\n",sum);
	for(i=0;i<2;i++) {
		for(j=0;j<3;j++) {
			free(seg[i][j]);
		}
		free(seg[i]);
	}
	return 0;
}
