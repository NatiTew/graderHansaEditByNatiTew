/*
TASK: MAXSEQ
LANG: C
AUTHOR: Taksapaun Kittiakrastien
CENTER: tu08
*/

#include<stdio.h>

int main()
{
  int n;
  char arr[2502];
  long maxsofar=0;
  long maxendinghere=0;
  int maxa=-1; //start and end of maxsofar
  int maxb=-1;
  int maxc=-1; //start and end of maxendinghere
  int maxd=-1;
  int i;

  scanf("%d", &n);
  for(i=0;i<n;i++)
  {
    scanf("%d", &arr[i]);
    if(maxendinghere+arr[i] > 0)
    {
      maxendinghere += arr[i];
      if(maxc == -1)
	maxc = i;
      maxd = i;
    }
    else
    {
      maxendinghere = 0;
      maxc = -1;
      maxd = -1;
    }

    if(maxsofar < maxendinghere)
    {
      maxa = maxc;
      maxb = maxd;
      maxsofar = maxendinghere;
    }

  }

  if(maxa == -1)
    printf("Empty sequence");
  else
  {
    for(i=maxa;i<=maxb;i++)
      printf("%d ", arr[i]);
    printf("\n%ld", maxsofar);
  }

  return 0;
}
