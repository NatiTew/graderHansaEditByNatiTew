/*
TASK: MAXSEQ
LANG: C
AUTHOR: NATCHANON ANGSUTORN
CENTER: MAHIDOL01
*/

#include<stdio.h>

int main(){
	int i,j;
	int n;
	int data[2500];

	long sum;
	long summax=-2147483648;
	int pos[2]={0,0};

	scanf("%d",&n);

	for(i=0;i<n;i++){
		scanf("%d",&data[i]);
	}

	for(i=0;i<n;i++){
		sum=0;
		for(j=i;j<n;j++){
			sum+=data[j];
			if(sum>summax){
				summax=sum;
				pos[0]=i;
				pos[1]=j;
			}
		}
	}

	if(summax>0){
		for(i=pos[0];i<pos[1]+1;i++){
			printf("%d ",data[i]);
		}

		printf("\n%d",summax);
	}
	else{
		printf("Empty sequence");
	}

	return 0;

}