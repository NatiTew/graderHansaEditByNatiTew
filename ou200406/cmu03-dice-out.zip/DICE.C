/*
TASK: DICE
LANG: C
AUTHOR: Worakan Jeeprabnan
CENTER: CMU03
*/
#include<stdio.h>
#include<string.h>
int t,f,l,b,r,u;
void dreset();
void fli(char);
int main()
{
  int n,i,j,len=0;
  char op;
  char str[1010];
  dreset();
  scanf("%d",&n);

  for(i=0;i<n;i++)
  {
    scanf("%s",str);
    len=strlen(str);
    for(j=0;j<len;j++)
    {
      op=str[j];
      fli(op);
    }
    printf("%d ",f);
    dreset();
  }
  return 0;
}
void fli(char op)
{
  int tmp;
  if(op=='F')
  {
    tmp=f;
    f=t;
    t=b;
    b=u;
    u=tmp;
  }
  else if(op=='B')
  {
    tmp=f;
    f=u;
    u=b;
    b=t;
    t=tmp;
  }
  else if(op=='L')
  {
    tmp=t;
    t=r;
    r=u;
    u=l;
    l=tmp;
  }
  else if(op=='R')
  {
    tmp=t;
    t=l;
    l=u;
    u=r;
    r=tmp;
  }
  else if(op=='C')
  {
    tmp=f;
    f=r;
    r=b;
    b=l;
    l=tmp;
  }
  else if(op=='D')
  {
    tmp=f;
    f=l;
    l=b;
    b=r;
    r=tmp;
  }
}
void dreset()
{
 t=1;
 f=2;
 l=3;
 b=5;
 r=4;
 u=6;
}