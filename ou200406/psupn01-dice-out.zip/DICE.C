/*
TASK: DICE
LANG: C
AUTHOR: NUTTAWUT MANEEKASORN
CENTER: PSUPN-01
*/

#include <string.h>
#include <stdio.h>

int dt(char ch){
  switch(ch){
    case 'F': return 0;
    case 'B': return 1;
    case 'L': return 2;
    case 'R': return 3;
    case 'C': return 4;
    case 'D': return 5;
  }
}

int main(){
  char strdirec[6][1024];
  int temp[6]={0};
  int dirconfig[6][6]= {{3,0,2,5,4,1},
			{1,5,2,0,4,3},
			{4,1,0,3,5,2},
			{2,1,5,3,0,4},
			{0,4,1,2,3,5},
			{0,2,3,4,1,5}};
  int curdice[6];
  int i,pos,j,len,cntdice,k;

  scanf("%d",&cntdice);
  for(k=0;k<cntdice;k++){
      scanf("%s",strdirec[k]);
  }


  for(k=0;k<cntdice;k++){

	curdice[0] = 1;
	curdice[1] = 2;
	curdice[2] = 3;
	curdice[3] = 5;
	curdice[4] = 4;
	curdice[5] = 6;

	len =strlen(strdirec[k]);
	for(j=0;j<len;j++){
	    for(i=0;i<6;i++){
		temp[i] = curdice[i];
	    }
	    for(i=0;i<6;i++){
		pos = dirconfig[dt(strdirec[k][j])][i];
		curdice[i] =  temp[pos];
	    }
	}
	printf("%d ",curdice[1]);
  }
  return 0;
}