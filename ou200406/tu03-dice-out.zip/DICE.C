/*
TASK: DICE
LANG: C
AUTHOR: Nuttakorn Benjamasutin
CENTER: tu03
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLEN 2001
#define MAX 6

const char txtDirect[]="FBLRCD";
const long firstDice[MAX*MAX]= { 1, 2, 3, 5, 4, 6 };
const long is[MAX*MAX][MAX*MAX]=
			{
				{ 4, 1, 3, 6, 5, 2 }, //Front
				{ 2, 6, 3, 1, 5, 4 }, //Back
				{ 5, 2, 1, 4, 6, 3 }, //Left
				{ 3, 2, 6, 4, 1, 5 }, //Right
				{ 1, 5, 2, 3, 4, 6 }, //Clockwise
				{ 1, 3, 4, 5, 2, 6 } //Counter Clockwise
			};

long dice[MAX*MAX];

void Init();
long Where(char, long);

int main()
{
	long n, i, j, len, temp[MAX*MAX];
	char input[MAXLEN];
	scanf("%ld",&n);
	for(; n>=1; n--)
	{
		Init();
		scanf("%s", input);
		len=strlen(input);
		for(i=0; i<len; i++)
		{
			for(j=0; j<MAX; j++)
				temp[j]=dice[ Where(input[i], j) - 1];

			for(j=0; j<MAX; j++)
				dice[j]=temp[j];
		}
		printf("%ld ", dice[1]);
	}
	return 0;
}
void Init()
{
	long i;
	for(i=0; i<MAX; i++)
		dice[i]=firstDice[i];
}
long Where(char c, long pos)
{
	long i, temp;
	for(i=0; i<MAX; i++)
		if(c == txtDirect[i])
		{
			temp=i;
			break;
		}
	return is[temp][pos];
}
