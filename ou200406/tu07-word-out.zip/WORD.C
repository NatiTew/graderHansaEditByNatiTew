/*
TASK: WORD
LANG: C
AUTHOR: KAWIN ASVAPATIPATT
CENTER: TU07
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>

char table[30][30],word[20] ;
int ans[20][2],length ;

int check (int i,int j,int now,int done)
{
if (length == now) return 1 ;
if (table[i-1][j-1] == word[now] && (done == 1 || done == 0))
	{ if (check(i-1,j-1,now+1,1) == 1) return 1 ; }
if (table[i-1][j] == word[now] && (done == 2 || done == 0))
	{ if (check(i-1,j,now+1,2) == 1) return 1 ; }
if (table[i-1][j+1] == word[now] && (done == 3 || done == 0))
	{ if (check(i-1,j+1,now+1,3) == 1) return 1 ; }
if (table[i][j-1] == word[now] && (done == 4 || done == 0))
	{ if (check(i,j-1,now+1,4) == 1) return 1 ; }
if (table[i][j+1] == word[now] && (done == 5 || done == 0))
	{ if (check(i,j+1,now+1,5) == 1) return 1 ; }
if (table[i+1][j-1] == word[now] && (done == 6 || done == 0))
	{ if (check(i+1,j-1,now+1,6) == 1) return 1 ; }
if (table[i+1][j] == word[now] && (done == 7 || done == 0))
	{ if (check(i+1,j,now+1,7) == 1) return 1 ; }
if (table[i+1][j+1] == word[now] && (done == 8 || done == 0))
	{ if (check(i+1,j+1,now+1,8) == 1) return 1 ; }
return 0 ;
}

int main ()
{
int i,j,l,m,n,k,now ;
scanf ("%d %d",&m,&n) ; //Number of data to input
for (i=0;i<m;i++) scanf ("%s",table[i]) ; //Input data into table
for (i=0;i<m;i++)
	{
	for (j=0;j<n;j++)	table[i][j] = tolower(table[i][j]) ;
	}
scanf ("%d",&k) ; // Number of word to seek
for (l=0;l<k;l++)
	{
	scanf ("%s",word) ;
	now = 0 ;
	length = strlen(word) ;
	for (j=0;j<length;j++) word[j] = tolower(word[j]) ;
	for (i=0;i<m;i++)
		{
		for (j=0;j<n;j++)
			{
			if (table[i][j] == word[now])
				{
				ans[l][0] = i ;
				ans[l][1] = j ;
				now++ ;
				if (check(i,j,now,0) == 1)
					{
					i = m ;
					j = n ;
					}
				else now = 0 ;
				}
			}
		}
	}
for (l=0;l<k;l++) printf ("%d %d\n",ans[l][0],ans[l][1]) ;
return 0 ;
}