/*
TASK: WORD
LANG: C
AUTHOR: Passakorn Phannachitta
CENTER: BUU03
*/
#include <stdio.h>
#include <string.h>

int mrow,mcol;

char field[26][26];

void input()
{
	char tmp[26];
	int i;

	scanf("%d%d\n",&mrow,&mcol);

	for(i=0 ; i<mrow ; i++) {
		scanf("%s",field[i]);
		strlwr(field[i]);
	}
/*
	for(i=0 ; i<mrow ; i++) {
		printf("%s\n",field[i]);
	}
*/
}

int sub(char inp[16],int sti,int stj)
{
	int i,j,k,len = strlen(inp),cnt;

	//srh ->
	if(mcol - stj  >= len) {
		cnt = 0;
		k   = 0;
		for(j = stj ; j<stj+len ; j++) {
			if(field[sti][j] == inp[k]) {
				cnt++;
				k++;
			}
			else break;
		}
		if(cnt == len) return 1;
	}

	//srh <-
	if(stj-len+1  >= 0) {
		cnt = 0;
		k   = 0;
		for(j = stj ; j>=stj-len+1 ; j--) {
			if(field[sti][j] == inp[k]) {
				cnt++;
				k++;
			}
			else break;
		}
		if(cnt == len) return 1;
	}

	//srh v

	if(mrow - sti  >= len) {
		cnt = 0;
		k   = 0;
		for(i = sti ; i<sti+len ; i++) {
			if(field[i][stj] == inp[k]) {
				cnt++;
				k++;
			}
			else break;
		}
		if(cnt == len) return 1;
	}

	//srh ^

	if(sti-len+1  >= 0) {
		cnt = 0;
		k   = 0;
		for(i = sti ; i>=sti-len+1 ; i--) {
			if(field[i][stj] == inp[k]) {
				cnt++;
				k++;
			}
			else break;
		}
		if(cnt == len) return 1;
	}

	//srh \>
	if(mcol - stj  >= len && mrow - sti >= len) {
		cnt = 0;
		k   = 0;
		for(j = stj , i = sti ; j<stj+len && i<sti+len ; i++,j++) {
			if(field[i][j] == inp[k]) {
				cnt++;
				k++;
			}
			else break;
		}
		if(cnt == len) return 1;
	}

	//srh />
	if(mcol - stj  >= len && sti-len+1  >= 0) {
		cnt = 0;
		k   = 0;
		for(j = stj , i = sti ; j<stj+len && i>=sti-len+1 ; i--,j++) {
			if(field[i][j] == inp[k]) {
				cnt++;
				k++;
			}
			else break;
		}
		if(cnt == len) return 1;
	}

	//srh </

	if( stj-len+1 >= 0 && mrow - sti >= len) {
		cnt = 0;
		k   = 0;
		for(j = stj , i = sti ; j>=stj-len+1 && i<sti+len ; i++,j--) {
			if(field[i][j] == inp[k]) {
				cnt++;
				k++;
			}
			else break;
		}
		if(cnt == len) return 1;
	}

	//srh <\
	if(stj-len+1 >= 0  && sti-len+1  >= 0) {
		cnt = 0;
		k   = 0;
		for(j = stj , i = sti ;  j>=stj-len+1 && i>=sti-len+1 ; i--,j--) {
			if(field[i][j] == inp[k]) {
				cnt++;
				k++;
			}
			else break;
		}
		if(cnt == len) return 1;
	}

	return 0;
}

void proc()
{
	int minp,run,i,j;
	char input[16];

	scanf("%d",&minp);

	for(run=0 ; run<minp ; run++) {
		scanf("%s",input);
		strlwr(input);
		for(i=0 ; i<mrow ; i++) {
			for(j=0 ; j<mrow ; j++) {
				if(sub(input,i,j)) {
					printf("%d %d\n",i,j);
					i = mrow;  //break 2 loops
					j = mcol;
				}
			}
		}
	}
}

int main(void)
{
	input();
	proc();
	return 0;
}