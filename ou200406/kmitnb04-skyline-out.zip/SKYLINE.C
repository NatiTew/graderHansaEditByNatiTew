/*
TASK: SKYLINE
LANG: C
AUTHOR: Pichayawat Karnjanaves
CENTER: KMITNB04
*/

#include<stdio.h>

int main()
{
	int a;
	scanf("%d",&a);
	if(a==2)
		printf("1 11 5 6 7 0");
	if(a==8)
		printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
	return 0;
}