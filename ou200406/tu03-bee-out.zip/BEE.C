/*
TASK: BEE
LANG: C
AUTHOR: Nuttakorn Benjamasutin (Assumption)
CENTER: tu03
*/

#include <stdio.h>

#define MAXARRAY 51
#define MAXN 30

typedef struct
{
	long work, soldier;
}TYPE;

TYPE dat[MAXARRAY];
const long queen=1;

int main()
{
	long i, n;
	dat[0].work=1; dat[0].soldier=0;
	for(i=1; i<=MAXN; i++)
	{
		dat[i].work=queen + dat[i-1].work + dat[i-1].soldier;
		dat[i].soldier=dat[i-1].work;
	}
	for( ; ; )
	{
		scanf("%ld",&n);
		if(n == -1) break;
		printf("%ld %ld\n", dat[n].work, dat[n].work + dat[n].soldier + queen);
	}
	return 0;
}