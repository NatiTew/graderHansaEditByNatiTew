/*
TASK: MAXSEQ
LANG: C
AUTHOR: KAWIN ASVAPATIPATT
CENTER: TU07
*/

#include <stdio.h>

int seq[3000],path[2][3000] ;
long max=-1 ;

int pick (int i,int n,long sum)
{
int j,k=0 ;
while (i != n)
	{
	path[0][k] = seq[i] ;
	sum = sum+seq[i] ;
	if (sum > max)
		{
		max = sum ;
		for(j=0;j<k+1;j++)
			path[1][j] = path[0][j] ;
		}
	k++ ;
	i++ ;
	}
return 0 ;
}

int main()
{
int n,i ;
long sum=0 ;
scanf ("%d",&n) ;
for (i=0;i<n;i++) scanf ("%d",&seq[i]) ;
for (i=0;i<n;i++) pick (i,n,0) ;
if (max > 0)
	{
	i = 0 ;
	do {
		sum = sum+path[1][i] ;
		printf ("%d ",path[1][i]) ;
		i++ ;
		} while (sum != max) ;
	printf ("\n%ld",max) ;
	}
else printf ("Empty sequence") ;
return 0 ;
}