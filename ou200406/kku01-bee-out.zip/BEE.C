/*
TASK: BEE
LANG: C
AUTHOR: Charuwat Houngkaew
CENTER: KKU01
*/
#include <stdio.h>

long bw=1;
long bq=1;
long bs=0;
long bo=0;
int n;
void recur(int lv)
{
long bo=bw;
	if(lv==n+1)
		return;
	else
	{
		bw+=bs+1;
		bs=bo;
		//bw=bw*2+1;
		//bw=lv;
		recur(lv+1);
	}
}

int main()
{
//recur(1);
int i;
scanf("%d",&n);
	while(n!=-1)
	{
			//scanf("%d",&n);
			bw=1;
			bs=0;
			bq=1;
			bo=0;
			recur(1);
			printf("%ld ",bw);
			printf("%ld\n",bw+bq+bs);
			scanf("%d",&n);
	}

return 0;
}
