/*
TASK: WORD
LANG: C
AUTHOR: WACHIRA SUPPASATEAN
CENTER: UBU02
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void MakeUpper( char *str )
{
	int len = strlen(str);
	int i;

	for( i=0; i<len; i++ )
	{
		str[i] = toupper( str[i] );
	}
}

int searchVerticle( char str[25][25], char *word , int len, int wordlen,int col)
{
	//int wordlen = strlen( word );
	int i, j, found = 0, match;


	for( i=0; i<=len-wordlen; i++ )
	{
		match = 1;
		for( j=0; j<wordlen; j++ )
		{
			if( word[j]!= str[i+j][col] )
			{
				//printf("%c    %c\n", word[j], str[i+j][col] );
				match = 0;
				break;
			}
			//printf("%c    %c\n", word[j], str[i+j][col] );
		}
		if(match)
		{
			found = 1;
			break;
		}
	}
	if( found )
	{
		return i;
	}


	for( i=len; i>=wordlen; i-- )
	{
		match = 1;
		for( j=0; j<wordlen; j++ )
		{
			if( word[j]!= str[i-j][col] )
			{
				match = 0;
				break;
			}
		}
		if(match)
		{
			found = 1;
			break;
		}
	}
	if( found )
	{
		return i;
	}

	return -1;
}


int searchHorizon( char *str, char *word , int len, int wordlen)
{
	//int wordlen = strlen( word );
	int i, j, found = 0, match;


	for( i=0; i<=len-wordlen; i++ )
	{
		match = 1;
		for( j=0; j<wordlen; j++ )
		{
			if( word[j]!= str[i+j] )
			{
				match = 0;
				break;
			}
		}
		if(match)
		{
			found = 1;
			break;
		}
	}
	if( found )
	{
		return i;
	}


	for( i=len; i>=wordlen; i-- )
	{
		match = 1;
		for( j=0; j<wordlen; j++ )
		{
			if( word[j]!= str[i-j] )
			{
				match = 0;
				break;
			}
		}
		if(match)
		{
			found = 1;
			break;
		}
	}
	if( found )
	{
		return i;
	}

	return -1;
}


int searchD( char str[25][25], char *word, int wordlen, int m, int n , int *col)
{
	int i, j, c, match;

	for( i=0; i<m; i++ )
	{
		for( j=0; j<n; j++ )
		{
			match = 1;
			for( c=0; c<wordlen; c++ )
			{
				if( str[i+c][j+c]!=word[c] )
				{
					match = 0;
					//printf( "*%c   %c\n",str[i+c][j+c], word[c] );
					break;
				}
				//printf( "%c   %c\n",str[i+c][j+c], word[c] );
			}

			if( match )
			{
				*col = j;
				return i;
			}

			match = 1;
			for( c=0; c<wordlen; c++ )
			{
				if( str[i+c][j-c]!=word[c] )
				{
					match = 0;
					//printf( "*%c   %c\n",str[i+c][j+c], word[c] );
					break;
				}
				//printf( "%c   %c\n",str[i+c][j+c], word[c] );
			}

			if( match )
			{
				*col = j;
				return i;
			}


			match = 1;
			for( c=0; c<wordlen; c++ )
			{
				if( str[i-c][j+c]!=word[c] )
				{
					match = 0;
					//printf( "*%c   %c\n",str[i+c][j+c], word[c] );
					break;
				}
				//printf( "%c   %c\n",str[i+c][j+c], word[c] );
			}

			if( match )
			{
				*col = j;
				return i;
			}


			match = 1;
			for( c=0; c<wordlen; c++ )
			{
				if( str[i-c][j-c]!=word[c] )
				{
					match = 0;
					//printf( "*%c   %c\n",str[i+c][j+c], word[c] );
					break;
				}
				//printf( "%c   %c\n",str[i+c][j+c], word[c] );
			}

			if( match )
			{
				*col = j;
				return i;
			}

		}
	}
	return -1;
}


int main( void )
{
	int m, n, i, col, nWord, x, y, maxx, maxy;
	int c,d, wordlen;
	char buffer[25][25];
	char word[16];

	scanf( "%d", &m );
	scanf( "%d", &n );

	for( i=0; i<m; i++ )
	{
		scanf("%s", buffer[i]);
		MakeUpper( buffer[i] );
	}

	//printf("%d", searchD( buffer, "ETUPMOC", 7, m, n, &col  ) );

	scanf("%d", &nWord);

	for( i=0; i<nWord; i++ )
	{
		maxx=maxy=26;
		scanf("%s", word);
		MakeUpper( word );
		wordlen = strlen( word );
		for( c=0; c<n; c++ )
		{
			y=searchVerticle( buffer, word , m, wordlen,c);
			if( y<maxy && y!=-1)
			{
				maxx = c;
				maxy = y;
				break;
			}
			else if( y==maxy && y!=-1 && c<maxx)
			{
				maxx = c;
				maxy = y;
				break;
			}
		}
		for( c=0; c<n; c++ )
		{
			x=searchHorizon( buffer[c], word , n, wordlen);
			if( x<maxx && x!=-1&&c<maxy)
			{
				maxx = x;
				maxy = c;
				break;
			}
		}

		y = searchD( buffer, word, wordlen, m, n , &x);

		if( y<maxy && y!=-1)
		{
			maxx = x;
			maxy = y;
		}
		else if( y==maxy&&x<maxx )
		{
			maxx = x;
			maxy = y;
		}
		printf("%d %d\n", maxy, maxx);


	}

	return 0;
}