/*
 TASK: SKYLINE
 LANG: C
 AUTHOR: Boonyarit Somrealvongon
 CENTER: MAHIDOL02
*/
#include <stdio.h>

int main(void)
{
 int i,j,max=0,n,sky[260],l,h,r;
 for (i=1; i<=260; i++) sky[i]=0;
 scanf("%d\n",&n);
 for (i=0; i<n; i++)
  {
   scanf("%d %d %d\n",&l,&h,&r);
   for (j=l; j<r; j++)
     if (h>sky[j]) sky[j]=h;
   if (r>max) max=r;
  }

 printf("%d",1);
 for (i=1; i<max; i++)
 {
  if(sky[i]!=sky[i+1])
    { printf(" %d",sky[i]);
      printf(" %d",i+1);

    }
 }
 printf(" 0");
 return 0;
}