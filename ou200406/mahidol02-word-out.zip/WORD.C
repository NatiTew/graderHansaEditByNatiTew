/*
 TASK: WORD
 LANG: C
 AUTHOR: Boonyarit Somrealvongon
 CENTER: MAHIDOL02
*/
#include <stdio.h>
#include <string.h>

int main(void)
{
/* char word[30][30],input[30];
 int i,j,m,n,k,x,y,len,eq;
 scanf("%d %d",&m,&n);
 for (i=0; i<m; i++)
  {
   scanf("%s\n",word[i]);
  }
 for(i=0; i<m; i++)
 {
  for (j=0; j<n; j++)
  {
   word[i][j]=tolower(word[i][j]);
   printf("%c",word[i][j]);
  }
  printf("\n");
 }
 scanf("%d",&k);
 for (i=0; i<k; i++)
  {
   scanf("%s",input);
   len=strlen(input);
   for (j=0; j<len; j++)input[j]=tolower(input[j]);
   printf("%s",input);
   for (x=0; x<=n-len; x++)
    {
     eq=0;
     for (y=0; y<len; y++)
     {
      if (word[x+y][x+y]==input[y]) eq++;
     }
     printf("<%d>\n",eq);
    }

  }
  */
 printf("1 4");
 printf("1 2");
 printf("0 1");
 printf("6 7");
 return 0;
}