/*
TASK: BEE
LANG: C
AUTHOR: Vanus Vachiratamporn
CENTER: TU09
*/
#include<stdio.h>

int main(void)
{   long int Bee[25][2],ans[50],i,n;
    for(n=0;;n++)
       {   scanf("%ld",&ans[n]);
	   if(ans[n]==-1)
	     break;
       }
    for(i=0;i<25;i++)
       {   Bee[i][0]=0;
	   Bee[i][1]=0;
       }
    Bee[0][0]=1;
    Bee[0][1]=0;
    for(i=1;i<25;i++)
       {   Bee[i][0]+=Bee[i-1][0]+Bee[i-1][1]+1;
	   Bee[i][1]+=Bee[i-1][0];
       }
    for(i=0;i<n;i++)
       {   printf("%ld %ld\n",Bee[ans[i]][0],Bee[ans[i]][0]+Bee[ans[i]][1]+1);
       }
    return 0;
}
