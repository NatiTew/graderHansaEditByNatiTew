/*
TASK: MAXSEQ
LANG: C
AUTHOR: SUTUTTA SEANGTHONG
CENTER: SU-03
*/

#include <stdio.h>
#define MAX 2500

int seq[MAX];

struct INDEX{
	int sum;
	int first,last;
}IN[MAX];

int main()
{  int n,i,tmp,k,in=0;
	scanf("%d",&n);
	if (n>=1&&n<=MAX)
	{	for (i=0;i<n;i++)
			scanf("%d",&seq[i]);

		k=0;
		for (i=0;i<n;i++)
		{	if (seq[i]>0)
			{	IN[k].first=i;
				IN[k].last=i;
				break;
			}
		}
		IN[k].sum=0;
		while (i<n)
		{       if (seq[i]>=-127&&seq[i]<=127)
			{
				tmp=IN[k].sum+seq[i];
				if (tmp>IN[k].sum||tmp+seq[i+1]>=IN[k].sum||tmp+seq[i+1]+seq[i+2]>=IN[k].sum)
				{       if (tmp!=0)
					{	IN[k].last=i;
						IN[k].sum=tmp;
					}
					else
					{       k++;
						IN[k].first=i+1;
						IN[k].last=i+1;
					}
				}
				else
				{       k++;
					IN[k].first=i+1;
					IN[k].last=i+1;
					IN[k].sum=0;

				}
			}
			i++;
		}
		tmp=0;
		for (i=1;i<=k;i++)
		{     	if (IN[i].sum>IN[in].sum)
			{	in=i;
				tmp=1;
			}
			if (in==0)
				tmp=1;

		}
		if (IN[in].sum!=0)
		{	if (tmp==1||in==0)
			{
				for (i=IN[in].first;i<=IN[in].last;i++)
					printf("%d ",seq[i]);
				printf("\n%d",IN[in].sum);
			}
		}
		else
			printf("Empty sequence");
	}
   return 0;
}