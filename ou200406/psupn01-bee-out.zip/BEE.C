/*
TASK: BEE
LANG: C
AUTHOR: NUTTAWUT MANEEKASORN
CENTER: PSUPN-01
*/

#include <stdio.h>

int main(){
  int i,j,k,num,cnt=0,years;
  long Bee[3],tempBee[3];
  int lstyear[1024];

  do{
     scanf("%d",&num);
     lstyear[cnt] = num;
     cnt++;
  }while(num!=-1);
  cnt--;

  for(k=0;k<cnt;k++){
	Bee[0] = 1;
	Bee[1] = 1;
	Bee[2] = 0;
	years = lstyear[k];
	for(i=0;i<years;i++){
	    for(j=0;j<3;j++){
		tempBee[j] = Bee[j];
	    }
	    Bee[1] = tempBee[1] + tempBee[2] + 1;
	    Bee[2] = tempBee[1];
	}
	printf("%ld %ld\n",Bee[1],Bee[2]+Bee[1]+1);
  }
  return 0;
}