/*
TASK: BEE
LANG: C
AUTHOR: Sorawit Boonyathee
CENTER: cmu01
*/

#include <stdio.h>

int main()
{
	int chk=1;
	int n;
	unsigned long work,la,i,twork,tla;
	while(chk==1)
	{
		scanf("%d",&n);
		if(n==-1)	chk=0;
		else
		{
			work=1;
			la=0;
			for(i=0;i<n;i++)
			{
				twork=work;
				tla=la;
				//for head
				work+=1;
				//for work
				work+=twork;
				la+=twork;
				//la
				work+=tla;
				//dead
				work-=twork;
				la-=tla;
			}
			printf("%ld %ld\n",work,work+la+1);
		}
	}
	return 0;
}