/*
TASK: DICE
LANG: C
AUTHOR: Naksit Anantalapochai
CENTER: cmu04
*/
#include <stdio.h>
int main()
{
	int top=1,bottom=6,front=2,back=5,left=3,right=4;
	static int n,i,j,ans[6],temp[2];
	char cmd[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		flushall();
		scanf("%s",cmd);
		j=0;
		while(cmd[j]!='\0'){
			if(cmd[j]=='F'){
				temp[0]=top;
				top=back;
				temp[1]=front;
				front=temp[0];
				temp[0]=bottom;
				bottom=temp[1];
				back=temp[0];
			}
			if(cmd[j]=='B'){
				temp[0]=top;
				top=front;
				temp[1]=back;
				back=temp[0];
				temp[0]=bottom;
				bottom=temp[1];
				front=temp[0];
			}
			if(cmd[j]=='L'){
				temp[0]=top;
				top=right;
				temp[1]=left;
				left=temp[0];
				temp[0]=bottom;
				bottom=temp[1];
				right=temp[0];
			}
			if(cmd[j]=='R'){
				temp[0]=top;
				top=left;
				temp[1]=right;
				right=temp[0];
				temp[0]=bottom;
				bottom=temp[1];
				left=temp[0];
			}
			if(cmd[j]=='C'){
				temp[0]=front;
				front=right;
				temp[1]=left;
				left=temp[0];
				temp[0]=back;
				back=temp[1];
				right=temp[0];
			}
			if(cmd[j]=='D'){
				temp[0]=front;
				front=left;
				temp[1]=right;
				right=temp[0];
				temp[0]=back;
				back=temp[1];
				left=temp[0];
			}
			j++;
		}
		ans[i]=front;
		top=1;
		front=2;
		left=3;
		back=5;
		right=4;
		bottom=6;
	}
	i=0;
	while(ans[i]!=0){
		printf("%d ",ans[i]);
		i++;
	}
	return 0;
}