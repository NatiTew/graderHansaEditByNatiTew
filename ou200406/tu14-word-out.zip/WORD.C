/*
TASK: WORD
LANG: C
AUTHOR: NATTHANON THANSIRARAK
CENTER: TU14
*/
#include<stdio.h>

void main()
{
	int m,n,input,input2,loop,loop2,loop3,ans[101][2],mark[101],cur2,cur;
	char str[26][26],word[101][16];
	scanf("%d%d",&m,&n);
	for(loop=0;loop<m;loop++)
	{
		scanf("%s",str[loop]);
		for(loop2=0;loop2<n;loop2++)
		{
			if(str[loop][loop2]>='A' && str[loop][loop2] <='Z')
				str[loop][loop2]+=32;
		}
	}
	scanf("%d",&input2);
	for(loop=0;loop<input2;loop++)
		mark[loop]=0;
	for(loop=0;loop<input2;loop++)
	{
		scanf("%s",word[loop]);
		for(loop2=0;word[loop][loop2]!=NULL;loop2++)
		{
			if(word[loop][loop2]>='A' && word[loop][loop2] <='Z')
				word[loop][loop2]+=32;
		}
	}
	for(loop=0;loop<m;loop++)
		for(loop2=0;loop2<n;loop2++)
		{
			for(loop3=0;loop3<input2;loop3++)
				if(str[loop][loop2]==word[loop3][0] && mark[loop3]==0)
				{
					cur2=loop2;
					for(cur=loop;word[loop3][loop2-cur2]!=NULL && cur>=0 && cur2>=0 && cur<=m && cur2<=n && mark[loop3]==0;cur--)
					{
						if(str[cur][cur2]!=word[loop3][loop2-cur2])
						{
							break;
						}
						cur2--;
					}
					if(word[loop3][loop2-cur2]==NULL)
					{
						ans[loop3][0]=loop2;
						ans[loop3][1]=loop;
						mark[loop3]=1;
					}
					cur2=loop2;
					for(cur=loop;word[loop3][loop-cur]!=NULL && cur>=0 && cur<=m && mark[loop3]==0;cur--)
					{
						if(str[cur][cur2]!=word[loop3][loop-cur])
						{
							break;
						}

					}
					if(word[loop3][loop-cur]==NULL)
					{
						ans[loop3][0]=loop2;
						ans[loop3][1]=loop;
						mark[loop3]=1;
					}
					cur2=loop2;
					for(cur=loop;word[loop3][cur2-loop2]!=NULL && cur>=0 && cur2>=0 && cur<=m  && mark[loop3]==0&& cur2<=n;cur--)
					{
						if(str[cur][cur2]!=word[loop3][cur2-loop2])
						{
							break;
						}
						cur2++;
					}
					if(word[loop3][cur2-loop2]==NULL)
					{
						ans[loop3][0]=loop2;
						ans[loop3][1]=loop;
						mark[loop3]=1;
					}
					cur2=loop2;
					for(cur=loop;word[loop3][cur2-loop2]!=NULL && cur>=0 && cur2>=0 && mark[loop3]==0&& cur<=m && cur2<=n;cur2++)
					{
						if(str[cur][cur2]!=word[loop3][cur2-loop2])
						{
							break;
						}

					}
					if(word[loop3][cur2-loop2]==NULL)
					{
						ans[loop3][0]=loop2;
						ans[loop3][1]=loop;
						mark[loop3]=1;
					}
					cur2=loop2;
					for(cur=loop;word[loop3][cur2-loop2]!=NULL && cur>=0 && mark[loop3]==0&& cur2>=0 && cur<=m && cur2<=n;cur2++)
					{
						if(str[cur][cur2]!=word[loop3][cur2-loop2])
						{
							break;
						}
						cur++;
					}
					if(word[loop3][cur2-loop2]==NULL)
					{
						ans[loop3][0]=loop2;
						ans[loop3][1]=loop;
						mark[loop3]=1;
					}
					cur2=loop2;
					for(cur=loop;word[loop3][cur-loop]!=NULL && cur>=0 && cur2>=0 && cur<=m && mark[loop3]==0&& cur2<=n;cur++)
					{
						if(str[cur][cur2]!=word[loop3][cur-loop])
						{
							break;
						}

					}
					if(word[loop3][cur-loop]==NULL)
					{
						ans[loop3][0]=loop2;
						ans[loop3][1]=loop;
						mark[loop3]=1;
					}
					cur2=loop2;
					for(cur=loop;word[loop3][loop2-cur2]!=NULL && cur>=0 && cur2>=0 && mark[loop3]==0&& cur<=m && cur2<=n;cur++)
					{
						if(str[cur][cur2]!=word[loop3][loop2-cur2])
						{
							break;
						}
						cur2--;
					}
					if(word[loop3][loop2-cur2]==NULL)
					{
						ans[loop3][0]=loop2;
						ans[loop3][1]=loop;
						mark[loop3]=1;
					}
					cur2=loop2;
					for(cur=loop;word[loop3][loop2-cur2]!=NULL && cur>=0 && cur2>=0 && mark[loop3]==0&& cur<=m && cur2<=n;cur2--)
					{
						if(str[cur][cur2]!=word[loop3][loop2-cur2])
						{
							break;
						}

					}
					if(word[loop3][loop2-cur2]==NULL)
					{
						ans[loop3][0]=loop2;
						ans[loop3][1]=loop;
						mark[loop3]=1;
					}
				}
		}
	for(loop=0;loop<input2;loop++)
		printf("%d %d\n",ans[loop][1],ans[loop][0]);
}
