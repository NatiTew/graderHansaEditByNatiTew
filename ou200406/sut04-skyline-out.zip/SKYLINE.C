/*
TASK: SKYLINE
LANG: C
AUTHER: Pattaravut Maleehuan
CENTER: SUT04
*/
#include<stdio.h>

struct town
{
	int data,l,r;
}tw[20],tmp2;

int n,i,j;

void s_sort();
void think();

void main()
{
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d %d %d",&tw[i].l,&tw[i].data,&tw[i].r);

		think();

}

void s_sort()
{
	int tmp=tw[0].l;
	for(i=0;i<n-1;i++,tmp=tw[i].l)
	{
		for(j=i+1;j<n;j++)
			if(tw[j].l > tw[tmp].l) tmp=j;

		tmp2=tw[tmp];
		tw[tmp]=tw[i];
		tw[i]=tmp2;
	}
}

void think()
{
	printf("%d ",tw[0].l);
	for(i=0;i<n-1;i++)
	{
		if(tw[i].data > tw[i+1].data) printf("%d %d",tw[i].data,tw[i].r);
		else printf("%d %d",tw[i].data,tw[i+1].l);
	}
	printf(" %d %d 0",tw[i].data,tw[i].r);
}