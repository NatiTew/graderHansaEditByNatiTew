/*
TASK: DICE
LANG: c
AUTHOR: Phumpong
CENTER: nu03
*/
#include<stdio.h>
int main()
{
	int a,i,j,up=1,down=6,left=3,right=4,front=2,back=5,tmp;
	char rot[5][1000];
	scanf("%d",&a);
	for(i=0;i<a;i++)
	{
		scanf("%s",rot[i]);
	}
	for(i=0;i<a;i++)
	{
		for(j=0;j<100;j++)
		{
			if(rot[i][j]=='F'||rot[i][j]=='B'||rot[i][j]=='L'||rot[i][j]=='R'||rot[i][j]=='C'||rot[i][j]=='D')
			{
				if(rot[i][j]=='F')
				{
				  tmp=up;
				  up=back;
				  back=down;
				  down=front;
				  front=tmp;
				}
				else if(rot[i][j]=='B')
				{
				  tmp=up;
				  up=front;
				  front=down;
				  down=back;
				  back=tmp;
				}
				else if(rot[i][j]=='L')
				{
				  tmp=up;
				  up=right;
				  right=down;
				  down=left;
				  left=tmp;
				}
				else if(rot[i][j]=='R')
				{
				  tmp=up;
				  up=left;
				  left=down;
				  down=right;
				  right=tmp;
				}
				else if(rot[i][j]=='C')
				{
				  tmp=front;
				  front=right;
				  right=back;
				  back=left;
				  left=tmp;
				}
				else if(rot[i][j]=='D')
				{
				  tmp=front;
				  front=left;
				  left=back;
				  back=right;
				  right=tmp;
				}

			}
		else
		{
			printf("%d ",front);
			up=1;down=6;left=3;right=4;front=2;back=5;
			break;
		}
		}
	}
  return 0;
}