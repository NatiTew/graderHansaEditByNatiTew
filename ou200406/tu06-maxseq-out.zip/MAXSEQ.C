/*
TASK: MAXSEQ
LANG: C
AUTHOR: CHANTAT EKSOMBATCHAI
CENTER: TU06
*/
#include<Stdio.h>
main()
{
	int b[2510],n,i,ans[2510],posx=0,posy=0;
	long a[2510],max=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&b[i]);
		a[i] = b[i];
	}
	if(a[0] > max)
		max = a[0];
	ans[0] = 0;
	for(i=1;i<n;i++)
	{
		if(a[i-1]+a[i] > a[i])
		{
			a[i] = a[i-1]+a[i];
			ans[i] = ans[i-1];
			if(a[i]>max)
			{
				max=a[i];
				posx = ans[i];
				posy = i;
			}
		}
		else
		{
			ans[i] = i;
			if(a[i]>max)
			{
				max = a[i];
				posx=ans[i];
				posy=ans[i];
			}
		}
	}
	if(max<=0)
		printf("Empty sequence\n");
	else
	{
		for(i=posx;i<posy;i++)
			printf("%d ",b[i]);
		printf("%d",b[posy]);
		printf("\n%ld\n",max);
	}
	return 0;
}


