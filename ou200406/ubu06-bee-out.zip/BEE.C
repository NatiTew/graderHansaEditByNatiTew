/*
TASK: BEE
LANG: C
AUTHOR: Sujin Kraiyasin
CENTER: Ubon 06
*/
#include <stdio.h>

int main(void)
{
	int years;
	do
	{
		scanf("%d",&years);
		if (years!=-1)
		{
			chkmember(years);
			printf("%d ",years);
		}

	}while(years!=-1);
	return(0);
}

void chkmember(int y)
{
	int mother=1,worker=1,soldier=0,bee=0,i;
	for (i=0;i<=y;i++)
	{
		bee=bee+bee;
	}
	worker=(bee/y)+(y%2);
	printf("%d %d",bee,worker);

}