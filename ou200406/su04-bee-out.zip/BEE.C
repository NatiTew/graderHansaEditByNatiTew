/*
TASK: BEE
LANG: C
AUTHOR: Theerapat Chawannakul
CENTER: SU - su04
*/
#include<stdio.h>


int main(){

	int A=1; //Queen
	int B=1; //Worker
	int C=0; //Soldier
	int i,l=0,k=0,max=0;
	int yr[25];
	int arr[25][3];
	int tmpB,tmpC;

	while(yr[l-1]!=-1){
	      scanf("%d",&yr[l]);
	      max = ( max > yr[l] )? max : yr[l];
	      l++;
	}

	for(i=1;i<=max;i++){



		tmpB=B;
		tmpC=C;

		B+=A;
		B+=tmpB+tmpC;
		B=B-tmpB;
		C+=tmpB;

		C=C-tmpC;



		for(k=0;k<l-1;k++){
			if(i==yr[k]){
				arr[k][0]=B;
				arr[k][1]=A+B+C;
			}
		}


	}
	for(k=0;k<l-1;k++){
		printf("%d %d",arr[k][0],arr[k][1]);
		if(k!=l-2) printf("\n");
	}
	return 0;
}