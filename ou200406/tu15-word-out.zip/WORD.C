/*
TASK: WORD
LANG: C
AUTHOR: NATHADOL SAHAWATWONG
CENTER: TU15
*/

#include<stdio.h>
#include<string.h>
#define MAX 51

char array[MAX][MAX],word[MAX];

main()
{
		char input;
		int n,m,i,j,k,l,over = 1 , run , limit,x,y,o,temp,z;
		scanf("%d %d",&n,&m);
		for(i=0 ; i<n ; i++)
		{
			for(j=0 ; j<m ; j++)
			{
				scanf("\n%c",&input);
					if(input >= 90)
						array[i][j] = input-32;
					else
						array[i][j] = input;
			}
		}
		scanf("%d",&k);
		for(l=0 ; l<k ; l++)
		{
			scanf("%s",word);
			limit = strlen(word);
			for(z=0 ; z<limit ; z++)
			{
				if(word[z]>=90)
					word[z]=word[z]-32;
			}
			for(i=0 ; i<n ; i++)
			{
				for(j=0 ; j<m ; j++)
				{
					if(array[i][j] == word[0] )
					{
						for(run = 1 ; run<= 8 ; run++ , temp = 0)
						{
							x=i;
							y=j;
							if(run == 1)
							{
									for(o = 0 ; o<=limit-1 ; o++)
									{
										if(array[x][y++]==word[o])
											temp = 1;
										else
										{
											temp = 0;
											break;
										}
									}
									if(temp == 1)
									{
										printf("%d %d",i,j);
										over = 0;
										break;
									}
							}
							if(run == 2)
							{
									for(o = 0 ; o<=limit-1 ; o++)
									{
										if(array[x++][y++]==word[o] )
											temp = 1;
										else
										{
											temp = 0;
											break;
										}
									}
									if(temp == 1)
									{
										printf("%d %d",i,j);
										over = 0;
										break;
									}
							}
							if(run == 3)
							{
									for(o = 0 ; o<=limit-1 ; o++)
									{
										if(array[x++][y]==word[o])
											temp = 1;
										else
										{
											temp = 0;
											break;
										}
									}
									if(temp == 1)
									{
										printf("%d %d",i,j);
										over = 0;
										break;
									}
							}
							if(run == 4)
							{
									for(o = 0 ; o<=limit-1 ; o++)
									{
										if(array[x++][y--]==word[o] )
											temp = 1;
										else
										{
											temp = 0;
											break;
										}
									}
									if(temp == 1)
									{
										printf("%d %d",i,j);
										over = 0;
										break;
									}
							}
							if(run == 5)
							{
									for(o = 0 ; o<=limit-1 ; o++)
									{
										if(array[x][y--]==word[o])
											temp = 1;
										else
										{
											temp = 0;
											break;
										}
									}
									if(temp == 1)
									{
										printf("%d %d",i,j);
										over = 0;
										break;
									}
							}
							if(run == 6)
							{
									for(o = 0 ; o<=limit-1 ; o++)
									{
										if(array[x--][y--]==word[o])
											temp = 1;
										else
										{
											temp = 0;
											break;
										}
									}
									if(temp == 1)
									{
										printf("%d %d",i,j);
										over = 0;
										break;
									}
							}
							if(run == 7)
							{
									for(o = 0 ; o<=limit-1 ; o++)
									{
										if(array[x--][y]==word[o] )
											temp = 1;
										else
										{
											temp = 0;
											break;
										}
									}
									if(temp == 1)
									{
										printf("%d %d",i,j);
										over = 0;
										break;
									}
							}
							if(run == 8)
							{
									for(o = 0 ; o<=limit-1 ; o++)
									{
										if(array[x--][y++]==word[o])
											temp = 1;
										else
										{
											temp = 0;
											break;
										}
									}
									if(temp == 1)
									{
										printf("%d %d",i,j);
										over = 0;
										break;
									}
							}
						if(over == 0)	break;
						}

					}
				if(over == 0)	break;
				}
			if (over == 0)	break;
			}
			over = 1;
		}
	return 0;
}