/*
TASK:MAXSEQ
LANG:C
AUTHOR:SUPASHOCK RENGSOMBOON
CENTER:KKU04
*/
#include<stdio.h>
#include<string.h>
int main(){
int  i,j;





return 0;
}