/*
TASK: seqment
LANG: C
AUTHOR: KHOMSAN PONSAI
CENTER: KKU02
*/
//