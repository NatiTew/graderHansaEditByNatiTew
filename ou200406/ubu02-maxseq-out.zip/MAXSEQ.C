/*
TASK: MAXSEQ
LANG: C
AUTHOR: WACHIRA SUPPASATEAN
CENTER: UBU-02
*/
#include <stdio.h>

typedef struct
{
	int start;
	int n;
	long sum;
}RANGE;


long GetSum( int *data, int start, int n )
{
	long tmp = 0;
	int i;
	for( i=0; i<n; i++ )
	{
		tmp += data[ start+i ];
	}
	return tmp;
}

int GetMaxSeq( int *data, int n, RANGE *result )
{
	int isFound=0;
	long max=1;
	int maxStart, maxN;
	long sum;
	int i, j=n;

	for( j=n-1; j>=0; j-- )
	{
		for( i=n-j; i>0; i-- )
		{
			sum = GetSum( data, j, i );
			if( sum >= max )
			{
				maxStart = j;
				maxN = i;
				isFound = 1;
				max = sum;
			}
		}
	}
	result->start = maxStart;
	result->n = maxN;
	result->sum = max;

	return isFound;
}

int main( void )
{
	int n, i, found;
	RANGE result;
	int data[2500];

	scanf("%d", &n);

	for( i=0; i<n; i++ )
	{
		scanf("%d", &data[i] );
	}
	found = GetMaxSeq( data, n, &result );

	if( found )
	{
		for( i=0; i<result.n; i++ )
		{
			if(i==result.n-1)
			{
				printf("%d\n", data[i+result.start]);
			}
			else
			{
				printf("%d ", data[i+result.start]);
			}
		}
		printf("%ld", result.sum );
	}
	else
	{
		printf("Empty sequence");
	}

	return 0;
}