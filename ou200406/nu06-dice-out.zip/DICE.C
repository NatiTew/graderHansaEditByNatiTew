/*
TASK: DICE
LANG: C
AUTHOR: THEERAPHONG PHUTHONG
CENTER: nu06
*/
#include<stdio.h>
#include<string.h>

int main()	{
	int i,j,n,toy[6]={1,2,3,4,5,6},point=1;
	char str[60][60]={{0},{0}};
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%s",&str[i]);
	}
	for(i=0;i<n;i++){
		for(j=0;j<strlen(str);j++){
		    if(str[i][j]=='F')
			point+=1;
		    if(str[i][j]=='B')
			point+=1;
		    if(str[i][j]=='L')
			point+=1;
		    if(str[i][j]=='R')
			point+=1;
		    if(str[i][j]=='C')
			point+=1;
		    if(str[i][j]=='D')
			point+=1;
		}
	     //	printf("%d ",toy[point]);
	}
	for(i=0;i<10;i++){
	   if(i==n)
	   printf("%d %d %d",toy[n-1],toy[n-2],toy[n-2]);
	}
return 0;	}
