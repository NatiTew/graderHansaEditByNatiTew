/*
TASK: MAXSEQ
LANG: C
AUTHOR: Sithipan Kasemvilas
CENTER: kmitnb-02
*/
#include<stdio.h>
#include<stdlib.h>
void main() {
int i,j,set,high,count=0,pos=0,ans=0,sub[2500]={0};
	scanf("%d",&set);
	if(set < 1 || set > 2500) {
		printf("");
		exit(0);
	}
	for(i=0;i<set;i++)
		scanf("%d",&sub[i]);
	for(i=0;i < set;i++)
		if(sub[i] > 0 ) {
			j=i;
		do {
				ans+=sub[j];
				j++;
			} 	while(sub[j] < 0);
			ans += sub[j];
			if (count == 0) {
				count =1;
				high = ans;
				pos = i;
			}

			if(ans > high) {
				high = ans;
				pos = i;
			}
		ans = 0;
		i = j;
		}
	if(pos > 0) {
		j = pos;
		do {
			printf("%d ",sub[j]);
			j++;
		} 	while(sub[j] < 0);
	printf("%d\n",sub[j]);
	printf("%d\n",high);
	}
	else printf("Empty sequence");
}
