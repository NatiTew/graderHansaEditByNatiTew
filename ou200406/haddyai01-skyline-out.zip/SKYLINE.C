/*
TASK: SKYLINE
LANG: C
AUTHOR: NARONG WAKAYAPHATTARAMANUS
CENTER: PSUHATYAI-HADDYAI01
*/
#include<stdio.h>
struct build
	{
	 int in;
	 int top;
	 int fin;
	}b[3000],temp;
int sort();
int n;
int main()
{
 int i,j;
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  scanf("%d %d %d",&b[i].in,&b[i].top,&b[i].fin);
 }
 sort();
 for(i=0;i<n;i++)
 {
  if(i==0)
  printf("%d %d ",b[i].in,b[i].top);
  for(j=i+1;j<n;j++)
  {
   if(b[j].top>=b[i].top)
   printf("%d %d",b[j].in,b[j].top);
   break;
  }
  if(b[i].fin>b[i+j].in)
  {
   printf("%d %d ",b[j-1].in,b[j-1].top);
  }
 }
 return 0;
}
int sort()
{
 int i,j,min=256,minp;
 for(i=0;i<n;i++)
 {
  min=256;
  for(j=i;j<n;j++)
  {
   if(b[j].in<min)
   {
    minp=j;
    min=b[j].in;
   }
  }
  temp=b[i];
  b[i]=b[minp];
  b[minp]=temp;
 }
 return 0;
}

