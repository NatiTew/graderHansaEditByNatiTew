/*
TASK: BEE
LANG: C
AUTHOR: RIVINWIT AKKARANGSRI
CENTER: UBON01
*/
#include<stdio.h>

int main(){
	long a[2];
	long temp,n,i;

	scanf("%ld",&n);
	while(n!=-1){
		a[0]=1;
		a[1]=0;
		for(i=0;i<n;i++){
			temp=a[0];
			a[0]=a[0]+a[1];
			a[1]=temp;
			a[0]++;
		}
		printf("%ld %ld\n",a[0],a[0]+a[1]+1);
		scanf("%ld",&n);
	}
	return 0;
}