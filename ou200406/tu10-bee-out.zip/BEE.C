/*
TASK: BEE
LANG: C
AUTHOR: Passarit Atiworraman
CENTER: tu10
*/

#include<stdio.h>

long a[3];

int main()
{
    long input,x,work,soldier;
    while(1)
    {
	a[0] = 1;
	a[1] = 1;
	a[2] = 0;
	scanf("%ld",&input);
	if(input == -1)
	    break;
	for(x=0;x<input;x++)
	{
	    work = 0;
	    soldier = 0;
	    if(a[0] != 0)
		work += a[0];
	    if(a[1] != 0)
	    {
		work += a[1];
		soldier += a[1];
		a[1] = 0;
	    }
	    if(a[2] != 0)
	    {
		work += a[2];
		a[2] = 0;
	    }
	    a[1] += work;
	    a[2] += soldier;
	}
	printf("%ld %ld\n",a[1],a[0]+a[1]+a[2]);
    }
    return 0;
}


