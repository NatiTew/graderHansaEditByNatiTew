/*
TASK: SKYLINE
LANG: C
AUTHOR: WACHIRA SUPPASATEAN
CENTER: UBU02
*/

#include <stdio.h>

int main( void )
{
	int n, h, l, r, i, j;
	int sky[256] = {0};

	scanf("%d", &n );

	for( i=0; i<n; i++ )
	{
		scanf("%d %d %d", &l, &h, &r );
		l--;
		r--;
		for( j=l; j<r ; j++ )
		{
			if( sky[j]<h )
			{
				sky[j]=h;
			}
		}
	}

	for( i=0; i<256; i++ )
	{
		printf("%d ", i+1);
		h=sky[i];
		printf("%d ", h);
		for(; sky[i]==h; i++ );
		i--;
		//printf("%d", sky[i] );
	}

	return 0;
}