/*
TASK:WORD
LANG:C
AUTHOR: SITTHITHEP NARATHONG
CENTER: PSUPN06
*/
#include<stdio.h>
#include<string.h>
void main(){
	int n1,n2,i,n3,n,k,m,ptr,j;
	char word[100][100],tword[100],word2[20],c[50],l[50],count=0;
	scanf("%d %d",&n1,&n2);
	for(m=0;m<n1;m++){
		scanf("%s",word[m]);
	}
	for(m=0;m<n1;m++){
		strlwr(word[m]);}
	scanf("%d",&n3);
	for(m=0;m<n3;m++){
		scanf("%s",&tword);
		n=strlen(tword);
		strlwr(tword);
		for(i=0;i<n1;i++){
			for(j=0;j<n2;j++){
				if(word[i][j]==tword[0] || word[i][j]==tword[n-1]){
				word2[n]='\0';
				for(k=0;k<n;k++)
					word2[k]=word[i][j+k];
				if(tword[0]==word2[n-1] && tword[1]==word2[n-2]){
					strrev(word2);}
				ptr=strcmpi(word2,tword);
				if(ptr==0){
					c[count]=i;
					l[count]=j;
					count++;break;}
				for(k=0;k<n;k++)
					word2[k]=word[i+k][j+k];

				if(tword[0]==word2[n-1] && tword[1]==word2[n-2])
					strrev(word2);
				ptr=strcmpi(word2,tword);
				if(ptr==0){
					c[count]=i;
					l[count]=j;
					count++;break;}
				for(k=0;k<n;k++)
					word2[k]=word[i+k][j];
				if(tword[0]==word2[n-1] && tword[1]==word2[n-2])
					strrev(word2);
				ptr=strcmpi(word2,tword);
				if(ptr==0){
					c[count]=i;
					l[count]=j;
					count++;break;}
				}
			}
		}
	}
		for(i=0;i<count-1;i++)
			printf("%d %d\n",c[i],l[i]);
}





