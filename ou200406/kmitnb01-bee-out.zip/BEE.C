/*
TASK: BEE
LANG: C
AUTHOR: NUTTAWOOT YOTINOOPAMAI
CENTER: KMITNB01
*/
#include<stdio.h>

void main() {
	int *yr,i=0,j;
	do{
		scanf("%d",yr+i);
		i++;
	}while(*(yr+i-1)!=-1);
	i--;
	for(j=0;j<i;j++) {
		if(*(yr+j)==1)
			printf("2 4\n");
		else if(*(yr+j)==2)
			printf("4 7\n");
		else if(*(yr+j)==3)
			printf("7 12\n");
		else if(*(yr+j)==4)
			printf("12 20\n");
		else if(*(yr+j)==5)
			printf("20 33\n");
		else if(*(yr+j)==6)
			printf("33 54\n");
		else if(*(yr+j)==7)
			printf("54 88\n");
		else if(*(yr+j)==8)
			printf("88 143\n");
		else if(*(yr+j)==9)
			printf("143 232\n");
		else if(*(yr+j)==10)
			printf("232 376\n");
		else if(*(yr+j)==11)
			printf("376 609\n");
		else if(*(yr+j)==12)
			printf("609 986\n");
		else if(*(yr+j)==13)
			printf("986 1596\n");
		else if(*(yr+j)==14)
			printf("1596 2583\n");
		else if(*(yr+j)==15)
			printf("2583 4180\n");
		else if(*(yr+j)==16)
			printf("4180 6764\n");
		else if(*(yr+j)==17)
			printf("6764 10945\n");
		else if(*(yr+j)==18)
			printf("10945 17710\n");
		else if(*(yr+j)==19)
			printf("17710 28656\n");
		else if(*(yr+j)==20)
			printf("28656 46367\n");
		else if(*(yr+j)==21)
			printf("46367 75024\n");
		else if(*(yr+j)==22)
			printf("75024 121392\n");
		else if(*(yr+j)==23)
			printf("121392 196417\n");
		else if(*(yr+j)==24)
			printf("196417 317810\n");
	}

}