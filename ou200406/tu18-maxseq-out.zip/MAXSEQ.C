/*
TASK: MAXSEQ
LANG: C
AUTHOR: ISRANU SAENGSUWAN
CENTER: SAMSEN18
*/
#include<stdio.h>

main()
{
	int seq[2501], maxseq[2501], seqsize, compare, max, count, i, j, k;
	scanf ("%d", &seqsize);
	for (i=0;i<seqsize;i++)
		scanf ("%d", &seq[i]);
	max = 0;
	for (i=0;i<seqsize;i++)
	{
		compare = 0;
		for (j=i;j<seqsize;j++)
		{
			if (seq[j] == NULL) return 0;
			compare += seq[j];
			if (compare>max)
			{
				max = compare;
				count = 0;
				for (k=i;k<=j;k++)
				{
					maxseq[count] = seq[k];
					count++;
				}
			}
		}
	}
	if (max <= 0)
	{
		printf ("Empty sequence");
		return 0;
	}
	for (i=0;i<count;i++)
		printf ("%d ", maxseq[i]);
	printf ("\n%d", max);
	return 0;
}