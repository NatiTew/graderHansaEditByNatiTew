/*
TASK: BEE
LANG: C
AUTHOR: Rawipas Ungtrakul
CENTER: haddyai04
*/
#include<stdio.h>
#include<stdlib.h>
void main()
{
 long int bhead,bwork,bsol,temp;
 int y,i;

 while(1)
 {
  scanf("%d",&y);
  if(y==-1) exit(0);

  bhead=1;
  bwork=1;
  bsol=0;

  for(i=0;i<y;i++)
  {
   temp=bwork;
   bwork=bhead+bsol+bwork;
   bsol=temp;
  }
  printf("%ld %ld\n",bwork,bwork+bsol+bhead);
 }
}