/*
TASK: SEGMENT
LANG: C
AUTHOR: ISRANU SAENGSUWAN
CENTER: SAMSEN18
*/
#include <stdio.h>

main()
{
	int n1, n2, i;
	char s1[4][40], s2[3][40], t1[11], t2[11];
	long int r1, r2;
	scanf ("%d %d", &n1, &n2);
	for (i=0;i<=3;i++) gets (s1[i]);
	for (i=0;i<3;i++) gets (s2[i]);
	for (i=0;i<n1;i++)
	{
		if (s1[1][i*4+1] == '_')
			if (s1[2][i*4] == '|')
				if (s1[2][i*4+1] == '_')
					if (s1[2][i*4+2] == '|')
						if (s1[3][i*4] == '|')
							t1[i] = '8';
						else t1[i] = '9';
					else if (s1[3][i*4] == '|')
						t1[i] = '6';
					else t1[i] = '5';
				else t1[i] = '0';
			else if (s1[2][i*4+1] == '_')
				if (s1[3][i*4] == '|')
					t1[i] = '2';
				else t1[i] = '3';
			else t1[i] = '7';
		else if (s1[2][i*4] == '|')
			t1[i] = '4';
		else t1[i] = '1';
	}
	for (i=0;i<n2;i++)
	{
		if (s2[0][i*4+1] == '_')
			if (s2[1][i*4] == '|')
				if (s2[1][i*4+1] == '_')
					if (s2[1][i*4+2] == '|')
						if (s2[2][i*4] == '|')
							t2[i] = '8';
						else t2[i] = '9';
					else if (s2[2][i*4] == '|')
						t2[i] = '6';
					else t2[i] = '5';
				else t2[i] = '0';
			else if (s2[1][i*4+1] == '_')
				if (s2[2][i*4] == '|')
					t2[i] = '2';
				else t2[i] = '3';
			else t2[i] = '7';
		else if (s2[1][i*4] == '|')
			t2[i] = '4';
		else t2[i] = '1';
	}
	r1 = atoi(t1);
	r2 = atoi(t2);
	printf ("%u", r1+r2);
	return 0;
}