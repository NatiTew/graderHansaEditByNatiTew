/*
TASK: SEGMENT
LANG: C
AUTHOR: Passakorn Phannachitta
CENTER: BUU03
*/
#include <stdio.h>
#include <string.h>

int up,dn;

typedef struct d{
	char arr[3][4];
}d;
/*
void input()
{
	int i,j;

	scanf("%d %d\n",&up,&dn);

	getchar();

	for(i=0 ; i<3 ; i++) {
		for(j=0 ; j<=3*up ; j++) {
			fst[i][j] = getchar();
		}
	}

	for(i=0 ; i<3 ; i++) {
		for(j=0 ; j<=3*dn ; j++) {
			sec[i][j] = getchar();
		}
	}
/*
	for(i=0 ; i<3 ; i++) {
		for(j=0 ; j<=3*up ; j++) {
			printf("%c",fst[i][j]);
		}
	}

	for(i=0 ; i<3 ; i++) {
		for(j=0 ; j<=3*dn ; j++) {
			printf("%c",sec[i][j]);
		}
	}

}*/

void init(d def[10])
{
	strcpy(def[0].arr[0]," _ ");
	strcpy(def[0].arr[1],"| |");
	strcpy(def[0].arr[2],"|_|");

	strcpy(def[1].arr[0],"   ");
	strcpy(def[1].arr[1],"  |");
	strcpy(def[1].arr[2],"  |");

	strcpy(def[2].arr[0]," _ ");
	strcpy(def[2].arr[1]," _|");
	strcpy(def[2].arr[2],"|_ ");

	strcpy(def[3].arr[0]," _ ");
	strcpy(def[3].arr[1]," _|");
	strcpy(def[3].arr[2]," _|");

	strcpy(def[4].arr[0],"  ");
	strcpy(def[4].arr[1],"|_|");
	strcpy(def[4].arr[2],"  |");

	strcpy(def[5].arr[0]," _ ");
	strcpy(def[5].arr[1],"|_ ");
	strcpy(def[5].arr[2]," _|");

	strcpy(def[6].arr[0]," _ ");
	strcpy(def[6].arr[1],"|_ ");
	strcpy(def[6].arr[2],"|_|");

	strcpy(def[7].arr[0]," _ ");
	strcpy(def[7].arr[1],"  |");
	strcpy(def[7].arr[2],"  |");

	strcpy(def[8].arr[0]," _ ");
	strcpy(def[8].arr[1],"|_|");
	strcpy(def[8].arr[2],"|_|");

	strcpy(def[9].arr[0]," _ ");
	strcpy(def[9].arr[1],"|_|");
	strcpy(def[9].arr[2]," _|");

}

int find(char tmp[3][4],d def[10])
{
	int i,j;
/*
	printf("%c%c%c\n",tmp[0][0],tmp[0][1],tmp[0][2]);
	printf("%c%c%c\n",tmp[1][0],tmp[1][1],tmp[2][2]);
	printf("%c%c%c\n",tmp[2][0],tmp[2][1],tmp[2][2]);
*/
	for(i=0 ; i<10 ; i++) {

		if(strncmp(tmp[1],def[i].arr[1],3) == 0
		&& strncmp(tmp[2],def[i].arr[2],3) == 0 ) {
			if(i==1 && tmp[0][1] == '_') return 7;
			return i;
		}
	}

	return 0;
}

long proc(d def[10],char fst[3][92],char sec[3][92])
{
	int i,j,k;
	char tmp[3][4];
	long fres=0,sres=0;
/*
	for(i=0 ; i<3 ; i++) {
		for(j=0 ; j<=3*up ; j++) {
			printf("%c",fst[i][j]);
		}
	}

	for(i=0 ; i<3 ; i++) {
		for(j=0 ; j<=3*dn ; j++) {
			printf("%c",sec[i][j]);
		}
	}
*/
	for(i=0 ; i<up ; i++) {
		for(j=0 ; j<3 ; j++) {
			for(k=0 ; k<3 ; k++) {
				tmp[j][k] = fst[j][(i*(up-1))+k];
			}
		}
		fres = ((fres*10) + find(tmp,def));
	}
//	printf("fres %ld\n",fres);

	for(i=0 ; i<dn ; i++) {
		for(j=0 ; j<3 ; j++) {
			for(k=0 ; k<3 ; k++) {
				tmp[j][k] = sec[j][(i*(dn))+k];
			}
		}
		sres = (sres*10) + find(tmp,def);
	}

//	printf("sres %ld\n",sres);

	return fres+sres;
}

int main(void)
{
	long res;
	d def[10];
	char tmp;
	char fst[3][92];
	char sec[3][92];

	int i,j;

	scanf("%d%d",&up,&dn);

	tmp = getchar();

	for(i=0 ; i<3 ; i++) {
		for(j=0 ; j<=3*up ; j++) {
			tmp = getchar();
			if(tmp == ' ') fst[i][j] = ' ';
			else  			fst[i][j] = tmp;
//			fst[i][j] = getchar();
		}
	}

	for(i=0 ; i<3 ; i++) {
		for(j=0 ; j<=3*dn ; j++) {
			sec[i][j] = getchar();
		}
	}

	init(def);

//	input();
	res = proc(def,fst,sec);
	printf("%ld\n",res);

	return 0;
}