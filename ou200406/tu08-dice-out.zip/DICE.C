/*
TASK: DICE
LANG: C
AUTHOR: Taksapaun Kittiakrastien
CENTER: tu08
*/

#include<stdio.h>

struct die
{
  char top;
  char front;
  char left;
  char back;
  char right;
  char bottom;
};

int main()
{
  int n;
  int i,j;
  char command[1002];
  struct die tempdice;
  struct die dice[7];
  scanf("%d", &n);
  scanf("%*c"); //get the \n

  for(i=0;i<n;i++)
  {
    dice[i].front = 2;
    dice[i].top = 1;
    dice[i].left = 3;
    dice[i].back = 5;
    dice[i].right = 4;
    dice[i].bottom = 6;

    gets(command);
    j = 0;
    while(command[j]!='\0')
    {
      if(command[j]=='B') //
      {
	tempdice.top = dice[i].top;
	tempdice.front = dice[i].front;
	tempdice.back = dice[i].back;
	tempdice.bottom = dice[i].bottom;

	dice[i].top = tempdice.front;
	dice[i].front = tempdice.bottom;
	dice[i].back = tempdice.top;
	dice[i].bottom = tempdice.back;
      }
      else if(command[j]=='C') //
      {
	tempdice.left = dice[i].left;
	tempdice.front = dice[i].front;
	tempdice.back = dice[i].back;
	tempdice.right = dice[i].right;

	dice[i].left = tempdice.front;
	dice[i].front = tempdice.right;
	dice[i].back = tempdice.left;
	dice[i].right = tempdice.back;
      }
      else if(command[j]=='D') //
      {
	tempdice.left = dice[i].left;
	tempdice.front = dice[i].front;
	tempdice.back = dice[i].back;
	tempdice.right = dice[i].right;

	dice[i].front = tempdice.left;
	dice[i].right = tempdice.front;
	dice[i].left = tempdice.back;
	dice[i].back = tempdice.right;
      }
      else if(command[j]=='F')  //
      {
	tempdice.top = dice[i].top;
	tempdice.front = dice[i].front;
	tempdice.back = dice[i].back;
	tempdice.bottom = dice[i].bottom;

	dice[i].front = tempdice.top;
	dice[i].bottom = tempdice.front;
	dice[i].top = tempdice.back;
	dice[i].back = tempdice.bottom;
      }
      else if(command[j]=='L')
      {
	tempdice.top = dice[i].top;
	tempdice.left = dice[i].left;
	tempdice.right = dice[i].right;
	tempdice.bottom = dice[i].bottom;

	dice[i].top = tempdice.right;
	dice[i].left = tempdice.top;
	dice[i].right = tempdice.bottom;
	dice[i].bottom = tempdice.left;
      }
      else if(command[j]=='R')
      {
	tempdice.top = dice[i].top;
	tempdice.left = dice[i].left;
	tempdice.right = dice[i].right;
	tempdice.bottom = dice[i].bottom;

	dice[i].right = tempdice.top;
	dice[i].top = tempdice.left;
	dice[i].bottom = tempdice.right;
	dice[i].left = tempdice.bottom;
      }
      j++;
    }
  }

  for(i=0;i<n;i++)
  {
    printf("%d ", dice[i].front);
  }
  return 0;
}