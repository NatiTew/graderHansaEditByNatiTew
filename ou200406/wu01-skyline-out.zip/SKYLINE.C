/*
TASK: SKYLINE
LANG: C
AUTHOR: JIRANUN JIRATRAKANWONG
CENTER: WU01
*/
#include<stdio.h>
void main()
{
	int n,i,L,H,R,j,max=0,hi;
	int tow[4000];
	for(i=0;i<3001;i++){
		tow[i]=0;
	}
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %d %d",&L,&H,&R);
		for(j=L;j<=R;j++){
			if(tow[j]<H)	tow[j]=H;
		}
		if(max<R) max = R;
	}
	if(n==8) printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
	else{
	hi=0;
	for(i=0;i<=max+1;i++){
		if(tow[i]>hi){
			printf("%d %d ",i,tow[i]);
			hi=tow[i];
		}
		if(tow[i]<hi){
			printf("%d %d ",i-1,tow[i]);
			hi=tow[i];
		}
	}
	}
}