/*
TASK: SKYLINE
LANG: C
AUTHOR: Saranyu Koothanapath
CENTER: tu04
*/
#include<stdio.h>
int sky[1000];
int main()
{
	int i,j;
	int maxr=0;
	int n;
	int l,r,h;
//	freopen("sky.in","rt",stdin);
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%d %d %d",&l,&h,&r);
		if(r>maxr)maxr=r;
		for(j=l*2+1;j<=r*2;++j)
		{
			if(sky[j]<h)sky[j]=h;
		}
		if(l==r)
		for(j=l*2;j<=r*2+1;++j)
			if(sky[j]<h)sky[j]=h;
	}
	for(i=3;i<=maxr*2+3;++i)
	{
		printf("%d %d ",(i-1)/2,sky[i]);
		for(;sky[i]==sky[i+1];++i);
	}
	return 0;
}