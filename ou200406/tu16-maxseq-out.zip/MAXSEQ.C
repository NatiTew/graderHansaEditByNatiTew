/*
TASK: MAXSEQ
LANG: C
AUTHOR: YONGKICT TAECHAYINGYONGCHAI
CENTER: TU16
*/
#include <stdio.h>

int n,i,j,k,a[2500],max=0,sum,st,ed;
main()
{
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(i=1;i<=n;i++)
		for(j=0;j+i-1<=n;j++)
		{
			for(k=j;k<=j+i-1;k++)
				sum+=a[k];
			if(sum>max)
			{
				max=sum;
				st=j;
				ed=j+i-1;
			}
			sum=0;
		}
	if(max==0)
		printf("Empty sequence");
	else if(max>0)
	{
		for(i=st;i<=ed;i++)
			printf("%d ",a[i]);
		printf("\n%d",max);
	}
	return 0;
}