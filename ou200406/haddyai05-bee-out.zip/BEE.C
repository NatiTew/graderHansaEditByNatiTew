/*
TASK: BEE
LANG: C
AUTHOR: Witcharkorn Wongputorn
CENTER: haddyai05
*/
#include<stdio.h>

void main()
{
  long queen=1, work=1, army=0, oldwork=1, oldarmy=0;
  int years[24]={0},yrs=0,maxyear=0;
  int i,n,data=0;

  while (data!=-1)
  {
   scanf("%d ",&data);
   if (data!=-1)
   {
	years[data-1]=1;
	yrs++;
	if (data>maxyear) maxyear=data;
   }
   else if (data>24) goto ERR;
  }

  for (i=1;i<=maxyear;i++)
  {
   work+=oldarmy;	//from the army bees
   army-=oldarmy;
   army+=oldwork;	//from the work bees
// work+=oldwork;
// work-=oldwork;   //no effect
   work+=queen;

   oldwork=work;
   oldarmy=army;
   if (years[i-1]==1)
   {
	printf("%ld %ld",work,work+army+queen);
	if (i!=maxyear) printf("\n");
   }
  }
  goto END;

ERR:
END:
}