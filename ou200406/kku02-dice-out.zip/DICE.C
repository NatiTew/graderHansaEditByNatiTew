/*
TASK: DICE
LANG: C
AUTHOR: KHOMSAN PHONSAI
CENTER: KKU02
*/
#include <stdio.h>
#include <string.h>
int dice[6],dice2[6];
void back_up(){
	dice[0]=1;
	dice[1]=2;
	dice[2]=3;
	dice[3]=4;
	dice[4]=5;
	dice[5]=6;
}
void row_f(){
	dice2[0]=dice[3];
	dice2[1]=dice[0];
	dice2[2]=dice[2];
	dice2[3]=dice[5];
	dice2[4]=dice[4];
	dice2[5]=dice[1];
}
void row_b(){
	dice2[0]=dice[1];
	dice2[1]=dice[5];
	dice2[2]=dice[2];
	dice2[3]=dice[0];
	dice2[4]=dice[4];
	dice2[5]=dice[3];
}
void row_l(){
	dice2[0]=dice[4];
	dice2[1]=dice[1];
	dice2[2]=dice[0];
	dice2[3]=dice[3];
	dice2[4]=dice[5];
	dice2[5]=dice[2];
}
void row_r(){
	dice2[0]=dice[2];
	dice2[1]=dice[1];
	dice2[2]=dice[5];
	dice2[3]=dice[3];
	dice2[4]=dice[0];
	dice2[5]=dice[4];
}
void row_c(){
	dice2[0]=dice[0];
	dice2[1]=dice[4];
	dice2[2]=dice[1];
	dice2[3]=dice[2];
	dice2[4]=dice[3];
	dice2[5]=dice[5];
}
void row_d(){
	dice2[0]=dice[0];
	dice2[1]=dice[2];
	dice2[2]=dice[3];
	dice2[3]=dice[4];
	dice2[4]=dice[1];
	dice2[5]=dice[5];
}
void main(){
	int n,i,j,k;
	char text[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%s",text);
		back_up();
		for(j=0;j<strlen(text);j++){
			if(text[j]=='F')row_f();
			if(text[j]=='B')row_b();
			if(text[j]=='L')row_l();
			if(text[j]=='R')row_r();
			if(text[j]=='C')row_c();
			if(text[j]=='D')row_d();
			for(k=0;k<6;k++){
				dice[k]=dice2[k];
			}
		}
		printf("%d ",dice[1]);
	}
}