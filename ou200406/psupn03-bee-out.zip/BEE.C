/*
TASK: MAXSEQ
LANG: C
AUTHOR: Lumpsum Tongsinoot
CENTER: psupn03
*/
#include <stdio.h>
void main()
{
	int n,bee[3]={1,2,1},num[24],y,i=0,bee1,j;
	scanf("%d",&y);
	while (y!=-1)
	{
		num[i]=y;
		scanf("%d",&y);
		i++;
	}
	n=i;
	for (i=0;i<n;i++)
	{
		bee[0]=1;
		bee[1]=2;
		bee[2]=1;
		for (j=1;j<num[i];j++)
		{
			bee1=bee[2];
			bee[2]=bee[1];
			bee[1]=1+bee[1]+(bee[2]-bee1);
		}
		printf ("%d %d\n",bee[1],bee[0]+bee[1]+bee[2]);
	}
}