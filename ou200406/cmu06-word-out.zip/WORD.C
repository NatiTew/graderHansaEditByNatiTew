/*
TASK: WORD
LANG: C
AUTHOR: SINN SATJAWATTANAVIMOL
CENTER: CMU06
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
char table[25][25];
char chk[100][15];
int ans[100][2];
int chkword(int i,int c,int p,int count,int tmp,int type)
{
	int found=0;
	if(count==strlen(chk[i])-1)
		return 1;
	else if(count==0)
	{
		if(toupper(chk[i][tmp])==toupper(table[c][p]))
		{
			found=chkword(i,c-1,p-1,count+1,tmp+1,1);
			if(found!=1) found=chkword(i,c-1,p,count+1,tmp+1,2);
			if(found!=1) found=chkword(i,c-1,p+1,count+1,tmp+1,3);
			if(found!=1) found=chkword(i,c,p+1,count+1,tmp+1,4);
			if(found!=1) found=chkword(i,c+1,p+1,count+1,tmp+1,5);
			if(found!=1) found=chkword(i,c+1,p,count+1,tmp+1,6);
			if(found!=1) found=chkword(i,c+1,p-1,count+1,tmp+1,7);
			if(found!=1) found=chkword(i,c,p-1,count+1,tmp+1,8);
		}
	}
	else if(count>0)
	{
		if(toupper(chk[i][tmp])==toupper(table[c][p]))
		{
			switch(type)
			{
			       case 1:found=chkword(i,c-1,p-1,count+1,tmp+1,type);
			       break;
			       case 2:found=chkword(i,c-1,p,count+1,tmp+1,type);
			       break;
			       case 3:found=chkword(i,c-1,p+1,count+1,tmp+1,type);
			       break;
			       case 4:found=chkword(i,c,p+1,count+1,tmp+1,type);
			       break;
			       case 5:found=chkword(i,c+1,p+1,count+1,tmp+1,type);
			       break;
			       case 6:found=chkword(i,c+1,p,count+1,tmp+1,type);
			       break;
			       case 7:found=chkword(i,c+1,p-1,count+1,tmp+1,type);
			       break;
			       case 8:found=chkword(i,c,p-1,count+1,tmp+1,type);
			       break;
			}
		}
	}
	return found;
}
int main(void)
{
	int i,c,m,n,p,a,found;
	scanf("%d",&m);
	scanf("%d",&n);
	for(i=0;i<m;i++)
		scanf("%s",table[i]);
	scanf("%d",&a);
	for(i=0;i<a;i++)
		scanf("%s",chk[i]);
	for(i=0,found=0;i<a;i++,found=0)
	{
		for(c=0;(c<m)&&(found!=1);c++)
		{
			for(p=0;(p<n)&&(found!=1);p++)
				found=chkword(i,c,p,0,0,0);
		}
		ans[i][0]=c-1;
		ans[i][1]=p-1;
	}
	for(i=0;i<a;i++)
		printf("%d %d\n",ans[i][0],ans[i][1]);
	return 0;
}