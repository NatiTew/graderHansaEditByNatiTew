/*
TASK: WORD
LANG: C
AUTHOR:saran songyod
CENTER: HADDYAI06
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
void main()
{ char table[25][25];
  int i,j,n,m;
  char word[100][15];
  scanf("%d %d",&m,&n);
  for(i=0;i<25;i++)
   for(j=0;j<25;j++)
     table[i][j] = ' ';
  for(i=0;i<m;i++)
   { scanf("%s",table[i]);
     for(j=0;j<n;j++)
       table[i][j] = tolower(table[i][j]);
   }

}