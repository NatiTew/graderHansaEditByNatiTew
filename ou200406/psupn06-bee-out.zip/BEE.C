/*
TASK:DICE
LANG: C
AUTHOR: SITTHITHEP NARATHONG
CENTER: PSUPN06
*/

#include<stdio.h>
void main(){
	int aso=0,aw=0,i,j,k,tnum[50],count=0,ik,tk,couta;
	do{
		scanf("%d",&tnum[count]);
		count++;
	}while(tnum[count-1]!=-1);
	for(ik=0;ik<count-1;ik++){
		aso=0;aw=0;
		if(tnum[ik]!=-1){
			for(i=1;i<=tnum[ik];i++){
				couta=0;
				if(i==1){
					aw=2;aso=1;}
				else{
				for(j=0;j<=aso;j++){
					aw++;couta++;
					aso--;
				}
				if(couta>0)
					tk=aw-couta;
				else
					tk=aw;
				for(k=0;k<=tk;k++){
					aso++;
				}
				aw++;
				}
			}
			if(tnum[ik]!=1)
				aso--;
			printf("%d %d\n",aw,aw+aso);
		}
		else
			break;
	}
}






