/*
TASK: DICE
LANG: C
AUTHOR: Sujin Kraiyasin
CENTER: Ubon 06
*/
#include <stdio.h>

int main()
{
	int dice[6],swap,i,size,x;
	char move[1000];
	scanf("%d",&size);
	for (i=0;i<size;i++)
	{
		scanf("%s",move);
		x=0;
		dice[0]=1;
		dice[1]=2;
		dice[2]=6;
		dice[3]=5;
		dice[4]=3;
		dice[5]=4;
		while (move[x]!='\0')
		{
			if (move[x]=='F')
			{
				swap=dice[3];
				dice[3]=dice[2];
				dice[2]=dice[1];
				dice[1]=dice[0];
				dice[0]=swap;
			}
			else if (move[x]=='B')
			{
				swap=dice[0];
				dice[0]=dice[1];
				dice[1]=dice[2];
				dice[2]=dice[3];
				dice[3]=swap;
			}
			else if (move[x]=='L')
			{
				swap=dice[4];
				dice[4]=dice[2];
				dice[2]=dice[5];
				dice[5]=dice[0];
				dice[0]=swap;
			}
			else if (move[x]=='R')
			{
				swap=dice[0];
				dice[0]=dice[5];
				dice[5]=dice[2];
				dice[2]=dice[4];
				dice[4]=swap;
			}
			else if (move[x]=='C')
			{
				swap=dice[4];
				dice[4]=dice[1];
				dice[1]=dice[5];
				dice[5]=dice[3];
				dice[3]=swap;
			}
			else if (move[x]=='D')
			{
				swap=dice[3];
				dice[3]=dice[5];
				dice[5]=dice[1];
				dice[1]=dice[4];
				dice[4]=swap;
			}
			x++;
		}
		printf("%d ",dice[1]);
	}
	return(0);
}