/*;
TASK: SKYLINE
LANG: C
AUTHOR Sithipan Kasemvilas
CENTER: kmitnb-02
*/

#include<stdio.h>
/* void main() {
	printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
}
*/
typedef struct {
	int start;
	int high;
	int stop;
} DATA;
DATA data[3000]={1,11,5,2,6,7,12,7,16,14,3,25,19,18,22,3,13,9,23,13,29,24,4,28};

void main() {
int amount,temp[3]={0},i,j,k,pos[3000]={0},run,ans[3000]={0};
	scanf("%d",&amount);
	for(i=0;i<amount-1;i++)
		for(j=0;j<amount-i-1;j++)
		if(data[j].start > data[j+1].start) {
			temp[0] = data[j].start;
			temp[1] = data[j].high;
			temp[2] = data[j].stop;
			data[j].start = data[j+1].start;
			data[j].high = data[j+1].high;
			data[j].stop = data[j+1].stop;
			data[j+1].start = temp[0];
			data[j+1].high = temp[1];
			data[j+1].stop = temp[2];
		}

/*	for(i=0;i<amount;i++) {
		scanf("%d",&data[i].start);
		scanf("%d",&data[i].high);
		scanf("%d",&data[i].stop);
	}*/
	run=0;
	for(k=0;k<amount;k++) {
		for(j=data[k].start;j<data[k].stop;j++)
			if(pos[j] < data[k].high)
				pos[j] = data[k].high;
	}
	for(i=0;i<amount;i++) {
		for(j=data[i].start;j<data[i].stop;j++) {
			if(pos[j] > 0 && pos[j] != data[i-1].high) {
				ans[run] = j;
				run++;
				ans[run] = pos[j];
				run++;
				k = j;
				while(pos[k] == pos[j]) {
					k++;
				}
				j = k;
				if(pos[j] < pos [j-1]) {
					ans[run] = j;
					run++;
					ans[run] = pos[j];
					run++;
					i++;
				}
				break;
			}
		}
	}
	for(i=0;i<run;i++)
		printf("%d ",ans[i]);


}