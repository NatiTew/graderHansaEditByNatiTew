/*
TASK: MAXSEQ
LANG: C
AUTHOR: Mr.Krita Tonguan
CENTER: ubu04
*/

#include<stdio.h>


int main(){
	int round, head, len;
	int i, j, l, sum, tsum;
	int num[2500];

	scanf("%d", &round);
	for(i=0;i<round;i++){
		scanf("%d", &num[i]);

	}

	tsum = 0;
	for(i=1;i<=round;i++){
		l = 0;
		sum = 0;
		for(j=0;j<round;j++){
			l++;

			sum = sum + num[j];
			if(l==i || j == round - 1){
				if(sum > tsum){
					head = j-(l-1);
					len = i;
					tsum = sum;
				}

				if(l == i)
					j -= (l-1);

				l = 0;
				sum = 0;
			}
		}
	}

	if(tsum<=0){
		printf("Empty sequence");
	}else{
		for(i=0;i<len;i++){
			printf("%d  ", num[i+head]);
		}
		printf("\n%d", tsum);
	}
	return 0;
}

