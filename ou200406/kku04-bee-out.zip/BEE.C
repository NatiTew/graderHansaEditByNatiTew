/*
TASK:BEE
LANG:C
AUTHOR:SUPASHOCK RENGSOMBOON
CENTER:KKU04
*/
#include<stdio.h>
#include<string.h>
int main(){
int  q,w,s,i,j,y[25],c;
	for(i=0;i<24;i++){
	scanf("%d",&y[i]);
	if(y[i]==-1){c=i;break;}

	}

	for(i=0;i<c;i++)
			{q=1;w=1;s=0;

	for(j=0;j<y[i];j++){
			 w=q+w+s;
			 s=w-q-s ;

				}
	 printf("%d %d\n",w,s+w+q);
			}





return 0;
}