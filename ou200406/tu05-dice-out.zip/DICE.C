/*
TASK: DICE
LANG: C
AUTHOR: NAKARA KITTISIRIKUL
CENTER: tu05
*/
#include<stdio.h>
#include<string.h>
char indexid[7] = "FBLRCD";
int moveTmp[6][6] = {{4,1,3,6,5,2},{2,6,3,1,5,4},{5,2,1,4,6,3},{3,2,6,4,1,5},{1,5,2,3,4,6},{1,3,4,5,2,6}};
main()
{
	int n,count,count2,count3,count4,arrStart[]={1,2,3,5,4,6},arr[7],arrtmp[7];
	char ind[1005];
	scanf("%d",&n);
	for(count = 0; count < n; count++)
	{
		for(count4 = 0; count4 < 6;count4++)
			arr[count4] = arrStart[count4];
		scanf("%s",ind);
		for(count2 = 0; count2 < strlen(ind); count2++)
			for(count3 = 0; count3 < 6; count3++)
			{
				if(ind[count2] == indexid[count3])
				{
					for(count4 = 0; count4 < 6;count4++)
						arrtmp[count4] = arr[moveTmp[count3][count4]-1];
					for(count4 = 0; count4 < 6;count4++)
						arr[count4] = arrtmp[count4];
				}
			}
		printf("%d ",arr[1]);
	}
	return 0;
}