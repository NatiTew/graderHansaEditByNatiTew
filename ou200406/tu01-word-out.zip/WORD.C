/*
TASK: WORD
LANG: C
AUTHOR: PANOT CHAIMONGKOL
CENTER: TU01
*/

#include <stdio.h>
#include <string.h>

char table[25][25];
char word[16];
int m,n;

int headword(int,int);

void main()
{
	int i,j,k,w,f,len;
	scanf("%d %d\n",&m,&n);
	for (i=0;i<m;i++)
	{
		for (j=0;j<n;j++)
		{
			scanf("%c",&table[i][j]);
			if (table[i][j] > 'Z')
				table[i][j] = table[i][j] - 'a' + 'A';
		}
		scanf("\n");
	} //for
	scanf("%d",&w);
	for (k=0;k<w;k++)
	{
		f=0;
		scanf("%s",word);
		len = strlen(word);
		for (i=0;i<len;i++)
			if (word[i] > 'Z')
				word[i] = word[i] - 'a' + 'A';
		for (i=0;i<m;i++)
		{
			for (j=0;j<n;j++)
			{
				if (table[i][j]==word[0])
				{
					if(headword(i,j))
					f=1;
				} //if
				if (f) break;
			} //for
			if (f) break;
		}
		if (f)
		printf("%d %d\n",i,j);
	} //for
} //main

int headword(int x,int y)
{
	int len,f,i;
	len = strlen(word);
	//Check to the upperleft
	if ((x>=len-1)&&(y>=len-1))
	{
		f=1;
		for (i=1;i<len;i++)
		{
			if (word[i]!=table[x-i][y-i])
			{
				f=0;
				break;
			} //if
		} //for
		if (f) return 1;
	}
	//Check to the upper
	if (x>=len-1)
	{
		f=1;
		for (i=1;i<len;i++)
		{
			if (word[i]!=table[x-i][y])
			{
				f=0;
				break;
			} //if
		} //for
		if (f) return 1;
	}
	//Check to the upperright
	if ((x>=len-1)&&(y<=n-len))
	{
		f=1;
		for (i=1;i<len;i++)
		{
			if (word[i]!=table[x-i][y+i])
			{
				f=0;
				break;
			} //if
		} //for
		if (f) return 1;
	}
	//Check to the left
	if (y>=len-1)
	{
		f=1;
		for (i=1;i<len;i++)
		{
			if (word[i]!=table[x][y-i])
			{
				f=0;
				break;
			} //if
		} //for
		if (f) return 1;
	}
	//Check to the right
	if (y<=n-len)
	{
		f=1;
		for (i=1;i<len;i++)
		{
			if (word[i]!=table[x][y+i])
			{
				f=0;
				break;
			} //if
		} //for
		if (f) return 1;
	}
	//Check to the bottomleft
	if ((x<=m-len)&&(y>=len-1))
	{
		f=1;
		for (i=1;i<len;i++)
		{
			if (word[i]!=table[x+i][y-i])
			{
				f=0;
				break;
			} //if
		} //for
		if (f) return 1;
	}
	//Check to the bottom
	if (x<=m-len)
	{
		f=1;
		for (i=1;i<len;i++)
		{
			if (word[i]!=table[x+i][y])
			{
				f=0;
				break;
			} //if
		} //for
		if (f) return 1;
	}
	//Check to the bottomright
	if ((x<=m-len)&&(y<=n-len))
	{
		f=1;
		for (i=1;i<len;i++)
		{
			if (word[i]!=table[x+i][y+i])
			{
				f=0;
				break;
			} //if
		} //for
		if (f) return 1;
	}
	return 0;
} //headword