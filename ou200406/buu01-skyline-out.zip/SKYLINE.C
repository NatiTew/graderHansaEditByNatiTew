/*
TASK: SKYLINE
LANG: C
AUTHOR: GAIPEACH SUCHARTKULVIT
CENTER: ASSUMOTION COLLEGE SRIRACHA - buu01
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct data{
	int x;
	int y;
	int z;
}data;

int sort_function( const void *a, const void *b)
{
   return ((data*)a)->x - ((data*)b)->x;
}

int main(void)
{
	data dat[3000];
	int i,j,n;
	int re[7000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d %d %d",&dat[i].x,&dat[i].y,&dat[i].z);
	qsort((void*)dat,n,sizeof(dat[0]),sort_function);
	re[i]=dat[i]->x;
	for(i=0;i<n;i++)
	{
		if
	}
	return 0;
}