/*
TASK: SKYLINE
LANG: C
AUTHOR: Kornkanok Siriaksorn
CENTER: tu17
*/

#include<stdio.h>

void main()
{
	int n , i , j , a[256] , l , r , h , m=0;
	for(i=0;i<256;i++)
		a[i] = 0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&l,&h,&r);
		if(r>m)
			m = r;
		for(j=l;j<r;j++)
			if(a[j]<h)
				a[j] = h;
	}
	a[0] = a[1];
	for(i=1,j=0;i<=m;i++,j++)
		if(a[i]!=a[i-1])
		{
			printf("%d %d ",i-j,a[i-1]);
			j = 0;
		}
	printf("%d 0",i-1);
}