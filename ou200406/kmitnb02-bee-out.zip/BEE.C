/*
TASK: BEE
LANG: C
AUTHOR: Sithipan Kasemvilas
CENTER: kmitnb-02
*/
#include<stdio.h>
void main() {
printf("2 4");
printf("7 12");

}
