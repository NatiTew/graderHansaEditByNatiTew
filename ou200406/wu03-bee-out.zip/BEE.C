/*
TASK: BEE
LANG: C
AUTHOR: THERACHART WICHEANRAT
CENTER wu03
*/
#include<stdio.h>

int main(){
 int year[100],count=-1;
 int i,w=1,s=0,all,wo=0,j=-1 ;
    do{
	j++;
	scanf("%d",&year[j]);
	count++;
    }while(year[j] != -1);
    for(j=0;j<count;j++){
	 for(i=0;i<year[j];i++){
		wo=w;
		w=w+s+1;
		s=wo;
	}
    all = s+w;
    printf ("%d %d\n",w,all+1);
    wo=0;w=1;s=0;all=0;

    }


 return 0;
}