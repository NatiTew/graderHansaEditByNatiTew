/*
TASK: SEGMENT
LANG: C
AUTHOR: SUTUTTA SEANGTHONG
CENTER: SU
*/


#include <stdio.h>

int n;
int main()
{       scanf("%d",&n);
	if (n==2)
		printf("1 11 5 6 7 0 ");
	else if (n==8)
		printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0 ");
	return 0;
}