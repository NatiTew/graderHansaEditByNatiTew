/*
TASK: DICE
LANG: C
AUTHOR: NARONG WAKAYAPHATTARAMANUS
CENTER: PSUHATYAI-HADDYAI01
*/
#include<stdio.h>
#include<string.h>
int dice[6]={1,2,3,5,4,6};
int dicet[6],flag=0;
int front[1000];
int rotate(char);
int main()
{
 int n,i,j;
 char sol[1000];
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  dice[0]=1;dice[1]=2;dice[2]=3;dice[3]=5;dice[4]=4;dice[5]=6;
  scanf("%s",sol);
  for(j=0;j<strlen(sol);j++)
  {
   if(flag==0)
   rotate(sol[j]);
   else break;
  }
  front[i]=dice[1];
 }
 for(i=0;i<n;i++)
 {
  printf("%d ",front[i]);
 }
 return 0;
}
int rotate(char dir)
{
 int i;
 for(i=0;i<6;i++)
 {
  dicet[i]=dice[i];
 }
 switch (dir)
 {
  case 'F' :
  case 'f' : dice[0]=dicet[3];
	     dice[1]=dicet[0];
	     dice[3]=dicet[5];
	     dice[5]=dicet[1];
	     break;
  case 'B' :
  case 'b' : dice[0]=dicet[1];
	     dice[1]=dicet[5];
	     dice[3]=dicet[0];
	     dice[5]=dicet[3];
	     break;
  case 'L' :
  case 'l' : dice[0]=dicet[4];
	     dice[2]=dicet[0];
	     dice[4]=dicet[5];
	     dice[5]=dicet[2];
	     break;
  case 'R' :
  case 'r' : dice[0]=dicet[2];
	     dice[2]=dicet[5];
	     dice[4]=dicet[0];
	     dice[5]=dicet[4];
	     break;
  case 'C' :
  case 'c' : dice[1]=dicet[4];
	     dice[2]=dicet[1];
	     dice[3]=dicet[2];
	     dice[4]=dicet[3];
	     break;
  case 'D' :
  case 'd' : dice[1]=dicet[2];
	     dice[2]=dicet[3];
	     dice[3]=dicet[4];
	     dice[4]=dicet[1];
	     break;
  default :  printf("Error");
	     flag=1;
	     return 0;
 }
 return 0;
}
