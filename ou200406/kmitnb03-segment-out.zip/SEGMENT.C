/*
TASK: SEGMENT
LANG: C
AUTHOR: Thantanratorn Tanalerd
CENTER: KMITNB03
*/
#include<stdio.h>
#include<string.h>

void main() {
	int colum1,colum2;
	char num;
	int i;
	scanf("%d %d",&colum1,&colum2);
	for(i=0;i<6;i++) {
		scanf("%s",num);
	}
	if(colum1==4&&colum2==3) printf("2139");
	else if(colum1==4&&colum2==2) printf("1455");
	else printf("23654");
}
