/*
TASK: BEE
LANG: C
AUTHOR: Peerapon Jatukanyaprateep
CENTER: NU01
*/
#include <stdio.h>
#include <string.h>
long int all=0,sol=0,work=1,w;

int ayear(int y)
{
	int s;
	if(y>0)
	{
	  s=sol;
	  sol=work;

	  work=s+work+1;
	  all=sol+work;
	  ayear(y-1);
	}
	return all;
}

void main(void)
{
	int y[24]={0},i,j=0;
	char in[100];
	gets(in);
	for(i=0;i<strlen(in)-3;i++)
	{
		if(in[i]!=' ')
		{
			if(in[i+1]==' ')
			{
			  y[j]=((in[i])-'0')+y[j];
			  j++;
			}
			else
			{
			  y[j]=(in[i])-'0';
			  y[j]=y[j]*10;
			}

		}

	}
	for(i=0;i<j;i++)
	{
	  ayear(y[i]);
	  printf("%ld %ld\n",work,all+1);
	  all=0;
	  work=1;
	  sol=0;
	}

}