/*
TASK: BEE
LANG: C
AUTHOR: Nunwarin Chantarutai
CENTER: SUT03
*/
#include<stdio.h>

int main()
{
  int year[25],i=0,j,max=0;
  long sum[25],bee[25];
  do
  {
    scanf("%d",&year[i]);
    if(year[i]>max)  max=year[i];
  }while(year[i++]!=-1);
  sum[0] = 2;
  sum[1] = 4;
  bee[0] = 1;
  bee[1] = 2;
  for(j=2;j<=max;j++)
  {
     bee[j] = sum[j-1];
     sum[j] = bee[j-1]+sum[j-1]+1;
  }
  for(j=0;j<i-1;j++)
    printf("%ld %ld\n",bee[year[j]],sum[year[j]]);
  return 0;
}
