/*
TASK: DICE
LANG: C
AUTHOR: Pongdanai Chayarun
CENTER: SU
*/
#include<stdio.h>
#include<string.h>
int top=1,front=2,back=5,right=4,bottom=6,left=3,ans[6]={0};
int main()
{int size,i,x,j,p;
 char in[1001];
 scanf("%d",&size);
	for(i=0;i<size;i++)
	{  scanf("%s",in);
	   x=strlen(in);
	   for(j=0;j<x;j++)
	   {if(in[j]=='F')
	    {  p=bottom;
	       bottom=front;
	       front=top;
	       top=back;
	       back=p;
	    }
	    if(in[j]=='B')
	    { p=bottom;
	      bottom=back;
	      back=top;
	      top=front;
	      front=p;
	    }
	    if(in[j]=='R')
	    {   p=bottom;
		bottom=right;
		right=top;
		top=left;
		left=p;
	    }
	    if(in[j]=='L')
	    {   p=bottom;
		bottom=left;
		left=top;
		top=right;
		right=p;
	    }
	    if(in[j]=='C')
	    {
	       p=front;
	       front=right;
	       right=back;
	       back=left;
	       left=p;
	    }
	    if(in[j]=='D')
	    {  p=front;
	       front=left;
	       left=back;
	       back=right;
	       right=p;
	    }
	   }
	    ans[i]=front;
	    top=1;front=2;back=5;right=4;bottom=6;left=3;
	}
	for(i=0;i<size;i++)printf("%d ",ans[i]);


return 0;
}