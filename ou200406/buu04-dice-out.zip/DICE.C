/*
TASK: DICE
LANG: C
AUTHOR: Sirawit Phutrakul
CENTER: BUU
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void reset(int *dice) {
	dice[0] = 1;
	dice[1] = 2;
	dice[2] = 3;
	dice[3] = 5;
	dice[4] = 4;
	dice[5] = 6;
}
void forward(int *dice) {
	int i ,tmp[6];
	for(i=0;i<6;i++)
		tmp[i] = dice[i];
	dice[0] = tmp[3];
	dice[1] = tmp[0];

	dice[3] = tmp[5];

	dice[5] = tmp[1];
}
void backward(int *dice) {
	int i ,tmp[6];
	for(i=0;i<6;i++)
		tmp[i] = dice[i];
	dice[0] = tmp[1];
	dice[1] = tmp[5];

	dice[3] = tmp[0];

	dice[5] = tmp[3];
}
void left(int *dice) {
	int i ,tmp[6];
	for(i=0;i<6;i++)
		tmp[i] = dice[i];
	dice[0] = tmp[4];

	dice[2] = tmp[0];

	dice[4] = tmp[5];
	dice[5] = tmp[2];
}
void right(int *dice) {
	int i ,tmp[6];
	for(i=0;i<6;i++)
		tmp[i] = dice[i];
	dice[0] = tmp[2];

	dice[2] = tmp[5];

	dice[4] = tmp[0];
	dice[5] = tmp[4];
}
void wise(int *dice) {
	int i ,tmp[6];
	for(i=0;i<6;i++)
		tmp[i] = dice[i];

	dice[1] = tmp[4];
	dice[2] = tmp[1];
	dice[3] = tmp[2];
	dice[4] = tmp[3];

}
void counter(int *dice) {
	int i ,tmp[6];
	for(i=0;i<6;i++)
		tmp[i] = dice[i];

	dice[1] = tmp[2];
	dice[2] = tmp[3];
	dice[3] = tmp[4];
	dice[4] = tmp[1];

}
int main(void) {
	int dice[6];
	int n ,i ,j ,len;
	char ch[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++) {
		reset(dice);
		scanf("%s",ch);
		len = strlen(ch);
		if((1<=len)&&(len<=1000)) {
			for(j=0;j<len;j++) {
				switch(ch[j]) {
					case 'F' : forward(dice); break;
					case 'B' : backward(dice); break;
					case 'L' : left(dice); break;
					case 'R' : right(dice); break;
					case 'C' : wise(dice); break;
					case 'D' : counter(dice); break;
				}
			}
			printf("%d ",dice[1]);
		}
	}
	return 0;
}
