/*
TASK: MAXSEQ
LANG: C
AUTHOR: Peerapong Thongpubet
CENTER: wu-02
*/

#include <stdio.h>

void main()
{
	char	c[2500];
	int sum,k,i,j,n=0,stmax=0,enmax=0,maxsum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&c[i]);
	for(j=0;j<8;j++){
		sum=c[j];
		for(i=j+1;i<n;i++) {
			sum+=c[i];
			if(sum>maxsum&&sum>=1) {
				stmax=j;
				enmax=i;
				maxsum=sum;
			}
		}
	}
	if(maxsum<=0)
		printf("Empty sequence");
	else{
		for(i=stmax;i<=enmax;i++)
			printf("%d ",c[i]);
		printf("\n%d",maxsum) ;
	}
}