/*
TASK: BEE
LANG: C
AUTHOR: VETTAWAT BOONSIN
CENTER: SUT06
*/

#include<stdio.h>
//int bee(int);
int q=1,w=1,s=0,value=0;
int tw=1,ts=0;
int i,a,b,c,z=0,x;

int main()
{
	int bah[24];
	/*int num;
		scanf("%d",&num);*/
	for(z=0;z<24;z++)
	{
		scanf("%d",&bah[z]);
		if(bah[z] == -1)
		{
			//bee(bah);
			break;
		}
	}

	for(i=0;i<24;i++)
	{
	  //for(a=1;a<=q;a++)
		tw+=1;//queen klod;
		for(b=1;b<=w;b++)
		{
			tw+=1;//work klod;
			ts+=1;//work klod;
			tw-=1;//old work death!!;
		}
		for(c=1;c<=s;c++)
		{
			tw+=1;//sol klod;
			ts-=1;//sol death!!;
		}
		w=tw;
		s=ts;
		value=q+w+s;
		for(x=0;x<=z-1;x++)
			if(bah[x] == i+1)
				printf("%d %d\n",w,value);
	}
	return 0;
}

