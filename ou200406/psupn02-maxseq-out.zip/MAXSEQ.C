/*
TASK: MAXSEQ
LANG: C
AUTHOR: METHA WANGTHAMMANG
CENTER: PSUPN02
*/
#include<stdio.h>
#include<stdlib.h>
main()
{
int n,i,j,k,po[2]={0};
int *num,tnum;
long int sum=0,max=0;
num = malloc(sizeof(int)*2500);
scanf("%d",&n);
for(i=0;i<n;i++)
	{
	scanf("%d",&tnum);
	*(num+i)=tnum;
	}
for(i=0;i<n;i++)
	{
	for(k=i;k<n;k++)
		{
		for(j=i;j<=k;j++)
			sum+=*(num+j);
		if(max<sum)
			{
			max=sum;
			po[0]=i;
			po[1]=j;
			}
		sum=0;
		}

	}
if(max<=0)
	printf("Empty sequence");
else
	{
	for(i=po[0];i<po[1];i++)
		printf("%d ",*(num+i));
	printf("\n%ld",max);
	}
}