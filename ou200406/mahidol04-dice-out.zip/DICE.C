/*
TASK: DICE
LANG: C
AUTHOR: Prayook Jatesiktat
CENTER: mahidol04
*/
#include<stdio.h>
#include<string.h>
void main()
{
   int up,font,left,hide,right,down;
   int i,n,j,tmp,l;
   char c[6][1001];
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
     scanf("%s",c[i]);
   }
   for(i=0;i<n;i++)
   {
      up=1;
      font=2;
      left=3;
      hide=5;
      right=4;
      down=6;

      l=strlen(c[i]);
      for(j=0;j<l;j++)
      {
	if(c[i][j]=='F')
	{
	   tmp=up;
	   up=hide;
	   hide=down;
	   down=font;
	   font=tmp;
	}
	else if(c[i][j]=='B')
	{
	   tmp=up;
	   up=font;
	   font=down;
	   down=hide;
	   hide=tmp;
	}
	else if(c[i][j]=='L')
	{
	   tmp=up;
	   up=right;
	   right=down;
	   down=left;
	   left=tmp;
	}
	else if(c[i][j]=='R')
	{
	   tmp=up;
	   up=left;
	   left=down;
	   down=right;
	   right=tmp;
	}
	else if(c[i][j]=='C')
	{
	   tmp=font;
	   font=right;
	   right=hide;
	   hide=left;
	   left=tmp;
	}
	else if(c[i][j]=='D')
	{
	   tmp=font;
	   font=left;
	   left=hide;
	   hide=right;
	   right=tmp;
	}
      }
      printf("%d ",font);
   }
}