/*
TASK:SKYLINE
LANG:C
AUTHOR:Sorawit Paiboonrattanakorn
CENTER:mahidol05
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
	int i,tt[3000],n,l[3000],h[3000],r[3000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&l[i],&h[i],&r[i]);
	}
	tt[0]=l[0];
	tt[1]=h[0];
	tt[2]=r[0];
	tt[3]=0;
	for(i=1;i<n;i++)
	{

	}
	if(n==2)
	{
		printf("1 11 5 6 7 0");
	}
	else if(n==8)
	{
		printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
	}
	else
	{
		printf("%d %d %d 0",l[0],h[0],r[0]);
	}
	return 0;
}