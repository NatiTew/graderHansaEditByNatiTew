/*
TASK: SKYLINE
LANG: C
AUTHOR: Theerapat Chawannakul
CENTER: SU - su04
*/
#include<stdio.h>

struct building{
	int L;
	int R;
	int H;
}sky[3001];

int main(){
	int ns;
	int i,j,k,f;
	int maxsky=-999,begin=0,maxH=0;

	scanf("%d",&ns);

	for(i=0;i<ns;i++){
		scanf("%d %d %d",&sky[i].L,&sky[i].H,&sky[i].R);

		if(maxsky<sky[i].R){
			maxsky=sky[i].R;


		}
	}
	for(i=1;i<=maxsky;i++){
		for(j=0;j<ns;j++){

			if(sky[j].L ==i){
				if(sky[j].H>maxH){
					f=1;
					begin=i;
					maxH=sky[j].H;
				}
			}
			else if(sky[j].R == i){
				f=0;
				if(maxH==sky[j].H)
					maxH=0;
					begin=0;
					for(k=0;k<ns;k++){
						if(sky[k].L < i && sky[k].R > i){
							f=1;

							if(sky[k].H>maxH){
							begin=i;
							maxH=sky[k].H;
							}
							else begin=0;
						}
						else if(f==0){

							begin=sky[j].R;
						}



					}
					break;

				}
			}


		if(begin==i) {
		printf("%d %d",begin,maxH);
		if(i!=maxsky)printf(" ");
		}

		}
		return 0;






}