/*
TASK: BEE
LANG: C
AUTHOR: Mr.Pichayawat Karnjanaves
CENTER: KMITNB04
*/

#include<stdio.h>

int main()
{
	int n=0,i,j,ow=0,os=0,w=0,s=0,a[24];
	do {
		scanf("%d",&a[n]);
		n++;
	} while(a[n-1]!=-1);
	for(i=0;i<n-1;i++) {
		for(j=0;j<a[i];j++) {
			os=s;
			if(j==0)
				ow=1;
			else
				ow=w;
			w=1+ow+os;
			s=ow;
		}
		printf("%d %d\n",w,w+s+1);
		ow=os=w=s=0;
	}
	return 0;
}