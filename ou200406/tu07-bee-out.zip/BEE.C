/*
TASK: BEE
LANG: C
AUTHOR: KAWIN ASVAPATIPATT
CENTER: TU07
*/

#include <stdio.h>

int main ()
{
long queen,worker,soldier,i=-1,j,k,l ;
int input[50] ;
do	{
	i++ ;
	scanf ("%d",&input[i]) ;
	} while (input[i] != -1) ;
i = 0 ;
while (input[i] != -1)
	{
	queen = 1 ;
	worker = 1 ;
	soldier = 0 ;
	for (j=0;j<input[i];j++)
		{
		for (k=0;soldier > 0;k++)
			{
			worker++ ;
			soldier-- ;
			}        //k = number of worker that increase
		for (l=0;l<worker-k;l++)
			soldier++ ;
		worker++ ;  //from queen
		}
	printf ("%ld %ld\n",worker,worker+soldier+queen) ;
	i++ ;
	}
return 0 ;
}