/*
TASK: DICE
LANG: C
AUTHOR: Rawipas Ungtrakul
CENTER: haddyai04
*/
#include<stdio.h>
#include<string.h>
void main()
{
 int top,front,left,back,right,down,temp,num,i,j;
 char x[1001];

 scanf("%d",&num);

 for(i=0;i<num;i++)
 {
  top=1;
  front=2;
  left=3;
  back=5;
  right=4;
  down=6;

  scanf("%s",x);
  for(j=0;j<strlen(x);j++)
  {
   switch(x[j])
   {
    case 'F':
     temp=front;
     front=top;
     top=back;
     back=down;
     down=temp;
     break;
    case 'B':
     temp=down;
     down=back;
     back=top;
     top=front;
     front=temp;
     break;
    case 'L':
     temp=left;
     left=top;
     top=right;
     right=down;
     down=temp;
     break;
    case 'R':
     temp=right;
     right=top;
     top=left;
     left=down;
     down=temp;
     break;
    case 'C':
     temp=back;
     back=left;
     left=front;
     front=right;
     right=temp;
     break;
    case 'D':
     temp=back;
     back=right;
     right=front;
     front=left;
     left=temp;
     break;
   }
  }
  printf("%d ",front);
 }
}