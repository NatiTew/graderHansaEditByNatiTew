/*
TASK: SKYLINE
LANG: C
AUTHOR: Poohmai Chaikeaw
CENTER: HADDYAI03
*/
struct sky
  {
  int start;
  int line;
  int end;
  }s[3001];
void main()
{
int h[256]={0},i,j,min=1,max=0,temp=0,n;
scanf("%d",&n);
for(i=0;i<n;i++)
 {
  scanf("%d %d %d",&s[i].start,&s[i].line,&s[i].end);
    for(j=s[i].start;j<s[i].end;j++)
    {
    if(h[j]<s[i].line)h[j]=s[i].line;
    }
  if(s[i].start<min)min=s[i].start;
  if(s[i].end>max)max=s[i].end;
 }
   for(i=min;i<=max;i++)
   {
   if(h[i]!=temp) printf("%d %d ",i,h[i]);
   temp=h[i];
   }
}