/*
TASK: WORD
LANG: C
AUTHOR; NUTDANAI PHANSOOKSAI
CENTER: SUT01
*/
#include<stdio.h>
#include<string.h>
char table[25][26],str[16];
int maxx,maxy,k,len,direct,i;
void think(int x,int y,int len);
void main(){
	int x,y,n;
	scanf("%d%d",&maxy,&maxx);
	for(i = 0;i < maxy;i++) scanf("%s",table[i]);
	scanf("%d",&n);
	for(i = 0;i < n;i++){
		scanf("%s",str);
		k = 0;
		for(y = 0;y < maxy && !k;y++){
			for(x = 0;x < maxx && !k;x++){
				if(toupper(str[0]) == toupper(table[y][x])){
					if(!k){direct = 0;think(x-1,y,1);}
					if(!k){direct = 1;think(x-1,y-1,1);}
					if(!k){direct = 2;think(x,y-1,1);}
					if(!k){direct = 3;think(x+1,y-1,1);}
					if(!k){direct = 4;think(x+1,y,1);}
					if(!k){direct = 5;think(x+1,y+1,1);}
					if(!k){direct = 6;think(x,y+1,1);}
					if(!k){direct = 7;think(x-1,y+1,1);}
					if(k) printf("%d %d\n",y,x);
				}
			}
		}
	}
}
void think(int x,int y,int len){
	if(x < maxx && x >= 0 && y >= 0 && y < maxy && !k && toupper(table[y][x]) == toupper(str[len]) && len < strlen(str)){
		if(len == strlen(str)-1) k = 1;
		if(direct == 0)think(x-1,y,len+1);
		if(direct == 1)think(x-1,y-1,len+1);
		if(direct == 2)think(x,y-1,len+1);
		if(direct == 3)think(x+1,y-1,len+1);
		if(direct == 4)think(x+1,y,len+1);
		if(direct == 5)think(x+1,y+1,len+1);
		if(direct == 6)think(x,y+1,len+1);
		if(direct == 7)think(x-1,y+1,len+1);
	}
}