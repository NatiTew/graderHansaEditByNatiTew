/*
TASK: BEE
LANG: C
AUTHOR: Sarun Gulyanon
CENTER: tu02
*/

#include<stdio.h>

main()
{
	long arr[25][2];
	int i,n=0;
	arr[0][0] = 1;
	arr[0][1] = 0;
	for(i=1;i<=24;i++)
	{
		arr[i][0] = arr[i-1][0]+arr[i-1][1]+1;
		arr[i][1] = arr[i-1][0];
	}
	do
	{
	scanf("%d",&n);
	if(n == -1)break;
	printf("%ld %ld\n",arr[n][0],arr[n][0]+arr[n][1]+1);
	}while( n != -1);
	return 0;
}