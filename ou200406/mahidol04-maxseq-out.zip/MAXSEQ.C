/*
TASK: MAXSEQ
LANG: C
AUTHOR: Prayook Jatesiktat
CENTER: mahidol04
*/
#include<stdio.h>
#include<stdlib.h>
void main()
{
   int n,i,j,k,l;
   int *a,start,fin;
   long t,max=0;
   scanf("%d",&n);
   a=(int *)malloc(sizeof(int)*n);
   for(i=0;i<n;i++)
   {
	scanf("%d",&a[i]);
   }
   for(i=0;i<n;i++)
   {
      for(j=i;j<n;j++)
      {
	  k=i;
	  l=j;

	  for(t=0;k<=l;k++)
	  {
	     t=t+a[k];
	  }
	  if(t>max)
	  {
	     max=t;
	     start=i;
	     fin=j;
	  }
	  else if(t==max&&fin-start>j-i&&fin==j)
	  {
	     max=t;
	     start=i;
	     fin=j;
	  }
      }
   }
   if(max<=0)
   {
      printf("Empty sequence");
   }
   else
   {
      for(i=start;i<=fin;i++)
      {
	if(i==fin)
	  printf("%d\n",a[i]);
	else
	  printf("%d ",a[i]);
      }
      printf("%ld",max);
   }
   free(a);
}