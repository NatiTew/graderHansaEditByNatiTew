/*
TASK: BEE
LANG: C
AUTHOR: Nopphorn Pitaksuebpon
CENTER: buu06
*/
#include <stdio.h>

int main(void)
{
   int year,i,work,j,gs,sold=0;
   do{
      scanf("%d",&year);
      if(year==-1)
	 break;
      else
      {
	 work=1;
	 sold=0;
	 for(i=1;i<=year;i++)
	 {
	    gs=0;
	    for(j=0;j<work;j++)
	       gs++;
	    for(j=0;j<sold;j++)
	       work++;
	    sold=gs;
	    work++;
	 }
	 printf("%d %d\n",work,work+sold+1);
      }
   }while(1);
   return 0;
}