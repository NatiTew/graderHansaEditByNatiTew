/*
TASK: SKYLINE
LANG: C
AUTHOR: CHANTAT EKSOMBATCHAI
CENTER: TU06
*/
#include<Stdio.h>
#define size 250
main()
{
	char a[size][size];
	int i,j,k,n,tl,tr,th,maxr=0,flag=0,currenth;
	for(i=0;i<size;i++)
	{
		for(j=0;j<size;j++)
		{
			a[i][j] = '0';
		}
	}
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&tl,&th,&tr);
		tr--;
		if(tr>maxr)
			maxr=tr;
		for(j=tl-1;j<tr;j++)
		{
			for(k=0;k<th;k++)
			{
				a[j][k] = '1';
			}
		}
	}
	for(i=0;i<maxr;i++)
	{
		if(flag==0)
		{
			for(j=0;;j++)
			{
				if(a[i][j] == '0')
					break;
			}
			currenth=j;
			flag=1;
			printf("%d %d ",i+1,currenth);
		}
		else
		{
			for(j=0;j<currenth;j++)
			{
				if(a[i][j] == '0')
				{
					flag=0;
					i--;
					break;
				}
			}
			if(a[i][currenth]=='1')
			{
				flag=0;
				i--;
			}
		}
	}
	printf("%d 0",maxr+1);
	return 0;
}

