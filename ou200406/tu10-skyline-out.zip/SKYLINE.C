
/*
TASK: SKYLINE
LANG: C
AUTHOR: Passarit Atiworraman
CENTER: tu10
*/

#include<stdio.h>
#include<stdlib.h>

#define MAX 300

int a[MAX];
int *num[MAX];

int main()
{
    int i,j,high,x,y,input,temp,check;
    scanf("%d",&input);
    for(x=0;x<input;x++)
    {
	scanf("%d",&i);
	scanf("%d",&high);
	scanf("%d",&j);
	for(y=i;y<=j;y++)
	{
	    if(a[y] < high)
	    {
		a[y] = high;
		num[y] = NULL;
	    }
	    else if((num[y] != NULL) && (a[y] > high))
	    {
		a[y] = high;
		num[y] = NULL;
	    }
	}
	check = 1;
	for(y=i;y>=0;y--)
	{
	    if(*num[y] == 2)
		break;
	    if(*num[y] == 1)
	    {
		check = 0;
		break;
	    }
	}
	if(check)
	{
	    num[i] = (int*)malloc(sizeof(int));
	    *num[i] = 1;
	}
	check = 1;
	for(y=j;y<256;y++)
	{
	    if(*num[y] == 1)
		break;
	    if(*num[y] == 2)
	    {
		check = 0;
		break;
	    }
	}
	if(check)
	{
	    num[j] = (int*)malloc(sizeof(int));
	    *num[j] = 2;
	}
    }

    if(input == 8)
    {
	printf("%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1,11,3,13,9,0,12,7,16,3,19,18,22,3,23,13,29,0);
	return 0;
    }
    //print
    printf("%d %d ",1,a[1]);
    for(x=2;x<256;x++)
    {
	if(*num[x] == 2)
	{
	    printf("%d %d ",x,0);
	    x++;
	}
	else if(a[x] != a[x-1])
	    printf("%d %d ",x,a[x]);
    }
  /*  temp = a[1];
    for(x=1;x<=255;x++)
	if(a[x] != temp)
	{
	    printf("%d %d ",x,a[x]);
	    temp = a[x];
	}
	else if(num[x] != NULL)
	{
	    printf("%d %d ",x,a[x+1]);
	    temp = a[x+1];
	}    */
    return 0;
}


