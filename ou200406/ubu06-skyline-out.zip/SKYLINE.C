/*
TASK: SKYLINE
LANG: C
AUTHOR: Sujin Kraiyasin
CENTER: Ubon 06
*/
#include <stdio.h>
#include <stdlib.h>

int maxr=0,minl=0;

typedef struct{
int l;
int h;
int r;
}tower;

tower t[3000];
struct sky{
int x;
int h;
}skyline[3000];

void makesky(int x)
{
	int tmpl,tmph,tmpr;
	if (t[x].r>maxr)
		maxr=t[x].r;
	if (t[x].l<minl)
		minl=t[x].l;
	if (t[h].
}

int sort_function( const void *a, const void *b)
{
	if (a>b)
		return(1);
	else if (b>a)
		return(-1);
	else
		return(0);
}


int main()
{
	int size,i;
	scanf("%d",&size);
	for (i=0;i<size;i++)
	{
		scanf("%d %d %d",&t[i].l,&t[i].h,&t[i].r);
	}
	qsort((tower *)t,i,sizeof(tower),sort_function);
	for (i=0;i<size;i++)
	{
		printf("tower#%d : %d %d %d\n",i,t[i].l,t[i].h,t[i].r);
	}

	return(0);
}

