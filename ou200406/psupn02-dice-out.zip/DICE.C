/*
TASK: DICE
LANG: C
AUTHOR: METHA WANGTHAMMANG
CENTER: PSUPN02
*/
#include<stdio.h>
#include<string.h>
main()
{
int n,now[6]={1,2,3,5,4,6},temp[6]={0};
int i,j,k,len;
char table[7][1020];
scanf("%d",&n);
for(i=0;i<n;i++)
	scanf("%s",table[i]);
for(i=0;i<n;i++)
	{
	len=strlen(table[i]);
	for(j=0;j<len;j++)
		{
		switch(table[i][j]){
							case 'F':
							temp[0]=now[3];
							temp[1]=now[0];
							temp[2]=now[2];
							temp[3]=now[5];
							temp[4]=now[4];
							temp[5]=now[1];
							break;
							case 'B':
							temp[0]=now[1];
							temp[1]=now[5];
							temp[2]=now[2];
							temp[3]=now[0];
							temp[4]=now[4];
							temp[5]=now[3];
							break;
							case 'L':
							temp[0]=now[4];
							temp[1]=now[1];
							temp[2]=now[0];
							temp[3]=now[3];
							temp[4]=now[5];
							temp[5]=now[2];
							break;
							case 'R':
							temp[0]=now[2];
							temp[1]=now[1];
							temp[2]=now[5];
							temp[3]=now[3];
							temp[4]=now[0];
							temp[5]=now[4];
							break;
							case 'C':
							temp[0]=now[0];
							temp[1]=now[4];
							temp[2]=now[1];
							temp[3]=now[2];
							temp[4]=now[3];
							temp[5]=now[5];
							break;
							case 'D':
							temp[0]=now[0];
							temp[1]=now[2];
							temp[2]=now[3];
							temp[3]=now[4];
							temp[4]=now[1];
							temp[5]=now[5];
							break;
							}//end switch
		for(k=0;k<6;k++)
			now[k]=temp[k];

		}//end for j
	//printf("%d %d %d %d %d %d",now[0],now[1],now[2],now[3],now[4],now[5]);
	printf("%d ",now[1]);
	now[0]=1;
	now[1]=2;
	now[2]=3;
	now[3]=5;
	now[4]=4;
	now[5]=6;
	}//end for i

}