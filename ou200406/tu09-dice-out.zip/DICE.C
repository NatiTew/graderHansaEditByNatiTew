/*
TASK: DICE
LANG: C
AUTHOR: Vanus Vachiratamporn
CENTER: Tu09
*/
#include<stdio.h>

int main(void)
{   char c;
    int n,i,front[10];
    scanf("%d",&n);
    while(getchar()!='\n');
    for(i=1;i<=n;i++)
       {   front[i]=2;
	   while(1)
	     {   c=getchar();
		 if(c==10)
		   break;
		 switch(c)
		 {
		 case 'F' : if(front[i]==2) front[i]=1;
			    else if(front[i]==1) front[i]=5;
			    else if(front[i]==5) front[i]=6;
			    else if(front[i]==6) front[i]=2;
			    break;
		 case 'B' : if(front[i]==1) front[i]=2;
			    else if(front[i]==5) front[i]=1;
			    else if(front[i]==6) front[i]=5;
			    else if(front[i]==2) front[i]=6;
			    break;
		 case 'C' : if(front[i]==2) front[i]=4;
			    else if(front[i]==4) front[i]=5;
			    else if(front[i]==5) front[i]=3;
			    else if(front[i]==3) front[i]=2;
			    break;
		 case 'D' : if(front[i]==4) front[i]=2;
			    else if(front[i]==5) front[i]=4;
			    else if(front[i]==3) front[i]=5;
			    else if(front[i]==2) front[i]=3;
			    break;
		 default :  break;
		 }
	     }
       }
    for(i=1;i<=n;i++)
       {   if(i!=1)
	     printf(" ");
	   printf("%d",front[i]);
       }
    return 0;
}