/*
TASK: MAXSEQ
LANG: C
AUTHOR: NATCHAPON ANANTARAMPORN
CENTER: NU05
*/
#include <stdio.h>
int main(void)
{
  int n,num[2500],sum=0;
  int i,j,chk=0,count=1,chk1=0;
  int a,b;
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
    scanf("%d",&num[i]);
  }
  for(i=0;i<n;i++)
  {
    sum=num[i];
    if(n!=1)
    {
      for(j=i+1;j<n;j++)
      {
	sum=sum+num[j];
	if(sum>chk)
	{
	  chk=sum;
	  count++;
	}
	else j=n;
      }
    }
    else chk=num[i];
    if(chk>chk1)
    {
      chk1=chk;
      chk=chk1;
      a=i;
      b=count;
    }
    count=1;
  }
  if(chk1>0)
  {
    for(i=a;i<b+a;i++)
    {
      printf("%d ",num[i]);
    }
    printf("\n%d",chk1);
  }
  else
    printf("Empty sequence");
  return 0;
}