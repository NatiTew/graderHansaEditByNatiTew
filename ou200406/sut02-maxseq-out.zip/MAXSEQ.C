/*
TASK: MAXSEQ
LANG: C
AUTHOR: Prayote Boonchaisuk
CENTER: SUT02
*/
#include<stdio.h>
void main(){
int N,num[2500]={0},sum=0,max=-32700,in[2],si,
    i,j;
scanf(" %d",&N);
for(i=0;i<N;i++)
   {
    scanf(" %d",&num[i]);
   }
for(i=0;i<N-1;i++)
   {
    if(num[i]>0)
	{
	 sum+=num[i];
	 si=sum;
	 for(j=i+1;j<N;j++)
	    {
	     if((sum+=num[j])>max)
		in[0]=i,in[1]=j,max=sum;
	    }
	 sum=si;
	}
   }
if(sum>0)
 {si=0;
 for(i=in[0];i<=in[1];i++)
	printf("%d ",num[i]),si+=num[i];
	printf("\n%d",si);
 }
else printf("Empty sequence");
}