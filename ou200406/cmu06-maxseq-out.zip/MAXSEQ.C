/*
TASK: MAXSEQ
LANG: C
AUTHOR: SINN SATJAWATTANAVIMOL
CENTER: CMU06
*/
#include<stdio.h>
int main(void)
{
	int n,i,c,p,seq[2500],ans[2500],max=0,sum=0,mc;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&seq[i]);
	for(c=1;n>=0;n--,c++)
	{
		for(i=0;i<n;i++)
		{

			for(sum=0,p=0;p<c;p++)
			{
				sum+=seq[i+p];
			}
			if(sum>max)
			{
				mc=p;
				max=sum;
				for(p=0;p<mc;p++)
					ans[p]=seq[i+p];
			}
		}
	}
	if(max>0)
	{
		for(i=0;i<mc;i++)
			printf("%d ",ans[i]);
		printf("\n%d",max);
	}
	else
		printf("Empty sequence");
	return 0;
}