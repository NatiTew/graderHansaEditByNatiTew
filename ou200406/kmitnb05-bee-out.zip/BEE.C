/*
TASK: BEE
LANG: C
AUTHOR: ISARAPONG JIROJWONG
CENTER: KMITNB05
*/



#include<stdio.h>


int main()
{
	int first_year,last_year,loop;

	int most=4,work=2;

	scanf("%d %d %d",&first_year,&last_year,&loop);
	if(loop!=-1 || last_year>24|| last_year<1|| last_year==first_year||first_year<1||first_year>24)
		return 0;

	for(loop=first_year;loop<last_year;loop++)
	{
		printf("%d %d\n",work,most);
		most*=last_year;
		work=work*last_year+1;
	}

	return 0;
}



