/*
TASK: WORD
LANG: C
AUTHOR: Peerasak Rattanamanee
CENTER: PSUPN04
*/
#include<stdio.h>
#include<string.h>
void main()
{
	int r,c,i,j,k,l,m,n,wrd,st1,st2;
	char table[26][26]={""},str[16]="",th;
	scanf("%d%d",&r,&c);
	for(i=0;i<r;i++)
	{
		scanf("%s",table[i]);
		strlwr(table[i]);
	}
	scanf("%d",&wrd);
	while(wrd!=0)
	{
		scanf("%s",str);
		strlwr(str);
		th='F';
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				if(table[i][j]==str[0])
				{
					n=1;
					st1=i;
					st2=j;
					for(k=-1;k<=1;k++)
					{
						for(l=-1;l<=1;l++)
						{
							for(m=1;m<strlen(str);m++)
							{
								if(table[i+k][j+l]==str[m])
								{
									i+=k;
									j+=l;
									n++;
									if(n==strlen(str))
									{
										printf("%d %d\n",st1,st2);
										i=st1;
										j=st2;
										th='T';
										break;
									}
								}
								else
								{
									i=st1;
									j=st2;
									break;
								}
							}
							if(th=='T')
								break;
						}
						if(th=='T')
							break;
					}
					if(th=='T')
						break;
				}
				if(th=='T')
					break;
			}
			if(th=='T')
				break;
		}
		wrd--;
	}
}