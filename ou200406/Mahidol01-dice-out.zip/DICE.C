/*
TASK: DICE
LANG: C
AUTHOR: NATCHANON ANGSUTORN
CENTER: MAHIDOL01
*/

#include<stdio.h>

int dice[6];

int cpy(int *dice1){
	int i;

	for(i=0;i<6;i++){
		dice[i]=dice1[i];
	}

	return 0;
}

int process(char ch){

	switch(ch){
		case 'F': forward();	break;
		case 'B': back();       break;
		case 'L': left();       break;
		case 'R': right();      break;
		case 'C': cw();         break;
		case 'D': ccw();        break;
	}

	return 0;
}

int forward(){
    int dice1[6];

    dice1[0]=dice[3];
    dice1[1]=dice[0];
    dice1[2]=dice[2];
    dice1[3]=dice[5];
    dice1[4]=dice[4];
    dice1[5]=dice[1];

    cpy(dice1);

    return 0;
}

int back(){
    int dice1[6];

    dice1[0]=dice[1];
    dice1[1]=dice[5];
    dice1[2]=dice[2];
    dice1[3]=dice[0];
    dice1[4]=dice[4];
    dice1[5]=dice[3];

    cpy(dice1);

    return 0;
}

int left(){
    int dice1[6];

    dice1[0]=dice[4];
    dice1[1]=dice[1];
    dice1[2]=dice[0];
    dice1[3]=dice[3];
    dice1[4]=dice[5];
    dice1[5]=dice[2];

    cpy(dice1);

    return 0;
}

int right(){
    int dice1[6];

    dice1[0]=dice[2];
    dice1[1]=dice[1];
    dice1[2]=dice[5];
    dice1[3]=dice[3];
    dice1[4]=dice[0];
    dice1[5]=dice[4];

    cpy(dice1);

    return 0;
}

int cw(){
    int dice1[6];

    dice1[0]=dice[0];
    dice1[1]=dice[4];
    dice1[2]=dice[1];
    dice1[3]=dice[2];
    dice1[4]=dice[3];
    dice1[5]=dice[5];

    cpy(dice1);

    return 0;
}

int ccw(){
    int dice1[6];

    dice1[0]=dice[0];
    dice1[1]=dice[2];
    dice1[2]=dice[3];
    dice1[3]=dice[4];
    dice1[4]=dice[1];
    dice1[5]=dice[5];

    cpy(dice1);

    return 0;
}

int makedice(){
	dice[0]=1;
	dice[1]=2;
	dice[2]=3;
	dice[3]=5;
	dice[4]=4;
	dice[5]=6;

	return 0;
}

int main(){
	int n;
	int i,j;
	char str[6][1001];

	scanf("%d",&n);

	for(i=0;i<n;i++){
		scanf("%s",str[i]);
	}

	for(i=0;i<n;i++){
		makedice();

		for(j=0;str[i][j]!='\0';j++){
			process(str[i][j]);
		}

		printf("%d ",dice[1]);
	}

	return 0;
}