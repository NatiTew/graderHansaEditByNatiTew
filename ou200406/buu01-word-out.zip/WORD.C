/*
TASK: WORD
LANG: C
AUTHOR: GAIPEACH SUCHARTKULVIT
CENTER: ASSUMOTION COLLEGE SRIRACHA - buu01
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
	int n,m,w;
	int i,j,k;
	char table[30][30];
	char word[100][17];
	int posx[100]={0},posy[100]={0};
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%s",table[i]);
		for(j=0;j<strlen(table[i]);j++)
			table[i][j]=tolower(table[i][j]);
	}
	scanf("%d",&w);
	for(i=0;i<w;i++)
	{
		scanf("%s",word[i]);
		for(j=0;j<strlen(word[i]);j++)
			word[i][j]=tolower(word[i][j]);
	}
	for(k=0;k<w;k++)
	{
		int true=1;
		for(i=0;i<n;i++)
		{
			for(j=0;j<m;j++)
			{
				int q,r,s;
				int z;
				z=strlen(word[k]);
				z--;
				if(i-z>=0)
				{
					for(true=1,r=0,q=i;q>=i-z;q--,r++)
					{
						if(word[k][r]!=table[q][j])
						{
							true=0;
							break;
						}
					}
					if(true==1)
					{
						posx[k]=i;
						posy[k]=j;
						break;
					}
				}
				if(j-z>=0)
				{
					for(true=1,r=0,q=j;q>=j-z;q--,r++)
					{
						if(word[k][r]!=table[i][q])
						{
							true=0;
							break;
						}
					}
					if(true==1)
					{
						posx[k]=i;
						posy[k]=j;
						break;
					}
				}
				if(j+z<m)
				{
					for(true=1,r=0,q=j;q<=j+z;q++,r++)
					{
						if(word[k][r]!=table[i][q])
						{
							true=0;
							break;
						}
					}
					if(true==1)
					{
						posx[k]=i;
						posy[k]=j;
						break;
					}
				}
				if(i+z<n)
				{
					for(true=1,r=0,q=i;q<=i+z;q++,r++)
					{
						if(word[k][r]!=table[q][j])
						{
							true=0;
							break;
						}
					}
					if(true==1)
					{
						posx[k]=i;
						posy[k]=j;
						break;
					}
				}
				if(j-z>=0&&i-z>=0)
				{
					for(true=1,s=i,r=0,q=j;q>=j-z;q--,s--,r++)
					{
						if(word[k][r]!=table[s][q])
						{
							true=0;
							break;
						}
					}
					if(true==1)
					{
						posx[k]=i;
						posy[k]=j;
						break;
					}
				}
				if(j+z<m&&i+z<n)
				{
					for(true=1,s=i,r=0,q=j;q<=j+z;q++,s++,r++)
					{
						if(word[k][r]!=table[s][q])
						{
							true=0;
							break;
						}
					}
					if(true==1)
					{
						posx[k]=i;
						posy[k]=j;
						break;
					}
				}
			}
			if(true==1)
				continue;
		}
	}
	for(i=0;i<w;i++)
		printf("%d %d\n",posx[i],posy[i]);
	return 0;
}