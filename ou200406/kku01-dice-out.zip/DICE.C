/*
TASK: DICE
LANG: C
AUTHOR: Charuwat Houngkaew
CENTER: kku01
*/

#include <stdio.h>
#include <string.h>
int a[6];
void swap(int *l,int *k)
{
int temp;
	temp=*k;
	*k=*l;
	*l=temp;
}
int main()
{
	int n,i,s[1005],j,temp,len;
	//char j;
	scanf("%d",&n);

	for(i=0;i<n;i++)
	{
		//for(j=0;j<6;j++)
			a[0]=1;
			a[1]=2;
			a[2]=3;
			a[3]=5;
			a[4]=4;
			a[5]=6;

		scanf("%s",&s);
		j=0;
		len=strlen(a);
		while(j<len)
		{
			switch(s[j])
			{
				case 'F':
					swap(a+3,a+5);
					swap(a,a+5);
					swap(a+1,a+5);
				break;
				case 'B':
					swap(a+1,a+5);
					swap(a,a+5);
					swap(a+3,a+5);
				break;
				case 'L':
					swap(a+5,a+4);
					swap(a+5,a+2);
					swap(a,a+2);
				break;
				case 'R':
					swap(a+4,a+5);
					swap(a,a+4);
					swap(a,a+2);
				break;
				case 'C':
					swap(a+3,a+4);
					swap(a+2,a+3);
					swap(a+1,a+2);
				break;
				case 'D':
					swap(a+4,a+1);
					swap(a+1,a+3);
					swap(a+1,a+2);
				break;

			}
		j++;
		}
		printf("%d ",a[1]);
		/*for(j=0;j<6;j++)
			printf("%d ",a[j]);
		printf("\n");
		*/
	}

return 0;
}