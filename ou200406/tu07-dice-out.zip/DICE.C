/*
TASK: DICE
LANG: C
AUTHOR: KAWIN ASVAPATIPATT
CENTER: TU07
*/

#include <stdio.h>

int main()
{
int n,i,dice[6][6],j,swap ;
char temp[1002] ;
scanf ("%d",&n) ;
for (i=0;i<n;i++)
	 {
	 dice[i][0] = 1 ;
	 dice[i][1] = 2 ;
	 dice[i][2] = 3 ;
	 dice[i][3] = 5 ;
	 dice[i][4] = 4 ;
	 dice[i][5] = 6 ;
	 }
for (i=0;i<n;i++)
	 {
	 scanf ("%s",temp) ;
	 j = 0 ;
	 while (temp[j] != '\0')
		 {
		 if (temp[j] == 'F')
			{
			swap = dice[i][0] ;
			dice[i][0] = dice[i][3] ;
			dice[i][3] = dice[i][5] ;
			dice[i][5] = dice[i][1] ;
			dice[i][1] = swap ;
			}
		 else if (temp[j] == 'B')
			{
			swap = dice[i][0] ;
			dice[i][0] = dice[i][1] ;
			dice[i][1] = dice[i][5] ;
			dice[i][5] = dice[i][3] ;
			dice[i][3] = swap ;
			}
		 else if (temp[j] == 'L')
			{
			swap = dice[i][0] ;
			dice[i][0] = dice[i][4] ;
			dice[i][4] = dice[i][5] ;
			dice[i][5] = dice[i][2] ;
			dice[i][2] = swap ;
			}
		 else if (temp[j] == 'R')
			{
			swap = dice[i][0] ;
			dice[i][0] = dice[i][2] ;
			dice[i][2] = dice[i][5] ;
			dice[i][5] = dice[i][4] ;
			dice[i][4] = swap ;
			}
		 else if (temp[j] == 'C')
			{
			swap = dice[i][1] ;
			dice[i][1] = dice[i][4] ;
			dice[i][4] = dice[i][3] ;
			dice[i][3] = dice[i][2] ;
			dice[i][2] = swap ;
			}
		 else if (temp[j] == 'D')
			{
			swap = dice[i][1] ;
			dice[i][1] = dice[i][2] ;
			dice[i][2] = dice[i][3] ;
			dice[i][3] = dice[i][4] ;
			dice[i][4] = swap ;
			}
		 j++ ;
		 }
	 }
for (i=0;i<n;i++)
printf ("%d ",dice[i][1]) ;
return 0 ;
}