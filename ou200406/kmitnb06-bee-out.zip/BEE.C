/*
TASK: BEE
LANG: C
AUTHOR: PIRAPAT JAKPAISAL
CENTER: KMITNB-06
*/
#include<stdio.h>

long check(long a[],long sum) {
	long i,j;
	for(i=0;i<sum;i++) {
		for(j=i+1;j<sum;j++)
			if(a[j]==a[i])
				return 1;
	}
	return 0;
}

void main() {
	long a[25],boss=1,worker=1,soldier;
	long worker1,soldier1;
	long total,sum,i,j,boss_wo,worker_so,worker_wo,soldier_wo;
	i=0;
	while(a[i-1]!=-1) {
		scanf("%ld",&a[i]);
		if(a[i]<1 && a[i]>24)
			exit(0);
		i++;
	}
	i--;
	sum=i;
	if(check(a,sum))
		exit(0);
	for(j=0;j<sum;j++) {
		boss=1;
		worker=1;
		soldier=0;
		worker_wo=0;
		worker_so=0;
		soldier_wo=0;
		boss_wo=0;
		total=0;
		for(i=0;i<a[j];i++){
			worker1=worker;
			soldier1=soldier;
			boss_wo=boss;
			worker_so=worker;
			worker_wo=worker;
			soldier_wo=soldier;

			worker+=worker_wo;
			worker+=boss_wo;
			worker+=soldier_wo;

			soldier+=worker_so;

			worker-=worker1;
			if(soldier!=1)
				soldier-=soldier1;

			total=worker+soldier+boss;
		}
		printf("%ld %ld\n",worker,total);
	}
}
