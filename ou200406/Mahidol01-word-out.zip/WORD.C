/*
TASK: WORD
LANG: C
AUTHOR: NATCHANON ANGSUTORN
CENTER: MAHIDOL01
*/

#include<stdio.h>
#include<string.h>
#include<ctype.h>

int n,m;
char data[25][25]={{' '}};
int nw;
char word[16];

int up(int x,int y){
	int i;

	i=0;

	while(x-i>0 && data[x-i][y]==word[i]){
		i++;
	}

	if((data[x-i][y]==word[i] || word[i]=='\0')  && i>0){
		return 1;
	}
	else{
		return 0;
	}

}

int down(int x,int y){
	int i;

	i=0;

	while(x+i<n && data[x+i][y]==word[i]){
		i++;
	}

	if((data[x+i][y]==word[i] || word[i]=='\0')  && i>0){
		return 1;
	}
	else{
		return 0;
	}

}

int left(int x,int y){
	int j;

	j=0;

	while(y-j>0 && data[x][y-j]==word[j]){
		j++;
	}

	if((data[x][y-j]==word[j] || word[j]=='\0')  && j>0){
		return 1;
	}
	else{
		return 0;
	}

}

int right(int x,int y){
	int j;

	j=0;

	while(y+j<m && data[x][y+j]==word[j]){
		j++;
	}

	if((data[x][y+j]==word[j] || word[j]=='\0')  && j>0){
		return 1;
	}
	else{
		return 0;
	}

}

int ul(int x,int y){
	int i;

	i=0;

	while(x-i>0 && y-i>0 && data[x-i][y-i]==word[i]){
		i++;
	}

	if((data[x-i][y-i]==word[i] || word[i]=='\0')  && i>0){
		return 1;
	}
	else{
		return 0;
	}

}

int ur(int x,int y){
	int i;

	i=0;

	while(x-i>0 && y+i<m && data[x-i][y+i]==word[i]){
		i++;
	}

	if((data[x-i][y+i]==word[i] || word[i]=='\0')  && i>0){
		return 1;
	}
	else{
		return 0;
	}

}

int dl(int x,int y){
	int i;

	i=0;

	while(x+i<n && y-i>0 && data[x+i][y-i]==word[i]){
		i++;
	}

	if((data[x+i][y-i]==word[i] || word[i]=='\0')  && i>0){
		return 1;
	}
	else{
		return 0;
	}

}

int dr(int x,int y){
	int i;

	i=0;

	while(x+i<n && y+i<m && data[x+i][y+i]==word[i]){
		i++;
	}

	if((data[x+i][y+i]==word[i] || word[i]=='\0')  && i>0){
		return 1;

	}
	else{
		return 0;
	}

}



int check(int x,int y){
	int i,j;
	int sum=0;

	sum+=up(x,y);
	if(sum==0)
	sum+=down(x,y);
	if(sum==0)
	sum+=left(x,y);
	if(sum==0)
	sum+=right(x,y);

	if(sum==0)
	sum+=ul(x,y);
	if(sum==0)
	sum+=ur(x,y);
	if(sum==0)
	sum+=dl(x,y);
	if(sum==0)
	sum+=dr(x,y);

	return sum;

}

int process(){
	int i,j;

	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			if(check(i,j)>0){
				printf("%d %d\n",i,j);
			}
		}
	}

	return 0;
}

int main(){
	int i,j;
	char ch;

	scanf("%d %d",&n,&m);

	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%c",&ch);

			if(ch!='\n'){
				data[i][j]=tolower(ch);
			}
			else{
				j--;
			}
		}
	}

	scanf("%d",&nw);

	for(i=0;i<nw;i++){
		scanf("%s",&word);
		strlwr(word);

		process();
	}




	return 0;

}