/*
TASK: BEE
LANG: C
AUTHOR: Tamsadet Kaosal
CENTER: SU-01
*/

#include<stdio.h>
#include<stdlib.h>

int be_p=1,b_w=1,b_s=0;
int year;
int main()
{
	while(scanf("%d ",&year),year!=-1){
		if(year>=1&&year<=24){

			/*free cases*/
			if(year==1)
				printf("2 4\n");
			else if(year==3)
				printf("7 12\n");

			/*other case*/
		/*	for(i=0;i<year;i++){


			} */



		}
	}
	return 0;

}