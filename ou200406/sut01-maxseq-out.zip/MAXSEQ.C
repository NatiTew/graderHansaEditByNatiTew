/*
TASK: MAXSEQ
LANG: C
AUTHOR: NUTDANAI PHANSOOKSAI
CENTER: SUT01
*/
#include<stdio.h>
void main(){
	int maxn,max = -32767,sum = 0;
	int data[2500];
	int n,ins,inf;
	int i,j;
	scanf("%d",&n);
	for(i = 0;i < n;i++) scanf("%d",&data[i]);
	for(maxn = 1;maxn <= n;maxn++){
		for(i = 0;i <= n-maxn;i++){
			sum = 0;
			for(j = i;j < maxn+i;j++) sum += data[j];
			if(sum > max){
				max = sum;
				ins = i;
				inf = j-1;
			}
		}
	}
	if(max <= 0) printf("Empty sequence");
	else{
		for(i = ins;i <= inf;i++) printf("%d ",data[i]);
		printf("\n%d",max);
	}
}