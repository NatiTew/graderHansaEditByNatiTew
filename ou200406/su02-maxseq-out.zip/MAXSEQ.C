/*
TASK: MAXSEQ
LANG: C
AUTHOR:Thitipong sansanayuth
CENTER: SU02
*/
#include<stdio.h>
int main()
{
	int n,ar[2500],i=0,j=0,k=0,ptrs,ptrf;
	long max=-317600,sum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&ar[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			 sum=0;
			 for(k=i;k<=j;k++)
			 {
				 sum=sum+ar[k];
			 }
			 if(sum>max)
			 {
				 max=sum;
				 ptrs=i;
				 ptrf=j;
			 }
		}
	}
	if(max>0)
	{
		for(i=ptrs;i<=ptrf;i++)
		{
			printf("%d ",ar[i]);
		}
		printf("\n%d",max);
	}
	else printf("Empty sequence");
	return 0;
}