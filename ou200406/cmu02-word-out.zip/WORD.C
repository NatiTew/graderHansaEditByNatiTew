/*
TASK: WORD
LANG: C
AUTHOR: Songkiet Kunopakarnphan
CENTER: cmu02
*/

#include<stdio.h>
#include<string.h>

int test(char table[25][25],char word[25],int row,int q)
{
	int i,count=0;
	if(q>0)
	{
	if(word[1]==table[row][q-1])
	{
		for(i=2;i<strlen(word);i++)
		{
			if(word[i]==table[row][q-i]||q-i==-1)
				count++;
			if(count==strlen(word)-2)
			{
				return 1;
			}
		}
	}
	if(word[1]==table[row+1][q-1])
	{
		for(i=2;i<strlen(word);i++)
		{
			if(word[i]==table[row+i][q-i]||q-i==-1)
				count++;
			if(count==strlen(word)-2)
			{
				return 1;
			}
		}
	}
	}
	if(word[1]==table[row][q+1])
	{
		for(i=2;i<strlen(word);i++)
		{
			if(word[i]==table[row][q+i])
				count++;
			if(count==strlen(word)-2)
			{
				return 1;
			}
		}
	}
	if(row>0)
	{
		if(word[1]==table[row-1][q])
		{
			for(i=2;i<strlen(word);i++)
			{
				if(word[i]==table[row-i][q])
					count++;
				if(count==strlen(word)-2)
				{
					return 1;
				}
			}
		}
		if(q>0)
		{
		if(word[1]==table[row-1][q-1])
		{
			for(i=2;i<strlen(word);i++)
			{
				if(word[i]==table[row-i][q-i]||q-i==-1)
					count++;
				if(count==strlen(word)-2)
				{
					return 1;
				}
			}
		}
		}
		if(word[1]==table[row-1][q+1])
		{
			for(i=2;i<strlen(word);i++)
			{
				if(word[i]==table[row-i][q+i])
					count++;
				if(count==strlen(word)-2)
				{
					return 1;
				}
			}
		}

	}
	if(word[1]==table[row+1][q])
	{
		for(i=2;i<strlen(word);i++)
		{
			if(word[i]==table[row+i][q])
				count++;
			if(count==strlen(word)-2)
			{
				return 1;
			}
		}
	}
	if(word[1]==table[row+1][q+1])
	{
		for(i=2;i<strlen(word);i++)
		{
			if(word[i]==table[row+i][q+i])
				count++;
			if(count==strlen(word)-2)
			{
				return 1;
			}
		}
	}else return 0;
	return 1;
}
int main()
{
	char table[25][25],word[25];
	int m,n,i,a,row,q,ans,asc,j;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		scanf("%s",&table[i]);
		for(j=0;j<strlen(table[i]);j++)
		{
			asc=(int)table[i][j]+1;
			if(asc<96)
				table[i][j]=table[i][j]+32;
		}
	}
	scanf("%d",&a);
	for(i=0;i<a;i++)
	{
		scanf("%s",&word);
		for(j=0;j<strlen(word);j++)
		{
			if(word[j]<96)
				word[j]=word[j]+32;
		}
		if(strlen(word)==1)
		{
			for(row=0;row<m;row++)
			{
				for(q=0;q<n;q++)
				{
					if(word[0]==table[row][q])
					{
						printf("%d %d\n",row,q);
						return 0;
					}
				}
			}
		}
		for(row=0;row<m;row++)
		{
			for(q=0;q<n;q++)
			{
				if(word[0]==table[row][q])
				{
					ans=test(table,word,row,q);
					if(ans==1)
					{
						printf("%d %d\n",row,q);
						goto again;
					}
				}
			}
		}
		again:
	}
	return 0;
}