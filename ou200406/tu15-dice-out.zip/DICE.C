/*
TASK: DICE
LANG: C
AUTHOR: NATHADOL SAHAWATWONG
CENTER: TU15
*/
#include<stdio.h>
#include<string.h>
#define MAX 1001

char input[MAX];

main()
{
	int n,i,j,temp;
	int up = 1 , down = 6 , front = 2 , back = 5 , left = 3 , right = 4;
	scanf("%d\n",&n);
	for(i = 1 ; i<=n ; i++)
	{
		scanf("%s",input);
		up=1,down=6,front=2,back=5,left=3,right=4;
		for(j = 0 ; j<strlen(input) ; j++)
		{
			if(input[j]=='F')
			{
				temp  = front;
				front = up;
				up    = back;
				back  = down ;
				down  = temp;
			}
			if(input[j]=='B')
			{
				temp  = front;
				front = down;
				down  = back;
				back  = up;
				up    = temp;
			}
			if(input[j]=='L')
			{
				temp = up;
				up = right;
				right= down;
				down = left;
				left = temp;

			}
			if(input[j]=='R')
			{
				temp = up;
				up = left;
				left = down;
				down = right;
				right = up;
			}
			if(input[j]=='C')
			{
				temp = front;
				front = right;
				right = back;
				back = left;
				left = temp;
			}
			if(input[j]=='D')
			{
				temp = front;
				front = left;
				left = back;
				back = right;
				right = temp;
			}
		}
		printf("%d ",front);
	}
	return 0;
}