/*
TASK: DICE
LANG: C
AUTHOR: NUTDANAI PHANSOOKSAI
CENTER: SUT01
*/
#include<stdio.h>
#include<string.h>
void main(){
	int dice[6] = {1,2,3,5,4,6},i,j,len,tmp;
	long int n;
	char ans[1001];
	scanf("%ld",&n);
	for(i = 0;i < n;i++){
		scanf("%s",ans);
		for(j = 0;j < 6;j++) dice[j] = j+1;
		dice[3] = 5; dice[4] = 4;
		for(len = 0;len < strlen(ans);len++){
			if(ans[len] == 'F'){ tmp = dice[0]; dice[0] = dice[3]; dice[3] = dice[5]; dice[5] = dice[1]; dice[1] = tmp;}
			else if(ans[len] == 'B'){ tmp = dice[1]; dice[1] = dice[5]; dice[5] = dice[3]; dice[3] = dice[0]; dice[0] = tmp;}
			else if(ans[len] == 'L'){ tmp = dice[0]; dice[0] = dice[4]; dice[4] = dice[5]; dice[5] = dice[2]; dice[2] = tmp;}
			else if(ans[len] == 'R'){ tmp = dice[0]; dice[0] = dice[2]; dice[2] = dice[5]; dice[5] = dice[4]; dice[5] = tmp;}
			else if(ans[len] == 'C'){
					tmp = dice[4];
					for(j = 4;j > 1;j--) dice[j] = dice[j-1];
					dice[1] = tmp;
				 }
			else{
				tmp = dice[1];
				for(j = 1;j < 4;j++) dice[j] = dice[j+1];
				dice[4] = tmp;
			}
		}
		printf("%d ",dice[1]);
	}
}