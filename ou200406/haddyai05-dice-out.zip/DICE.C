/*
TASK : DICE
LANG: C
AUTHOR: Witcharkorn Wongputorn
CENTER: haddyai05
*/
#include<stdio.h>

void main()
{
  int dice[6], dices=0;
  int fronts[6]={-1,-1,-1,-1,-1,-1};
  char commands[1000];
  int temp,i,d;

  scanf("%d",&dices);
  if (dices>6) goto ERR;

  for (d=0;d<dices;d++)
  {
   i=0;
   scanf("%s",commands);
   dice[0]=1;  dice[1]=2;  dice[2]=3;
   dice[3]=5;  dice[4]=4;  dice[5]=6;

  while (commands[i]!='\0')
  {
   switch (commands[i])
   {
	case 'F':
	{
	  temp=dice[1];
	  dice[1]=dice[0];    //front=top
	  dice[0]=dice[3];    //top=back
	  dice[3]=dice[5];    //back=bottom
	  dice[5]=temp;	//bottom=oldfront
	} break;
	case 'B':
	{
	  temp=dice[1];
	  dice[1]=dice[5];    //front=bottom
	  dice[5]=dice[3];    //bottom=back
	  dice[3]=dice[0];    //back=top
	  dice[0]=temp;	//top=oldfront
	} break;
	case 'L':
	{
	  temp=dice[0];
	  dice[0]=dice[4];	//top=right
	  dice[4]=dice[5];	//right=bottom
	  dice[5]=dice[2];	//bottom=left
	  dice[2]=temp;	//left=oldtop
	} break;
	case 'R':
	{
	  temp=dice[0];
	  dice[0]=dice[2];	//top=left
	  dice[2]=dice[5];	//left=bottom
	  dice[5]=dice[4];	//bottom=right
	  dice[4]=temp;     //right=oldtop
	} break;
	case 'C':
	{
	  temp=dice[1];
	  dice[1]=dice[4];	//front=right
	  dice[4]=dice[3];    //right=back
	  dice[3]=dice[2];	//back=left
	  dice[2]=temp;	//left=oldfront
	} break;
	case 'D':
	{
	  temp=dice[1];
	  dice[1]=dice[2];	//front=left
	  dice[2]=dice[3];	//left=back
	  dice[3]=dice[4];	//back=right
	  dice[4]=temp;	//right=oldfront
	} break;
	default: break;
   }
   fronts[d]=dice[1];
   i++;
  }
 }

 for (i=0;i<dices;i++)
 {
  printf("%d",fronts[i]);
  if (i!=dices-1) printf(" ");
 }
 goto END;

 ERR:
 END:
}
