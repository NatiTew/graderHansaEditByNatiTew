/*
TASK: MAXSEQ
LANG: C
AUTHOR: KAMONPOP JARUJIT
CENTER: KKU06
*/

#include <stdio.h>
int main(){
	int i,n,x[2500],j,sum=0,tmp,y[2500],k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&x[i]);
	}for(i=0;i<n;i++){
		tmp=0;
		for(j=i;j<n-i;j++){
			tmp+=x[j];
			if(tmp>=sum){
				for(k=0;k<=j-i;k++){
					y[k]=x[i+k];
				}sum=tmp;
			}
		}
	}if(sum<=0){printf("Empty sequence");}
	else{
		for(i=0;i<k;i++){printf("%d ",y[i]);}
		printf("\n%d",sum);
	}return 0;
}
