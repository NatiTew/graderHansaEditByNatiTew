/*
TASK: BEE
LANG: C
AUTHOR: Kraipitch Tassanasaengsoon
CENTER: TU12
*/

# include <stdio.h>

void main()
{
	int input,c;
	long mom,work,sol,temp;
	do
	{
		scanf("%d",&input);
		if( input == -1 ) break;
		for( c=1 , mom=work=1 , sol=0 ; c <= input ; c++ )
		{
			temp=sol;
			sol=work;
			work+=1+temp;
		}
		printf("%ld %ld\n",work,mom+work+sol);
	} while( 1 );
}