/*
TASK: WORD
LANG: C
AUTHOR: Worakan Jeeprabnan
CENTER: CMU03
*/
#include<stdio.h>
#include<string.h>
char ttable[26][26]={NULL};
static int m,n,x,y;
int find(char str[]);
int main()
{
  char tmpp;
  int k,i=0,j=0,tmp=0;
  char str[26]={NULL};
  char ban[26];
  //scanf("%c",&ttable[i][j]);
  scanf("%d %d",&m,&n);
  scanf("%c",&tmpp);
  for(i=0;i<m;i++)
  {
      scanf("%s",ban);
      for(j=0;j<n;j++)
      {
	ttable[i][j]=ban[j];
      }
  }
  scanf("%d",&k);
  for(i=0;i<k;i++)
  {
    scanf("%s",str);
    tmp=find(str);
    if(tmp!=10)
    printf("%d %d\n",x,y);
    else printf("bug!!\n");
  }
  return 0;
}
int find(char str[])
{
  static int l,i,j,k,chk;
  l=strlen(str);
  for(i=0;i<m;i++)
  {
    for(j=0;j<(n-l)+1;j++)
    {
      chk=0;
      for(k=0;k<l;k++)
      {
	if(str[k]==ttable[i][j+k])
	chk++;
      }
      if(chk==l){x=i;y=j;return 0;}
      chk=0;
      for(k=0;k<l;k++)
      {
	if(str[k]==ttable[i+k][j])
	chk++;
      }
      if(chk==l){x=i;y=j;return 0;}
      /*chk=0;
      for(k=0;k<l;k++)
      {
	if(str[k]==ttable[i][(m-j)-k])
	chk++;
      }
      if(chk==l){x=i;y=j;return 0;}
      chk=0;
      for(k=0;k<l;k++)
      {
	if(str[k]==ttable[(n-i)-k][j])
	chk++;
      }
      if(chk==l){x=i;y=j;return 0;}*/
    }
  }
  return 10;
}