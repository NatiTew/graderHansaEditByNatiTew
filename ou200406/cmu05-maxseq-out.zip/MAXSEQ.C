/*
TASK: MAXSEQ
LANG: C
AUTHOUR: Pongsakorn Jaiban
CENTER: CMU05
*/

#include<stdio.h>

int main(void)
{
	int num[2501],input,arrmax=0,add,i;
//i cou scanf
	scanf("%d",&input);
	for(i=0;i<input-1;i++)
	{
		scanf("%d ",&num[i]);
	}
// i cou input-2
	for(i=0;i<input-1;i++)
	{
		if(arrmax<(num[i]+num[i+1]+num[i+2]))
		{
			arrmax=(num[i]+num[i+1]+num[i+2]);
			add=i;
		}
	}
	if(arrmax>0)
	{
		printf("%d %d %d\n%d",num[add],num[add+1],num[add+2],arrmax);
	}
	else
	{
		printf("Empty sequence");
	}
	return 0;
}