/*
TASK: BEE
LANG: C
AUTHOR: SARAN LERTPRADIT
CENTER: TU
*/
#include<stdio.h>
main()
{
	long w[26],s[26];
	int i,n,count=0,ans[24];
	w[0]=1;
	s[0]=0;
	for(i=1;i<26;i++)
	{
		w[i]=w[i-1]+s[i-1]+1;
		s[i]=w[i-1];
	}
	while(1)
	{
		scanf("%d",&n);
		if(n==-1)
		{
			break;
		}
		ans[count]=n;
		count++;
	}
	for(i=0;i<count;i++)
	{
		printf("%ld %ld\n",w[ans[i]],w[ans[i]+1]);
	}
	return 0;
}