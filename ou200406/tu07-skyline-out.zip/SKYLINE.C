/*
TASK: SKYLINE
LANG: C
AUTHOR: KAWIN ASVAPATIPATT
CENTER: TU07
*/

int main ()
{
int ans[6500],n,i,j,k,l,h,r ;
char building[255][255] ;
for (i=0;i<255;i++)
	{
	for (j=0;j<255;j++) building[i][j] = 'o' ;
	}
scanf ("%d",&n) ;
for (i=0;i<n;i++)
	{
	scanf ("%d %d %d",&l,&h,&r) ;
	for (j=l-1;j<=r-1;j++)
		{
		for (k=0;k<h;k++)	building[j][k] = 'x' ;
		}
	}
k = 0 ;
for (i=0;i<255;i++)
	{
	for (j=255;j>=0;j++)
		{
		if (building[i][j] == 'x' && (k == 0 || ans[k-1] != j))
			{
			ans[k] = i+1 ;
			ans[k+1] = j ;
			k = k+2 ;
			}
		else if (k != 0 && ans[k-1] != j)
			{
			ans[k] = i+1 ;
			ans[k+1] = 0 ;
			k = k+2 ;
			}
		}
	}
k = k-2 ;
for (i=0;i<k;i++)
	printf ("%d",ans[i]) ;
return 0 ;
}