/*
TASK: BEE
LANG: C
AUTHOR: Peerasak Rattanamanee
CENTER: psupn04
*/
#include<stdio.h>
void main()
{
	int i,year;
	long work,soi,temp;
	while(1)
	{
		scanf("%d",&year);
		if(year==-1)
			break;
		work=1;
		soi=0;
		for(i=0;i<year;i++)
		{
			temp=soi;
			soi=work;
			work=work+temp+1;
		}
		printf("%ld %ld\n",work,work+soi+1);
	}
}