/*
TASK: MAXSEQ
LANG: C
AUTHOR: Sarun Gulyanon
CENTER tu02
*/

#include<stdio.h>

main()
{
	int num;
	long max = 0;
	long temp;
	int ans1,ans2;
	int i,j;
	int head,tail;
	char arr[2502];

	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(head=0;arr[head] <= 0 && head < num;head++);
	for(tail=num; arr[tail-1] <= 0 && tail > 0 ; tail--);

	if(head > tail)
	{
		printf("Empty sequence");
		return 0;
	}

	for(i=head;i<tail;i++)
	{
		temp = 0;
		for(j=i;j<tail;j++)
		{
			temp += arr[j];
			if(temp <= 0)
			{
				break;
			}
			if(temp > max)
			{
			ans1 = i;
			ans2 = j;
			max = temp;
			}
		}

		for(;arr[i] >= 0 && i < tail+1;i++);
		for(;arr[i] <= 0 && i < tail+1;i++);
		i--;
	}
	if(max == 0)
	{
		printf("Empty sequence");
		return 0;
	}
	else
	{
		for(i=ans1;i<=ans2;i++)
		{
			printf("%d ",arr[i]);
		}
		printf("\n%d",max);
	}
	return 0;
}