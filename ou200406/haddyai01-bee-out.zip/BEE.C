/*
TASK: BEE
LANG: C
AUTHOR: NARONG WAKAYAPHATTARAMANUS
CENTER: PSUHATYAI-HADDYAI01
*/
#include<stdio.h>
int bee(int y);
int main()
{
 int year[24]={NULL},i=0,j;
 do
 {
  scanf("%d",&year[i]);
  if(year[i]>24)
  {
   printf("Error Try Again");
   i--;
  }
  i++;
 }
 while(year[i-1]!=-1);
 for(j=0;j<i-1;j++)
 {
  bee(year[j]);
 }
 return 0;
}
int bee(int y)
{
 int i;
 long int boss=1,sol=0,work=1;
 long int soln,workn;
 for(i=0;i<y;i++)
 {
  workn=boss+sol+work;
  soln=work;
  work=workn;
  sol=soln;
 }
 printf("\n%ld %ld",work,boss+sol+work);
 return 0;
}