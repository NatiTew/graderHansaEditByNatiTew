/*
TASK: BEE
LANG: C
AUTHOR: JIRANUN JIRATRAKANWONG
CENTER: WU01
*/
#include<stdio.h>
void main()
{
	int i=0,work,sold,c,j,k;
	int work2,sold2;
	char *con;
	gets(con);
	do{
		if(con[i+1]!=' '){
			c=((con[i]-'0')*10)+(con[i+1]-'0');
			i+=3;
		}
		else {
			c=con[i]-'0';
			i+=2;
		}
	work=1;sold=0;
	for(j=0;j<c;j++){
	sold2=0;work2=1;
		for(k=0;k<work;k++){
			sold2++;
			work2++;
		}
		for(k=0;k<sold;k++){
			work2++;
		}
	sold=sold2;
	work=work2;
	}
	printf ("%d %d\n",work,work+sold+1);
	}while(con[i]!='-');
}