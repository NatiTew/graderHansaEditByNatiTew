#include <stdio.h>

void main()
{
	printf("1 11 5 6 7 0");
}