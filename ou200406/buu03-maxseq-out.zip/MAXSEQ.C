/*
TASK: MAXSEQ
LANG: C
AUTHOR: Passakorn Phannachitta
CENTER: BUU03
*/
#include <stdio.h>

int  max;
int  maxlen;
char res[2500];

void sub(int sti,int len,char arr[2500])
{
	int i,sum = 0;
	for(i=sti ; i<len ; i++) {
		sum+=arr[i];
	}
	if(sum > max) {
		max = sum;
		maxlen = len-sti;

		for(i=0 ; i<maxlen ; i++) {
			res[i] = arr[sti+i];
		}
	}
}

void proc(int len,char arr[2500])
{
	int i,j;
	for(i=0 ; i<len ; i++) {
		for(j=1 ; j<len-i+1 ; j++) {
			sub(i,i+j,arr);
		}
	}
}

int main(void)
{
  char arr[2500];
  int length,i;

  scanf("%d",&length);

  for(i=0 ; i<length ; i++) {
	  scanf("%d",&arr[i]);
  }

  max = 0;

  proc(length,arr);

  if(max>0) {
	for(i=0 ; i<maxlen-1 ; i++) {
		printf("%d ",res[i]);
	}
	printf("%d\n",res[i]);

	printf("%d\n",max);
  }

  else printf("Empty sequence\n");

  return 0;
}