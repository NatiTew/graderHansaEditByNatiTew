/*
TASK: SEGMENT
LANG: C
AUTHEOR: KUNAKORN TENGCHIANG
CENTER: NU02
*/

#include<stdio.h>


unsigned long int powwer(int y){
	int i,x=1;
	for(i=2;i<=y;i++)
		x*=10;
	return x;
}

main(){
 unsigned long int num,sum=0;
 int i,j,n[3];
 char seg[4][50];


 scanf("%d %d",&n[0],&n[1]);
 gets(seg[0]);
 for(i=0;i<2;i++){
	gets(seg[0]);
	gets(seg[1]);
	gets(seg[2]);
	num=0;
	for(j=0;j<(n[i]*4)-1;j+=4){
		if(seg[0][j+1]!='_'){
			if(seg[1][j+1]=='_')
				num+=4*(powwer(n[i]-(j/4)));
			else
				num+=1*(powwer(n[i]-(j/4)));
		}
		else if(seg[1][j+1]!='_'){
			if(seg[1][j]==' ')
				num+=7*(powwer(n[i]-(j/4)));
		}
		else if(seg[1][j]==' '){
			if(seg[2][j+2]==' ')
				num+=2*(powwer(n[i]-(j/4)));
			else
				num+=3*(powwer(n[i]-(j/4)));
		}
		else if(seg[1][j+2]==' '){
			if(seg[2][j]==' ')
				num+=5*(powwer(n[i]-(j/4)));
			else
				num+=6*(powwer(n[i]-(j/4)));
		}
		else{
			if(seg[2][j]==' ')
				num+=9*(powwer(n[i]-(j/4)));
			else
				num+=8*(powwer(n[i]-(j/4)));
		}

	}
	sum+=num;
 }
 printf("%ld",sum);
 return 0;
}
