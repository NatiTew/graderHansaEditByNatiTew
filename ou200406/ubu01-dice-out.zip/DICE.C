/*
TASK: DICE
LANG: C
AUTHOR: RIVINWIT AKKARANGSRI
CENTER: UBON
*/
#include<stdio.h>

int main(){
	int a[5];
	int temp;
	int n,i;
	char ch[1001];

	scanf("%d",&n);
	while(n>0){
		scanf("%s",ch);
		a[0]=1;
		a[1]=2;
		a[2]=3;
		a[3]=5;
		a[4]=4;
		a[5]=6;
		i=0;
		while(ch[i]!='\0'){
			if(ch[i]=='F'){
				temp=a[0];
				a[0]=a[3];
				a[3]=a[5];
				a[5]=a[1];
				a[1]=temp;
			}else if(ch[i]=='B'){
				temp=a[0];
				a[0]=a[1];
				a[1]=a[5];
				a[5]=a[3];
				a[3]=temp;
			}else if(ch[i]=='L'){
				temp=a[0];
				a[0]=a[4];
				a[4]=a[5];
				a[5]=a[2];
				a[2]=temp;
			}else if(ch[i]=='R'){
				temp=a[0];
				a[0]=a[2];
				a[2]=a[5];
				a[5]=a[4];
				a[4]=temp;
			}else if(ch[i]=='C'){
				temp=a[1];
				a[1]=a[4];
				a[4]=a[3];
				a[3]=a[2];
				a[2]=temp;
			}else{   //case D
				temp=a[1];
				a[1]=a[2];
				a[2]=a[3];
				a[3]=a[4];
				a[4]=temp;
			}
		  /*	printf("%c",ch);
			printf("_");
			scanf("%c",&ch); */
			i++;
		}
		printf("%d",a[1]);
		if(n!=1)
			printf(" ");
		n--;
	}
	printf("\n");
	return 0;
}