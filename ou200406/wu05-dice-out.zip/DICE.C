/*
TASK: DICE
LANG: C
AUTHOR: Wachiraphan Charoenwet
CENTER: WU05
*/

#include<stdio.h>
struct DICE{
int top;
int	front;
int	left;
int	right;
int	back;
int	bottom;
}dice;


int main(){
int n,i,j;
int top,left,right,bottom,back,front;
int ans[10];
char cmd[1100];
	scanf("%d",&n);
	for(i=0;i<n;i++){
			dice.top=1;
			dice.left=3;
			dice.right=4;
			dice.bottom=6;
			dice.front=2;
			dice.back=5;
		scanf("%s",cmd);

		for(j=0;j<strlen(cmd);j++){
			top=dice.top;
			left=dice.left;
			right=dice.right;
			bottom=dice.bottom;
			front=dice.front;
			back=dice.back;
			switch(cmd[j]){
				case 'B':
					dice.top=front;
					dice.back=top;
					dice.bottom=back;
					dice.front=bottom;
					break;
				case 'C':
					dice.back=left;
					dice.left=front;
					dice.right=back;
					dice.front=right;

					break;
				case 'D':
					dice.back=right;
					dice.left=back;
					dice.right=front;
					dice.front=left;
					break;
				case 'F':
					dice.top=back;
					dice.back=bottom;
					dice.bottom=front;
					dice.front=top;
					break;
				case 'L':
					dice.top=right;
					dice.left=top;
					dice.right=bottom;
					dice.bottom=left;
					break;
				case 'R':
					dice.top=left;
					dice.left=bottom;
					dice.right=top;
					dice.bottom=right;
					break;
				default :
					break;
			}
		}
		ans[i]=dice.front;

	}

	for(i=0;i<n;i++)
		printf("%d ",ans[i]);

 return 0;
}