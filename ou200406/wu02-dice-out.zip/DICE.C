/*
TASK: DICE
LANG: C
NAME: Peerapong Thongpubet
CENTER wu-02
*/
#include <stdio.h>
#include <string.h>

void f(char c,int p[]){
	int i,t[6],k;
  /*	p[4]=k;
	p[4]=p[5];
	p[5]=k;*/
	for(i=0;i<6;i++)
		t[i]=p[i];
   //	switch (c) {
	if(c=='F'){ p[0]=t[3]; p[1]=t[0]; p[3]=t[5];  p[5]=t[1];    }
	else
	if(c=='B'){ p[0]=t[2]; p[1]=t[5]; p[3]=t[0]; p[5]=t[3];     }
	else
	if(c=='L'){ p[0]=t[4]; p[2]=t[0]; p[4]=t[5]; p[5]=t[2];     }
	else
	if(c=='R'){ p[0]=t[2]; p[2]=t[5]; p[4]=t[0]; p[5]=t[4];     }
	else
	if(c=='C'){p[1]=t[4]; p[2]=t[1]; p[3]=t[2]; p[4]=t[3];      }
	else
	if(c=='D'){ p[1]=t[2]; p[2]=t[3]; p[3]=t[4]; p[4]=t[1];     }
}

void main(){

	int ns,j,n,p[6],i,m[6]={1,2,3,5,4,6};
	char s[1000];
	scanf("%d",&n);
	for(j=0;j<n;j++){
		scanf("%s",&s);
		ns=strlen(s);
		m[0]=1;
		m[1]=2;
		m[2]=3;
		m[3]=5;
		m[4]=4;
		m[5]=6;
		for(i=0;i<ns;i++)
			f(s[i],m);
		p[j]=m[1];

	}
	for(i=0;i<n;i++){
		printf("%d ",p[i]);
	}
}