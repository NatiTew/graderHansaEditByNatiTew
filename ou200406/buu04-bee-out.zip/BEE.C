/*
TASK: BEE
LANG: C
AUTHOR: Sirawit Phutrakul
CENTER: BUU
*/
#include<stdio.h>
#include<stdlib.h>
int main(void) {
	int year ,i ,tmp;
	int work ,war ,all ;
	while((scanf("%d",&year)!=0)&&(year != -1)) {
		if((1<=year)&&(year<=24)) {
			work = 1;
			war = 0;
			for(i=0;i<year;i++) {
				tmp = work;
				work = war;
				work += tmp + 1;
				war = tmp;
				all = war + work + 1;
			}
			printf("%d %d\n",work,all);
		}
	}
	return 0;
}