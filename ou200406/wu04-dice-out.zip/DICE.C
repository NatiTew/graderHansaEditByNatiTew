/*
TASK: DICE
LANG: C
AUTHOR: Pijak Jirapiwong
CENTER: WU-04
*/
#include <stdio.h>
#include <string.h>

void swap(int *a,int *b) {
	int tmp;
	tmp=*a; *a=*b; *b=tmp;
}

void CreateDice(int dice[]) {
	int i;
	for(i=1;i<=6;i++) dice[i-1]=i;
	swap(&dice[3],&dice[4]);
}

void Shuffle(int dice[],char *cm,int len) {
	int i,tmp;
	for(i=0;i<len;i++) {
		if(cm[i]=='F') {
			swap(&dice[3],&dice[0]);
			swap(&dice[3],&dice[1]);
			swap(&dice[3],&dice[5]);
		}
		else if(cm[i]=='B') {
			swap(&dice[1],&dice[0]);
			swap(&dice[1],&dice[5]);
			swap(&dice[3],&dice[5]);
		}
		else if(cm[i]=='L') {
			swap(&dice[0],&dice[4]);
			swap(&dice[2],&dice[4]);
			swap(&dice[4],&dice[5]);
		}
		else if(cm[i]=='R') {
			swap(&dice[0],&dice[2]);
			swap(&dice[2],&dice[5]);
			swap(&dice[4],&dice[5]);
		}
		else if(cm[i]=='C') {
			swap(&dice[1],&dice[4]);
			swap(&dice[2],&dice[4]);
			swap(&dice[3],&dice[4]);
		}
		else if(cm[i]=='D') {
			swap(&dice[1],&dice[2]);
			swap(&dice[2],&dice[3]);
			swap(&dice[3],&dice[4]);
		}
	}
}

void main() {
	int i,n,len,dice[6],front[6];
	char cm[1024];
	scanf("%d",&n);
	for(i=0;i<n;i++) {
		CreateDice(dice);
		scanf("%s",cm);
		len=strlen(cm);
		Shuffle(dice,cm,len);
		front[i]=dice[1];
	}
	for(i=0;i<n;i++) printf("%d ",front[i]);
}