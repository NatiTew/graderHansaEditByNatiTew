/*
TASK: SEGMENT
LANG: C
AUTHOR: Saranyu Koothanapath
CENTER: tu04
*/
#include<stdio.h>
#include<string.h>
int n,n2;
long now=0;
long lala;
long sum;
int up[12];
char map[3][60];
int last()
{
	int a;
	int cou;
	int i;
	a=0;
	cou=0;
	for(i=0;i<12;i++)up[i]=0;

	for(i=strlen(map[0]);i>=0;i--)
	{
		if(map[0][i]=='_')
		{
			up[a]=1;
		}
		else if(map[0][i]==' ')
		{
			cou++;
			if(cou==3)
			{
				cou=0;
				a++;
			}
		}
	}
	return 0;
}
int change(int row)
{
	char t[60];
	int i,len,j;
	int count;
	len=strlen(map[row]);
	count=0;
	for(i=len-2;i>=0;--i)
	{
		if(map[row][i]==' ' || map[row][i]=='|' || map[row][i]=='_')t[count++]=map[row][i];
		else
		{
			break;
		}
	}
	j=0;
	map[row][n*4-1]=' ';
	for(i=n*4-2;i>=0;--i)
	{
		if(j<count)map[row][i]=t[j++];
		else map[row][i]=' ';
	}
	return 0;
}
int check()
{
	int b;
	b=lala-3;
	// 2
	lala-=4;

	if(  map[1][b]=='|' && map[1][b+1]=='_' && map[1][b+2]=='|'
		&&map[2][b]=='|' && map[2][b+1]=='_' && map[2][b+2]=='|')return 8;
	if(  map[1][b]==' ' && map[1][b+1]=='_' && map[1][b+2]=='|'
		&&map[2][b]=='|' && map[2][b+1]=='_' )return 2;


	if(  map[1][b]=='|' && map[1][b+1]=='_'
		&&map[2][b]=='|' && map[2][b+1]=='_' && map[2][b+2]=='|')return 6;
	if(  map[1][b]==' ' && map[1][b+1]=='_' && map[1][b+2]=='|'
		&&map[2][b]==' ' && map[2][b+1]=='_' && map[2][b+2]=='|')return 3;

	if(  map[1][b]=='|' && map[1][b+1]=='_' && map[1][b+2]=='|'
		&&map[2][b]==' ' && map[2][b+1]==' ' && map[2][b+2]=='|')return 4;

	if(  map[1][b]=='|' && map[1][b+1]=='_'
		&&map[2][b]==' ' && map[2][b+1]=='_' && map[2][b+2]=='|')return 5;



	if(  map[1][b]=='|' && map[1][b+1]=='_' && map[1][b+2]=='|'
		&&map[2][b]==' ' && map[2][b+1]=='_' && map[2][b+2]=='|')return 9;

	if(  map[1][b]=='|' && map[1][b+1]==' ' && map[1][b+2]=='|'
		&&map[2][b]=='|' && map[2][b+1]=='_' && map[2][b+2]=='|')return 0;

	if(map[1][b+2]=='|' &&
		map[2][b+2]=='|')
		{
			if(up[now]==1)return 7;
			else return 1;
		}


	return 0;
  //	if(  map[1][b]==' ' && map[1][b+1]=='_' && map[1][b+2]=='|'
  //		&&map[1][b]=='|' && map[1][b+1]=='_' && map[1][b+2]==' ')return 2;
}
int main()
{
	FILE * fi;
	int i,j;
	int ten;
	long tmp;
	int max;
//	fi=fopen("seg.in","rt");
		  fi=stdin;
	fscanf(fi,"%d %d",&n,&n2);
	fgets(map[0],60,fi);
	for(i=0;i<3;++i)
	{
	//	for(j=0;n*4;++j)
	 //	{
			fgets(map[i],n*4,fi);
			if(i==0)last();
//			change(i);

			fscanf(fi,"\n");
//			fscanf(fi,"%c",&map[i][j]);
	 //	}
	}
	tmp=0;
	ten=1;
	if(strlen(map[1])>strlen(map[2]))max=strlen(map[1]);
	else max=strlen(map[2]);
	for(lala=max-1;lala>=0;)
	{


		tmp+=ten*check();
		ten*=10;
		now++;
	}




	sum+=tmp;






	for(i=0;i<3;++i)
	for(j=0;j<60;++j)
	 map[i][j]=0;
	n=n2;
	for(i=0;i<3;++i)
	{
	//	for(j=0;n*4;++j)
	 //	{
			fgets(map[i],n*4,fi);
			if(i==0)last();
//			change(i);

			fscanf(fi,"\n");
//			fscanf(fi,"%c",&map[i][j]);
	 //	}
	}
	now=strlen(map[2])-1;
	if(map[2][now]!='\n')map[2][now+1]='\n';
	now=0;
	ten=1;
	tmp=0;
	if(strlen(map[1])>strlen(map[2]))max=strlen(map[1]);
	else max=strlen(map[2]);

	for(lala=max-1;lala>=0;)
	{


		tmp+=ten*check();
		ten*=10;
		now++;
	}



	sum+=tmp;
//	for(i=0;i<3;++i)
//		printf("%s",map[i]);
	printf("%ld",sum);
	return 0;
}
