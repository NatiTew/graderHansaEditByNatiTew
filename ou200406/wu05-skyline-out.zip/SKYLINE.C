/*
TASK: SKYLINE
LANG: C
AUTHOR:Wachiraphan Charoenwet
CENTER:WU05
*/

#include<stdio.h>

int skyline[500];

int main(){
int l,h,r,n,i,j,maxx=0;
	scanf("%d",&n);

	for(i=0;i<n;i++){
		scanf("%d %d %d",&l,&h,&r);
		for(j=l;j<r;j++){
			if(skyline[j]<=h){
				 skyline[j]=h;
			}
			if(r>maxx)
				maxx=r;
		}
	}
	 j=0;
	while(j<maxx){
		while(skyline[j-1]==skyline[j]){
			j++;
		}

				printf("%d %d ",j,skyline[j]);



			j++;
	}





 return 0;
}