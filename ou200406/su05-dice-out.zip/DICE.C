/*
TASK:DICE
LANG:C
AUTHOR:SUTTIKORN POTHONGKOM
CENTER:SU05
*/
#include<stdio.h>
int t1=1,n1=2,w1=3,s1=5,e1=4,b1=6;	 //n=front s=back b=bottom
int pos=0,ans[6];
int main()
{
	int num,i,tmp,j,len;
	char str[100][100]  ;
	scanf("%d\n",&num);
	for(i=0;i<num;i++)
		scanf("%s",str[i]);
	/*for(i=0;i<num;i++)
		printf("%s\n",str[i]); */
	for(i=0;i<num;i++)
	{
		//scanf("%s",str);
		len=strlen(str[i]);
		for(j=0;j<len;j++)
		{
			if(str[i][j]=='F')
			{
				tmp=b1;   //tmp=b; b=n; n=t; t=s; s=tmp;
				b1=n1;
				n1=t1;
				t1=s1;
				s1=tmp;

			}
			else if(str[i][j]=='R')
			{
				tmp=b1;   //tmp=e; e=t;t=w;w=b;b =tmp
				b1=e1;
				e1=t1;
				t1=w1;
				w1=tmp;

			}
			else if(str[i][j]=='B')
			{
				tmp=b1;
				b1=s1;
				s1=t1;
				t1=n1;
				n1=tmp;

			}
			else if(str[i][j]=='L')
			{
				tmp=b1;
				b1=w1;
				w1=t1;
				t1=e1;
				e1=tmp;

			}
			else if(str[i][j]=='C')
			{
				tmp=n1;
				n1=e1;
				e1=s1;
				s1=w1;
				w1=tmp;

			}
			else if(str[i][j]=='D')
			{
				tmp=n1;
				n1=w1;
				w1=s1;
				s1=e1;
				e1=tmp;

			}
		}
		ans[pos]=n1;
		pos++;
		t1=1;n1=2;w1=3;s1=5;e1=4;b1=6;
	}
	for(i=0;i<pos;i++)	printf("%d ",ans[i]);

	return 0;
}

