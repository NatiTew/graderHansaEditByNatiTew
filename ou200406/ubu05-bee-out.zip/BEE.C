/*
TASK: BEE
LANG: C
AUTHOR: Withee Pongsawadarn
CENTER: UBU05
*/

#include<stdio.h>


int main(int argc, char *argv[])
{
	
	int mas=1,i;
	long num,result=4,work=2,sold=1;
	FILE *fp =fopen(argv[1],"r+t");
	fscanf(fp,"%ld",&num);
	while(num != -1)
	{
		//fscanf(fp,"%ld",&num);
		//printf("%ld ",num);
		if(num ==1)
		{
			
			printf("%ld %ld\n",work,result);
		}
		else
		{
			
			for(i=2; i<=num; i++)
			{
				
				sold = work;
				work = result;
				result = sold + work+mas;
			}
			
			printf("%ld %ld\n",work,result);
		}
	
	result = 4;
	sold = 1;
	work = 2;
	fscanf(fp,"%ld",&num);		
		
	}



fclose(fp);
return 0;
}