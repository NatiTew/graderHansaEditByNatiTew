/*
TASK: MAXSEQ
LANG: C
AUTHOR : NARONG WAKAYAPHATTARAMANUS
CENTER : PSUHATYAI-HADDYAI01
*/
#include<stdio.h>
int chmax(void);
int chmem(void);
int check(void);
int check1(void);
int n,maxseq=-15000,flag=0;
int sub[2500],ch[2500];
int main()
{
 int i;
 do
 {
  scanf("%d",&n);
 }
 while((n>2500)||(n<1));
 for(i=0;i<n;i++)
 {
  scanf("%d",&sub[i]);

  if((sub[i]<-127)||(sub[i]>127))
  {
   printf("Error");
   return 0;
  }
 }
 check();
 if(maxseq>0)
 check1();
 if(maxseq>0)
 printf("%d",maxseq);
 else
 printf("Empty sequence");
 return 0;
}
int check1()
{
 int i,j;
 if(flag!=1)
 {
  for(i=0;i<n;i++)
  {
   for(j=0;j<n;j++)
   {
    ch[j]=0;
   }
   for(j=i;j<n;j++)
   {
    ch[j]=1;
    if(flag!=1)
    chmem();
    else return 0;
   }
  }
 }
 return 0;
}
int chmem()
{
 int i,sum=0;
 for(i=0;i<n;i++)
 {
  if(ch[i]==1)
  {
   sum=sum+sub[i];
  }
 }
 if(sum==maxseq)
 {
  for(i=0;i<n;i++)
  {
   if(ch[i]==1)
   printf("%d ",sub[i]);
  }
  printf("\n");
  flag=1;
 }
  return 0;
}

int check()
{
 int i,j;
 for(i=0;i<n;i++)
 {
  for(j=0;j<n;j++)
  {
   ch[j]=0;
  }
  for(j=i;j<n;j++)
  {
   ch[j]=1;
   chmax();
  }
 }
  return 0;
}

int chmax()
{
 int i,sum=0;
 for(i=0;i<n;i++)
 {
  if(ch[i]==1)
  {
   sum=sum+sub[i];
  }
 }
 if(sum>maxseq)
 {
  maxseq=sum;
 }
 return 0;
}



