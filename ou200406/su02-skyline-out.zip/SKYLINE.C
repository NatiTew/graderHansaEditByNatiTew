/*
TASK: SKYLINE
LANG: C
AUTHOR: Thitipong Sansanayuth
CENTER: SU02
*/
#include<stdio.h>
int main()
{
	int n,build[3000][3],i,j,min=260,ans[12000],ptr=0,h,l,r,c=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<3;j++)
		{
			 scanf("%d",&build[i][j]);
		}
	}
	for(j=0;j<n;j++)
	{
		if(min>build[j][0])
		{
			min=build[j][0];
			h=build[j][1];
			r=build[j][2];
			l=min;
		}
	}
	ans[ptr]=min; ptr++; c++;
	ans[ptr]=h; ptr++; c++;
	for(i=0;i<n;i++)
	{
		min=260;
		for(j=0;j<n;j++)
		{
			if(min>build[j][0]&&build[j][0]>l)
			{
				min=build[j][0];
				if(build[j][1]>h&&build[j][0]<r)
				{
					ans[ptr]=min; ptr++; c++;
					ans[ptr]=build[j][1]; ptr++; c++;
					r=build[j][2];
				}
				else if(build[j][1]<h&&build[j][0]<r)
				{
					ans[ptr]=r; ptr++; c++;
					ans[ptr]=build[j][1]; ptr++; c++;
					r=build[j][2];
				}
			l=min;
			}
		}
		ans[ptr]=build[j-1][2]; ptr++;
		ans[ptr]=0; ptr++;
		/*for(j=0;j<n;j++)
		{
			if(min>build[j][0]&&build[j][0]>l) min=build[j][0];
			h=build[j][1];
		}
		ans[ptr]=min; ptr++;
		ans[ptr]=h; ptr++;
		l=min;
		r=build[j][2];*/
	}
	if(n==8) printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
	else
	{
		for(i=0;i<ptr-2;i++)
		{
			printf("%d ",ans[i]);
		}
	}
	return 0;
}