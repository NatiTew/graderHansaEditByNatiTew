/*
TASK: WORD
LANG: C
AUTHOR: Theerapat Chawannakul
CENTER: SU - su04
*/
#include<stdio.h>
#include<string.h>


char str[26][26];
char word[101][16];

char toupper(char c){
	if(c>='a' && c<='z')
		c-=32;
	return c;
}

int main(){

	int i,j,k,l,m,n,nw,flag,s,x,y,found=0;
	scanf("%d %d",&m,&n);

	for(i=0;i<m;i++){
		scanf("%s",str[i]);
	}
	scanf("%d",&nw);
	for(i=0;i<nw;i++)scanf("%s",word[i]);

	for(k=0;k<nw;k++){
	found=0;
		for(i=0;i<m;i++){
		if(found)break;
			for(j=0;j<n;j++){
				if(found)break;
				if(toupper(str[i][j])==toupper(word[k][0])){
					for(l=0;l<8;l++){
						if(found)break;
						flag=1;
						//for(s=0;s<strlen(word[k])-1 && flag==1;s++){
							s=0;
							y=i;
							x=j;
							if(l==0){  //left
								while(x>=0 && flag){
								     if(toupper(str[y][x])==toupper(word[k][s])){
									flag=1;
									x--;

									if(s==strlen(word[k])-1) break;
									s++;

								     }
								     else {
									  flag=0;
									  break;
								     }
								}
							}
							else if(l==1){ //right
								while(x<n &&flag){
								     if(toupper(str[y][x])==toupper(word[k][s])){
									flag=1;
									x++;


									if(s==strlen(word[k])-1) break;
									s++;
								     }
								     else {
									flag=0;
									break;
								     }
								}

							}
							else if(l==2){ //up
								while(y>=0&&flag){
								     if(toupper(str[y][x])==toupper(word[k][s])){
									flag=1;
									y--;
									if(s==strlen(word[k])-1) break;
									s++;

								     }
								     else{
									flag=0;
									break;
								     }
								}
							}
							else if(l==3){ //down
								while(y<m&&flag){
								     if(toupper(str[y][x])==toupper(word[k][s])){
									flag=1;
									y++;
									if(s==strlen(word[k])-1) break;
									s++;

								     }
								     else{
									flag=0;
									break;
								     }
								}
							}
							else if(l==4){ //diag upleft
								while(y>=0 && x>=0 &&flag){
								     if(toupper(str[y][x])==toupper(word[k][s])){
									flag=1;
									y--;
									x--;
									if(s==strlen(word[k])-1) break;
									s++;


								     }
								     else{
									flag=0;
									break;
								     }
								}
							}
							else if(l==5){ //diag upright
								while(y>=0 && x<n&&flag){
								     if(toupper(str[y][x])==toupper(word[k][s])){
									flag=1;
									y--;
									x++;
									if(s==strlen(word[k])-1) break;
									s++;

								     }
								     else{
									flag=0;
									break;
								     }
								}
							}
							else if(l==6){ //diag downleft
								while(y<m && x>=0&&flag){
								     if(toupper(str[y][x])==toupper(word[k][s])){
									flag=1;
									y++;
									x--;
									if(s==strlen(word[k])-1) break;
									s++;

								     }
								     else{
									 flag=0;
									 break;
								     }
								}
							}
							else if(l==7){ //diag downright
								while(y<m && x<n && flag){
								     if(toupper(str[y][x])==toupper(word[k][s])){
									flag=1;
									y++;
									x++;
									if(s==strlen(word[k])-1) break;
									s++;

								     }
								     else {
									flag=0;
									break;
								     }
								}

							}

							if(x<-1 || x>n || y>n || y<-1) flag=0;
							if(s==strlen(word[k])-1 && flag==1){
								printf("%d %d",i,j);
								printf("\n");
								found=1;
								break;


						}


					}
				}

			}
		}
	}
	return 0;
}