/*
TASK: BEE
LANG: C
AUTHOR: Saranyu Koothanapath
CENTER: tu04
*/
#include<stdio.h>
long bee[50][2];
int main()
{
	int in=0;
	int know=1;
	bee[0][0]=1;
	for(;in!=-1;)
	{
		scanf("%d",&in);
		if(in==-1)break;
		if(in>=know)
		{
			for(;know<=in;++know)
			{
				bee[know][0]+=bee[know-1][0];
				bee[know][0]+=bee[know-1][1];
				++bee[know][0];
				bee[know][1]+=bee[know-1][0];
			}
		}
		printf("%ld %ld\n",bee[in][0],bee[in][0]+bee[in][1]+1);
	}
	return 0;
}
