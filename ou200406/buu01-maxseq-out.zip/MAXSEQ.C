/*
TASK: MAXSEQ
LANG: C
AUTHOR: GAIPEACH SUCHARTKULVIT
CENTER: ASSUMPTION COLLEGE SRIRACHA - buu01
*/
#include <stdio.h>

int main(void)
{
	int n,pos=-1;
	int i,j,true=0;
	int in[2600],posl[2600];
	long maxy=0,max[2600]={0};
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&in[i]);
		if(in[i]>-1)
			true++;
	}
	if(true==n)
	{
		for(i=0;i<n;i++)
		{
			printf("%d ",in[i]);
			maxy+=in[i];
		}
		printf("\n%ld\n",maxy);
	}
	else if(true==0)
	{
		printf("Empty sequence\n");
	}
	else
	{
		long psum[2600]={0};
		for(i=n-1;i>=0;i--)
		{
			for(j=i;j<n;j++)
			{
				long sum=0;
				sum=in[i]+psum[j];
				if(sum>max[i])
				{
					posl[i]=j;
					max[i]=sum;
				}
				psum[j]=sum;
			}
		}
		for(maxy=0,i=0;i<n;i++)
		{
			if(max[i]>maxy)
			{
				pos=i;
				maxy=max[i];
			}
		}
		for(i=pos;i<=posl[pos];i++)
		{
			printf("%d ",in[i]);
		}
		printf("\n%ld\n",maxy);
	}
	return 0;
}