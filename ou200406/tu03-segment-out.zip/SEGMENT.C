/*
TASK: SEGMENT
LANG: C
AUTHOR: Nuttakorn Benjamasutin (Assumption)
CENTER: tu03
*/

#include <stdio.h>
#include <string.h>

#define MAX 20
#define MAXLEN 3
#define BLANK ' '
#define MAXDIGIT 10

const char digit[][MAX]={ " _ | ||_|","     |  |"," _  _||_ ",
						  " _  _| _|","   |_|  |"," _ |_  _|",
						  " _ |_ |_|"," _   |  |"," _ |_||_|",
						  " _ |_| _|" };
char a[MAX][MAX], b[MAX][MAX];

long whatIs(char temp[])
{
	int i;
	for(i=0; i<MAXDIGIT; i++)
		if( !strcmp(temp, digit[i]) ) return i;
	return 0;
}
int main()
{
	long nA, nB, sumA, sumB;
	long i, j, k, len;
	char temp[MAX];
//	freopen("input2.txt","rt",stdin);
	scanf("%ld %ld\n",&nA,&nB);
	// Input A
	for(i=0; i<MAXLEN; i++)
	{
		for(j=0; ;j++)
		{
			scanf("%c",&temp[j]);
			if(temp[j] == '\n') break;
		}
		temp[j]=NULL;
		len=j-1;
		for(j=nA-1; j>=0; j--)
		{
			for(k=MAXLEN-1; k>=0;)
			{
				if(len>=0) a[j][i*3+k]=temp[len--];
				else a[j][i*3+k]=' ';
				if(a[j][i*3+k] == '|' || a[j][i*3+k] == '_' || a[j][i*3+k] == BLANK) k--;
				else;
			}
			if(len>=0) len--;
		}
	}
	// Input B
	for(i=0; i<MAXLEN; i++)
	{
		for(j=0; ;j++)
		{
			scanf("%c",&temp[j]);
			if(temp[j] == '|' || temp[j] == '_' || temp[j] == BLANK);
			else break;
		}
		temp[j]=NULL;
		len=j-1;
		for(j=nB-1; j>=0; j--)
		{
			for(k=MAXLEN-1; k>=0;)
			{
				if(len>=0) b[j][i*3+k]=temp[len--];
				else b[j][i*3+k]=' ';
				if(b[j][i*3+k] == '|' || b[j][i*3+k] == '_' || b[j][i*3+k] == BLANK) k--;
				else;
			}
			if(len>=0) len--;
		}
	}

	for(i=0, sumA=0; i<nA; i++, sumA*=10)
		sumA+=whatIs(a[i]);
	sumA/=10;
	for(i=0, sumB=0; i<nB; i++, sumB*=10)
		sumB+=whatIs(b[i]);
	sumB/=10;
	sumA+=sumB;
	printf("%ld\n", sumA);
	return 0;
}