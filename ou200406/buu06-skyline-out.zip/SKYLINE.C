/*
TASK: SKYLINE
LANG: C
AUTHOR: Nopphorn Pitaksuebpon
CENTER: buu06
*/
#include <stdio.h>

int main(void)
{
   int con=0,n,i,j,l,h,r,max=0,point[255][3];
   for(i=0;i<=255;i++)
   {
      point[i][0]=0;
      point[i][1]=0;
      point[i][2]=-1;
   }
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
      scanf("%d %d %d",&l,&h,&r);
      if((point[l][0]==0)&&(point[l][1]<h))
      {
	 point[l][0]=1;
	 point[l][1]=h;
	 point[l][2]=h;
      }
      for(j=l+1;j<r;j++)
      {
	 if(point[j][1]<h)
	 {
	    if((point[j][0]==1)&&(point[j][2]<h))
	    {
	       point[j][0]=0;
	       point[j][2]=-1;
	    }
	    point[j][1]=h;
	 }
      }
      if((point[r][0]==0)&&(point[r][1]==0))
      {
	 point[r][0]=1;
	 point[r][1]=0;
	 point[r][2]=h;
      }
      else if((point[r][0]==0)&&(point[r][1]!=0))
      {
	 point[r][0]=1;
      }
      if(r>max)
	 max=r;
   }
   for(i=1;i<=max;i++)
   {
      if(point[i][0]==1)
      {
	 if(con==0)
	    con=1;
	 else
	    printf(" ");
	 printf("%d %d",i,point[i][1]);
      }
   }
   printf("\n");
   return 0;
}