/*
TASK: WORD
LANG: C
AUTHOR: Suthee Kongkiatpaiboon
CENTER: Mahidol03
*/

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>

char a[30][30]={{0}};
char s[20]={0};
int col,row,n;
FILE *fi;

int sca(int ,int );
int scal(int ,int );
int scaul(int ,int );
int scau(int ,int );
int scaur(int ,int );
int scar(int ,int );
int scadr(int ,int );
int scad(int ,int );
int scadl(int ,int );
int inp(void);


int main()
{

  int i,x,y;
  int num;

//  FILE *fi;
  //fi=fopen("C:\\posn2\\wo1.in","r");
  fi=stdin;
  inp();

  fscanf(fi,"%d",&num);

  for(i=0;i<num;i++)
  {
    fscanf(fi,"%s",s);
    strlwr(s);
    for(x=1;x<=row;x++)
      {
	for(y=1;y<=col;y++)
	  {
	     if(sca(x,y)==1)
	       {
		 printf("%d %d\n",x-1,y-1);
	       }
	  }
      }
  }


  return 0;
}

int inp(void)
{
  int i,j;
  fscanf(fi,"%d %d\n",&row,&col);

  for(i=1;i<=row;i++)
    {
      for(j=1;j<=col;j++)
	{
	  fscanf(fi,"%c",&a[i][j]);
	  a[i][j]=tolower(a[i][j]);
	}
      fgetc(fi);
    }
  return 0;
}

int sca(int x,int y)
{
   if(scal(x,y)==1) return 1;
   if(scaul(x,y)==1) return 1;
   if(scau(x,y)==1) return 1;
   if(scaur(x,y)==1) return 1;
   if(scar(x,y)==1) return 1;
   if(scadr(x,y)==1) return 1;
   if(scad(x,y)==1) return 1;
   if(scadl(x,y)==1) return 1;

   return 0;

}

int scal(int x,int y)
{
    int i,cnt;
    cnt=0;
    for(i=0;(i<strlen(s))&&(y-i>0);i++)
      {
	 if(a[x][y-i]==s[i])
	   {
	     cnt++;
	   }
	 else break;
      }
    if(cnt==strlen(s))
      return 1;
    return 0;
}

int scaul (int x,int y)
{
  int i,cnt;
  cnt=0;

  for(i=0;(i<strlen(s))&&(x-i>0)&&(y-i>0);i++)
    {
      if(a[x-i][y-i]==s[i])
       cnt++;
      else break;
    }
  if(cnt==strlen(s))
    return 1;
  return 0;
}

int scau(int x,int y)
{
  int i,cnt;
  cnt=0;

  for(i=0;(i<strlen(s))&&(x-i>0);i++)
    {
      if(a[x-i][y]==s[i])
	{
	  cnt++;
	}
      else break;
    }
  if(cnt==strlen(s))
    return 1;
  return 0;
}

int scaur(int x,int y)
{
   int i,cnt;
   cnt=0;

   for(i=0;(i<strlen(s))&&(x-i>0)&&(y+i<=col);i++)
     {
       if(a[x-i][y+i]==s[i])
	 cnt++;
       else break;
     }

   if(cnt==strlen(s))
    return 1;
   return 0;
}

int scar(int x,int y)
{
  int i,cnt;
  cnt=0;

  for(i=0;(i<strlen(s))&&(y+i<=col);i++)
    {
      if(a[x][y+i]==s[i])
	cnt++;
      else break;
    }
  if(cnt==strlen(s))
    return 1;
   return 0;

}

int scadr(int x,int y)
{
  int i,cnt;
  cnt=0;

  for(i=0;(i<strlen(s))&&(y+i<=col)&&(x+i<=row);i++)
    {
      if(a[x+i][y+i]==s[i])
	cnt++;
      else break;
    }
  if(cnt==strlen(s))
    return 1;
   return 0;

}

int scad(int x,int y)
{
  int i,cnt;
  cnt=0;

  for(i=0;(i<strlen(s))&&(x+i<=col);i++)
    {
      if(a[x+i][y]==s[i])
	cnt++;
      else break;
    }
  if(cnt==strlen(s))
    return 1;
   return 0;

}

int scadl(int x,int y)
{
  int i,cnt;
  cnt=0;

  for(i=0;(i<strlen(s))&&(y-i>0)&&(x+i<=row);i++)
    {
      if(a[x+i][y-i]==s[i])
	cnt++;
      else break;
    }
  if(cnt==strlen(s))
    return 1;
   return 0;

}