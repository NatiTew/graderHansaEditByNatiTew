/*
TASK: SEGMENT
LANG: C
AUTHOR: Taksapaun Kittiakrastien
CENTER: tu08
*/

#include<stdio.h>
#include<math.h>

int main()
{
  int a,b;
  int i,j,k;
  char ch[10][3][3];     //number, row, col
  double val[2]={0,0};

//  freopen("test.in", "r", stdin);

  scanf("%d", &a);
  scanf("%d", &b);
  scanf("%*c");


  for(i=0;i<3;i++)         //3 lines
  {
    for(j=0;j<a;j++)       //a numbers
    {
      for(k=0;k<3;k++)     //3 chrs in each num
      {
	scanf("%c", &ch[j][i][k]);
      }
      scanf("%*c"); //get the space or \n
    }
  }

  //convert
  for(i=0;i<a;i++)
  {
    if(ch[i][0][1]=='_')
    {
      if(ch[i][2][0]=='|')
      {
	//2 6 8 0
	if(ch[i][1][0]==' ')
	{
	  //2
	  val[0]+= pow(10,(a-i-1)) * 2;
	}
	else if(ch[i][1][2]==' ')
	{
	  //6
	  val[0]+= pow(10,(a-i-1)) * 6;
	}
	else if(ch[i][1][1]=='_')
	{
	  //8
	  val[0]+= pow(10,(a-i-1)) * 8;
	}
	else
	{
	  //0
	}
      }
      else
      {
	//3 5 7 9
	if(ch[i][1][0]=='|')
	{
	  //5 9
	  if(ch[i][1][2]==' ')
	  {
	    //5
	    val[0]+= pow(10,(a-i-1)) * 5;
	  }
	  else
	  {
	    //9
	    val[0]+= pow(10,(a-i-1)) * 9;
	  }
	}
	else
	{
	  //3 7
	  if(ch[i][1][1]=='_')
	  {
	    //3
	    val[0]+= pow(10,(a-i-1)) * 3;
	  }
	  else
	  {
	    //7
	    val[0]+= pow(10,(a-i-1)) * 7;
	  }
	}
      }
    }
    else
    {
      // 1 or 4
      if(ch[i][1][1]=='_')
      {
	//4
	val[0]+= pow(10,(a-i-1)) * 4;
      }
      else
      {
	//1
	val[0]+= pow(10,(a-i-1));
      }
    }
  }//end convert



  //for b <same code>
  for(i=0;i<3;i++)         //3 lines
  {
    for(j=0;j<b;j++)       //b numbers
    {
      for(k=0;k<3;k++)     //3 chrs in each num
      {
	scanf("%c", &ch[j][i][k]);
      }
      scanf("%*c"); //get the space or \n
    }
  }

  //convert
  for(i=0;i<b;i++)
  {
    if(ch[i][0][1]=='_')
    {
      if(ch[i][2][0]=='|')
      {
	//2 6 8 9
	if(ch[i][1][0]==' ')
	{
	  //2
	  val[1]+= pow(10,(b-i-1)) * 2;
	}
	else if(ch[i][1][2]==' ')
	{
	  //6
	  val[1]+= pow(10,(b-i-1)) * 6;
	}
	else if(ch[i][1][1]=='_')
	{
	  //8
	  val[1]+= pow(10,(b-i-1)) * 8;
	}
	else
	{
	  //0
	}
      }
      else
      {
	//3 5 7 9
	if(ch[i][1][0]=='|')
	{
	  //5 9
	  if(ch[i][1][2]==' ')
	  {
	    //5
	    val[1]+= pow(10,(b-i-1)) * 5;
	  }
	  else
	  {
	    //9
	    val[1]+= pow(10,(b-i-1)) * 9;
	  }
	}
	else
	{
	  //3 7
	  if(ch[i][1][1]=='_')
	  {
	    //3
	    val[1]+= pow(10,(b-i-1)) * 3;
	  }
	  else
	  {
	    //7
	    val[1]+= pow(10,(b-i-1)) * 7;
	  }
	}
      }
    }
    else
    {
      // 1 or 4
      if(ch[i][1][1]=='_')
      {
	//4
	val[1]+= pow(10,(b-i-1)) * 4;
      }
      else
      {
	//1
	val[1]+= pow(10,(b-i-1));
      }
    }
  }//end convert b

  printf("%.0lf", val[0]+val[1]);

  return 0;
}