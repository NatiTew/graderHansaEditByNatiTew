/*
TASK: SKYLINE
LANG: C
AUTHER: Prayote Boonchaisuk
CENTER: SUT02
*/
#include<stdio.h>
void main(){
 int N,i,j,in=0,
     l,h,r,
     tb[260]={0},t[800]={0};
	scanf(" %d",&N);
	for(i=0;i<N;i++)
	   {
	    scanf(" %d",&l);
	    scanf(" %d",&h);
	    scanf(" %d",&r);
	    for(j=l;j<r;j++)
		if(tb[j]<h)   tb[j]=h;
	   }
	for(i=0;i<260;i++)
	   {
	    if(tb[i]!=t[in])
		{
		 t[++in]=i;
		 t[++in]=tb[i];
		}
	   }
	for(i=0;i<in;i++)
	   printf("%d ",t[i+1]);
}