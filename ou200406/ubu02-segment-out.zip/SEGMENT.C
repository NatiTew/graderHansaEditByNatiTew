/*
TASK: SEGMENT
LANG: C
AUTHOR: WACHIRA SUPPASATEAN
CENTER: UBU02
*/
#include <stdio.h>

int main( void )
{

	return 0;
}