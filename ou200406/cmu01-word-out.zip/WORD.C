/*
TASK: WORD
LANG: C
AUTHOR: Sorawit Boonyathee
CENTER: cmu01
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
	char word[26][26];
	char chk[16];
	int i,row,len,count,found,j,k,length,temp,x,headrow,headcol,m;
	scanf("%d",&row);
	scanf("%d",&len);
	for(i=0;i<row;i++)
	{
		scanf("%s",word[i]);
	}
	//change to lower
	for(i=0;i<row;i++)
	{
		for(j=0;j<len;j++)
		{
			word[i][j]=tolower(word[i][j]);
		}
	}
	scanf("%d",&count);
	for(i=0;i<count;i++)
	{
		scanf("%s",chk);
		length=strlen(chk);
		//change to lower
		for(j=0;j<length;j++)
		{
			chk[j]=tolower(chk[j]);
		}
		found=0;
		//change to lower
		for(j=0;j<length;j++)
		{
			chk[j]=tolower(chk[j]);
		}
		found=0;
		//find in row
		for(j=0;j<row&&found==0;j++)
		{
			temp=0;
			x=0;
			for(k=0;k<len&&found==0;k++)
			{
				if(word[j][k]==chk[x])
				{
					temp++;
					x++;
					if(temp==1)
					{
						headrow=j;
						headcol=k;
					}
				}
				if(temp==length)	found=1;
			}
		}
		//find back row
		for(j=0;j<row&&found==0;j++)
		{
			temp=0;
			x=0;
			for(k=len-1;k>=0&&found==0;k--)
			{
				if(word[j][k]==chk[x])
				{
					temp++;
					x++;
					if(temp==1)
					{
						headrow=j;
						headcol=k;
					}
				}
				if(temp==length)	found=1;
			}
		}
		//find col 0 - n
		for(j=0;j<len&&found==0;j++)
		{
			temp=0;
			x=0;
			for(k=0;k<row&&found==0;k++)
			{
				if(word[k][j]==chk[x])
				{
					temp++;
					x++;
					if(temp==1)
					{
						headrow=k;
						headcol=j;
					}
				}
				if(temp==length)	found=1;
			}
		}
		//find col n - 0
		for(j=0;j<len&&found==0;j++)
		{
			temp=0;
			x=0;
			for(k=row-1;k>=0&&found==0;k--)
			{
				if(word[k][j]==chk[x])
				{
					temp++;
					x++;
					if(temp==1)
					{
						headrow=k;
						headcol=j;
					}
				}
				if(temp==length)	found=1;
			}
		}
		//cross r to l up to down
		for(j=0;j<row&&found==0;j++)
		{
			for(k=0;k<len&&found==0;k++)
			{
				for(m=0,x=0,temp=0&&found==0;j+m<row&&k+m<len;m++)
				{
				if(word[j+m][k+m]==chk[x])
				{
					temp++;
					x++;
					if(temp==1)
					{
						headrow=j+m;
						headcol=k+m;
					}
				}
				if(temp==length)	found=1;
				}
			}
		}
		//cross l to r up to down
		for(j=0;j<row&&found==0;j++)
		{
			for(k=len-1;k>=0&&found==0;k--)
			{
				for(m=0,x=0,temp=0;found==0&&j+m<row&&k-m>=0;m++)
				{
				if(word[j+m][k-m]==chk[x])
				{
					temp++;
					x++;
					if(temp==1)
					{
						headrow=j+m;
						headcol=k-m;
					}
				}
				if(temp==length)	found=1;
				}
			}
		}
		//cross r to l down to up
		for(j=row-1;j>=0&&found==0;j--)
		{
			for(k=0;k<len&&found==0;k++)
			{
				for(m=0,x=0,temp=0;found==0&&j-m>=0&&k+m<len;m++)
				{
				if(word[j-m][k+m]==chk[x])
				{
					temp++;
					x++;
					if(temp==1)
					{
						headrow=j-m;
						headcol=k+m;
					}
				}
				if(temp==length)	found=1;
				}
			}
		}
		//cross l to r down to up
		for(j=row-1;j>=0&&found==0;j--)
		{
			for(k=len-1;k>=0&&found==0;k--)
			{
				for(m=0,x=0,temp=0;found==0&&j-m>=0&&k-m>=0;m++)
				{
				if(word[j-m][k-m]==chk[x])
				{
					temp++;
					x++;
					if(temp==1)
					{
						headrow=j-m;
						headcol=k-m;
					}
				}
				if(temp==length)	found=1;
				}
			}
		}
		printf("%d %d\n",headrow,headcol);
	}
	return 0;
}