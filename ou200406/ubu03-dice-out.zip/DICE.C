/*
TASK: DICE
LANG: C
AUTHOR: THAWATCHAI MUKMANEE
CENTER: ubu03
*/
#include <stdio.h>
#include <string.h>
char time[1000];
int num;
int ward1(int j);
int ward2(int j);
int ward3(int j);
int ward4(int j);
int ward5(int j);
int ward6(int j);
int main()
{
	int x,i,k,n;
	int arry[6];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	scanf("%s",time);
	x=strlen(time);
	num=7;
		for(k=x-1;k>=0;k--)
		{
			switch(time[k])
			{
			case 'F':ward1(num);break;
			case 'B':ward2(num);break;
			case 'L':ward3(num);break;
			case 'R':ward4(num);break;
			case 'C':ward5(num);break;
			case 'D':ward6(num);break;
			}
		}
		switch(num)
		{
		case 1:arry[i]=1;break;
		case 2:arry[i]=2;break;
		case 3:arry[i]=3;break;
		case 4:arry[i]=5;break;
		case 5:arry[i]=4;break;
		case 6:arry[i]=6;break;
		}
	}
	for(i=0;i<n;i++)
	{
	printf("%d",arry[i]);
	 if(i<n-1)
	 printf(" ");
	 else
	 printf("\n");
	}
	return 0;
}
int ward1(int j)
{
switch(j)
{
case 1:num=4;break;
case 2:num=1;break;
case 3:num=3;break;
case 4:num=6;break;
case 5:num=5;break;
case 6:num=2;break;
case 7:num=1;break;
}
return 0;
}
int ward2(int j)
{
switch(j)
{
case 1:num=2;break;
case 2:num=6;break;
case 3:num=3;break;
case 4:num=1;break;
case 5:num=5;break;
case 6:num=4;break;
case 7:num=6;break;
}
return 0;
}
int ward3(int j)
{
switch(j)
{
case 1:num=5;break;
case 2:num=2;break;
case 3:num=1;break;
case 4:num=4;break;
case 5:num=6;break;
case 6:num=3;break;
case 7:num=2;break;
}
return 0;
}
int ward4(int j)
{
switch(j)
{
case 1:num=3;break;
case 2:num=2;break;
case 3:num=6;break;
case 4:num=4;break;
case 5:num=1;break;
case 6:num=5;break;
case 7:num=2;break;
}
return 0;
}
int ward5(int j)
{
switch(j)
{
case 1:num=1;break;
case 2:num=5;break;
case 3:num=2;break;
case 4:num=3;break;
case 5:num=4;break;
case 6:num=6;break;
case 7:num=5;break;
}

return 0;
}
int ward6(int j)
{
switch(j)
{
case 1:num=1;break;
case 2:num=3;break;
case 3:num=4;break;
case 4:num=5;break;
case 5:num=2;break;
case 6:num=6;break;
case 7:num=3;break;
}
return 0;
}