/*
TASK: SEGMENT
LANG: C
AUTHOR: Charuwat Hougkaew
CENTER: KKU01
*/

#include <stdio.h>
int a[10][3][3];
char s[60];
int num=0;
double data[2]={0,0};
int digit[2];
int checknum(int arr[][3])
{
	int temp=0,i,j;
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			temp=temp<<1;
			temp|=arr[i][j]&1;
		}
	}
		switch(temp)
	{
		case 9: return 1;
		case 158 : return 2;
		case 155: return 3;
		case 57: return 4;
		case 179 :return 5;
		case 183 : return 6;
		case 137: return 7;
		case 191 :return 8;
		case 187: return 9;
		case 151:return 0;
	}

}


int main()
{
	int i,j,k,l,m,len;
	char c;

	scanf("%d %d",&digit[0],&digit[1]);
	for(i=0;i<2;i++)
	{

			for(k=0;k<3;k++)
			{
				rewind(stdin);
				fgets(s,60,stdin);
				//strcpy(s,s+1);
				len=strlen(s);
				for(j=0;j<len && j<4*digit[i]-1;j++)
				{

				   if(j%4==3)continue;
				   else
					c=s[j];

						if(c=='|' || c=='_')
							a[j/4][k][j%4]=1;
						else
							a[j/4][k][j%4]=0;
				}

			}
			if(i!=1)
			fgets(s,60,stdin);
			for(k=0;k<digit[i];k++)
			{
				data[i]*=10;
				data[i]+=checknum(a+k);
			}


	}


	printf("%.0lf\n",data[0]+data[1]);

return 0;
}