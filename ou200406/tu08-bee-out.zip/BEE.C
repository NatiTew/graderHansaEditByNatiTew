/*
TASK: BEE
LANG: C
AUTHOR: Taksapaun Kittiakrastien
CENTER: tu08
*/

#include<stdio.h>

int main()
{
  char ch;
  int i;
  long int ansarr[26][3];  //3 is worker-soldier-total

  ansarr[0][0] = 1;
  ansarr[0][1] = 0;
  ansarr[0][2] = 2;
  //calc
  for(i=1;i<=24;i++)
  {
    ansarr[i][0] = ansarr[i-1][0] + ansarr[i-1][1] + 1;
    ansarr[i][1] = ansarr[i-1][0];
    ansarr[i][2] = ansarr[i][0] + ansarr[i][1] + 1;
  }

  //scan and print
  scanf("%d", &ch);
  while(ch!=-1)
  {
    printf("%ld %ld\n", ansarr[ch][0], ansarr[ch][2]);
    scanf("%d", &ch);
  }
  return 0;
}