/*
TASK: SKYLINE
LANG: C
AUTHEOR: KUNAKORN TENGCHIANG
CENTER: NU02
*/


#include<stdio.h>
#include<ctype.h>


main(){
 int n,l,h,r,i,a=3,j;
 int line[100];

 scanf("%d",&n);
 for(i=1;i<=n;i++){
	scanf("%d %d %d",&l,&h,&r);
	if(i==1){
		line[0]=l;
		line[1]=h;
		line[2]=r;
	}
	else{
		for(j=0;j<a;j++){
			if(l>line[j]){
				if(h>line[j+1]){
					if(line[j+2]<=r){
					line[j+2]=l;
					line[j+3]=h;
					line[j+4]=r;
					a=j+5;
					}
					else if(line[j+2]>r){
					line[j+5]=line[j+1];
					line[j+6]=line[j+1];
					line[j+2]=l;
					line[j+3]=h;
					line[j+4]=r;
					a=j+7;
					}

				}
				else if(line[j+2]<r){
					line[j+3]=h;
					line[j+4]=r;
					a=j+5;
				}

			}
		}
	}
 }
 for(i=0;i<a;i++)
	printf("%d ",line[i]);
 printf("0");
 return 0;
}
