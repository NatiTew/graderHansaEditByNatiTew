/*
TASK: DICE
LANG: C
AUTHOR: Veerakorn Poonsilp
CENTER: PSUPN05
*/
#include<stdio.h>
#include<string.h>
void swap(int *a,int *b);
void main(){
 int n,i,j,item1,item2,left,right,top,bottom,forward,backward,dice[6],item3,item4,item5,item6;
 char tis[6][1000]={NULL};
 scanf("%d",&n);
 for(i=0;i<n;i++){
    scanf("%s",&tis[i]);
 }
 for(i=0;i<n;i++){
    top=1;
    forward=2;
    left=3;
    right=4;
    backward=5;
    bottom=6;
    j=0;
    while(tis[i][j]!=NULL){
      item1=top;
      item2=forward;
      item3=left;
      item4=right;
      item5=backward;
      item6=bottom;
      switch(tis[i][j]){
	case 'F':
		 forward=item1;
		 top=item5;
		 backward=item6;
		 bottom=item2;
	       break;
	case 'B':
		 top=item2;
		 backward=item1;
		 bottom=item5;
		 forward=item6;
	       break;
	case 'L':
		 left=item1;
		 bottom=item3;
		 right=item6;
		 top=item4;
	       break;
	case 'R':
		 right=item1;
		 bottom=item4;
		 left=item6;
		 top=item3;
	       break;
	case 'C':left=item2;
		 backward=item3;
		 right=item5;
		 forward=item4;
	       break;
	case 'D':
		 right=item2;
		 backward=item4;
		 left=item5;
		 forward=item3;
	       break;
      }
      j++;
    }
    dice[i]=forward;
 }
 for(i=0;i<n;i++){
    printf("%d ",dice[i]);
 }
}
void swap(int *a,int *b){
 int item;
 item=*a;
 *a=*b;
 *b=item;
}