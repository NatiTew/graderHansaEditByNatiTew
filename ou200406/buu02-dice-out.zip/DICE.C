/*
TASK: DICE
LANG: C
AUTHOR: Khakhana Thimachai
CENTER: buu02
*/

#include<stdio.h>


void set(int *p1,int *p2,int *p3,int *p4,int *p5,int *p6);
void swap(int *a,int *b);
int main(void){
	int p1,p2,p3,p4,p5,p6;
	int n;
	int i=0;
	int ch;
	scanf("%d ",&n);
	while(i<n){
		set(&p1,&p2,&p3,&p4,&p5,&p6);
		//printf("%d %d %d %d %d %d\n",p1,p2,p3,p4,p5,p6);
		ch = getchar();
		while(ch!='\n'){
		//while(ch=='F'||ch=='B'||ch=='L'||ch=='R'||ch=='C'||ch=='D'){
			if(ch=='F'){
				swap(&p1,&p4);
				swap(&p2,&p6);
				swap(&p2,&p4);
			}else if(ch=='B'){
				swap(&p4,&p6);
				swap(&p2,&p1);
				swap(&p2,&p4);
			}else if(ch=='L'){
				swap(&p5,&p6);
				swap(&p6,&p1);
				swap(&p6,&p3);
			}else if(ch=='R'){
				swap(&p1,&p5);
				swap(&p1,&p6);
				swap(&p3,&p1);
			}else if(ch=='C'){
				swap(&p2,&p5);
				swap(&p3,&p5);
				swap(&p4,&p5);
			}else if(ch=='D'){
				swap(&p2,&p3);
				swap(&p3,&p4);
				swap(&p4,&p5);
			}
			//printf("%c  ",ch);
			ch = getchar();
		}
		printf("%d ",p2);
		i++;
	}
	return 0;
}
void set(int *p1,int *p2,int *p3,int *p4,int *p5,int *p6){
	*p1=1;
	*p2=2;
	*p3=3;
	*p4=5;
	*p5=4;
	*p6=6;
}
void swap(int *a,int *b){
	int tmp;
	tmp = *a;
	*a = *b;
	*b = tmp;
}