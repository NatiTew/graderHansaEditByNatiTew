/*
TASK: WORD
LANG: C
AUTHOR: CHaruwat Houngkaew
CENTER: KKU01
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
char a[25][25];int m,n;
int words;
int pos[2]={25,25};
char s[20];
//int check(int x,int y)
//{
	//if(x <0 || x>=m || y<0 || y>=n)
	//return 0;
	//else
	//return 1;
//}
void proc1(int x,int y)
{
	int i,j,len,k;
	len= strlen(s);
	for(i=x,k=0;i<len+x;i++,k++)
	{
		if( s[k]!=a[y][i])
		break;
	}
		if(i==len+x)
		{
			if(x+y<pos[0]+pos[1])
			pos[0]=y;
			pos[1]=x;
		}
}
void proc2(int x,int y)
{
	int i,j,len,k;
	len= strlen(s);
	for(i=y,k=0;i<len+y;i++,k++)
	{
		if(s[k]!=a[i][x])
		break;
	}
		if(i==len+y)
		{
			if(x+y<pos[0]+pos[1])
			pos[0]=y;
			pos[1]=x;
		}
}
void proc3(int x,int y)
{
	int i,j,len,k;
	len= strlen(s);
	for(i=0,k=0;i>-len;i--,k++)
	{
		if(s[k]!=a[y][i+x])
		break;
	}
		if(i==-len)
		{
			if(x+y<pos[0]+pos[1])
			pos[0]=y;
			pos[1]=x;
		}
}

void proc4(int x,int y)
{
	int i,j,len,k;
	len= strlen(s);
	for(i=y,k=0;i>y-len;i--,k++)
	{
		if(s[k]!=a[i][x])
		break;
	}
		if(i==y-len)
		{
			if(x+y<pos[0]+pos[1])
			pos[0]=y;
			pos[1]=x;
		}
}
void proc5(int x,int y)
{
	int i,j,len,k;
	len= strlen(s);
	for(i=0,k=0,j=0;i<len&&j<len;i++,j++,k++)
	{
		if(s[k]!=a[i+y][j+x])
		break;
	}
		if(i==len && j==len)
		{
			if(x+y+i+j<pos[0]+pos[1])
			pos[0]=y;
			pos[1]=x;
		}
}
void proc6(int x,int y)
{
	int i,j,len,k;
	len= strlen(s);
	for(i=0,j=0,k=0;i<len&&j>-len;i++,j--,k++)
	{
		if(s[k]!=a[i+y][j+x])
		break;
	}
		if(i==len && j==-len)
		{
			if(x+y<pos[0]+pos[1])
			pos[0]=y;
			pos[1]=x;
		}
}
void proc7(int x,int y)
{
	int i,j,len,k;
	len= strlen(s);
	for(i=0,j=0,k=0;i>-len&&j>-len;i--,j--,k++)
	{
		if( s[k]!=a[i+y][j+x])
		break;
	}
		if(i==-len && j==-len)
		{
			if(x+y<pos[0]+pos[1])
			pos[0]=y;
			pos[1]=x;
		}
}
void proc8(int x,int y)
{
	int i,j,len,k;
	len= strlen(s);
	for(i=0,j=0,k=0;i>-len&&j<len;i--,j++,k++)
	{
		if(s[k]!=a[i+y][j+x])
		break;
	}
		if(i==-len && j==len)
		{
			if(x+y<pos[0]+pos[1])
			pos[0]=y;
			pos[1]=x;
		}
}

int main()
{
	int i,j,k,len=0;
	//clrscr();
	scanf("%d %d",&n,&m);
	scanf("%c",&a[0][0]);
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%c",&a[i][j]);

			a[i][j]=tolower(a[i][j]);
			if(!isalpha(a[i][j]))j--;
		}
		//scanf("%c");
	}
	scanf("%d",&words);
	len=strlen(s);
	for(k=0;k<len;k++)
		s[k]=tolower(s[k]);

	for(k=0;k<words;k++)
	{   scanf("%s",&s);
		pos[0]=25;
		pos[1]=25;

		for(i=0;i<n;i++)
		{
			for(j=0;j<m;j++)
			{
				if(s[0]==a[i][j])
				{
					proc1(j,i);
					proc2(j,i);
					proc3(j,i);
					proc4(j,i);
					proc5(j,i);
					proc6(j,i);
					proc7(j,i);
					proc8(j,i);
				}
			}
		}
		printf("%d %d\n",pos[0],pos[1]);
	}
return 0;
}