/*
TASK: DICE
LANG: C
AUTHOR: SINN SATJAWATTANAVIMOL
CENTER: CMU06
*/
#include<stdio.h>
int main(void)
{
	int n,i,c,up=1,fr=2,lf=3,bk=5,rt=4,dw=6,ans[1000],temp;
	char cmd[1000];
	scanf("%d",&n);
	for(i=0,c=0;i<n;i++,c=0,up=1,fr=2,lf=3,bk=5,rt=4,dw=6)
	{
		scanf("%s",cmd);
		while(cmd[c]!='\0')
		{
			switch(cmd[c])
			{
				case 'F':	temp=bk;
						bk=dw;
						dw=fr;
						fr=up;
						up=temp;
				break;
				case 'B':	temp=fr;
						fr=dw;
						dw=bk;
						bk=up;
						up=temp;
				break;
				case 'L': 	temp=rt;
						rt=dw;
						dw=lf;
						lf=up;
						up=temp;
				break;
				case 'R':	temp=lf;
						lf=dw;
						dw=rt;
						rt=up;
						up=temp;
				break;
				case 'C':	temp=rt;
						rt=bk;
						bk=lf;
						lf=fr;
						fr=temp;
				break;
				case 'D': 	temp=lf;
						lf=bk;
						bk=rt;
						rt=fr;
						fr=temp;
				break;
			}
			c++;
		}
		ans[i]=fr;
	}
	for(c=0;c<i;c++)
		printf("%d ",ans[c]);
	return 0;
}