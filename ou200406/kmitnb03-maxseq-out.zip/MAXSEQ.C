/*
TASK: MAXSEQ
LANG: C
AUTHOR: THANTARATORN TANALERD
CENTER: KMITNB03
*/

#include<stdio.h>
void main() {
	int N,max=0;
	int i,j,a,k,result=0;
	int set[2500];
	int ans[3],ans2[3];
	scanf("%d",&N);
   if(N<=3) {
	for(i=0;i<N;i++) scanf("%d",&set[i]);
	printf("Enpty sequence");
   } else {
	for(i=0;i<N;i++) {
		scanf("%d",&set[i]);
	}
	for(i=0;i<=N-3;i++) {
		a=0;
		for(j=i;j<=i+2;j++) {
			ans[a]=set[j];
			result=result+ans[a];
			a++;
		}
		if(result>max){
			max=result;
			for(k=0;k<3;k++) {
				ans2[k]=ans[k];
			}
		}
		result=0;
	}
	for(k=0;k<3;k++) printf("%d ",ans2[k]);
	printf("\n%d",max);
   }
}