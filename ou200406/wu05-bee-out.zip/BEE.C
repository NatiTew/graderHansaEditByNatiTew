/*
TASK: BEE
LANG: C
AUTHOR: Wachiraphan Charoenwet
CENTER: WU05
*/

#include<stdio.h>

int gen(int x){
long sol=0,wrk=1,mom=1,i,keepw,keeps;
	if(x==1){
		printf("2 4\n");
		return 0;
	}
	for(i=1;i<=x;i++){
	       keepw=wrk;	//keep wrk for add at sol
	       keeps=sol;	// keep sub at sol
	       wrk+=wrk+sol+1;    //wrk added by wrk and sol and mom
	       sol+=keepw;    //sol added by wrk
	       wrk-=keepw;     // both died
	       sol-=keeps;
	}

		printf("%ld %ld\n",wrk,sol+1+wrk);

return 0;
}



int main(){
int y[50],n=0,i;

	scanf("%d",&y[n]);

	while(y[n]!=-1){
		n++;
		scanf("%d",&y[n]);
	}

	for(i=0;i<n;i++){
		gen(y[i]);
	}
 return 0;
}