/*
TASK: WORD
LANG: C
AUTHOR: NAKARA KITTISIRIKUL
CENTER: tu05
*/
#include<stdio.h>
#include<string.h>
#define max 30
int nr,nc,nw;
int direct[][2] = {{-1,0},{-1,+1},{0,+1},{+1,+1},{+1,0},{+1,-1},{0,-1},{-1,-1}};
char map[max][max];
void find(char word[])
{
	int rc,cc,dc,wc,tmpr,tmpc,chk;
	for(rc = 0; rc < nr;rc++)
		for(cc = 0; cc < nc; cc++)
			for(dc = 0; dc < 8; dc++)
			{
				tmpr = rc;
				tmpc = cc;
				chk = 1;
				for(wc = 0; wc < strlen(word);wc++)
				{
					if(tmpr >= nr || tmpr < 0 || tmpc >= nc || tmpc < 0)
					{
						chk = 0;
						break;
					}
					if(word[wc] < 'a')
						word[wc] += 'a'-'A';
					if(map[tmpr][tmpc] < 'a')
						map[tmpr][tmpc] += 'a'-'A';
					if(map[tmpr][tmpc] != word[wc])
					{
						chk = 0;
						break;
					}
					tmpr+= direct[dc][0];
					tmpc+= direct[dc][1];
				}
				if(chk == 1)
				{
					printf("%d %d\n",rc,cc);
					return;
				}
			}
}
main()
{
	int count;
	char wordin[50];
	scanf("%d %d",&nr,&nc);
	for(count = 0; count < nr; count++)
		scanf("%s",map[count]);
	scanf("%d",&nw);
	for(count = 0; count < nw;count++)
	{
		scanf("%s",wordin);
		find(wordin);
	}
	return 0;
}