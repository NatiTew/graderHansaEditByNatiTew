/*
TASK: MAXSEQ
LANG: C
AUTHOR: Charuwat Houngkaew
CENTER: KKU01
*/
#include <stdio.h>

long max=0;
int pos[2];
int a[2500];

int main()
{
	int i,j,n,k;
	long sum;
	scanf("%d",&n) ;
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);

	for(i=0;i<n;i++)
	{
		//pos[0]=i;
		//pos[1]=j;
		for(j=i;j<n;j++)
		{
			sum=0;
			for(k=i;k<=j;k++)
				sum+=a[k];
			if(sum>max)
			{
				pos[0]=i;
				pos[1]=j;
				max=sum;
			}
			else if(sum<0)
				break;

		}
	}

	if(max==0)
		printf("Empty sequence");
	else
	{
		for(i=pos[0];i<=pos[1];i++)
			printf("%d ",a[i]);
			printf("\n%ld",max);
	}

return 0;
}