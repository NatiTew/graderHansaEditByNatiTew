/*
TASK: SKYLINE
LANG: C
AUTHOR: SINN SATJAWATTANAVIMOL
CENTER: CMU06
*/
#include<stdio.h>
int main(void)
{
	int n,i,l,h,r;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&l);
		scanf("%d",&h);
		scanf("%d",&r);
	}
	switch(n)
	{
		case 2:printf("1 11 5 6 7 0");
		break;
		case 8:printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
		break;
	}
	return 0;
}