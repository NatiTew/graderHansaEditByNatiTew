/*
TASK: MAXSEQ
LANG: C
AUTHOR: Vanus Vachiratamporn
CENTER: Tu09
*/
#include<stdio.h>

int main(void)
{   int N,seq[2501],i,j,k,front,rear;
    long max=-1,temp;
    scanf("%d",&N);
    for(i=0;i<N;i++)
       scanf("%d",&seq[i]);
    for(i=0;i<N;i++)
       {  for(k=i,temp=0;k<N;k++)
	     temp+=seq[k];
	  for(j=N-1;j>=i;j--)
	      {    if(j!=N-1)
		     temp-=seq[j+1];
		   if(temp>max)
		     {   max=temp;
			 front=i;
			 rear=j;
		     }
	      }
       }
    if(max==-1)
      printf("Empty sequence");
    else
      {   for(i=front;i<=rear;i++)
	     {  printf("%d",seq[i]);
		if(i!=rear)
		  printf(" ");
	     }
	  printf("\n%d",max);
      }
    return 0;
}