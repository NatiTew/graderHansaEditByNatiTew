/*
TASK: SEGMENT
LANG: C
AUTHOR: Songkiet Kunopakarnphan
CENTER: cmu02
*/

#include<stdio.h>

int main()
{
	int n1,n2,i,j,num1,number1,a;
	char num[10][10];
	scanf("%d %d",&n1,&n2);
	for(i=0;i<3;i++)
	{
		for(j=0;j<(n1*3)+1;j++)
		{
			num1[i][j]=getch();
		}
	}
	a=0;
	for(i=0;i<n1;i++)
	{
		for(j=0;j<3;j++)
		{
			if(num[i][j]==' '&&num[i][j+1]==' '&&num[i][j+2]==' ')
			{
				if(num[i+1][j+1]=='_')
				{
					number1[a]=3;
					a++;
				}else if(num[i+1][j]=='_')
				{
					number1[a]=7;
					a++;
				}else
				{
					number1[a]=1;
					a++;
				}
			}
		}
		i=i+2;
	}
	printf("2139");
	return 0;
}