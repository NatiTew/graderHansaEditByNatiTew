/*
TASK: WORD
LANG: C
AUTHOR: NARONG WAKAYAPHATTARAMANUS
CENTER: PSUHATYAI-HADDYAI01
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
char t[25][25]={NULL};
char tmp[15],ser[15];
int search(char);
int check(int,int);
int dat[2][100];
int sx,sy,n,x=0;
int main()
{
 int i,j;
 scanf("%d %d",&sy,&sx);
 for(i=0;i<sy;i++)
 {
  scanf("%s",t[i]);
  for(j=0;j<sx;j++)
  {
   t[i][j]=tolower(t[i][j]);
  }
 }
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  scanf("%s",ser);
  for(j=0;j<strlen(ser);j++)
  {
   ser[j]=tolower(ser[j]);
  }
  search(ser[0]);
 }
 for(i=0;i<n;i++)
 {
  printf("%d %d\n",dat[0][i],dat[1][i]);
 }
 return 0;
}
int check(int y,int z)
{
 int i,p,q;
 p=y;
 q=z;
 for(i=0;i<strlen(ser);i++)
 {
  if(ser[i]==t[p][q])
  {
   q++;
  }
  else break;
 }
 if(i==strlen(ser))
 {
  dat[0][x]=p;
  dat[1][x]=q-i;
  x++;
  return 0;
 }
 p=y;
 q=z;
 for(i=0;i<strlen(ser);i++)
 {
  if(ser[i]==t[p][q])
  {
   p++;
  }
  else break;
 }
 if(i==strlen(ser))
 {
  dat[0][x]=p-i;
  dat[1][x]=q;
  x++;
  return 0;
 }
  p=y;
 q=z;
 for(i=0;i<strlen(ser);i++)
 {
  if(ser[i]==t[p][q])
  {
   q--;
  }
  else break;
 }
 if(i==strlen(ser))
 {
  dat[0][x]=p;
  dat[1][x]=q+i;
  x++;
  return 0;
 }
  p=y;
 q=z;
 for(i=0;i<strlen(ser);i++)
 {
  if(ser[i]==t[p][q])
  {
   p--;
  }
  else break;
 }
 if(i==strlen(ser))
 {
  dat[0][x]=p+i;
  dat[1][x]=q;
  x++;
  return 0;
 }
  p=y;
 q=z;
 for(i=0;i<strlen(ser);i++)
 {
  if(ser[i]==t[p][q])
  {
   p++;
   q++;
  }
  else break;
 }
 if(i==strlen(ser))
 {
  dat[0][x]=p-i;
  dat[1][x]=q-i;
  x++;
  return 0;
 }
  p=y;
 q=z;
 for(i=0;i<strlen(ser);i++)
 {
  if(ser[i]==t[p][q])
  {
   p--;
   q--;
  }
  else break;
 }
 if(i==strlen(ser))
 {
  dat[0][x]=p+i;
  dat[1][x]=q+i;
  x++;
  return 0;
 }
  p=y;
 q=z;
 for(i=0;i<strlen(ser);i++)
 {
  if(ser[i]==t[p][q])
  {
   q++;
   p--;
  }
  else break;
 }
 if(i==strlen(ser))
 {
  dat[0][x]=p+i;
  dat[1][x]=q-i;
  x++;
  return 0;
 }
  p=y;
 q=z;
 for(i=0;i<strlen(ser);i++)
 {
  if(ser[i]==t[p][q])
  {
   p++;
   q--;
  }
  else break;
 }
 if(i==strlen(ser))
 {
  dat[0][x]=p-i;
  dat[1][x]=q+i;
  x++;
  return 0;
 }
 return 0;
}
int search(char ch)
{
 int i,j;
 for(i=0;i<sy;i++)
 {
  for(j=0;j<sx;j++)
  {
   if(ch==t[i][j])
   {
    check(i,j);
   }
  }
 }
 return 0;
}