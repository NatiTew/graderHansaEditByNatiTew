#include<stdio.h>
#include<stdlib.h>

main()
{
int n,i,*l,*h,*r,j,k,t1,t2,t3;
l = malloc(sizeof(int)*300);
h = malloc(sizeof(int)*300);
r = malloc(sizeof(int)*300);
scanf("%d",&n);
for(i=0;i<n;i++)
	{
	scanf("%d %d %d",&t1,&t2,&t3);
	*(l+i)=t1;
	*(h+i)=t2;
	*(r+i)=t3;
	}
}