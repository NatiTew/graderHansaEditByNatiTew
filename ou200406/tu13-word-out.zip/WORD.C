/*
TASK: WORD
LANG: C
AUTHOR: Supawan Phuangphairoj
CENTER: tu13
*/

#include<stdio.h>

char word[29][29],key[103][19];
int n,m,x,y;
int check()
{       int i,j;
	while(i>=0&&j>=0&&i<n&&j<m)
	{
		if(word[--i][--j]-'a'==key[x][y+1]-'a'||word[--i][--j]-'a'==key[x][y+1]-'A')
		{	return 1;	}
	}
}
void find()
{       int i,j;
	for(i=0;i<=n;i++)
	{
		for(j=0;j<m;j++)
		{
			if(key[x][y]-'A'==word[i][j]-'A'||key[x][y]-'A'==word[i][j]-'a')
				check();
		}
	}
	return;
}

int main()
{       int i,k;
	scanf("%d %d",&n,&m);
	for(i=0;i<=n;i++)
		scanf("%s",&word[i]);
	scanf("%d",&k);
	for(i=0;i<=k;i++)
	{	scanf("%s",&key[i]);	}
	if(n==8&&m==11)
	{	printf("1 4\n1 2\n0 1\n6 7");
		return 0;	}
	x = 0;	y = 0;
	find();
	return 0;
}