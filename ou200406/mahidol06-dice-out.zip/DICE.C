#include<stdio.h>
int d1[6]={1,2,3,4,5,6},d2[6];
void f(int *d)
{
 d2[0]=d[4];
 d2[1]=d[0];
 d2[2]=d[3];
 d2[3]=d[5];
 d2[4]=d[3];
 d2[5]=d[1];
}
void b(int *d)
{
 d2[0]=d[1];
 d2[1]=d[5];
 d2[2]=d[2];
 d2[3]=d[0];
 d2[4]=d[3];
 d2[5]=d[4];
}
void l(int *d)
{
 d2[0]=d[3];
 d2[1]=d[1];
 d2[2]=d[0];
 d2[3]=d[4];
 d2[4]=d[5];
 d2[5]=d[2];
}
void r(int *d)
{
 d2[0]=d[2];
 d2[1]=d[1];
 d2[2]=d[5];
 d2[3]=d[4];
 d2[4]=d[0];
 d2[5]=d[3];
}
void cc(int *d)
{
 d2[0]=d[0];
 d2[1]=d[3];
 d2[2]=d[1];
 d2[3]=d[2];
 d2[4]=d[4];
 d2[5]=d[5];
}
void d(int *d)
{
 d2[0]=d[0];
 d2[1]=d[2];
 d2[2]=d[4];
 d2[3]=d[3];
 d2[4]=d[1];
 d2[5]=d[5];
}
int main()
{
 int i=0,n;
 char c;
 scanf("%d",&n);
 for(i=0;i<n;i++)
  {
   flushall();
   while(scanf("%c",&c)=='\n')
   {
    if(c=='F') f(d1);
    else if(c=='B') b(d1);
    else if(c=='L') l(d1);
    else if(c=='R') r(d1);
    else if(c=='C') cc(d1);
    else d(d1);
   d1[0]=d2[0];
   d1[1]=d2[1];
   d1[2]=d2[2];
   d1[3]=d2[3];
   d1[4]=d2[4];
   d1[5]=d2[5];
   }
   printf("%d ",d1[1]);
  }
 return 0;
}