/*
TASK: SKYLINE
LANG: C
AUTHOR: NUTTAWUT MANEEKASORN
CENTER: PSUPN01
*/

#include <stdio.h>
#include <string.h>
#define CS 25
void main(){
  int i,j,k;
  int Li,Hi,Ri,Bucnt;
  int Direc=1;
  int maxJ;

  char City[CS][CS];


  clrscr();
  memset(City,'-',CS*CS);
  scanf("%d",&Bucnt);
  for(k=0;k<Bucnt;k++){
      scanf("%d %d %d",&Li,&Hi,&Ri);
      for(j=Li;j<=Ri;j++){
	  for(i=0;i<Hi;i++){
	      City[j][i] = '+';
	  }
      }
  }


  for(j=0;j<CS;j++){
      for(i=0;i<CS;i++){
	  printf("%c",City[j][i]);
      }
      printf("\n");
  }


  for(j=0;j<CS;j++){
      if(City[j][i]=='-'){
	 maxJ = j;
	 break;
      }
  }
  j =1;
  printf("1 ");
  for(i=1;i<CS&&i>=0&&j<maxJ;i+=Direc){
      if(City[j][i]!='+'){
	 i--;
	 printf("%d ",i+1);
	 for(j=j;j<maxJ;j++){
	     if(City[j][i+1]!='-'){
		printf("%d ",j);
		break;
	     }
	     else{
		if(City[j][i-1]!='+'){
		   printf("%d ",j);
		   Direc = -1;
		}
	     }
	 }



      }

  }



}