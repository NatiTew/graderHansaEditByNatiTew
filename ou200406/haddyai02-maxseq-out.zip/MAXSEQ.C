/*
Task:Maxseq
LANG:C
AUTHOR:PHONGRAPEE PHONGVIVAT
CENTER:HADDYAI02
*/
#include<stdio.h>

void main()
{int a[2500],i,j,n,k,max,temp,x=0,y=0;
 scanf("%d",&n);
 for(i=0;i<n;i++)
  scanf("%d",&a[i]);
   max=0;

 for(i=0;i<n;i++)
   { if(a[i]>max)
       max=a[i];
     }

  if(max<=0)
   printf("Empty sequence");
  else
   { for(i=0;i<n;i++)
      {for(j=i;j<n;j++)
	{ temp=0;
	 for(k=i;k<n-j;k++)
	   temp=temp+a[k];

	 if(temp>max)
	  {max=temp;
	    x=i;
	    y=k;
	    }//if
	 }//for j

	}// for i

     for(i=x;i<y;i++)
      printf("%d ",a[i]);

    printf("\n%d",max);

    }//else
}