/*
TASK: DICE
LANG: C
AUTHOR: WACHIRA SUPPASATEAN
CENTER: UBU-02
*/
#include <stdio.h>
#include <string.h>

#define top 	0
#define front 	1
#define left 	2
#define back 	3
#define right 	4
#define buttom 	5

char dice[] = {1,2,3,5,4,6};

void resetDice();

void Flip( char dir )
{
	char tmp;
	switch( dir )
	{
	case 'F':
		tmp = dice[top];
		dice[top] = dice[back];
		dice[back] = dice[buttom];
		dice[buttom] = dice[front];
		dice[front] = tmp;
	break;
	case 'B':
		tmp = dice[top];
		dice[top] = dice[front];
		dice[front] = dice[buttom];
		dice[buttom] = dice[back];
		dice[back] = tmp;
	break;
	case 'L':
		tmp = dice[top];
		dice[top] = dice[right];
		dice[right] = dice[buttom];
		dice[buttom] = dice[left];
		dice[left] = tmp;
	break;
	case 'R':
		tmp = dice[top];
		dice[top] = dice[left];
		dice[left] = dice[buttom];
		dice[buttom] = dice[right];
		dice[right] = tmp;
	break;
	case 'C':
		tmp = dice[front];
		dice[front] = dice[right];
		dice[right] = dice[back];
		dice[back] = dice[left];
		dice[left] = tmp;
	break;
	case 'D':
		tmp = dice[front];
		dice[front] = dice[left];
		dice[left] = dice[back];
		dice[back] = dice[right];
		dice[right] = tmp;
	break;
	}
}

void resetDice()
{
	dice[top] = 1;
	dice[front] = 2;
	dice[left] = 3;
	dice[back] = 5;
	dice[right] = 4;
	dice[buttom] = 6;
}

int getFront( char *dir )
{
	int i;
	int n = strlen(dir);

	resetDice();

	for( i=0; i<n; i++ )
	{
		Flip( dir[i] );
	}
	return dice[front];
}

int main( void )
{
	int i;
	int result[6];
	int n;
	char dir[1000];

	scanf("%d", &n );
	for( i=0; i<n; i++)
	{
		scanf("%s", dir);
		result[i] = getFront( dir );
	}

	for( i=0; i<n; i++)
	{
		if( i== n-1 )
		{
			printf("%d", result[i] );
		}
		else
		{
			printf("%d ", result[i] );
		}
	}

	return 0;
}