/*
TASK: SEGMENT
LANG: C
AUTHOR: THEERAPHONG PHUTHONG
CENTER: nu06
*/
#include<stdio.h>


int main()	{
	long int num1=0,num2=0;
	char n1[2][3][3],n2[2][3][3];
	scanf("%ld %ld",&num1,&num2);
	for(i=0;i<num1;i++){
		scanf("%s",&n1[0][i]);
	}
	for(i=0;i<num1;i++){
		scanf("%s",&n1[1][i]);
	}
	for(i=0;i<num2;i++){
		scanf("%s",&n2[0][i]);
	}
	for(i=0;i<num2;i++){
		scanf("%s",&n2[1][i]);
	}
	if(n1[0][0][0]=='|'&&n1[1][0][0]=='|')
	       x=1;
	if(n1[0][1][0]=='|'&&n1[0][1][1]=='_'&&n1[0][1][2]=='|'&&n1[1][1][0]=='|')
	       x=4;

return 0;	}