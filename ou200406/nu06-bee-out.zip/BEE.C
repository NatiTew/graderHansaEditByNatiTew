/*
TASK: BEE
LANG: C
AUTHOR: THEERAPHONG PHUTHONG
CENTER: nu06
*/
#include<stdio.h>
int main()	{
    int y[25],i,n=0,w[25],w1,s[25],m=0,bee[25];
	for(i=0;i<24;i++){
	     scanf("%d",&m);
	     if(m!=-1){
	     y[i]=m;
	     n++;
	     }
	     else i=24;
	}
	w[0]=1;
	s[0]=0;
	bee[0]=2;
	for(i=1;i<=24;i++){
	     w[i]=w[i-1]+w[i-2]+1;
	  }
	 for(i=0;i<n;i++){
		w1=y[i];
	     printf("%d %d\n",w[w1],w[w1]+w[w1-1]+1);

	 }
return 0;	}