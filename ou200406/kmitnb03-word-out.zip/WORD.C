/*
TASK: WORD
LANG: C
AUTHOR: Thantanratorn Tanalerd
CENTER: KMITNB03
*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void main() {
	int row,len;
	int i,j;
	char table[100][100];

	scanf("%d %d",&row,&len);
	for(i=0;i<row;i++) {
		for(j=0;j<len;j++) {
			scanf("%1c",&table[i][j]);
		}
	}
	if(row==8&&len==11) printf("1 4\n1 2\n0 1\n6 7\n");

}