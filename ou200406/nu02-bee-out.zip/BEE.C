/*
TASK: BEE
LANG: C
AUTHOR: KUNAKORN TENGCHIANG
CENTER: NU02
*/

#include<stdio.h>

#define Qbee 1

void checkbee(int n);

main(){
 int year[26],i=0;

 do{
	scanf("%d",&year[i]);
	if(year[i]==-1)
		return 0;
	checkbee(year[i]);
 }while(year[i-1]!=-1);
 return 0;
}

void checkbee(int n){
 int Wbee=2,Sbee=1,bee=4;
 int i,a;

 if(n!=1){
	for(i=2;i<=n;i++){
		a=Wbee;
		Wbee=Wbee+Qbee+Sbee;
		Sbee=a;
		bee=Wbee+Sbee+Qbee;
	}
 }
 printf("%d %d\n",Wbee,bee);
}