/*
TASK: SEGMENT
LANG: C
AUTHOR: NAKARA KITTISIRIKUL
CENTER: tu05
*/
#include<stdio.h>
#define maxc 100
#define maxr 3
char map[10][4][4] = {{ " _ ","| |","|_|"},{"   ","  |","  |"},{" _ "," _|","|_ "},{" _ "," _|"," _|"},{"   ","|_|","  |"},{" _ ","|_ "," _|"},{" _ ","|_ ","|_|"},{" _ ","  |","  |"},{" _ ","|_|","|_|"},{" _ ","|_|"," _|"}};
main()
{
	unsigned long num[2]= {0,0};
	int count,count1,count2,count3,count4,len[2],chk;
	char arr[2][maxr+2][maxc],tmp;
	scanf("%d %d",&len[0],&len[1]);
   do{scanf("%c",&tmp);}while(tmp !='\n');
	for(count = 0; count < 2; count++)
		for(count1 = 0; count1 < maxr; count1++)
			for(count2 = 0;;count2++)
			{
				scanf("%c",&arr[count][count1][count2]);
				if(arr[count][count1][count2] == '\n')
					break;
			}

	for(count = 0; count < 2;count++)
   {
      num[count] = 0;
		for(count1 = 0; count1 < len[count];count1++)
		{
			for(count4 = 0; count4 < 10; count4++)
			{
				chk = 1;
				for(count2 = 0; count2 < maxr;count2++)
				{
					for(count3 = 0;count3 < maxr;count3++)
					{
						if(map[count4][count2][count3] != arr[count][count2][count3+(count1*4)])
						{
							chk = 0;
							break;
						}
					}
					if(chk == 0)
						break;
				}
				if(chk == 1)
				{
					num[count] = (num[count]*10)+count4;
					break;
				}
			}
		}
   }
	printf("%lu",num[0]+num[1]);
	return 0;
}