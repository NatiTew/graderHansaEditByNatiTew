/*
TASK: WORD
LANG: C
AUTHOR: Wachiraphan Charoenwet
CENTER: WU05
*/

#include<stdio.h>
#include<string.h>

char stage[30][30];
int x[150];
int y[150];

int main(){
int m,n,i,j,k,amount,get;
int a,b,c,d,l;
char word[100];
	scanf("%d %d",&m,&n);

	for(i=0;i<m;i++){
		scanf("%s",word);
		strlwr(word);
		for(j=0;j<n;j++){
			stage[i][j]=word[j];
		}
	}

	scanf("%d",&amount);

	for(k=0;k<amount;k++){
		scanf("%s",word);
		strlwr(word);
		l=strlen(word);
		get=0;
		for(i=0;i<m;i++){
			for(j=0;j<n;j++){

				if(word[0]==stage[i][j]){
					a=1;
					c=i;d=j;
				//search top
					while(word[a]==stage[c-1][d]&&a<l&&get==0){
						c--;
						a++;
						if(a==l){
							 x[k]=j;
							 y[k]=i;
							 i=m;j=n;
							 get=1;
						}
					}
					a=1;
					c=i;d=j;
				//search left
					while(word[a]==stage[c][d-1]&&a<l&&get==0){
						d--;
						a++;
						if(a==l-1){
							 x[k]=j;
							 y[k]=i;
							 i=m;j=n;
							 get=1;
						}
					}
					a=1;
					c=i;d=j;
				//search right
					while(word[a]==stage[c][d+1]&&a<l&&get==0){
						d++;
						a++;
						if(a==l){
							 x[k]=j;
							 y[k]=i;
							 i=m;j=n;
							 get=1;
						}
					}
					a=1;
					c=i;d=j;
				//search bottom
					while(word[a]==stage[c+1][d]&&a<l&&get==0){
						c++;
						a++;
						if(a==l){
							 x[k]=j;
							 y[k]=i;
							 i=m;j=n;
							 get=1;
						}
					}

					a=1;
					c=i;d=j;
				//search righttop
					while(word[a]==stage[c-1][d+1]&&a<l&&get==0){
						c--;
						d++;
						a++;
						if(a==l){
							 x[k]=j;
							 y[k]=i;
							 i=m;j=n;
							 get=1;
						}
					}
					a=1;
					c=i;d=j;
				//search lefttop
					while(word[a]==stage[c-1][d-1]&&a<l&&get==0){
						d--;
						c--;
						a++;
						if(a==l-1){
							 x[k]=j;
							 y[k]=i;
							 i=m;j=n;
							 get=1;
						}
					}
					a=1;
					c=i;d=j;
				//search rightbotom
					while(word[a]==stage[c+1][d+1]&&a<l&&get==0){
						d++;
						a++;
						c++;
						if(a==l){
							 x[k]=j;
							 y[k]=i;
							 i=m;j=n;
							 get=1;
						}
					}
					a=1;
					c=i;d=j;
				//search leftbottom
					while(word[a]==stage[c+1][d-1]&&a<l&&get==0){
						c++;
						d--;
						a++;
						if(a==l){
							 x[k]=j;
							 y[k]=i;
							 i=m;j=n;
							 get=1;
						}
					}

				}
			}
		}


	}
	for(i=0;i<k;i++)
		printf("%d %d\n",y[i],x[i]);


 return 0;
}