/*
TASK: BEE
LANG: C
AUTHOR: Kornkanok Siriaksorn
CENTER: tu17
*/

#include<stdio.h>

struct bee{
	long w , s;
};

void main()
{
	int y[24] , i;
	struct bee b[25];
	b[1].w = 2;
	b[1].s = 1;
	for(i=2;i<25;i++)
	{
		b[i].w = b[i-1].s+1+b[i-1].w;
		b[i].s = b[i-1].w;
	}
	i = -1;
	do
	{
		i++;
		scanf("%d",&y[i]);
	}while(y[i]!=-1);
	for(i=0;y[i]!=-1;i++)
		printf("%ld %ld\n",b[y[i]].w,b[y[i]].w+b[y[i]].s+1);
}