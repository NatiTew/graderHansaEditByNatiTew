/*
TASK: BEE
LANG: C
AUTHOR: Supawan Phuangphairoj
CENTER: tu13
*/

#include<stdio.h>

long a,b,ans[26],ansb[26];
int max=0,year[26];
void process()
{       int i;
	long temp;
	for(i=1;i<=max;i++)
	{       temp = a;
		a += b+1;
		b = temp;
		ans[i] = a;
		ansb[i] = a+b+1;
	}
}
int main()
{       int i,j;
	for(i=0;;i++)
	{	scanf("%d",&year[i]);
		if(year[i]>max)
			max = year[i];
		if(year[i]==-1)
		{	year[i] = 0;
			i--;
			break;	}
	}
	a = 1;
	b = 0;
	process();
	for(j=0;j<=i;j++)
	{	printf("%ld %ld\n",ans[year[j]],ansb[year[j]]);	}
	return 0;
}