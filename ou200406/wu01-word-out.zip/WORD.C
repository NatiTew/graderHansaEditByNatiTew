/*
TASK: WORD
LANG: C
AUTHOR: JIRANUN JIRATRAKANWONG
CENTER: WU01
*/
#include<stdio.h>
#include<string.h>
void main()
{
	int m,n,i=0,k,p,j,nword;
	int l,chk=1;
	char s[26][26],word[101][16];
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++){
		scanf("%s",s[i]);
		for(j=0;j<n;j++){
			if(s[i][j]>97) s[i][j]-=32;
		}
	}
	scanf("%d",&k);
	for(i=0;i<k;i++){
		scanf("%s",word[i]);
		nword=strlen(word[i]);
		for(j=0;j<nword;j++){
			if(word[i][j]>97) word[i][j]-=32;
		}
	}
	i=0;
	do{
		chk=1;
		nword=strlen(word[i]);
		for(p=0;p<m;p++){
		if(chk==nword) break;
			for(j=0;j<n;j++){
				if(s[p][j]==word[i][0]){
					chk=1;
					for(l=1;l<nword;l++){
						if(s[p][j+l]==word[i][l]) chk++;
						else { chk=1; break; }
					}
					if(chk!=nword){
					for(l=1;l<nword;l++){
						if(s[p+l][j]==word[i][l]) chk++;
						else { chk=1; break; }
					}}
					if(chk!=nword){
					for(l=1;l<nword;l++){
						if(s[p+l][j+l]==word[i][l]) chk++;
						else { chk=1; break; }
					}}
					if(chk!=nword){
					for(l=1;l<nword;l++){
						if(s[p-l][j]==word[i][l]) chk++;
						else { chk=1; break; }
					}}
					if(chk!=nword){
					for(l=1;l<nword;l++){{
						if(s[p][j-l]==word[i][l]) chk++;
						else { chk=1; break; }
					}}
					if(chk!=nword){
					for(l=1;l<nword;l++){
						if(s[p-l][j-l]==word[i][l]) chk++;
						else { chk=1; break; }
					}}
					if(chk!=nword){
					for(l=1;l<nword;l++){
						if(s[p-l][j+l]==word[i][l]) chk++;
						else { chk=1; break; }
					}}
					if(chk!=nword){
					for(l=1;l<nword;l++){
						if(s[p+l][j-l]==word[i][l]) chk++;
						else { chk=1; break; }
					}}
				}
				if(chk==nword){
					i++;
					printf("%d %d\n",p,j);
					break;
				}
			}
		    }
		}
	}while(i!=k);
}







