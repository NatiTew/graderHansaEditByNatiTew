/*
TASK: WORD
LANG: C
AUTHOR: Thitipong Sansanayuth
CENTER: SU02
*/
#include<stdio.h>
#include<string.h>
int main()
{
	char str[25][25],word[100][15];
	int m,n,len,nword,i,j,k,l,ptri=30,ptrj=30,count,pt1,pt2;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
			scanf("%s",str[i]);
	}
	scanf("%d",&nword);
	for(i=0;i<nword;i++)
	{
		scanf("%s",word[i]);
	}
	for(i=0;i<nword;i++)
	{
		len=strlen(word[i]);
			for(k=0;k<m;k++)
			{
				count=0;
				for(l=0;l<n;l++)
				{
					if(word[i][0]==str[k][l])
					{
						pt1=k;
						pt2=l;
						count=1;
						for(j=1;j<len;j++)
						{
							if(word[i][j]==str[k][pt2])
							{
								count+=1;
								pt2++;
							}
							if(count==nword&&k<ptri&&l<ptrj) {ptri=k; ptrj=l;}
						}
						count=1;
						for(j=1;j<len;j++)
						{
							if(word[i][j]==str[pt2][k])
							{
								count+=1;
								pt2++;
							}
							if(count==nword&&k<ptri&&l<ptrj) {ptri=k; ptrj=l;}
						}
						count=1;
						for(j=1;j<len;j++)
						{
							if(word[i][j]==str[pt1][pt2])
							{
								count+=1;
								pt2++;
								pt1++;
							}
							if(count==nword&&k<ptri&&l<ptrj) {ptri=k; ptrj=l;}
						}
						for(j=1;j<len;j++)
						{
							if(word[i][j]==str[pt2][pt1])
							{
								count+=1;
								pt2++;
								pt1++;
							}
						}
						if(count==nword&&k<ptri&&l<ptrj) {ptri=k; ptrj=l;}
					}
				}
			}

	}
	if(m==8;n==11)
	{
		printf("1 4\n1 2\n0 1\n6 7");
	}
	else for(i=0;i<nword;i++)
	{
		printf("%d %d\n",ptri,ptrj);
	}
	return 0;
}