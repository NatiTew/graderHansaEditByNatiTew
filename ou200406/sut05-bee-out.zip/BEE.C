/*
TASK: BEE
LANG: C
AUTHOR: Thananon Patinyasakdikul
CENTER: SUT
*/

#include<stdio.h>

int sol;
int work=1;
int i,year[25];
int a,b,c;

void main(){

   for(i=0;i<24;i++){
    scanf("%d",&year[i]);
    if(year[i]== -1) break;
   }

   for(a=0;a<i;a++){
    for(b=0;b<year[a]-1;b++){

       sol = work;
       work = work+1+sol;

    }

   }



   printf("%d %d",work,work+sol+2);

}