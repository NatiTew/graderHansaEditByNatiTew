/*
TASK: MAXSEQ
LANG: C
AUTHOR: Lumpsum Tongsinoot
CENTER: psupn03
*/
#include <stdio.h>
#include <string.h>
int sum;
void one (char str1);
void two (char str1);
void three (char str1);
void four (char str1);
void five (char str1);
void six (char str1);
void main()
{
	int i,j,num,n;
	char str3;
	char str[6][1000];
	scanf("%d",&num);
	for (i=0;i<num;i++)
	{
		scanf("%s",str[i]);
	}
	for (i=0;i<num;i++)
	{
		sum=2;
		n=strlen(str[i]);
		for (j=0;j<n;j++)
		{
			str3=str[i][j];
			switch (sum)
			{
				case 1: one(str3); break;
				case 2: two(str3); break;
				case 3: three(str3); break;
				case 4: four(str3); break;
				case 5: five(str3); break;
				case 6: six(str3); break;
			}
		}
		printf("%d ",sum);
	}
}
void one (char str1)
{
	switch (str1)
	{
		case 'F':   sum=5; break;
		case 'B':   sum=2; break;
		case 'L':   sum=4; break;
		case 'R':   sum=3; break;
		case 'C':   sum=1; break;
		case 'D':   sum=1; break;
	}
}
void two (char str1)
{
	switch (str1)
	{
		case 'F':   sum=1; break;
		case 'B':   sum=6; break;
		case 'L':   sum=2; break;
		case 'R':   sum=2; break;
		case 'C':   sum=4; break;
		case 'D':   sum=3; break;
	}
}
void three (char str1)
{
	switch (str1)
	{
		case 'F':   sum=3; break;
		case 'B':   sum=3; break;
		case 'L':   sum=1; break;
		case 'R':   sum=6; break;
		case 'C':   sum=2; break;
		case 'D':   sum=5; break;
	}
}

void four (char str1)
{
	switch (str1)
	{
		case 'F':   sum=4; break;
		case 'B':   sum=4; break;
		case 'L':   sum=6; break;
		case 'R':   sum=1; break;
		case 'C':   sum=5; break;
		case 'D':   sum=2; break;
	}
}

void five (char str1)
{
	switch (str1)
	{
		case 'F':   sum=6; break;
		case 'B':   sum=1; break;
		case 'L':   sum=5; break;
		case 'R':   sum=5; break;
		case 'C':   sum=3; break;
		case 'D':   sum=4; break;
	}
}

void six (char str1)
{
	switch (str1)
	{
		case 'F':   sum=2; break;
		case 'B':   sum=5; break;
		case 'L':   sum=3; break;
		case 'R':   sum=4; break;
		case 'C':   sum=6; break;
		case 'D':   sum=6; break;
	}
}
