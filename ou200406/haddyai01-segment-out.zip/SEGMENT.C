/*
TASK: SEGMENT
LANG: C
AUTHOR: NARONG WAKAYAPHATTARAMANUS
CENTER:PSUHATYAI-HADDYAI01
*/
#include<stdio.h>
#include<math.h>
struct number
	{
	 char n[3][3];
	}num[1000]={NULL};
int lf,ls;
long n1,n2,xum;
int check(int);
int main()
{
 int i,j;
 scanf("%d %d",&lf,&ls);
 for(i=0;i<3;i++)
 {
  for(j=0;j<lf;j++)
  {
   flushall();
   scanf("%c%c%c",&num[j].n[i][0],&num[j].n[i][1],&num[j].n[i][2]);
  }
 }
 n1=check(lf);
 for(i=0;i<3;i++)
 {
  for(j=0;j<ls;j++)
  {
   flushall();
   scanf("%c%c%c",&num[j].n[i][0],&num[j].n[i][1],&num[j].n[i][2]);
  }
 }
 n2=check(ls);
 xum=n1+n2;
 printf("%ld",xum);
 return 0;
}
int check(int x)
{
 int i,sum=0;
 for(i=0;i<x;i++)
 {
  if((num[i].n[0][0]==' ')&&(num[i].n[0][1]==' ')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]==' ')&&(num[i].n[1][1]==' ')&&(num[i].n[1][2]=='|')&&
    (num[i].n[2][0]==' ')&&(num[i].n[2][1]==' ')&&(num[i].n[2][2]=='|'))
    sum=sum+(1*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]=='_')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]==' ')&&(num[i].n[1][1]=='_')&&(num[i].n[1][2]=='|')&&
    (num[i].n[2][0]=='|')&&(num[i].n[2][1]=='_')&&(num[i].n[2][2]==' '))
    sum=sum+(2*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]=='_')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]==' ')&&(num[i].n[1][1]=='_')&&(num[i].n[1][2]=='|')&&
    (num[i].n[2][0]==' ')&&(num[i].n[2][1]=='_')&&(num[i].n[2][2]=='|'))
    sum=sum+(3*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]==' ')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]=='|')&&(num[i].n[1][1]=='_')&&(num[i].n[1][2]=='|')&&
    (num[i].n[2][0]==' ')&&(num[i].n[2][1]==' ')&&(num[i].n[2][2]=='|'))
    sum=sum+(4*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]=='_')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]=='|')&&(num[i].n[1][1]=='_')&&(num[i].n[1][2]==' ')&&
    (num[i].n[2][0]==' ')&&(num[i].n[2][1]=='_')&&(num[i].n[2][2]=='|'))
    sum=sum+(5*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]=='_')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]=='|')&&(num[i].n[1][1]=='_')&&(num[i].n[1][2]==' ')&&
    (num[i].n[2][0]=='|')&&(num[i].n[2][1]=='_')&&(num[i].n[2][2]=='|'))
    sum=sum+(6*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]=='_')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]==' ')&&(num[i].n[1][1]==' ')&&(num[i].n[1][2]=='|')&&
    (num[i].n[2][0]==' ')&&(num[i].n[2][1]==' ')&&(num[i].n[2][2]=='|'))
    sum=sum+(7*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]=='_')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]=='|')&&(num[i].n[1][1]=='_')&&(num[i].n[1][2]=='|')&&
    (num[i].n[2][0]=='|')&&(num[i].n[2][1]=='_')&&(num[i].n[2][2]=='|'))
    sum=sum+(8*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]=='_')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]=='|')&&(num[i].n[1][1]=='_')&&(num[i].n[1][2]=='|')&&
    (num[i].n[2][0]==' ')&&(num[i].n[2][1]=='_')&&(num[i].n[2][2]=='|'))
    sum=sum+(9*pow(10,x-(i+1)));
  else if
    ((num[i].n[0][0]==' ')&&(num[i].n[0][1]=='_')&&(num[i].n[0][2]==' ')&&
    (num[i].n[1][0]=='|')&&(num[i].n[1][1]==' ')&&(num[i].n[1][2]=='|')&&
    (num[i].n[2][0]=='|')&&(num[i].n[2][1]==' ')&&(num[i].n[2][2]=='|'))
    sum=sum+(3*pow(10,x-(i+1)));
 }
 return sum;
}