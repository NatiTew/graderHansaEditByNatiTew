/*
TASK: MAXSEQ
LANG: C
AUTHOR: Kornkanok Siriaksorn
CENTER: tu17
*/

#include<stdio.h>

void main()
{
	int n , i , c , b , j;
	long max=0 , t;
	char a[2500];
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		t = 0;
		for(j=i;j<n;j++)
		{
			t += a[j];
			if(max<t)
			{
				max = t;
				c = i;
				b = j;
			}
		}
	}
	if(max==0)
		printf("Empty sequence");
	else
	{
		for( ;c<=b;c++)
			printf("%d ",a[c]);
		printf("\n%d",max);
	}
}