/*
TASK: SEGMENT
LANG: C
AUTHOR: SARAN LERTPRADIT
CENTER: TU
*/
#include<stdio.h>
main()
{
	int pos[10][7]={{1,1,0,1,1,1,1},//0
					{0,0,0,1,0,0,1},//1
					{1,0,1,1,1,1,0},//2
					{1,0,1,1,0,1,1},//3
					{0,1,1,1,0,0,1},//4
					{1,1,1,0,0,1,1},//5
					{1,1,1,0,1,1,1},//6
					{1,0,0,1,0,0,1},//7
					{1,1,1,1,1,1,1},//8
					{1,1,1,1,0,1,1}};//9
	int num[10][10],n[2],i,j,k,select;
	long a[2];
	char c;
	scanf("%d",&n[0]);
	scanf("%d",&n[1]);
	c=getchar();
	for(k=0;k<2;k++)
	{
		for(i=0;i<10;i++)
			for(j=0;j<10;j++)
				num[i][j]=0;

		for(i=0;i<n[k];i++)
		{
			c=getchar();
			c=getchar();
			if(c=='|'||c=='_')select=1;
			else select=0;
			for(j=0;j<10;j++)
			{
				if(pos[j][0]==select)num[i][j]++;
			}
			c=getchar();
			c=getchar();
		}
		for(i=0;i<n[k];i++)
		{
			c=getchar();
			if(c=='|'||c=='_')select=1;
			else select=0;
			for(j=0;j<10;j++)
			{
				if(pos[j][1]==select)num[i][j]++;
			}
			c=getchar();
			if(c=='|'||c=='_')select=1;
			else select=0;
			for(j=0;j<10;j++)
			{
				if(pos[j][2]==select)num[i][j]++;
			}
			c=getchar();
			if(c=='|'||c=='_')select=1;
			else select=0;
			for(j=0;j<10;j++)
			{
				if(pos[j][3]==select)num[i][j]++;
			}
			c=getchar();
		}
		for(i=0;i<n[k];i++)
		{
			c=getchar();
			if(c=='|'||c=='_')select=1;
			else select=0;
			for(j=0;j<10;j++)
			{
				if(pos[j][4]==select)num[i][j]++;
			}
			c=getchar();
			if(c=='|'||c=='_')select=1;
			else select=0;
			for(j=0;j<10;j++)
			{
				if(pos[j][5]==select)num[i][j]++;
			}
			c=getchar();
			if(c=='|'||c=='_')select=1;
			else select=0;
			for(j=0;j<10;j++)
			{
				if(pos[j][6]==select)num[i][j]++;
			}
			c=getchar();
		}

		a[k]=0;
		for(i=0;i<n[k];i++)
			for(j=0;j<10;j++)
				if(num[i][j]==7)
				{
					a[k]=a[k]*10+j;
					break;
				}


	}
	printf("%ld",a[0]+a[1]);
	return 0;
}