/*
TASK: BEE
LANG: C
AUTHOR: SINN SATJAWATTANAVIMOL
CENTER: CMU06
*/
#include<stdio.h>
int main(void)
{       int c,s,i,w,year[100],st,count=0,wt,bee;
	scanf("%d",&year[count]);
	while(year[count]!=-1)
	{
		count++;
		scanf("%d",&year[count]);
	}
	for(c=0;c<count;c++)
	{
		s=wt=st=bee=0;
		w=1;
		for(i=0;i<year[c];i++)
		{
			wt+=s;
			wt+=w;
			st+=w;
			w=wt+1;
			s=st;
			wt=st=0;
		}
		bee+=w+s+1;
		printf("%d %d\n",w,bee);
	}
	return 0;
}