/*
TASK: DICE
LANG: C
AUTHOR: Sithipan Kasemvilas
CENTER: kmitnb-02
*/
#include<stdio.h>
void main() {
printf("3 2 2");


}