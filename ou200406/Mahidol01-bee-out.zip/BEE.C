/*
TASK: BEE
LANG: C
AUTHOR: NATHANON ANGSUTORN
CENTER: MAHIDOL01
*/


#include<stdio.h>


int inc(long int *bee){
	long int i;
	long int bee3=0;
	long int bee2=0;

	for(i=0;i<bee[1];i++){
		bee2++;
		bee3++;
	}
	for(i=0;i<bee[2];i++){
		bee2++;
	}
	bee2++;

	bee[1]=bee2;
	bee[2]=bee3;

	return 0;
}

int main(){
	int year;
	int i;

	scanf("%d",&year);

	while(year!=-1){
		long int bee[3]={1,1,0};

		for(i=0;i<year;i++){
			inc(bee);
		}

		printf("%ld %ld\n",bee[1],bee[0]+bee[1]+bee[2]);

		scanf("%d",&year);
	}


	return 0;
}