/*
TASK: WORD
LANG: C
AUTHOR: Pichayawat Karnjanaves
CENTER: KMITNB04
*/

#include<stdio.h>

int main()
{
	int m,n,i,j,num,len[15],l;
	char a[25][25],k[15][100];
	int x,y,posx[25],posy[25];
	FILE *fp;
	fp=fopen("w.in","r");
	fscanf(fp,"%d%d\n",&m,&n);
	for(i=0;i<m;i++) {
		for(j=0;j<n;j++) {
			fscanf(fp,"%c",&a[i][j]);
			if(a[i][j]<97)
				a[i][j]+=32;
			}
			fscanf(fp,"\n");
		}
	fscanf(fp,"%d",&num);
	for(i=0;i<num;i++) {
		fscanf(fp,"%s",k[i]);
		len[i]=strlen(k[i]);
		for(j=0;j<len[i];j++)
			if(k[i][j]<97)
				k[i][j]+=32;
		}
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
			for(l=0;l<num;l++) {
				if(a[i][j]==k[l][0]) {
					x=j;y=i;
					while(a[i][x]==k[l][x-j]) x++;
					if(x-j==len[l]) {
						posx[l]=i;
						posy[l]=j;
						}
					x=j;y=i;
					while(a[i][x]==k[l][j-x]) x--;
					if(j-x==len[l]) {
						posx[l]=i;
						posy[l]=j;
						}
					x=j;y=i;
					while(a[y][j]==k[l][y-i]) y++;
					if(y-i==len[l]) {
						posx[l]=i;
						posy[l]=j;
						}
					x=j;y=i;
					while(a[y][j]==k[l][i-y]) y--;
					if(i-y==len[l]) {
						posx[l]=i;
						posy[l]=j;
						}
					x=j;y=i;
					while((a[y][x]==k[l][x-j]) && y<n-1 || x<m-1) {
						x++;
						y++;
					}
					if(x-j==len[l]) {
						posx[l]=i;
						posy[l]=j;
						}
					x=j;y=i;
					while((a[y][x]==k[l][j-x]) && y<n-1 || x>0) {
						x--;
						y++;
					}
					if(j-x==len[l]) {
						posx[l]=i;
						posy[l]=j;
						}
					x=j;y=i;
					while((a[y][x]==k[l][x-j]) && y>0 || x<m-1) {
						x++;
						y--;
					}
					if(x-j==len[l]) {
						posx[l]=i;
						posy[l]=j;
						}
					x=j;y=i;
					while((a[y][x]==k[l][j-x])) {
						x--;
						y--;
					}
					if(j-x==len[l]) {
						posx[l]=i;
						posy[l]=j;
						}
					}
				}
		printf("\n\n");
	for(i=0;i<num;i++)
		printf("%d %d\n",posx[i],posy[i]);
	return 0;
}