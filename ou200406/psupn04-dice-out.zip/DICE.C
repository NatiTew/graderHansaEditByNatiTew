/*
TASK: DICE
LANG: C
AUTHOR: Peerasak Ratanamanee
CENTER: psupn04
*/
#include<stdio.h>
#include<string.h>
void main()
{
	int dice[6],temp,temp2,i,count;
	char rota[1001];
	scanf("%d",&count);
	while(count!=0)
	{
		scanf("%s",rota);
		dice[0]=1;
		dice[1]=2;
		dice[2]=3;
		dice[3]=5;
		dice[4]=4;
		dice[5]=6;
		for(i=0;i<strlen(rota);i++)
		{
			if(rota[i]=='F')
			{
				temp=dice[0];
				dice[0]=dice[3];
				temp2=dice[1];
				dice[1]=temp;
				dice[3]=dice[5];
				dice[5]=temp2;
			}
			else if(rota[i]=='B')
			{
				temp=dice[0];
				dice[0]=dice[1];
				dice[1]=dice[5];
				temp2=dice[3];
				dice[3]=temp;
				dice[5]=temp2;
			}
			else if(rota[i]=='L')
			{
				temp=dice[0];
				dice[0]=dice[4];
				temp2=dice[2];
				dice[2]=temp;
				dice[4]=dice[5];
				dice[5]=temp2;
			}
			else if(rota[i]=='R')
			{
				temp=dice[0];
				dice[0]=dice[2];
				temp2=dice[4];
				dice[4]=temp;
				dice[2]=dice[5];
				dice[5]=temp2;
			}
			else if(rota[i]=='C')
			{
				temp=dice[1];
				dice[1]=dice[4];
				temp2=dice[2];
				dice[2]=temp;
				dice[4]=dice[3];
				dice[3]=temp2;
			}
			else if(rota[i]=='D')
			{
				temp=dice[1];
				dice[1]=dice[2];
				temp2=dice[3];
				dice[3]=dice[4];
				dice[4]=temp;
				dice[2]=temp2;
			}
		}
		count--;
		printf("%d ",dice[1]);
	}
}