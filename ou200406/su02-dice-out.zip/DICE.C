/*
TASK: DICE
LANG: C
AUTHOR: Thitipong Sansanayuth
CENTER: SU02
*/
#include<stdio.h>
#include<string.h>
int main()
{
	int n,i,j,len,tmp,f=2,t=1,l=3,b=4,r=5,bo=6,ans[6];
	char str[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",str);
		f=2;t=1;l=3;b=5;r=4;bo=6;
		len=strlen(str);
		for(j=0;j<len;j++)
		{
			if(str[j]=='F') {tmp=f;f=t;t=b;b=bo;bo=tmp;}
			else if(str[j]=='B') {tmp=b;b=t;t=f;f=bo;bo=tmp;}
			else if(str[j]=='L') {tmp=l;l=t;t=r;r=bo;bo=tmp;}
			else if(str[j]=='R') {tmp=r;r=t;t=l;l=bo;bo=tmp;}
			else if(str[j]=='C') {tmp=f;f=r;r=b;b=l;l=tmp;}
			else if(str[j]=='D') {tmp=f;f=l;l=b;b=r;r=tmp;}
		}
		ans[i]=f;
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",ans[i]);
	}
	return 0;
}