#include <stdio.h>
void main() {
	int a;
	char s[10];
	scanf("%d\n",&a);
	scanf("%s",a)
	printf("Empty sequence");
}