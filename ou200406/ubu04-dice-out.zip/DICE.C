/*
TASK: MAXSEQ
LANG: C
AUTHOR: Mr.Krita Tonguan
CENTER: ubu04
*/

#include<stdio.h>
#include<string.h>


int main(){
	int num;
	int i, j, len;
	int top, front, left, back, right ,bottom, tmp;
	char t[1000];

	scanf("%d", &num);
	for(i=0;i<num;i++){
		scanf("%s", t);
		len = strlen(t);
		top = 1;
		front = 2;
		left = 3;
		back = 5;
		right = 4;
		bottom = 6;

		for(j=0;j<len;j++){

			switch(t[j]){
				case 'F' : tmp = top;
					top = back;
					back = bottom;
					bottom = front;
					front = tmp;
				break;

				case 'B' : tmp = top;
					top = front;
					front = bottom;
					bottom =back;
					back = tmp;
				break;

				case 'L' : tmp = top;
					top = right;
					right = bottom;
					bottom = left;
					left = tmp;

				break;
				case 'R' : tmp = top;
					top = left;
					left = bottom;
					bottom = right;
					right = tmp;
					break;
				case 'C' : tmp = front;
					front = right;
					right = back;
					back = left;
					left = tmp;
					break;
				case 'D' : tmp = front;
					front = left;
					left = back;
					back  = right;
					right = tmp;
					break;
			}
		}

		printf("%d ", front);

	}

	return 0;
}