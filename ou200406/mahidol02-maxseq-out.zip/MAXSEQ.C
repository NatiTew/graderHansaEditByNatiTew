/*
 TASK: MAXSEQ
 LANG: C
 AUTHOR: Boonyarit Somrealvongon
 CENTER: MAHIDOL02
*/
#include <stdio.h>

int main()
{
 int n,i,j,k,maxL,maxR;
 signed long sum,max=-1;
 int *a;
 scanf("%d\n",&n);
 a=(int *)malloc(sizeof(int)*(n+2));
 scanf("%d",&a[0]);
 for (i=1; i<n; i++) scanf(" %d",&a[i]);
 for (i=1; i<=n; i++)
  {
   for (j=0; j<=n-i; j++)
    {
      sum=0;
      for (k=j; k<j+i; k++)
       {
	 sum=sum+a[k];
       }
      if (sum>max)
       {
	max=sum;
	maxL=k-i;
	maxR=j+i-1;
       }
    }
  }
 if (max>0) {
  printf("%d",a[maxL]);
  for (i=maxL+1; i<=maxR; i++) printf(" %d",a[i]);
  printf("\n");
  printf("%ld",max);
  free(a);
 } else
  {
   printf("Empty sequence");
  }
 return 0;
}