/*
TASK: BEE
LANG: C
AUTHOR: Naksit Anantalapochai
CENTER: cmu04
*/
#include <stdio.h>

int main()
{
	int master=1,worker=1,soldier=0,i=-1,year,j,bw,bs,temp,ans1[24],ans2[24];
	static int cmd[24];
	do{
		i++;
		scanf("%d",&cmd[i]);
	}while(cmd[i]!=-1&&cmd[i]<=24);
	i=0;
	while(cmd[i]!=-1){
		year=cmd[i];
		for(j=0;j<year;j++){
			temp=worker;   // num of workers
			worker=(worker*2)-temp;
			worker=worker+soldier;
			soldier=0;
			soldier=soldier+temp;   // from worker
			worker++;    // from master
		}
		printf("%d %d\n",worker,worker+soldier+master);
		i++;
		master=1;
		soldier=0;
		worker=1;
	}
	return 0;
}