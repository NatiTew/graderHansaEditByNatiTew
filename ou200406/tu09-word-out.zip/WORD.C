/*
TASK: WORD
LANG: C
AUTHOR: Vanus Vachiratamporn
CENTER: TU09
*/
#include <stdio.h>
void small(char *c)
{   int i;
    for(i=0;c[i]!='\0';i++)
       {   if(c[i]<'a')
	     c[i]-='A'-'a';
       }
}

int main(void)
{   int m,n,k,i,j,l,o,ans[105][2],ch;
    char mat[30][30],c[20];
    scanf("%d",&m);
    scanf("%d",&n);
    for(i=0;i<m;i++)
       {   scanf("%s",mat[i]);
	   small(mat[i]);
       }
    scanf("%d",&k);
    for(i=0;i<k;i++)
       {   scanf("%s",c);
	   small(c);
	   for(j=0;j<m;j++)
	      {   for(l=0;mat[j][l]!='\0';l++)
		     {   if(mat[j][l]==c[0])
			   {   for(o=1,ch=0;c[o]!='\0';o++)
				  {   if(mat[j][l+o]!=c[o]||l+o>n-1)
					{   ch=1;
					    break;
					}
				  }
			       if(ch==0)
				 break;
			       for(o=1,ch=0;c[o]!='\0';o++)
				  {   if(mat[j][l-o]!=c[o]||l-o<0)
					{   ch=1;
					    break;
					}
				  }
			       if(ch==0)
				 break;
			       for(o=1,ch=0;c[o]!='\0';o++)
				  {   if(mat[j+o][l]!=c[o]||j+o>m-1)
					{   ch=1;
					    break;
					}
				  }
			       if(ch==0)
				 break;
			       for(o=1,ch=0;c[o]!='\0';o++)
				  {   if(mat[j-o][l]!=c[o]||j-o<0)
					{   ch=1;
					    break;
					}
				  }
			       if(ch==0)
				 break;
			       for(o=1,ch=0;c[o]!='\0';o++)
				  {   if(mat[j+o][l+o]!=c[o]||l+o>n-1||j+o>m-1)
					{   ch=1;
					    break;
					}
				  }
			       if(ch==0)
				 break;
			       for(o=1,ch=0;c[o]!='\0';o++)
				  {   if(mat[j-o][l-o]!=c[o]||l-o<0||j-o<0)
					{   ch=1;
					    break;
					}
				  }
			       if(ch==0)
				 break;
			       for(o=1,ch=0;c[o]!='\0';o++)
				  {   if(mat[j+o][l-o]!=c[o]||j+o>m-1||l-o<0)
					{   ch=1;
					    break;
					}
				  }
			       if(ch==0)
				 break;
			       for(o=1,ch=0;c[o]!='\0';o++)
				  {   if(mat[j-o][l+o]!=c[o]||l+o>n-1||j-o<0)
					{   ch=1;
					    break;
					}
				  }
			       if(ch==0)
				 break;
			   }
		     }
		   if(ch==0&&l!=n)
		     break;
	      }
	  ans[i][0]=j;
	  ans[i][1]=l;
       }
    for(i=0;i<k;i++)
       printf("%d %d\n",ans[i][0],ans[i][1]);
    return 0;
}