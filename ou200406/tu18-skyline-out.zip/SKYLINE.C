/*
TASK: SKYLINE
LANG: C
AUTHOR: ISRANU SAENGSUWAN
CENTER: SAMESEN18
*/
#include <stdio.h>

main()
{
	int amount, max=0, i, j;
	long data[3001][3], height[256], hgt;
	scanf ("%d", &amount);
	for (i=0;i<amount;i++)
	{
		scanf ("%ld %ld %ld", &data[i][0], &data[i][1], &data[i][2]);
		if (data[i][2] > max) max = data[i][2];
	}
	for (i=0;i<max;i++) height[i] = 0;
	for (i=0;i<amount;i++)
		for (j=0;j<max;j++)
			if (j>=data[i][0] && j<data[i][2])
				if (data[i][1] > height[j])
					height[j] = data[i][1];
	hgt = 0;
	for (i=1;i<max;i++)
		if (hgt != height[i])
		{
			hgt = height[i];
			printf ("%d %ld ", i, height[i]);
		}
	printf ("%d 0", i);
	return 0;
}