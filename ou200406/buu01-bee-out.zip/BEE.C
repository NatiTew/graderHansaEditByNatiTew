/*
TASK: BEE
LANG: C
AUTHOR: GAIPEACH SUCHARTKULVIT
CENTER: ASSUMPTION COLLEGE SRIRACHA - buu01
*/
#include <stdio.h>

int main(void)
{
	int n;
	int i;
	long pbs,pbw;
	long bw,bm,bs,sumb;
	while(1)
	{
		scanf("%d",&n);
		if(n==-1)
			break;
		bm=1;
		bw=1;
		bs=0;
		for(i=0;i<n;i++)
		{
			pbs=bs;
			pbw=bw;
			bw+=(bm+pbs);
			bs=pbw;
		}
		sumb=bm+bw+bs;
		printf("%ld %ld\n",bw,sumb);
	}
	return 0;
}