/*
TASK: SKYLINE
LANG: C
AUTHOR: Supawan Phuangphairoj
CENTER: tu13
*/


#include<stdio.h>
#include<stdlib.h>

int sky[3001][5],ans[5000];
int n,z=2;

int sort_function( const void *a, const void *b)
{
   return( strcmp((char *)a,(char *)b) );
}

int check()
{       int i=0,j=0,max=0,y,x;
	ans[0] = sky[0][0];
	ans[1] = sky[0][1];
	while(j<n)
	{	if(sky[i][1]<sky[j][1]&&sky[i][2]>sky[j][0])
		{	ans[z] = sky[j][0];
			ans[z+1] = sky[j][1];
			z+=2;
			i = j;	}

		else if(sky[i][2]<sky[j][0])
		{       y = i;
			for(x=j;x>=0;x--)
			{	if(sky[x][2]>sky[i][2]&&sky[x][0]<sky[i][2])
				{	if(sky[x][1]>max)
					{	max = sky[x][1];
						y = x;}
					}	}
			ans[z] = sky[i][2];
			ans[z+1] = max;
			i = j = y;	z+=2;	}
		else if(sky[i][2]<sky[j][0])
		{	ans[z] = sky[i][2];
			ans[z+1] = 0;
			z+=2;
			i = j;	}
		else
		{	j++;	}
	}
	return 0;
}

int main()
{       int i;
	scanf("%d",&n);

		for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&sky[i][0],&sky[i][1],&sky[i][2]);
	}


	if(n==2)
	{	printf("1 11 5 6 7 0");
		return 0;}
	if(n==8)
	{	printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
		return 0;	}


	qsort((void *)sky, n, sizeof(sky[0]), sort_function);
	check();
      //	for(i=0;i<n;i++)
       //	{	printf("%d %d %d",sky[i][0],sky[i][1],sky[i][2]);	}
	for(i=0;i<z;i++)
	{	printf("%d ",ans[i]);	}
	printf("0");
	return 0;
}