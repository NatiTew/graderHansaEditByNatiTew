/*
TASK: BEE
LANG: C
AUTHOR: Pongdanai Chayarun
CENTER: SU
*/
#include<stdio.h>
int in[24];
int ans[24][2]={0};
int work=1,sold=0,i,count=0,j;
int main()
{  while(scanf("%d",&in[count]),in[count]!=-1)count++;
  for(i=0;i<count;i++)
  {   ans[i][0]=work;
      ans[i][1]=sold;
     for(j=1;j<=in[i];j++)
     {   ans[i][0]+=j;
	 ans[i][1]+=j-1;
     }
  }
  for(i=0;i<count;i++)
  { if (in[i]<=3) printf("%d %d\n",ans[i][0],ans[i][0]+ans[i][1]+2);
    else printf("%d %d\n",ans[i][0],ans[i][0]+ans[i][1]+in[i]-1);
  }
return 0;
}