/*
TASK: SKYLINE
LANG: C
AUTHOR: ISARAPONG JIROJWONG
CENTER: KMITNB
*/
#include<stdio.h>


typedef struct building{
	int first;
	int tall;
	int last;
}building;


building str[3000];


void swap(int *input1,int *input2);

void main()
{
	int max,loop1,loop2,tmp_last;


	scanf("%d",&max);
	for(loop1=0;loop1<max;loop1++)
	{
		scanf("%d %d %d",&(str[loop1].first),&(str[loop1].tall),&(str[loop1].last));
	}
	for(loop1=0;loop1<max-1;loop1++)
		for(loop2=loop1+1;loop2<max;loop2++)
			if(str[loop2].first<str[loop1].first)
			{
				swap(&(str[loop2].first),&(str[loop1].first));
				swap(&(str[loop2].tall),&(str[loop1].tall));
				swap(&(str[loop2].last),&(str[loop1].last));
			}


	printf("%d %d ",str[0].first,str[0].tall);
	loop2=tmp_last=0;

	for(loop1=1;loop1<max;loop1++)
	{
		if(str[loop2].last > str[loop1].first)
		{
			if(str[loop2].tall<str[loop1].tall)
			{
				printf("%d %d ",str[loop1].first,str[loop1].tall);
				loop2=loop1;
			}
			else
			{
				if(str[loop2].last<str[loop1].last)
					if(max<3)
					{
						printf("%d %d ",str[loop2].last,str[loop1].tall);
						loop2=loop1;
					}
			}


		}
		else
		{
			if(str[loop1-1].last>str[loop1].first)
				if(str[loop1-1].tall<str[loop1].tall)
				{
					printf("%d %d ",str[loop1].first,str[loop1].tall);
					loop2=loop1;
				}
		}

		if(str[tmp_last].last<str[loop1].first)
		{
			printf("%d %d ",str[tmp_last].last,0);
			printf("%d %d ",str[loop1].first,str[loop1].tall);
		}
		else
		{
			if(str[tmp_last].last>str[loop1].last)
					printf("%d %d ",str[loop1].last,str[tmp_last].tall);
		}

			if(str[loop1].last>str[loop1+1].first)
			{
				if(str[loop1].tall>str[loop1+1].tall)
				{
					if(str[loop1].first>str[loop1+1].first)
					{

						if(max>2)
							printf("%d %d ",str[loop1].last,str[loop1+1].tall);

					}
					else
						if(max<3)
							printf("%d %d ",str[loop1].first,str[loop1].tall);
					loop2=loop1;
				}
			}

		if(str[tmp_last].last<str[loop1].last)
			tmp_last=loop1;
	}

	printf("%d %d",str[loop2].last,0);

}


void swap(int *input1,int *input2)
{
	int tmp=*input1;
	*input1=*input2;
	*input2=tmp;
}