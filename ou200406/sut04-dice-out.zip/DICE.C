/*
TASK: DICE
LANG: C
AUTHOR: Pattaravut Maleehuan
CENTER: SUT04
*/
#include<stdio.h>
#include<string.h>
int tmp,i,n,j;
char s[1002];

struct dice
{
	int t,
	r,l,b,f,bk;
}di[6];

void move(int,int);
void init();

int main()
{
	scanf("%d",&n);
	init();
	for(i=0;i<n;i++)
	{
		scanf("%s",&s);
		for(j=0;j<strlen(s);j++)
			move(i,s[j]);
	}
	for(i=0;i<n;i++)
		printf("%d ",di[i].f);
 return 0;
}

void init()
{
	for(i=0;i<6;i++)
	{
		di[i].t=1;
		di[i].f=2;
		di[i].l=3;
		di[i].r=4;
		di[i].bk=5;
		di[i].b=6;
	}
}

void move(int in,int d)
{
	if(d == 'F')
	{
		tmp=di[in].f;
		di[in].f=di[in].t;
		di[in].t=di[in].bk;
		di[in].bk=di[in].b;
		di[in].b=tmp;
	}else if(d == 'B')
	{
		tmp=di[in].b;
		di[in].b=di[in].bk;
		di[in].bk=di[in].t;
		di[in].t=di[in].f;
		di[in].f=tmp;
	}else if(d == 'C')
	{
		tmp=di[in].l;
		di[in].l=di[in].f;
		di[in].f=di[in].r;
		di[in].r=di[in].bk;
		di[in].bk=tmp;
	}else if(d == 'D')
	{
		tmp=di[in].r;
		di[in].r=di[in].f;
		di[in].f=di[in].l;
		di[in].l=di[in].bk;
		di[in].bk=tmp;
	}else if(d == 'L')
	{
		tmp=di[in].l;
		di[in].l=di[in].t;
		di[in].t=di[in].r;
		di[in].r=di[in].b;
		di[in].b=tmp;
	}else if(d == 'R')
	{
		tmp=di[in].r;
		di[in].r=di[in].t;
		di[in].t=di[in].l;
		di[in].l=di[in].b;
		di[in].b=tmp;
	}
}