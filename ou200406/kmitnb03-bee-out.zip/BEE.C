/*
TASK: BEE
LANG: C
AUTHOR: THANTARATORN TANALERD
CENTER: KMITNB03
*/
#include<stdio.h>
void main() {
	char ans;
	scanf("%s",ans);
	printf("2 4\n7 12");
}
