/*
TASK: MAXSEQ
LANG: C
AUTHOR: Aniwat Kusantear
CENTER: KHONKAEN05
*/
#include<stdio.h>
int Pfirst,Plast[2500],nummax;
int num[2500];
int maxseq(int k)
{
	int MAX[2500],i,temp=-500;

	for(i=k;i<=nummax;i++){
		MAX[k]+=num[i];
		if(temp<MAX[k]){
			Plast[k]=i;
			temp=MAX[k];
		}
	}
	return temp;
}
int main(void)
{
	int i,j=0,MAX[2500],temp=0;
	Pfirst=0;
	scanf("%d",&nummax);
	for(j=0;j<nummax;j++){
		scanf("%d ",&num[j]);
			}
	for(i=0;i<=nummax;i++){
		MAX[i]=maxseq(i);
	}
	for(i=0;i<=nummax;i++){
		if(temp<MAX[i]){
			Pfirst=i;
			temp=MAX[i];
	}
	printf("%d\n",MAX[Pfirst]);
	for(i=Pfirst;i<=Plast[Pfirst];i++)
		if(MAX[Pfirst]<0)
			printf("Empty sequence");
		printf("%d ",num[i]);
	return 0;
}
}