/*
 TASK: DICE
 LANG: C
 AUTHOR: Boonyarit Somrealvongon
 CENTER: MAHIDOL02
*/

#include <stdio.h>
#include <string.h>

int main()
{
 int init,i,j,n,sol[6];
 char ch,str[1009];

 scanf("%d",&n);

 for(j=1; j<=n; j++)
  {
   init=2;
 scanf("%s",str);
 for(i=0; i<strlen(str); i++)
  { ch=str[i];

    if (ch=='F' && init==1) init=5;
    else if (ch=='F' && init==2) init=1;
    else if (ch=='F' && init==3) init=3;
    else if (ch=='F' && init==5) init=6;
    else if (ch=='F' && init==4) init=4;
    else if (ch=='F' && init==6) init=2;

    else if (ch=='B' && init==1) init=2;
    else if (ch=='B' && init==2) init=6;
    else if (ch=='B' && init==3) init=3;
    else if (ch=='B' && init==5) init=1;
    else if (ch=='B' && init==4) init=4;
    else if (ch=='B' && init==6) init=5;

    else if (ch=='L' && init==1) init=4;
    else if (ch=='L' && init==2) init=2;
    else if (ch=='L' && init==3) init=1;
    else if (ch=='L' && init==5) init=5;
    else if (ch=='L' && init==4) init=6;
    else if (ch=='L' && init==6) init=3;

    else if (ch=='R' && init==1) init=3;
    else if (ch=='R' && init==2) init=2;
    else if (ch=='R' && init==3) init=6;
    else if (ch=='R' && init==5) init=5;
    else if (ch=='R' && init==4) init=1;
    else if (ch=='R' && init==6) init=4;

    else if (ch=='C' && init==1) init=1;
    else if (ch=='C' && init==2) init=4;
    else if (ch=='C' && init==3) init=2;
    else if (ch=='C' && init==5) init=3;
    else if (ch=='C' && init==4) init=5;
    else if (ch=='C' && init==6) init=6;

    else if (ch=='D' && init==1) init=1;
    else if (ch=='D' && init==2) init=3;
    else if (ch=='D' && init==3) init=5;
    else if (ch=='D' && init==5) init=4;
    else if (ch=='D' && init==4) init=2;
    else if (ch=='D' && init==6) init=6;


  }
   sol[j-1]=init;
  }

  printf("%d",sol[0]);
  for(j=1; j<n; j++)
  {
   printf(" %d",sol[j]);
  }
  return 0;
}