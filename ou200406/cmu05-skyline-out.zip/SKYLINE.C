/*
TASK: SKYLINE
LANG: C
AUTHOR: Pongsakorn Jaiban
CENTER: CMU05
*/

#include<stdio.h>

int main(void)
{
	//data constant
	static int data[3][3000];
	static int height[10000];


	//normal constant
	int input,i,maxnum=0,num;

	scanf("%d",&input);
	for(i=0;i<input;i++)
	{
		scanf("%d %d %d\n",&data[0][i],&data[1][i],&data[2][i]);
		if(data[2][i]>maxnum)
			maxnum=data[2][i];
	}
	for(i=0;i<input;i++)
		for(num=data[0][i];num<data[2][i];num++)
			if(height[num]<data[1][i])
				height[num]=data[1][i];

	for(i=0;i<maxnum;i++)
		if(height[i]!=height[i+1])
			printf("%d %d ",i+1,height[i+1]);
	return 0;
}