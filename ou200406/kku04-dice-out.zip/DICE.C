/*
TASK:DICE
LANG:C
AUTHOR:SUPASHOCK RENGSOMBOON
CENTER:KKU04
*/
#include<stdio.h>
#include<string.h>
int main(){
int  i,j,box[6][6],t,temp;
char c[6][1001]  ;
	scanf("%d",&t);

	for(i=0;i<t;i++){
	box[i][0]=1;
	box[i][1]=2;
	box[i][2]=3;
	box[i][3]=5;
	box[i][4]=4;
	box[i][5]=6;
	j=0;
	scanf("%s",c[i]);

	for(j=0;j<strlen(c[i]);j++){



	if(c[i][j]=='F'){temp=box[i][0];
			 box[i][0]=box[i][3];
			 box[i][3]=box[i][5];
			 box[i][5]=box[i][1];
			 box[i][1]=temp;}

	else if(c[i][j]=='B'){temp=box[i][1];
			 box[i][1]=box[i][5];
			 box[i][5]=box[i][3];
			 box[i][3]=box[i][0];
			 box[i][0]=temp;}

	else if(c[i][j]=='L'){temp=box[i][0];
			 box[i][0]=box[i][4];
			 box[i][4]=box[i][5];
			 box[i][5]=box[i][2];
			 box[i][2]=temp;}

	else if(c[i][j]=='R'){temp=box[i][2];
			 box[i][2]=box[i][5];
			 box[i][5]=box[i][4];
			 box[i][4]=box[i][0];
			 box[i][0]=temp;}

	else if(c[i][j]=='C'){temp=box[i][1];
			 box[i][1]=box[i][4];
			 box[i][4]=box[i][3];
			 box[i][3]=box[i][2];
			 box[i][2]=temp;}

	else if(c[i][j]=='D'){temp=box[i][2];
			 box[i][2]=box[i][3];
			 box[i][3]=box[i][4];
			 box[i][4]=box[i][1];
			 box[i][1]=temp;}


				}





			 }

	for(i=0;i<t;i++)
	printf("%d ",box[i][1]);

return 0;
}