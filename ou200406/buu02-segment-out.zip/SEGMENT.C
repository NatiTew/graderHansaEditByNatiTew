/*
TASK: SEGMENT
LANG: C
AUTHOR: Khakhana Thimachai
CENTER: buu02
*/
#include<stdio.h>
#include<stdlib.h>
long int sum;
char check2(int a);
char check27(int a);
char check28(int a);
char check29(int a);
char check20(int a);
char check21(int a);
char check22(int a);
char check23(int a);
char check24(int a);
char check25(int a);
char check26(int a);
char check(int a);
char check7(int a);
char check8(int a);
char check9(int a);
char check0(int a);
char check1(int a);
char check12(int a);
char check3(int a);
char check4(int a);
char check5(int a);
char check6(int a);
char in1[3][40],in2[3][40];
int main(void){
	long int sum;
	long int t1,t2;
	char tmp1[11],tmp2[11];
	int i,j;
	int r1,r2;
	scanf("%d",&r1,&r2);
	for(i=0;i<3;i++){
		for(j=0;j<r1*3;j++){
			scanf("%c",&in1[i][j]);
		}
	}
	for(i=0;i<3;i++){
		for(j=0;j<r2*3;j++){
			scanf("%c",&in2[i][j]);
		}
	}

	for(i=0;i<r1;i++){
		tmp1[i]=check(i);
	}
	tmp1[i]='\0';
	for(i=0;i<r2;i++){
		tmp2[i]=check2(i);
	}
	tmp1[i]='\0';
	t1 = atol(tmp1);
	t2 = atol(tmp2);
	sum = t1+t2;
	printf("%ld",sum);
	return 0;
}
char check2(int a){
	char ch=0;
	if(ch==0)
	ch = check20(a);
	if(ch==0)
	ch = check21(a);
	if(ch==0)
	ch = check22(a);
	if(ch==0)
	ch = check23(a);
	if(ch==0)
	ch = check24(a);
	if(ch==0)
	ch = check25(a);
	if(ch==0)
	ch = check26(a);
	if(ch==0)
	ch = check27(a);
	if(ch==0)
	ch = check28(a);
	if(ch==0)
	ch = check29(a);


	return ch;
}

char check20(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!='_')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[1][a*3+a+1]!=' ')
		ex=0;
	if(in2[1][a*3+a+2]!='|')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[2][a*3+a+1]!='_')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '0';
	else
		return 0;
}

char check21(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!=' ')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[1][a*3+a+1]!=' ')
		ex=0;
	if(in2[1][a*3+a+2]!='|')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[2][a*3+a+1]!=' ')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '1';
	else
		return 0;
}
char check22(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!='_')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[1][a*3+a+1]!='_')
		ex=0;
	if(in2[1][a*3+a+2]!='|')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[2][a*3+a+1]!='_')
		ex=0;
	if(in2[2][a*3+a+2]!=' ')
		ex=0;
	if(ex)
		return '2';
	else
		return 0;
}
char check23(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!='_')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[1][a*3+a+1]!='_')
		ex=0;
	if(in2[1][a*3+a+2]!='|')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[2][a*3+a+1]!='_')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '3';
	else
		return 0;
}
char check24(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!=' ')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[1][a*3+a+1]!='_')
		ex=0;
	if(in2[1][a*3+a+2]!='|')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[2][a*3+a+1]!=' ')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '4';
	else
		return 0;
}
char check25(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!='_')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[1][a*3+a+1]!='_')
		ex=0;
	if(in2[1][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[2][a*3+a+1]!='_')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '5';
	else
		return 0;
}
char check26(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!='_')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[1][a*3+a+1]!='_')
		ex=0;
	if(in2[1][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[2][a*3+a+1]!='_')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '6';
	else
		return 0;
}
char check27(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!='_')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[1][a*3+a+1]!=' ')
		ex=0;
	if(in2[1][a*3+a+2]!='|')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[2][a*3+a+1]!=' ')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '7';
	else
		return 0;
}
char check28(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!='_')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[1][a*3+a+1]!='_')
		ex=0;
	if(in2[1][a*3+a+2]!='|')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[2][a*3+a+1]!='_')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '8';
	else
		return 0;
}
char check29(int a){
	int ex=1;
	if(in2[0][a*3+a+0]!=' ')
		ex=0;
	if(in2[0][a*3+a+1]!='_')
		ex=0;
	if(in2[0][a*3+a+2]!=' ')
		ex=0;
	if(in2[1][a*3+a+0]!='|')
		ex=0;
	if(in2[1][a*3+a+1]!='_')
		ex=0;
	if(in2[1][a*3+a+2]!='|')
		ex=0;
	if(in2[1][a*3+a+0]!=' ')
		ex=0;
	if(in2[2][a*3+a+1]!='_')
		ex=0;
	if(in2[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '9';
	else
		return 0;
}
char check(int a1){
	char ch=0;
	if(ch==0)
	ch = check0(a1);
	if(ch==0)
	ch = check1(a1);
	if(ch==0)
	ch = check12(a1);
	if(ch==0)
	ch = check3(a1);
	if(ch==0)
	ch = check4(a1);
	if(ch==0)
	ch = check5(a1);
	if(ch==0)
	ch = check6(a1);
	if(ch==0)
	ch = check7(a1);
	if(ch==0)
	ch = check8(a1);
	if(ch==0)
	ch = check9(a1);


	return ch;
}

char check0(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!='_')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[1][a*3+a+1]!=' ')
		ex=0;
	if(in1[1][a*3+a+2]!='|')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[2][a*3+a+1]!='_')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '0';
	else
		return 0;
}

char check1(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!=' ')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[1][a*3+a+1]!=' ')
		ex=0;
	if(in1[1][a*3+a+2]!='|')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[2][a*3+a+1]!=' ')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '1';
	else
		return 0;
}
char check12(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!='_')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[1][a*3+a+1]!='_')
		ex=0;
	if(in1[1][a*3+a+2]!='|')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[2][a*3+a+1]!='_')
		ex=0;
	if(in1[2][a*3+a+2]!=' ')
		ex=0;
	if(ex)
		return '2';
	else
		return 0;
}
char check3(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!='_')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[1][a*3+a+1]!='_')
		ex=0;
	if(in1[1][a*3+a+2]!='|')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[2][a*3+a+1]!='_')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '3';
	else
		return 0;
}
char check4(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!=' ')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[1][a*3+a+1]!='_')
		ex=0;
	if(in1[1][a*3+a+2]!='|')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[2][a*3+a+1]!=' ')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '4';
	else
		return 0;
}
char check5(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!='_')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[1][a*3+a+1]!='_')
		ex=0;
	if(in1[1][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[2][a*3+a+1]!='_')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '5';
	else
		return 0;
}
char check6(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!='_')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[1][a*3+a+1]!='_')
		ex=0;
	if(in1[1][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[2][a*3+a+1]!='_')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '6';
	else
		return 0;
}
char check7(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!='_')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[1][a*3+a+1]!=' ')
		ex=0;
	if(in1[1][a*3+a+2]!='|')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[2][a*3+a+1]!=' ')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '7';
	else
		return 0;
}
char check8(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!='_')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[1][a*3+a+1]!='_')
		ex=0;
	if(in1[1][a*3+a+2]!='|')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[2][a*3+a+1]!='_')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '8';
	else
		return 0;
}
char check9(int a){
	int ex=1;
	if(in1[0][a*3+a+0]!=' ')
		ex=0;
	if(in1[0][a*3+a+1]!='_')
		ex=0;
	if(in1[0][a*3+a+2]!=' ')
		ex=0;
	if(in1[1][a*3+a+0]!='|')
		ex=0;
	if(in1[1][a*3+a+1]!='_')
		ex=0;
	if(in1[1][a*3+a+2]!='|')
		ex=0;
	if(in1[1][a*3+a+0]!=' ')
		ex=0;
	if(in1[2][a*3+a+1]!='_')
		ex=0;
	if(in1[2][a*3+a+2]!='|')
		ex=0;
	if(ex)
		return '9';
	else
		return 0;
}