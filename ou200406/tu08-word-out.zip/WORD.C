/*
TASK: WORD
LANG: C
AUTHOR: Taksapaun Kittiakrastien
CENTER: tu08
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node{
  char val[15]; //14 chrs
  int id; //id of this word
  struct node* next;
};


int m,n;
char arr[26][26];


int search(int r, int c, struct node* x)
{
			  //found return 1 else return 0
			  //8 dir according to numpad
			  //row, col, node
  int i=0;
  //dir 1
    for(i=0;x->val[i]>='a' && x->val[i]<= 'z' && r+i<m && c-i>=0; i++)
    {
      if(x->val[i]!=arr[r+i][c-i])
      {
	break;
      }
    }
    if(x->val[i]<'a' || x->val[i]>'z')
      return 1;

  i = 0;
  //dir 2
    for(i=0;x->val[i]>='a' && x->val[i]<= 'z' && r+i<m; i++)
    {
      if(x->val[i]!=arr[r+i][c])
      {
	break;
      }
    }
    if(x->val[i]<'a' || x->val[i]>'z')
      return 1;

  i = 0;
  //dir 3
    for(i=0;x->val[i]>='a' && x->val[i]<= 'z' && r+i<m && c+i<n; i++)
    {
      if(x->val[i]!=arr[r+i][c+i])
      {
	break;
      }
    }
    if(x->val[i]<'a' || x->val[i]>'z')
      return 1;

  i = 0;
  //dir 4
    for(i=0;x->val[i]>='a' && x->val[i]<= 'z' && c-i>=0; i++)
    {
      if(x->val[i]!=arr[r][c-i])
      {
	break;
      }
    }
    if(x->val[i]<'a' || x->val[i]>'z')
      return 1;

  i = 0;
  //dir 6
    for(i=0;x->val[i]>='a' && x->val[i]<= 'z' && c+i<n; i++)
    {
      if(x->val[i]!=arr[r][c+i])
      {
	break;
      }
    }
    if(x->val[i]<'a' || x->val[i]>'z')
      return 1;

  i = 0;
  //dir 7
    for(i=0;x->val[i]>='a' && x->val[i]<= 'z' && c-i>=0 && r-i>=0; i++)
    {
      if(x->val[i]!=arr[r-i][c-i])
      {
	break;
      }
    }
    if(x->val[i]<'a' || x->val[i]>'z')
      return 1;

  i = 0;
  //dir 8
    for(i=0;x->val[i]>='a' && x->val[i]<= 'z' && r-i>=0; i++)
    {
      if(x->val[i]!=arr[r-i][c])
      {
	break;
      }
    }
    if(x->val[i]<'a' || x->val[i]>'z')
      return 1;

  i = 0;
  //dir 9
    for(i=0;x->val[i]>='a' && x->val[i]<= 'z' && r-i>=0 && c+i<n; i++)
    {
      if(x->val[i]!=arr[r-i][c+i])
      {
	break;
      }
    }
    if(x->val[i]<'a' || x->val[i]>'z')
      return 1;


  return 0;
}

int main()
{
  int i,j;
  char temp[16];
  int k;
  struct node* start[27];
  struct node* newnode;
  struct node* curnode;
  int words;
  int ans[101][3];

  scanf("%d", &m);
  scanf("%d", &n);
  for(i=0;i<m;i++)
  {
    for(j=0;j<n;j++)
    {
      scanf("%c", &arr[i][j]);
      if(arr[i][j]<'Z')
	arr[i][j] += 32;
    }
    scanf("%*c");
  }
  scanf("%d", &words);
  for(i=0;i<words;i++)
  {
    gets(temp);
    newnode = (struct node*)malloc(sizeof(struct node));
    strcpy(newnode->val, temp);
    start[temp[0]-97] = newnode;
  }

  for(i=m;i>=0;i--)
  {
    for(j=n;j>=0;j--)
    {
      if(start[arr[i][j]-97]!=NULL)
      {
	curnode = start[arr[i][j]-97];
	while(curnode!=NULL)
	{
	  if(search(i,j,curnode)==1)
	  {
	      //found here
	      ans[curnode->id][0] = i;
	      ans[curnode->id][1] = j;
	      break;
	  }
	  curnode = curnode->next;
	}
      }
    }
  }

  for(i=0;i<words;i++)
  {
    printf("%d %d\n", ans[i][0], ans[i][1]);
  }
  return 0;
}