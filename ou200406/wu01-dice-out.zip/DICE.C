/*
TASK: DICE
LANG: C
AUTHOR: JIRANUN JIRATRAKANWONG
CENTER: WU01
*/
#include<stdio.h>
#include<string.h>
int on=1,forw=2,right=4,back=5,left=3,under=6;

struct dice{
	char c[2000];
}con[6];

void conF(){
	int tmp=0;
	tmp=on;on=back;back=under;under=forw;forw=tmp;
}

void conB(){
	int tmp=0;
	tmp=on;on=forw;forw=under;under=back;back=tmp;
}

void conL(){
	int tmp=0;
	tmp=on;on=right;right=under;under=left;left=tmp;
}

void conR(){
	int tmp=0;
	tmp=on;on=left;left=under;under=right;right=tmp;
}

void conC(){
	int tmp=0;
	tmp=forw;forw=right;right=back;back=left;left=tmp;
}

void conD(){
	int tmp=0;
	tmp=forw;forw=left;left=back;back=right;right=tmp;
}



void main()
{
	int n,i,ncon,j;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%s",con[i].c);
	}
	for(i=0;i<n;i++){
	on=1;forw=2;right=4;back=5;left=3;under=6;
	ncon=strlen(con[i].c);
		for(j=0;j<ncon;j++){
			if(con[i].c[j]=='F') conF();
			else if(con[i].c[j]=='B') conB();
			else if(con[i].c[j]=='L') conL();
			else if(con[i].c[j]=='R') conR();
			else if(con[i].c[j]=='C') conC();
			else if(con[i].c[j]=='D') conD();
			}
	printf("%d ",forw);
	}
}

