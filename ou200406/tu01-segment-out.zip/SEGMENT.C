/*
TASK: SEGMENT
LANG: C
AUTHOR: PANOT CHAIMONGKOL
CENTER: TU01
*/

#include <stdio.h>

void main()
{
	int an,bn,i,j;
	unsigned long a,b,sum;
	char ac[3][30],bc[3][30],tmp;
	scanf("%d %d%c",&an,&bn,&tmp);
	for (i=0;i<3;i++)
	{
		for (j=0;j<an;j++)
		{
			scanf("%c%c%c",&ac[i][3*j],&ac[i][3*j+1],&ac[i][3*j+2]);
			if (j<an-1)
				scanf("%c",&tmp);
		}
		scanf("%c",&tmp);
	}
	for (i=0;i<3;i++)
	{
		for (j=0;j<bn;j++)
		{
			scanf("%c%c%c",&bc[i][3*j],&bc[i][3*j+1],&bc[i][3*j+2]);
			if (j<bn-1)
				scanf("%c",&tmp);
		}
		scanf("%c",&tmp);
	}
	//READ A
	a=0;
	for (i=0;i<an;i++)
	{
		if (ac[0][i*3+1]==' ') // 1 or 4
			if (ac[1][i*3]==' ') // 1
				a = a*10 + 1;
			else
				a = a*10 + 4;
		else if (ac[1][i*3+2]==' ') // 5 or 6
			if (ac[2][i*3]==' ') // 5
				a = a*10 + 5;
			else
				a = a*10 + 6;
		else if (ac[1][i*3+1]==' ') // 7 or 0
			if (ac[1][i*3]==' ') // 7
				a = a*10 + 7;
			else
				a = a*10;
		else if (ac[2][i*3]==' ') // 3 or 9
			if (ac[1][i*3]==' ') // 3
				a = a*10 + 3;
			else
				a = a*10 + 9;
		else // 2 or 8
			if (ac[1][i*3]==' ')
				a = a*10 + 2;
			else
				a = a*10 + 8;
	} //for
	//READ B
	b=0;
	for (i=0;i<bn;i++)
	{
		if (bc[0][i*3+1]==' ') // 1 or 4
			if (bc[1][i*3]==' ') // 1
				b = b*10 + 1;
			else
				b = b*10 + 4;
		else if (bc[1][i*3+2]==' ') // 5 or 6
			if (bc[2][i*3]==' ') // 5
				b = b*10 + 5;
			else
				b = b*10 + 6;
		else if (bc[1][i*3+1]==' ') // 7 or 0
			if (bc[1][i*3]==' ') // 7
				b = b*10 + 7;
			else
				b = b*10;
		else if (bc[2][i*3]==' ') // 3 or 9
			if (bc[1][i*3]==' ') // 3
				b = b*10 + 3;
			else
				b = b*10 + 9;
		else // 2 or 8
			if (bc[1][i*3]==' ')
				b = b*10 + 2;
			else
				b = b*10 + 8;
	} //for
	sum = a+b;
	printf("%lu",sum);
} //main