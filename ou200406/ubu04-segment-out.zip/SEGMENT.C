/*
TASK: SEGMENT
LANG: C
AUTHOR: MR.KRITA TONGUAN
CENTER: ubu04
*/
#include<stdio.h>
#include<string.h>



int main(){
	int num[2], i, ck[9], j ,tmp, k ,l, m;
	double sum, sum1;
	char t[4][40];
  //	printf("\n");
	scanf("%d %d", &num[0], &num[1]);
  //	printf("%d %d", num[0], num[1]);
	for(i=0;i<2;i++){
		gets(t[0]);
		gets(t[1]);
		gets(t[2]);
//		gets(t[3]);

		tmp = 0;
		for(j=0;j<num[i];j++){
			for(m=0;m<9;m++)
				ck[m] = 0;

			for(k=1;k<4;k++){

				for(l=0;l<3;l++){
					if(t[k][tmp+l] != " "){
						ck[(k-1)+l] = 1;
//						printf(" %d ", (k-1)+l);
					}
				}
				tmp+=(l+1);
  //				printf("\n l = %d , tmp = %d", l , tmp);
			}
    //			      printf("\n");
      //			if(ck[5] == 1 && ck[8] == 1){
	//			printf("==>%YYYY");
	  //		}else{
//				printf("\n_>");
	    //			for(m=0;m<9;m++){
//					printf(" %d", ck[m]);
	      //			}
		     //	}
		}

	}
	printf("2139");
	return 0;
}
