/*
TASK: SEGMENT
LANG: C
AUTHOR: KAWIN ASVAPATIPATT
CENTER: TU07
*/

#include <stdio.h>

char num[3][15] ;

int analysis (int i)
{
i = (i*3)+i ;
if (num[0][i+1] == ' ' && num[1][i] == ' ' && num[1][i+1] == ' ' && num[1][i+2] == '|' && num[2][i] == ' ' && num[2][i+1] == ' ' && num[2][i+2] == '|')
	return 1 ;
else if (num[0][i+1] == '_' && num[1][i] == ' ' && num[1][i+1] == '_' && num[1][i+2] == '|' && num[2][i] == '|' && num[2][i+1] == '_' && num[2][i+2] == ' ')
	return 2 ;
else if (num[0][i+1] == '_' && num[1][i] == ' ' && num[1][i+1] == '_' && num[1][i+2] == '|' && num[2][i] == ' ' && num[2][i+1] == '_' && num[2][i+2] == '|')
	return 3 ;
else if (num[0][i+1] == ' ' && num[1][i] == '|' && num[1][i+1] == '_' && num[1][i+2] == '|' && num[2][i] == ' ' && num[2][i+1] == ' ' && num[2][i+2] == '|')
	return 4 ;
else if (num[0][i+1] == '_' && num[1][i] == '|' && num[1][i+1] == '_' && num[1][i+2] == ' ' && num[2][i] == ' ' && num[2][i+1] == '_' && num[2][i+2] == '|')
	return 5 ;
else if (num[0][i+1] == '_' && num[1][i] == '|' && num[1][i+1] == '_' && num[1][i+2] == ' ' && num[2][i] == '|' && num[2][i+1] == '_' && num[2][i+2] == '|')
	return 6 ;
else if (num[0][i+1] == '_' && num[1][i] == ' ' && num[1][i+1] == ' ' && num[1][i+2] == '|' && num[2][i] == ' ' && num[2][i+1] == ' ' && num[2][i+2] == '|')
	return 7 ;
else if (num[0][i+1] == '_' && num[1][i] == '|' && num[1][i+1] == '_' && num[1][i+2] == '|' && num[2][i] == '|' && num[2][i+1] == '_' && num[2][i+2] == '|')
	return 8 ;
else if (num[0][i+1] == '_' && num[1][i] == '|' && num[1][i+1] == '_' && num[1][i+2] == '|' && num[2][i] == ' ' && num[2][i+1] == '_' && num[2][i+2] == '|')
	return 9 ;
else return 0 ;
}

int main ()
{
int n,m,i,j ;
unsigned long num1=0,num2=0,k ;
scanf ("%d %d",&n,&m) ;
scanf ("%c") ;
for (i=0;i<3;i++) gets(num[i]) ;
k = 1 ;
for (i=1;i<n;i++) k=k*10 ;
for (i=0;i<n;i++)
	{
	num1 = (analysis(i)*k)+num1 ;
	k=k/10 ;
	}
for (i=0;i<3;i++) gets(num[i]) ;
k = 1 ;
for (i=1;i<m;i++) k=k*10 ;
for (i=0;i<m;i++)
	{
	num2 = (analysis(i)*k)+num2 ;
	k=k/10 ;
	}
printf ("%ld",num1+num2) ;
return 0 ;
}