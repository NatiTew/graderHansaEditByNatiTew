/*
TASK: WORD
LANG: C
AUTHOR: Thananon Patinyasakdikul
CENTER: SUT
*/

#include<stdio.h>
#include<string.h>
#include<ctype.h>

int check;
void think(int,int);
int mark[26][26];
char str[101][26];
char str1[101][26];
int lvl,i,n,j,k,m,num,l;
int pos,pos1;
void show();

void main(){
  scanf("%d %d",&m,&n);
   for(j= 0;j<m;j++){
  scanf("%s",&str[j]);
  }
    for(j= 0;j<m;j++){
      for(i=0;i<n;i++)
       str[j][i] = toupper(str[j][i]);
      }

  scanf("\n");
  scanf("%d",&num);
  for(i=0;i<num;i++) scanf("%s",&str1[i]);

  for(j= 0;j<num;j++){
      for(i=0;i<25;i++)
       str1[j][i] = toupper(str1[j][i]);
      }

for(l=0;l<num;l++)
 for(j= 0;j<m;j++)
  for(i=0;i<n;i++){
     if(str[j][i] == str1[pos][pos1]){
       check = 0;
       pos1 = 0;
       think(j,i);
     }

  }

}



void think(int x,int y){

  if(mark[x][y] == 0 && pos1< strlen(str1[pos]) && check == 0){

	if(pos1 == strlen(str1[pos])-1) {
	pos++;
	pos1 = 0;
	show();

	}
     if(str1[pos][pos1] == str[x][y] ){
	mark[x][y] = 1;

	pos1++;
	think(x+1,y);
	think(x-1,y);
	think(x+1,y+1);
	think(x-1,y+1);
	think(x,y+1);
	think(x,y-1);
	think(x+1,y-1);
	think(x-1,y-1);
	mark[x][y] = 0;

     }

  }

}


void show(){

  printf("%d %d\n",j,i);
  check = 1;
}