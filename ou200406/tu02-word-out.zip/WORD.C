/*
TASK: WORD
LANG: C
AUTHOR: Sarun Gulyanon
CENTER: tu02
*/

#include<stdio.h>

char arr[30][30];
char word[101][20];
int length[101];
int n,m,k;

int check(int w,int row,int col)
{
	int j;
	if(length[w] + row <= n)
	{
		for(j=1;word[w][j] != '\0' && word[w][j] == arr[row+j][col];j++);
		if(word[w][j] == '\0')
		{
			return 1;
		}

		if(length[w] + col <= m )
		{
			for(j=1;word[w][j] != '\0' && word[w][j] == arr[row+j][col+j];j++);
			if(word[w][j] == '\0')
			{
				return 1;
			}
		}
		if(col - length[w] >= 0)
		{
			for(j=1;word[w][j] != '\0' && word[w][j] == arr[row+j][col-j];j++);
			if(word[w][j] == '\0')
			{
				return 1;
			}
		}
	}
	if(row - length[w]>= 0)
	{
		for(j=1;word[w][j] != '\0' && word[w][j] == arr[row-j][col];j++);
		if(word[w][j] == '\0')
		{
			return 1;
		}
		if(length[w] + col <= m )
		{
			for(j=1;word[w][j] != '\0' && word[w][j] == arr[row-j][col+j];j++);
			if(word[w][j] == '\0')
			{
				return 1;
			}
		}
		if(col - length[w] >= 0)
		{
			for(j=1;word[w][j] != '\0' && word[w][j] == arr[row-j][col-j];j++);
			if(word[w][j] == '\0')
			{
				return 1;
			}
		}
	}
	if(length[w] + col <= m )
	{
		for(j=1;word[w][j] != '\0' && word[w][j] == arr[row][col+j];j++);
		if(word[w][j] == '\0')
		{
			return 1;
		}
	}
	if(col - length[w]>= 0)
	{
		for(j=1;word[w][j] != '\0' && word[w][j] == arr[row][col-j];j++);
		if(word[w][j] == '\0')
		{
			return 1;
		}
	}
	return 0;
}

main()
{
	int i,j,w;

	scanf("%d",&n);
	scanf("%d",&m);
	for(i=0;i<n;i++)
	{
		scanf("%s",&arr[i]);
	}
	scanf("%d",&k);
	for(i=0;i<k;i++)
	{
		scanf("%s",&word[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			if(arr[i][j] >= 'A' && arr[i][j] <= 'Z')
			{
				arr[i][j] = arr[i][j] - 'A' + 'a';
			}
		}
	}
	for(i=0;i<k;i++)
	{
		for(j=0;word[i][j] != '\0' ; j++)
		{
			if(word[i][j] >= 'A' && word[i][j] <= 'Z')
			{
				word[i][j] = word[i][j] -'A' +'a';
			}
		}
		length[i] = j;
	}
	for(w=0;w<k;w++)
	{
		for(i=0;i<n;i++)
		{
			for(j=0;j<m;j++)
			{
				if(word[w][0] == arr[i][j])
				{
					if(check(w,i,j))
					{
						printf("%d %d\n",i,j);
						i=n;
						j=m;
					}
				}
			}
		}
	}
	return 0;
}