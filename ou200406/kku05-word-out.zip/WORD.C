/*
TASK: WORD
LANG: C
AUTHOR: Aaniwat Kusantear
CENTER: Khonkaen05
*/
#include<stdio.h>
#include<string.h>
char table[25][25];
char word[100][16];
int row,col,Pr[100],Pc[100];
void tablelower(int m,int n)
{
	int i,j;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			if(table[i][j]>='A'&&table[i][j]<='Z')
				table[i][j]+=32;
		}
	}

}
void wordlower(int k,int text)
{
	int i;
	for(i=0;i<k;i++){
		if(word[text][i]>='A'&&word[text][i]<='Z')
			word[text][i]+=32;
	}
}
void find(int k)
{
	int t=0,round=0,tMAX,i,j,check;
	tMAX=strlen(word[k]);
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			if(word[k][t]==table[i][j]){
				check=0;
				while(check<7*tMAX){
					round++;
					if(t==tMAX-1){
						Pr[k]=i;
						Pc[k]=j;
					}
				if(word[k][t+round]==table[i][j+round]){check++;t++;}
				else if(word[k][t+round]==table[i+round][j]&&check<tMAX){check++;t++;}
				else if(word[k][t+round]==table[i+round][j+round]&&check<tMAX*2){check++;t++;}
				else if(word[k][t+round]==table[i+round][j-round]&&check<tMAX*3){check++;t++;}
				else if(word[k][t+round]==table[i][j-round]&&check<tMAX*4){check++;t++;}
				else if(word[k][t+round]==table[i-round][j]&&check<tMAX*5){check++;t++;}
				else if(word[k][t+round]==table[i-round][j+round]&&check<tMAX*6){check++;t++;}
				else if(word[k][t+round]==table[i-round][j-round]&&check<tMAX*7){check++;t++;}
				else {check++;}
				}
			}
		}
	}
}
int main(void)
{
	int k,n;
	int i;
	scanf("%d %d",&row,&col);
	for(i=0;i<row;i++){
		scanf("%s",table[i]);
	}
	scanf("%d",&k);
	for(i=0;i<k;i++){
		scanf("%s",word[i]);
		n=strlen(word[i]);
		wordlower(n,i);
	}
	tablelower(row,col);
	for(i=0;i<k;i++){
		find(i);
		printf("%d %d\n",Pr[i],Pc[i]);
	}
	return 0;
}