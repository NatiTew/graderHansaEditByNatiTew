/*
TASK: SEGMENT
LANG: C
AUTHOR: Napat Hataivichian
CENTER: buu05
*/

#include <stdio.h>
#include <stdlib.h>

int main (void)
{
 int i,n=0,num[1],j;
 long ans[1];
 char get[3][60],sum[1][20],z;
  scanf("%d",&num[0]);
  scanf("%d",&num[1]);
 for(j=0;j<2;j++)
 {
  n = 0;
  if(j == 0)
	 scanf("%c",&z);
  gets(get[0]);
  gets(get[1]);
  gets(get[2]);
  for(i=0;i<=(num[j]*3)+num[j]-1;i+=4)
	{
	 if((get[1][i+2] == '|') && (get[2][i+2] == '|') && (get[0][i+1] != '_') && (get[1][i] != '|'))
	  {
		sum[j][n] = '1';
		n++;
	  }
	  if((get[0][i+1] == '_') && (get[1][i+1] == '_') && (get[1][i+2] == '|') && (get[2][i] == '|') && (get[2][i+1] == '_') && (get[2][i+2] != '|'))
			 {
			  sum[j][n] = '2';
			  n++;
			 }
			 if((get[0][i+1] == '_') && (get[1][i+1] == '_') && (get[1][i+2] == '|') && (get[2][i+2] == '|') && (get[2][i+1] == '_') && (get[1][i] != '|'))
					{
					 sum[j][n] = '3';
					 n++;
					}
					if((get[1][i] == '|') && (get[1][i+1] == '_') && (get[1][i+2] == '|') && (get[2][i+2] == '|') && (get[0][i+1] != '_'))
						  {
							sum[j][n] = '4';
							n++;
						  }
						  if((get[0][i+1] == '_') && (get[1][i] == '|') && (get[1][i+1] == '_') && (get[2][i+1] == '_') && (get[2][i+2] == '|') && (get[2][i] != '|'))
								 {
								  sum[j][n] = '5';
								  n++;
								 }
								 if( (get[0][i+1] == '_') && (get[1][i] == '|') && (get[1][i+1] == '_') && (get[2][i] == '|') && (get[2][i+1] == '_') && (get[2][i+2] == '|') && (get[1][i+2] != '|'))
										{
										 sum[j][n] = '6';
										 n++;
										}
										if((get[0][i+1] == '_') && (get[1][i+2] == '|') && (get[2][i+2] == '|') && (get[1][i+1] != '_'))
											  {
												sum[j][n] = '7';
												n++;
											  }
											  if((get[0][i+1] == '_') && (get[1][i] == '|') && (get[1][i+1] == '_') && (get[1][i+2] == '|') && (get[2][i] == '|') && (get[2][i+1] == '_') && (get[2][i+2] == '|'))
													 {
													  sum[j][n] = '8';
													  n++;
													 }
													 if((get[0][i+1] == '_') && (get[1][i] == '|') && (get[1][i+1] == '_') && (get[1][i+2] == '|') && (get[2][i+1] == '_') && (get[2][i+2] == '|') && (get[2][i] != '|'))
															{
															 sum[j][n] = '9';
															 n++;
															}
															if((get[0][i+1] == '_') && (get[1][i] == '|') && (get[1][i+2] == '|') && (get[2][i] == '|') && (get[2][i+1] == '_') && (get[2][i+2] == '|') && (get[1][i+1] != '_'))
																 {
																  sum[j][n] = '0';
																  n++;
																 }
	}
 }
  ans[0] = atol(sum[0]);
  ans[1] = atol(sum[1]);
  printf("%ld",ans[0]+ans[1]);
 return 0;
}
