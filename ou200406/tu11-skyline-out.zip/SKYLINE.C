/*
TASK: SKYLINE
LANG: C
AUTHOR: SARAN LERTPRADIT
CENTER: TU
*/
#include<stdio.h>
struct building
{
	int l;
	int h;
	int r;
}line[3000];
int partition(int i,int j)
{
	int key=line[i].l,h=i+1,k=j,tmp;
	while(1)
	{
		for(h=h;h<j;h++)
		{
			if(line[h].l>key)break;
		}
		for(k=k;k>i;k--)
		{
			if(line[k].l<key)break;
		}
		if(h>=k)break;
		tmp=line[k].l;
		line[k].l=line[h].l;
		line[h].l=tmp;
		tmp=line[k].h;
		line[k].h=line[h].h;
		line[h].h=tmp;
		tmp=line[k].r;
		line[k].r=line[h].r;
		line[h].r=tmp;
	}
	h=i;
		tmp=line[k].l;
		line[k].l=line[h].l;
		line[h].l=tmp;
		tmp=line[k].h;
		line[k].h=line[h].h;
		line[h].h=tmp;
		tmp=line[k].r;
		line[k].r=line[h].r;
		line[h].r=tmp;
	return k;
}
void quick(int i,int j)
{
	int m;
	if(i>=j)return;
	m=partition(i,j);
	quick(i,m-1);
	quick(m+1,j);
	return;
}

main()
{
	int n,i,j,height[256],a;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&line[i].l);
		scanf("%d",&line[i].h);
		scanf("%d",&line[i].r);
	}
	quick(0,n-1);
	for(i=0;i<256;i++)
	{
		height[i]=0;
	}
	for(i=0;i<n;i++)
	{
		for(j=line[i].l;j<=line[i].r;j++)
		{
			if(height[j]<line[i].h)height[j]=line[i].h;
		}
	}
	a=0;
	for(i=0;i<256;i++)
	{
		if(a!=height[i])
		{
			if(a<height[i])printf("%d ",i);
			else printf("%d ",i-1);
			printf("%d ",height[i]);
			a=height[i];
		}
	}





	return 0;
}