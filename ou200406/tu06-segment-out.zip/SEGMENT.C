/*
TASK: SEGMENT
LANG: C
AUTHOR: CHANTAT EKSOMBATCHAI
CENTER: TU06
*/
#include<stdio.h>
#include<math.h>
char tmp[4][100];
unsigned long a=0,b=0;
int convert(int spos)
{
	if((tmp[0][spos+1] == ' ')&&(tmp[1][spos+1] == ' '))
		return 1;
	if((tmp[0][spos+1] == '_')&&(tmp[1][spos] == '|')&&(tmp[1][spos+1] == '_')&&(tmp[1][spos+2] == '|')&&(tmp[2][spos] == '|')&&(tmp[2][spos+1] == '_')&&(tmp[2][spos+2] == '|'))
		return 8;
	if((tmp[0][spos+1] == '_')&&(tmp[1][spos] == '|')&&(tmp[1][spos+2] == '|')&&(tmp[2][spos] == '|')&&(tmp[2][spos+1] == '_')&&(tmp[2][spos+2] == '|'))
		return 0;
	if((tmp[0][spos+1] == '_')&&(tmp[1][spos] == '|')&&(tmp[1][spos+1] == '_')&&(tmp[1][spos+2] == '|')&&(tmp[2][spos+1] == '_')&&(tmp[2][spos+2] == '|'))
		return 9;
	if((tmp[0][spos+1] == '_')&&(tmp[1][spos] == '|')&&(tmp[1][spos+1] == '_')&&(tmp[2][spos] == '|')&&(tmp[2][spos+1] == '_')&&(tmp[2][spos+2] == '|'))
		return 6;
	if((tmp[0][spos+1] == '_')&&(tmp[1][spos+1] == '_')&&(tmp[1][spos+2] == '|')&&(tmp[2][spos+1] == '_')&&(tmp[2][spos+2] == '|'))
		return 3;
	if((tmp[0][spos+1] == '_')&&(tmp[1][spos+1] == '_')&&(tmp[1][spos+2] == '|')&&(tmp[2][spos] == '|')&&(tmp[2][spos+1] == '_'))
		return 2;
	if((tmp[0][spos+1] == '_')&&(tmp[1][spos] == '|')&&(tmp[1][spos+1] == '_')&&(tmp[2][spos+1] == '_')&&(tmp[2][spos+2] == '|'))
		return 5;
	if((tmp[1][spos] == '|')&&(tmp[1][spos+1] == '_')&&(tmp[1][spos+2] == '|')&&(tmp[2][spos+2] == '|'))
		return 4;
	return 7;
}
main()
{
	int lena,lenb,i,j;
	scanf("%d %d",&lena,&lenb);
	for(i=0;i<3;i++)
	{
		for(j=0;j<lena*4-1;j++)
		{
			scanf("%c",&tmp[i][j]);
			while((tmp[i][j]!='|')&&(tmp[i][j]!='_')&&(tmp[i][j]!=' '))
				scanf("%c",&tmp[i][j]);
		}
	}
	for(i=0;i<lena;i++)
		a = a+ convert(i*4)*pow(10,lena-i-1);
	for(i=0;i<3;i++)
	{
		for(j=0;j<lenb*4-1;j++)
		{
			scanf("%c",&tmp[i][j]);
			while((tmp[i][j]!='|')&&(tmp[i][j]!='_')&&(tmp[i][j]!=' '))
				scanf("%c",&tmp[i][j]);
		}
	}
	for(i=0;i<lenb;i++)
		b = b+ convert(i*4)*pow(10,lenb-i-1);
	printf("%lu\n",a+b);
	return 0;
}
