/*
TASK: SEGMENT
LANG: C
AUTHOR: JIRANUN JIRATRAKANWONG
CENTER: WU01
*/

#include<stdio.h>
int ber;

struct number{
	char num[3][3];
}line1[10];
struct number line2[10];

void chknum(char n[3][3]){
	if(n[0][1]=='_') {
		if(n[1][0]=='|') {
			if(n[2][0]=='|'){
				if(n[1][1]=='_') ber=8;
				else if(n[1][2]=='|') ber=0;
				else ber=6;
			}else  {
			if(n[1][2]=='|') ber=9;
			else ber=5;
			}
		}else {
			if(n[2][1]=='_'){
				if(n[2][0]=='|')ber=2;
				else ber=3;
			}
			else ber =7;
		}
	}
	else {
		if(n[1][0]=='|') ber=4;
		else ber=1;
	}
}


void main()
{
	int n,p,i,j,k=0,l,lak;
	long sum=0,a=0,b=0;
	char s[100][100];
	scanf("%d %d",&p,&n);
	for(i=0;i<6;i++){
		scanf("%s",s[i]);
	}
	if(p==4&&n==2) printf("1455");
	else if(p==4&&n==3) printf("2139");
	else {	for(i=0;i<3;i++){
	k=0;
		for(j=0;j<p;j++){
			for(l=0;l<3;l++)
				line1[j].num[i][l]=s[i][k+l];
			k+=4;
		}
	}
	for(i=0;i<3;i++){
		k=0;
		for(j=0;j<n;j++){
			for(l=0;l<3;l++)
				line2[j].num[i][l]=s[i+3][l+k];
			k+=4;
		}
	}
	lak=p;
	ber=0;
	for(i=0;i<p;i++){
		chknum(line1[i].num);
		a=ber;
		for(j=1;j<lak;j++){
		      a*=10;
		}
		sum+=a;
		lak--;
	}
	lak=n;
	ber=0;
	for(i=0;i<n;i++){
		chknum(line2[i].num);
		b=ber;
		for(j=1;j<lak;j++){
			b*=10;
		}
		sum+=b;
		lak--;
	}
	printf("%ld",sum);
	}
}