/*
TASK: WORD
LANG: C
AUTHOR: Saranyu Koothanapath
CENTER: tu04
*/
#include<stdio.h>
#include<string.h>
#define MAX 70
int row,col;
int n;
int len;
int count;
char map[MAX][MAX];
char in[MAX];
// up down left right downleft upleft downright upright
int way[8][2]={{-1,0},{1,0},{0,-1},{0,1},{1,-1},{-1,-1},{1,1},{-1,1}};
int check(int sr,int sc)
{
	int i,j;
	int rr,cc;
	for(i=0;i<8;++i)
	{
		count=0;
		for(rr=sr,cc=sc,j=0;j<len;++j)
		{
			if(map[rr][cc]==in[j])++count;
			else break;
			rr+=way[i][0];
			cc+=way[i][1];
		}
		if(count==len)return 1;
	}
	return 0;
}
int main()
{
	int i,j,k;

//	freopen("word.in","rt",stdin);
	scanf("%d %d\n",&row,&col);
	for(i=0;i<row;++i)
	{
			scanf("%s",&map[i]);
	}
	for(i=0;i<row;++i)
	for(j=0;j<col;++j)
	if(map[i][j]>='A' && map[i][j]<='Z')map[i][j]+='a'-'A';
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{

		scanf("%s",&in);
		len=strlen(in);
		for(j=0;j<len;++j)
			if(in[j]>='A' && in[j]<='Z')in[j]+='a'-'A';
		for(j=0;j<row;++j)
		{
			for(k=0;k<col;++k)
			{
				if(map[j][k]==in[0])
				if(check(j,k))
				{
					printf("%d %d\n",j,k);
				}
			}
		}

	}
	return 0;
}
