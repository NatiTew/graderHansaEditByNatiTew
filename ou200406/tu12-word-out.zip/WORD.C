/*
TASK: WORD
LANG: C
AUTHOR: Kraipitch Tassanasaengsoon
CENTER: TU12
*/

# include <stdio.h>
# include <string.h>
# include <math.h>

# define Max 50

int Search(int,int,int);

int m,n,k;
char input[Max][Max],word[Max];

void main()
{
	int c,c2,c3,check=0;
	scanf("%d %d",&m,&n);
	for( c = 0 ; c < m ; ++c ) scanf("%s",input[c]);
	scanf("%d",&k);
	for( c = 1 ; c <= k ; ++c )
	{
		scanf("%s",word);
		for( c2=0 ; c2 < m ; ++c2 )
		{
			for( c3=0 ; c3 < n ; ++c3 )
				if( input[c2][c3] == word[0] || abs(input[c2][c3] - word[0]) == 32 )
					if( Search(c2,c3,strlen(word)) == 1 ) { check=1; break; }
			if( check )
			{
				check=0;
				printf("%d %d\n",c2,c3);
				break;
			}
		}
	}
}

int Search(int x,int y,int length)
{
	int c,c2,c3;
	for( c=1 , c2=x-1 , c3=y ; c < length ; ++c , c2-- )
		if( input[c2][c3] != word[c] && abs(input[c2][c3] - word[c]) != 32 )
			break;
	if( c == length ) return 1;

	for( c=1 , c2=x-1 , c3=y+1 ; c < length ; ++c , c2-- , ++c3 )
		if( input[c2][c3] != word[c] && abs(input[c2][c3] - word[c]) != 32 )
			break;
	if( c == length ) return 1;

	for( c=1 , c2=x , c3=y+1 ; c < length ; ++c , ++c3 )
		if( input[c2][c3] != word[c] && abs(input[c2][c3] - word[c]) != 32 )
			break;
	if( c == length ) return 1;

	for( c=1 , c2=x+1 , c3=y+1 ; c < length ; ++c , ++c2 , ++c3 )
		if( input[c2][c3] != word[c] && abs(input[c2][c3] - word[c]) != 32 )
			break;
	if( c == length ) return 1;

	for( c=1 , c2=x+1 , c3=y ; c < length ; ++c , ++c2 )
		if( input[c2][c3] != word[c] && abs(input[c2][c3] - word[c]) != 32 )
			break;
	if( c == length ) return 1;

	for( c=1 , c2=x-1 , c3=y+1 ; c < length ; ++c , --c2 , ++c3 )
		if( input[c2][c3] != word[c] && abs(input[c2][c3] - word[c]) != 32 )
			break;
	if( c == length ) return 1;

	for( c=1 , c2=x , c3=y-1 ; c < length ; ++c , --c3 )
		if( input[c2][c3] != word[c] && abs(input[c2][c3] - word[c]) != 32 )
			break;
	if( c == length ) return 1;

	for( c=1 , c2=x-1 , c3=y-1 ; c < length ; ++c , --c2 , --c3 )
		if( input[c2][c3] != word[c] && abs(input[c2][c3] - word[c]) != 32 )
			break;
	if( c == length ) return 1;

	return 0;
}