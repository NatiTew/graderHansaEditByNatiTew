/*
TASK: WORD
LANG: C
AUTHOR: SUTUTTA SEANGTHONG
CENTER: SU
*/

#include <stdio.h>
#include <string.h>
#define MAX 25

char puzz[MAX][MAX];
char word_find[100][15];

int F_line(char*);
int F_updown(char*);
int Tayang_down(char*);
int Tayang_up(char*);


int m,n;

int main()
{  int i,fw;
	scanf("%d %d",&m,&n);
	for (i=0;i<m;i++)
		scanf("%s",puzz[i]);

	scanf("%d",&fw);
	for (i=0;i<fw;i++)
		scanf("%s",word_find[i]);

	for (i=0;i<fw;i++)
		if(F_line(word_find[i])==0)
		{  if(F_updown(word_find[i])==0)
		   {}
		}

   return 0;
}

int F_line(char *str)
{  int i,j,k,len,tmp,index;
	len=strlen(str);
	for (i=0;i<m;i++)
	{	j=0;
		k=0;
		for (j=0;j<=n-len+1||j<=len-1;j++)
		{       tmp=0;
			if (puzz[i][j]==str[k]||puzz[i][j]+32==str[k]||puzz[i][j]-32==str[k])
			{	tmp=1; index=j;
				break;
			}
		}
		if (tmp==1)
		{       /* left to right */
		    if (j<=n-len+1)
		    {   j++;k++;
			while (j<=n-len+1&&k<len)
			{	if (puzz[i][j]!=str[k]&&puzz[i][j]+32!=str[k]&&puzz[i][j]-32!=str[k])
				{	k=0; j=index;
					tmp=0; break;
				}
				j++; k++;
			}
		     }
			/* right to left */
		     if (tmp==0||j<=len-1)
		     {  j--; k++;
			while (k<len)
			{	if (puzz[i][j]!=str[k]&&puzz[i][j]+32!=str[k]&&puzz[i][j]-32!=str[k])
				{	k=0; tmp=0;
					break;
				}
				j--; k++;
			}
		     }
			if (tmp==1)
			{	printf("%d %d\n",i,index);
				return 1;
			}
		}
	}
	return 0;
}

int F_updown(char *str)
{  int i,j,k,len,tmp,index;
	len=strlen(str);
	for (j=0;j<n;j++)
	{	j=0;
		k=0;
		for (i=0;i<=m-len+1||i<=len-1;i++)
		{       tmp=0;
			if (puzz[i][j]==str[k]||puzz[i][j]+32==str[k]||puzz[i][j]-32==str[k])
			{	tmp=1; index=i;
				break;
			}
		}

		if (tmp==1)
		{       /* left to right */
		    if (i<=m-len+1)
		    {   i++;k++;
			while (i<=n-len+1&&k<len)
			{	if (puzz[i][j]!=str[k]&&puzz[i][j]+32!=str[k]&&puzz[i][j]-32!=str[k])
				{	k=0; i=index;
					tmp=0; break;
				}
				i++; k++;
			}
		     }
			/* right to left */
		     if (tmp==0||i<=len-1)
		     {  i--;k++;
			while (k<len)
			{	if (puzz[i][j]!=str[k])
				{	k=0;
					tmp=0;
					break;
				}
				i--;
				k++;
			}
		     }
			if (tmp==1)
			{	printf("%d %d\n",index,j);
				return 1;
			}
		}
	}
	return 0;
}

