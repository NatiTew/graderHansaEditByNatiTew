/*
TASK: SEGMENT
LANG: C
AUTHOR: Nopphorn Pitaksuebpon
CENTER: buu06
*/
#include <stdio.h>
#include <math.h>

int main(void)
{
   long i,k,j,a=0,b=0,ga,gb;
   char cha[10][9],chb[10][9],line[41];
   scanf("%ld %ld",&ga,&gb);
   getchar();
   for(i=0;i<3;i++)
   {
      j=0;
      do{
	 line[j]=getchar();
	 if((line[j]=='\0')||(line[j]=='\n'))
	    break;
	 else
	    j++;
      }while(1);
      k=0;
      for(j=0;j<ga;j++)
      {
	 cha[j][(i*3)+0]=line[k];
	 cha[j][(i*3)+1]=line[k+1];
	 cha[j][(i*3)+2]=line[k+2];
	 k=k+4;
      }
   }
   for(i=0;i<3;i++)
   {
      j=0;
      do{
	 scanf("%c",line[j]);
	 if((line[j]=='\0')||(line[j]=='\n'))
	    break;
	 else
	    j++;
      }while(1);
      k=0;
      for(j=0;j<gb;j++)
      {
	 chb[j][(i*3)+0]=line[k];
	 chb[j][(i*3)+1]=line[k+1];
	 chb[j][(i*3)+2]=line[k+2];
	 k=k+4;
      }
   }
   for(i=ga-1;i>=0;i--)
   {
      if(cha[i][1]=='_')
      {
	 if((cha[i][3]=='|')&&(cha[i][5]=='|'))
	 {
	    if(cha[i][6]=='|')
	       a=a+(8*pow(10,ga-i));
	    else
	       a=a+(9*pow(10,ga-i));

	 }
	 else if((cha[i][3]=='|')&&(cha[i][5]!='|'))
	 {
	    if(cha[i][6]=='|')
	       a=a+(6*pow(10,ga-i));
	    else
	       a=a+(5*pow(10,ga-i));
	 }
	 if((cha[i][3]!='|')&&(cha[i][5]=='|'))
	 {
	    if(cha[i][0]=='_')
	    {
	       if(cha[i][6]=='|')
		  a=a+(2*pow(10,ga-i));
	       else
		  a=a+(3*pow(10,ga-i));
	    }
	    else
	       a=a+(7*pow(10,ga-i));
	 }
      }
      else
      {
	 if(cha[i][3]=='|')
	    a=a+(4*pow(10,ga-i));
	 else
	    a=a+(1*pow(10,ga-i));
      }
   }
   for(i=gb-1;i>=0;i--)
   {
      if(chb[i][1]=='_')
      {
	 if((chb[i][3]=='|')&&(chb[i][5]=='|'))
	 {
	    if(chb[i][6]=='|')
	       b=b+(8*pow(10,gb-i));
	    else
	       b=b+(9*pow(10,gb-i));

	 }
	 else if((chb[i][3]=='|')&&(chb[i][5]!='|'))
	 {
	    if(chb[i][6]=='|')
	       b=b+(6*pow(10,gb-i));
	    else
	       b=b+(5*pow(10,gb-i));
	 }
	 if((chb[i][3]!='|')&&(chb[i][5]=='|'))
	 {
	    if(chb[i][1]=='_')
	    {
	       if(chb[i][6]=='|')
		  b=b+(2*pow(10,gb-i));
	       else
		  b=b+(3*pow(10,gb-i));
	    }
	    else
	       b=b+(7*pow(10,gb-i));
	 }
      }
      else
      {
	 if(chb[i][3]=='|')
	    b=b+(4*pow(10,gb-i));
	 else
	    b=b+(1*pow(10,gb-i));
      }
   }
   printf("%ld",a+b);
   return 0;
}