/*
TASK: DICE
LANG: C
AUTHOR: Napat Hataivichian
CENTER: buu05
*/

#include <stdio.h>
#include <stdlib.h>

int main (void)
{
 int r,i,dice[6] = {1,2,3,5,4,6},n,k=1,tmp[6],j;
 char *mov;
  mov = (char *)malloc(sizeof(char)*10);
  scanf("%d",&r);
  for(i=0;i<r;i++)
	{
	 n = 0;
	 dice[0] = 1;
	 dice[1] = 2;
	 dice[2] = 3;
	 dice[3] = 5;
	 dice[4] = 4;
	 dice[5] = 6;
	 while(1)
	  {
		if(n>(10*k))
		 {
		  k++;
		  mov = (char *)realloc(mov,sizeof(char)*(10*k));
		 }
		scanf("%c",&mov[n]);
		if((mov[n] == '\n') && (n > 0))
		  break;
		switch(mov[n])
		 {
		  case 'F' :
						{
						 for(j=0;j<6;j++)
							tmp[j] = dice[j];
						 dice[0] = tmp[3];
						 dice[1] = tmp[0];
						 dice[3] = tmp[5];
						 dice[5] = tmp[1];
						} break;
		  case 'B' :
						{
						 for(j=0;j<6;j++)
							tmp[j] = dice[j];
						 dice[0] = tmp[1];
						 dice[1] = tmp[5];
						 dice[3] = tmp[0];
						 dice[5] = tmp[3];
						} break;
		  case 'L' :
						{
						 for(j=0;j<6;j++)
							tmp[j] = dice[j];
						 dice[0] = tmp[4];
						 dice[2] = tmp[0];
						 dice[4] = tmp[5];
						 dice[5] = tmp[2];
						} break;
		  case 'R' :
						{
						 for(j=0;j<6;j++)
							tmp[j] = dice[j];
						 dice[0] = tmp[2];
						 dice[2] = tmp[5];
						 dice[4] = tmp[0];
						 dice[5] = tmp[4];
						} break;
		  case 'C' :
						{
						 for(j=0;j<5;j++)
							tmp[j] = dice[j];
						 dice[1] = tmp[4];
						 dice[2] = tmp[1];
						 dice[3] = tmp[2];
						 dice[4] = tmp[3];
						} break;
		  case 'D' :
						{
						 for(j=0;j<5;j++)
							tmp[j] = dice[j];
						 dice[1] = tmp[2];
						 dice[2] = tmp[3];
						 dice[3] = tmp[4];
						 dice[4] = tmp[1];
						} break;
		 }
		n++;
	  }
	  printf("%d ",dice[1]);
	}
 return 0;
}