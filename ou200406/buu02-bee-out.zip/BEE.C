/*
TASK: BEE
LANG: C
AUTHOR: Khakhana Thimachai
CENTER: buu02
*/
#include<stdio.h>

int main(void){
	long int wb=1,sb=0,total;
	long int tmps;
	long int tmpw;
	int i;
	int year;
	scanf("%ld",&year);
	while(year!=-1){
		wb=1;
		sb=0;
		for(i=0;i<year;i++){
			tmps=wb;
			tmpw=wb+sb;
			wb=tmpw+1;
			sb=tmps;
		}
		total = wb+sb;
		printf("%ld %ld\n",wb,total+1);
		scanf("%ld",&year);
	}
	return 0;
}
