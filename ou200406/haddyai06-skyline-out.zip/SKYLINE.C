/*
TASK: SKYLINE
LANG: C
AUTHOR: SARAN SONGYOD
CENTER: HGADDYAI06
*/
#include<stdio.h>

void main()
{ int city[3000];
  int left,right,high,chk=-1,max=0;
  int i,j,n;
  for(i=0;i<3000;i++)
    city[i]=0;
  scanf("%d",&n);
  for(i=0;i<n;i++)
  { scanf("%d %d %d",&left,&high,&right);
    if(right>max)
      max = right;
    for(j=left-1;j<right-1;j++)
      if(city[j]<high)
	  city[j] = high;
  }
  for(i=0;i<=max;i++)
  { if(chk!=city[i])
    { printf("%d %d ",i+1,city[i]);
      chk = city[i];
    }
  }


}