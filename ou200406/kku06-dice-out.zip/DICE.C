/*
TASK: DICE
LANG: C
AUTHOR: KAMONPOP JARUJIT
CENTER: KKU06
*/

#include <stdio.h>
int main(){
	char c[1000];
	int n,i,ans,x;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%s",c);ans=2;x=0;
		while(c[x]!='\0'){
			if(ans==1){
				if(c[x]=='F'){ans=5;}
				else if(c[x]=='B'){ans=2;}
				else if(c[x]=='L'){ans=4;}
				else if(c[x]=='R'){ans=3;}
			}else if(ans==2){
				if(c[x]=='F'){ans=1;}
				else if(c[x]=='B'){ans=6;}
				else if(c[x]=='C'){ans=4;}
				else if(c[x]=='D'){ans=3;}
			}else if(ans==3){
				if(c[x]=='L'){ans=1;}
				else if(c[x]=='R'){ans=6;}
				else if(c[x]=='C'){ans=2;}
				else if(c[x]=='D'){ans=5;}
			}else if(ans==5){
				if(c[x]=='F'){ans=6;}
				else if(c[x]=='B'){ans=1;}
				else if(c[x]=='C'){ans=3;}
				else if(c[x]=='D'){ans=4;}
			}else if(ans==4){
				if(c[x]=='L'){ans=6;}
				else if(c[x]=='R'){ans=1;}
				else if(c[x]=='C'){ans=5;}
				else if(c[x]=='D'){ans=2;}
			}else if(ans==6){
				if(c[x]=='F'){ans=2;}
				else if(c[x]=='B'){ans=5;}
				else if(c[x]=='L'){ans=3;}
				else if(c[x]=='R'){ans=4;}
			}x++;
		}printf("%d ",ans);
	}return 0;
}