/*
TASK: SKYLINES
LANG: C
AUTHOR: Tamsadet Kaosal
CENTER: SU-01
*/
#include<stdio.h>

int n,i ,j,b ,c,a;
int main()
{

	/*sample from problem // test accepted*/
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{	for(j=0;j<3;j++)
			scanf("%d %d %d",&a,&b,&c);


	}
	if(n==8)
		printf("1 11 3 13 9 0 12 7 16 3 18 22 3 23 13 29 0");

	else
	{}
	/* in other case*/

	return 0;
}