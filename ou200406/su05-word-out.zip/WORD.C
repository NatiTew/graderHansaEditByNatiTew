/*
TASK:WORD
LANG:c
AUTHOR:SUTTIKORN POTHONGKOM
CENTER:SU05
*/
#include<stdio.h>
int m,n,w,x,y;
char cha[25][25],cmp[25];
int ans[2];
int chk_h()
{
	int i,j,k=0,found=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			k=j;
			if(cmp[k-j]==cha[i][j])
			{
				while(cmp[k-j]==cha[i][k])k++;
				if(cmp[k-j+1]=='\0')
				{
					found=1;
					x=i+1;
					y=j+1;
					break;
				}
			}
			j=k;
		}
		if(found)	break;
	}
	return found;
}
int chk_v()
{
	int i,j,k=0,found=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			k=j;
			if(cmp[k-j]==cha[j][i])
			{
				while(cmp[k-j]==cha[i][k])k++;
				if(cmp[k-j+1]=='\0')
				{
					found=1;
					x=i+1;
					y=j+1;
					break;
				}
			}
			j=k;
		}
		if(found)	break;
	}
	return found;
}

int main()
{
	int i,j,found;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
			scanf("%c",&cha[i][j]);
	scanf("%d",&w);
	for(i=0;i<w;i++)
	{
		j=0;
		scanf("%s",cmp[i]);
		if(chk_h==1)
		{
			ans[i]=x;    j=i++;
			ans[j]=y;
		}
		else (chk_v==1)
		{      ans[i]=x;   j=i++;
			ans[j]=y;
		}
	}
	for(i=0;i<w;i++)
	{       j=i++;
		printf("%d %d",ans[i],ans[j]);
	}
	return 0;

}
}
/*----------I'm Sorry,today I'm very stupid-------------*/