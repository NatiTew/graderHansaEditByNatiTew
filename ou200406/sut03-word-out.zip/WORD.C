/*
TASK: WORD
LANG: C
AUTHOR: Nunwarin Chantarutai
CENTER: SUT03
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>

char table[26][26],str[100][16];
int x,y,a,b,j,i,count,len[100];

int think(int,int);
int think2(int,int);
int think3(int,int);
int think4(int,int);
int think5(int,int);
int think6(int,int);


int main()
{
  int n;
  scanf("%d%d",&y,&x);
  for(i=0;i<y;i++)
    for(j=0;j<x;j++)
    {
     scanf(" %c",&table[i][j]);
     table[i][j]=toupper(table[i][j]);
    }
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
   scanf("%s",str[i]);
   strupr(str[i]);
   len[i] = strlen(str[i]);
  }
  for(i=0;i<n;i++)
  {
   for(a=0;a<y;a++)
    for(j=0;j<x;j++)
    {
     if(count==len[i]&&i<n-1) i++;
     else if(count==len[i]&&i>=n) break;
      count = 0;
      think(a,j);
     if(count!=len[i])
      {count=0;think2(a,j);}
     if(count!=len[i])
      {count=0;think3(a,j);}
     if(count!=len[i])
      {count=0;think4(a,j);}
     if(count!=len[i])
      {count=0;think5(a,j);}
     if(count!=len[i])
      {count=0;think6(a,j);}
    }
  }
  return 0;
}

int think(int yy,int xx)
{
   if(count<len[i]&&xx<x&&yy<y)
   {
      if(str[i][count] == table[yy][xx])
	 count++;
      else
      return 0;
      if(count==len[i])  printf("%d %d\n",yy,xx-2);
      else
      think(yy,xx+1);
   }
   return 0;
}

int think2(int yy,int xx)
{
   if(count<len[i]&&xx<x&&yy<y)
   {
      if(str[i][count] == table[yy][xx])
	 count++;
      else
      return 0;
      if(count==len[i])  printf("%d %d\n",yy-1,xx);
      else
      think2(yy+1,xx);
}
  return 0;
}

int think3(int yy,int xx)
{
   if(count<len[i]&&xx<x&&yy<y)
   {
      if(str[i][count] == table[yy][xx])
	 count++;
      else
	return 0;
      if(count==len[i])  printf("%d %d\n",yy-1,xx-1);
      else
      think3(yy+1,xx+1);
}
  return 0;
}
int think4(int yy,int xx)
{
   if(count<len[i]&&xx<x&&yy<y&&xx>=0&&yy>=0)
   {
      if(str[i][count] == table[yy][xx]&&count<len[i])
	 count++;
      if(count==len[i])  printf("%d %d\n",yy+1,xx);

      else
      think4(yy-1,xx);
   }
   return 0;
}

int think5(int yy,int xx)
{
   if(count<len[i]&&xx<x&&yy<y&&xx>=0&&yy>=0)
   {
      if(str[i][count] == table[yy][xx]&&count<len[i])
	 count++;
      if(count==len[i]) { printf("%d %d\n",yy,xx+1);   return 0;}
      else
      think5(yy,xx-1);
   }
   return 0;
}

int think6(int yy,int xx)
{
   if(count<len[i]&&xx<x&&yy<y&&xx>=0&&yy>=0)
   {
      if(str[i][count] == table[yy][xx]&&count<len[i])
	 count++;
      if(count==len[i])  {printf("%d %d\n",yy+1,xx+1);return 0;}
      else
      think6(yy-1,xx-1);
   }
   return 0;
}