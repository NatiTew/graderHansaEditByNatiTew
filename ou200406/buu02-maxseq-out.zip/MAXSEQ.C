/*
TASK: MAXSEQ
LANG: C
AUTHER: Khakhana Thimachai
CENTER: buu02
*/

#include<stdio.h>
#include<stdlib.h>

int main(void){
	int *in;
	int *out;
	int n;
	int max=0;
	int tmp;
	int i,j,k,size=0;
	scanf("%d",&n);
	in = (int *)malloc(sizeof(int)*n);
	out = (int *)malloc(sizeof(int)*n);
	for(i=0;i<n;i++){
		scanf("%d",&in[i]);
	}
	for(i=0;i<=n;i++){
		for(j=0;j<=n-i;j++){
		tmp=0;
			for(k=0;k<i;k++){
				tmp+=in[k+j];
			}
		if(tmp>max){
			size=0;
			for(k=0;k<i;k++,++size){
				out[size]=in[k+j];
			}
			max=tmp;
		}
		}
	}
	if(max>0){
		for(i=0;i<size;i++){
			printf("%d ",out[i]);
		}
		printf("\n%d",max);
	}
	else
		printf("Empty sequence");
	free(out);
	free(in);
	return 0;
}