/*
TASK: BEE
LANG: C
AUTHOR: METHA WANGTHAMMANG
CENTER: PSUPN02
*/
#include<stdio.h>
int bee_mom=1,bee_work=1,bee_sol=0;
int child_work=0,child_sol=0;
void mom();
void work();
void sol();
main()
{
int num[25]={0},count=0,ntemp,i,j,k;
do{
scanf("%d",&ntemp);
if(ntemp!=-1)
	{
	num[count]=ntemp;
	count++;
	}
else
	break;
}while(1);
for(i=0;i<count;i++)
	{
	for(j=0;j<num[i];j++)
		{
		if(bee_mom!=0)
			mom();
		if(bee_work!=0)
			{
			for(k=0;k<bee_work;k++)
				work();
			bee_work=0;
			}
		if(bee_sol!=0)
			{
			for(k=0;k<bee_sol;k++)
				sol();
			bee_sol=0;
			}
		bee_work+=child_work;
		bee_sol+=child_sol;

		child_work=0;
		child_sol=0;
		}//end for j
	printf("%d %d\n",bee_work,bee_mom+bee_work+bee_sol);
	bee_mom=1;
	bee_work=1;
	bee_sol=0;
	}


}
void mom()
{
child_work++;
}
void work()
{
child_work++;
child_sol++;
///////
//bee_work--;
}
void sol()
{
child_work++;
//////////
//bee_sol--;
}
