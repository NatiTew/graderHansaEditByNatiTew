/*
TASK: DICE
LANG: C
AUTHOR: SONGKIET KUNOPAKARNPHAN
CENTER: cmu02
*/

#include<stdio.h>
#include<string.h>

int main()
{
	char ball[6],keep,keep2,order[1000]={NULL};
	int i,n,length,j;
	scanf("%d",&n);
	for(j=0;j<n;j++)
	{
	scanf("%s",&order);
	length=strlen(order);
	ball[0]='1';
	ball[1]='2';
	ball[2]='3';
	ball[3]='5';
	ball[4]='4';
	ball[5]='6';
	for(i=0;i<length;i++)
	{
		if(order[i]=='F')
		{
			keep=ball[0];
			ball[0]=ball[3];
			keep2=ball[1];
			ball[1]=keep;
			ball[3]=ball[5];
			ball[5]=keep2;
		}else if(order[i]=='B')
		{
			keep=ball[0];
			ball[0]=ball[1];
			keep2=ball[3];
			ball[1]=ball[5];
			ball[3]=keep;
			ball[5]=keep2;
		}else if(order[i]=='L')
		{
			keep=ball[0];
			ball[0]=ball[4];
			keep2=ball[2];
			ball[2]=keep;
			ball[4]=ball[5];
			ball[5]=keep2;
		}else if(order[i]=='R')
		{
			keep=ball[0];
			ball[0]=ball[2];
			keep2=ball[4];
			ball[4]=keep;
			ball[2]=ball[5];
			ball[5]=keep2;
		}else if(order[i]=='C')
		{
			keep=ball[1];
			ball[1]=ball[4];
			keep2=ball[2];
			ball[2]=keep;
			ball[4]=ball[3];
			ball[3]=keep2;
		}else if(order[i]=='D')
		{
			keep=ball[1];
			ball[1]=ball[2];
			keep2=ball[4];
			ball[4]=keep;
			ball[2]=ball[3];
			ball[3]=keep2;
		}
	}
	printf("%c ",ball[1]);
	}
	return 0;
}