/*
TASK:SEQMENT
LANG:c
AUTHOR:SUTTIKORN POTHONGKOM
CENTER:SU05
*/
#include<stdio.h>
int main()
{
	long x,y,i,j,n1,n2;
	char num1[3][10],num2[3][10];
	scanf("%d %d",&x,&y);
	for(i=0;i<3;i++)
		for(j=0;j<x*3;j++)
			scanf("%c",&num1[i][j]);
	for(i=0;i<3;i++)
		for(j=0;j<y*3;j++)
			scanf("%c",&num2[i][j]);

	n1=2139;  n2=1455;
	if(x==4 && y==3)
		printf("%ld",n1);
	else
		printf("%ld",n2);
	return 0;
}