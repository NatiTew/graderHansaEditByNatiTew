/*
TASK: SEGMENT
LANG: C
AUTHOR: Theerapat
CENTER: SU - su04
*/
#include<stdio.h>
#include<stdlib.h>

int main(){
	unsigned long num1,num2;
	char sn1[100][100];
	char sn2[100][100];
	char num[250];
	int i,j,k;

	scanf("%ld %ld",&num1,&num2);

	for(j=0;j<3;j++){

			scanf("%s",sn1[j]);

	}
	for(j=0;j<3;j++)
		scanf("%s",sn2[j]);

	for(i=1;i<(num1)*4;i+=4){
		if(sn1[j][i+1]=='_'){
			if(sn1[j+1][i]=='|'){
				if(sn1[j+1][i+1]=='_'){
					if(sn1[j+2][i]=='|'){
						if(sn1[j+1][i+2]=='|')
						num[k]='8';
						else if(sn1[i+1][j+1]=='_') num[k]='5';
						else num[k]='6';
					}
					else if(sn1[j+1][i+2]=='|')
					num[k]='9';
					else num[k]='0';


				}

				else num[k]='7';
			}
			else if(sn1[j+1][i+2]=='|'){
				if(sn1[j+2][i]=='|') num[k]='2';
				else num[k]='3';
			}
		}
		else if(sn1[j+1][i+2]=='|'){
			if(sn1[j+1][i+1]=='_') num[k]='4';
			else num[k]='1';
		}


			k++;
		}

		num1=atoi(num);
		for(i=0;i<k+1;i++){
			num[i]=' ';

	      k=0;
	      for(i=1;i<(num2)*4;i+=4){
		if(sn2[j][i+1]=='_'){
			if(sn2[j+1][i]=='|'){
				if(sn2[j+1][i+1]=='_'){
					if(sn2[j+2][i]=='|'){
						if(sn2[j+1][i+2]=='|')
						num[k]='8';
						else if(sn2[i+1][j+1]=='_') num[k]='5';
						else num[k]='6';
					}
					else if(sn2[j+1][i+2]=='|')
					num[k]='9';
					else num[k]='0';


				}

				else num[k]='7';
			}
			else if(sn2[j+1][i+2]=='|'){
				if(sn2[j+2][i]=='|') num[k]='2';
				else num[k]='3';
			}
		}
		else if(sn2[j+1][i+2]=='|'){
			if(sn2[j+1][i+1]=='_') num[k]='4';
			else num[k]='1';
		}


			k++;
		}
		num2=atoi(num);


		printf("%ld",num1+num2);

	}
	return 0;



}