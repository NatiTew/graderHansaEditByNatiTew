/*
TASK: MAXSEQ
LANG: C
AUTHOR: SARAN LERTPRADIT
CENTER: TU
*/
#include<stdio.h>
main()
{
	int n,i,j,k,imax,jmax;
	long sum,max;
	char arr[2500];
	max=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=0;i<n;i++)
	{
		if(arr[i]<0)
		{
			continue;
		}
		sum=0;
		for(j=i;j<n;j++)
		{
			sum=sum+arr[j];
			if(sum>max)
			{
				imax=i;
				jmax=j;
				max=sum;
			}
		}
	}
	if(max>0)
	{
		for(k=imax;k<=jmax;k++)
		{
			printf("%d ",arr[k]);
		}
		printf("\n%ld",max);
	}
	else
	{
		printf("Empty sequence");
	}
	return 0;
}