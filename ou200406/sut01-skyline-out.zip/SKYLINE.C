/*
TASK: SKYLINE.C
LANG: C
AUTHOR; NUTDANAI PHANSOOKSAI
CENTER: SUT01
*/

#include<stdio.h>
void main(){
	int line[255] = {0},n,st,hi,fin,i,j,min = 32767,max = 0;
	scanf("%d",&n);
	for(i = 0;i < n;i++){
		scanf("%d %d %d",&st,&hi,&fin);
		for(j = st;j <= fin;j++) if(line[j] < hi) line[j] = hi;
		if(st < min) min = st;
		if(fin > max) max = fin;
	}
	printf("%d ",min);
	for(i = min;i <= max;i++){
		printf("%d ",line[i]);
		while(line[i] == line[i+1])i++;
		if(i %2 == 0) printf("%d ",i+1);
		else printf("%d ",i);
	}
	if(max != 255) printf("0");
}