/*
TASK: MAXSEQ
LANG: C
AUTHOR: Sujin Kraiyasin
CENTER: Ubon 06
*/
#include <stdio.h>

int main()
{
	int size,i,value[2500]={0},x=0,lx=0,maxptr=0;
	long maxvalue=0,tmpsum=0,tmp=0;
	//Read INPUT
	scanf("%d",&size);
	for (i=0;i<size;i++)
	{
		scanf("%d",&value[i]);
	}

	//check case value has 1,2 member
	if (size<=2)
	{
		maxvalue=value[0]+value[1];
		if(maxvalue>0&&size==1)
		{
			printf("%d\n",value[0]);
			printf("%d",maxvalue);
		}
		else if(maxvalue>0&&size==2)
		{
			printf("%d %d\n",value[0],value[1]);
			printf("%d",maxvalue);
		}
		else
		printf("Empty sequence");

	}
	else
	{
	//case member >= 3
	for (i=0;i<size;i++)
	{
		tmpsum=value[i];
		for (x=i+1;x<size;x++)
		{
			tmp=tmpsum;
			tmpsum=tmp+value[x];
			if(tmpsum>maxvalue)
			{
				maxvalue=tmpsum;
				maxptr=i;
				lx=x;
			}

		}
	}
	if (maxvalue>0)
	{
		for(i=maxptr;i<=lx;i++)
		{
			printf("%d ",value[i]);
		}
		printf("\n%d",maxvalue);
	}
	else
	printf("Empty sequence");
	}
	//fclose(fp);
	return(0);
}