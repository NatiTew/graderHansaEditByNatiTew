/*
TASK: WORD
LANG: C
AUTHOR: Nuttakorn Benjamasutin (Assumption)
Center: tu03
*/

#include <stdio.h>

#define MAXMAP 55
#define MAXWORD 105
#define MAXLEN 25
#define MAXDIRECT 8

const int direct[][2]={ {0,1}, {0,-1}, {1,0}, {-1,0}, {-1,1}, {1,-1}, {-1,-1}, {1,1} };
char map[MAXMAP][MAXMAP];
char word[MAXWORD][MAXLEN];
int check[MAXWORD];
int out[MAXWORD][2];
int m, n, k;

int Check(int l, int j, int y, int x)
{
		if(y+direct[j][0]*l >= 0 && y+direct[j][0]*l <= m) // Check Y
		{
			if(x+direct[j][1]*l >= 0 && x+direct[j][1]*l <= n); // Check X
			else return 0;
		}
		else return 0;
		return 1;
}
void Find(int y, int x)
{
	int i, j, l, m, len;
	int yes;
	for(i=0; i<k; i++)
	{
		if(check[i] == 1) continue;
		len=strlen(word[i]);
		for(j=0; j<MAXDIRECT; j++)
		{
			for(l=0, yes=1; l<len; l++)
			{
				if( Check(l, j, y, x) && word[i][l] == map[y+direct[j][0]*l][x+direct[j][1]*l]);
				else { yes=0; break; }
			}
			if(yes)
			{
				out[i][0]=y;
				out[i][1]=x;
				check[i]=1;
			}
		}
	}
}
int main()
{
	int i, j, len;
//	freopen("input.txt","rt",stdin);
	scanf("%d%d",&m,&n);
	for(i=0; i<m; i++)
	{
		scanf("%s", map[i]);
		for(j=0; j<n; j++)
			if(map[i][j] >= 'A' && map[i][j] <= 'Z')
				map[i][j]=map[i][j]-'A'+'a';
	}
	scanf("%d",&k);
	for(i=0; i<k; i++)
	{
		scanf("%s",word[i]);
		for(j=0, len=strlen(word[i]); j<len; j++)
			if(word[i][j] >= 'A' && word[i][j] <= 'Z')
				word[i][j]=word[i][j]-'A'+'a';
	}
	for(i=0; i<m; i++)
		for(j=0; j<n; j++)
			Find(i, j);
	for(i=0; i<k; i++)
		printf("%d %d\n",out[i][0],out[i][1]);
	return 0;
}