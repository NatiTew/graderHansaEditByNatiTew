/*
TASK: DICE
LANG: C
AUTHOR: Kraipitch Tassanasaengsoon
CENTER: TU12
*/

# include <stdio.h>
# include <string.h>

# define Max 1050

void main()
{
	int n,c,c2,top=1,front=2,left=3,back=5,right=4,bottom=6,temp;
	char order[Max];
	scanf("%d",&n);
	for( c=1 ; c <= n ; c++ , top=1,front=2,left=3,back=5,right=4,bottom=6 )
	{
		scanf("\n%s",&order);
		for( c2=0 ; c2 < strlen(order) ; c2++ )
		{
			switch( order[c2] )
			{
				case 'F' : temp=front; front=top; top=back; back=bottom; bottom=temp; break;
				case 'B' : temp=front; front=bottom; bottom=back; back=top; top=temp; break;
				case 'L' : temp=left; left=top; top=right; right=bottom; bottom=temp; break;
				case 'R' : temp=right; right=top; top=left; left=bottom; bottom=temp; break;
				case 'C' : temp=front; front=right; right=back; back=left; left=temp; break;
				case 'D' : temp=front; front=left; left=back; back=right; right=temp; break;
			}
		}
		printf("%d ",front);
	}
}