/*
TASK: BEE
LANG: C
AUTHOR: NUTDANAI PHANSOOKSAI
CENTER: SUT01
*/
#include<stdio.h>
void main(){
	int i = 0,n;
	long int work,sol,tmp;
	do{
		scanf("%d",&n);
		if(n == -1) break;
		work = 1;
		sol = 0;
		for(i = 0;i < n;i++){
			tmp = work;
			tmp += sol+1;
			sol = work;
			work = tmp;
		}
		printf("%ld %ld\n",work,work+sol+1);
	}while(n != -1);
}