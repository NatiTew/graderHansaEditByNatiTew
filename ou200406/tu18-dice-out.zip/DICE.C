/*
TASK: DICE
LANG: C
AUTHOR: ISRANU SAENGSUWAN
CENTER: SAMSEN18
*/
#include <stdio.h>

main()
{
	char input[7][1001];
	int amount, dice[6], dicetmp[6], i, j, k;
	dice[0] = 1;
	dice[1] = 2;
	dice[2] = 3;
	dice[3] = 5;
	dice[4] = 4;
	dice[5] = 6;
	scanf ("%d", &amount);
	for (i=0;i<amount;i++)
		scanf ("%s",input[i]);
	for (i=0;i<amount;i++)
	{
		j = 0;
		while (input[i][j] != '\0')
		{
			for (k=0;k<6;k++) dicetmp[k] = dice[k];
			switch (input[i][j])
			{
			case 'F':
				dice[0] = dicetmp[3];
				dice[3] = dicetmp[5];
				dice[5] = dicetmp[1];
				dice[1] = dicetmp[0];
				break;
			case 'B' :
				dice[3] = dicetmp[0];
				dice[5] = dicetmp[3];
				dice[1] = dicetmp[5];
				dice[0] = dicetmp[1];
				break;
			case 'L' :
				dice[2] = dicetmp[0];
				dice[5] = dicetmp[2];
				dice[4] = dicetmp[5];
				dice[0] = dicetmp[4];
				break;
			case 'R' :
				dice[0] = dicetmp[2];
				dice[2] = dicetmp[5];
				dice[5] = dicetmp[4];
				dice[4] = dicetmp[0];
				break;
			case 'C' :
				dice[2] = dicetmp[1];
				dice[3] = dicetmp[2];
				dice[4] = dicetmp[3];
				dice[1] = dicetmp[4];
				break;
			case 'D' :
				dice[1] = dicetmp[2];
				dice[2] = dicetmp[3];
				dice[3] = dicetmp[4];
				dice[4] = dicetmp[1];
				break;
			}
			j++;
		}
		printf ("%d ",dice[1]);
	}
	return 0;
}