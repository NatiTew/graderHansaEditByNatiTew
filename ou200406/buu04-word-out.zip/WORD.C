/*
TASK: WORD
LANG: C
AUTHOR: Sirawit Phutrakul
CENTER: BUU
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(void) {
	int m ,n ,i ,k ,x ,y ,j ,line ,chk ,a ,b;
	char ch[25][25];
	char find[16];
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++) {
		flushall() ;
		gets(ch[i]);
		strlwr(ch[i]);
	}
	flushall();
	scanf("%d",&k);
	for(i=0;i<k;i++) {
		scanf("%s",find);
		strlwr(find);
		chk = 0;
		for(y=0;y<m;y++) {
			for(x=0;x<n;x++) {
				for(line=0;line<8;line++) {
					a = y;
					b = x;
				for(j=0;find[j]!='\0';j++) {
					if(find[j]!=ch[a][b]) {
						break;
					} else {
							switch(line) {
								case 0: b++; break;
								case 1: a++; b++; break;
								case 2: a++; break;
								case 3: a++; b--; break;
								case 4: b--; break;
								case 5: a--; b--; break;
								case 6: a--; break;
								case 7: a--; b++; break;
							}

					}
				}
				if(find[j]=='\0') {
					chk = 1;
					break;
				}

				}
				if(chk == 1)
				break;

			}
			if(chk == 1)
				break;
		}
		printf("%d %d\n",y,x);
	}
	return 0;
}