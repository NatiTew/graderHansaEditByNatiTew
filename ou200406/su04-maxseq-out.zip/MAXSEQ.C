/*
TASK: MAXSEQ
LANG: C
AUTHOR: Theerapat Chawannakul
CENTER: SU - su04
*/
#include<stdio.h>

int num[2501];
int main(){
	int i,j,length,sum=0,max=-128,begin,end;

	scanf("%d",&length);

	for(i=0;i<length;i++)scanf(" %d",&num[i]);

	for(i=0;i<length;i++){
		sum=0;
		for(j=i;j<length;j++){
		sum+=num[j];

			if(sum>max){
				max=sum;
				begin=i;
				end=j;
			}
		}

	}
	if(max>0){
		for(i=begin;i<=end;i++){
			printf("%d",num[i]);
			if(i!=end) printf(" ");
		}
		printf("\n%d",max);
	}
	else
		printf("Empty sequence");



	return 0;

}