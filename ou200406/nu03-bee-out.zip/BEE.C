/*
TASK: BEE
LANG: C
AUTHOR: Phumpong Chaiwongkhot
CENTER: nu03
*/
#include<stdio.h>
int main()
{
	int y[24],c,i,j,count=0;
	long work=1,sol=0,tmp=0;

	 for(c=0;c<24;c++)
	{
		scanf("%d",&y[c]);
	}

	for(j=1;j<24;j++)  //incheck
	{
		if(y[j]!=-1)
		{
			count++;
		}
		else
		{
			break;
		}
	}
	for(i=0;i<=count;i++)
	{
		sol=0;
		tmp=0;
		work=1;
		for(j=0;j<y[i];j++)
		{
			tmp=sol;
			sol=work;
			work=sol+tmp+1;
		}
		printf("%ld  %ld\n",work,work+sol+1);
	}

	return 0;
}
