
/*
TASK: BEE
LANG: C
AUTHOR: Pattaravut Maleehuan
CENTER: SUT04
*/
#include<stdio.h>

struct bee
{
	long int mas,wk,sol,dat;
}be[25];

int n,j,i,max=-1;
long int data[25];

void think(int);

int main()
{
	for(i=0;i<25;i++)
	{
		scanf("%ld",&be[i].dat);
		if(be[i].dat == -1) break;
		else if(max < be[i].dat) max=be[i].dat;
	}
	think(max);
	for(i=0;i<25 && be[i].dat != -1;i++)
		printf("%ld %ld\n",be[be[i].dat].wk,data[be[i].dat]);
	return 0;
}

void think(int in)
{
	be[0].mas=1;
	be[0].wk=1;
	be[0].sol=0;
	for(j=1;j<=in;j++)
	{
		be[j].wk=1+be[j-1].wk+be[j-1].sol;
		be[j].sol=be[j-1].wk;
		data[j]=1+be[j].wk+be[j].sol;
	}
}