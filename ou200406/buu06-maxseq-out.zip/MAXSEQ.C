#include <stdio.h>
/*
TASK: MAXSEQ
LANG: C
AUTHOR: Nopphorn Pitaksuebpon
CENTER: buu06
*/

int main(void)
{
   int get[2500],con=0,rtotal=0,total,mk,mj,i,n,j,k;
   scanf("%d",&n);
   for(i=0;i<n;i++)
      scanf("%d",&get[i]);
   for(i=1;i<=n;i++)
   {
      for(j=0;j<n-i+1;j++)
      {
	 total=0;
	 for(k=0;k<i;k++)
	 {
	    total=total+get[k+j];
	 }
	 if((total>0)&&(total>rtotal))
	 {
	    mk=k;
	    mj=j;
	    con=1;
	    rtotal=total;
	 }
      }
   }
   if(con==1)
   {
      for(k=0;k<mk;k++)
      {
	 printf("%d ",get[k+mj]);
      }
      printf("\n%d\n",rtotal);
   }
   else
   {
      printf("Empty sequence\n");
   }
   return 0;
}