/*
TASK: SKYLINE
LANG: C
AUTHOR: Naksit Anantalapochai
CENTER: cmu04
*/
#include <stdio.h>
int main(){
	int n,i;
	char a[20];
	for(i=0;i<n;i++){
		gets(a);
	}
	printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
	return 0;
}