/*
TASK: BEE
LANG: C
AUTHOR: SARAN SONGYOD
CENTER: haddyai06
*/
#include<stdio.h>

void main()
{ int bee[3] = {1,1,0}; //QPS
  int total;
  int year[24];
  int i;
  int chk;

  for(i=0;i<24;i++)
    year[i] = 0;
  scanf("%d",&chk);
  while(chk!=-1)
  { if((chk<=24)&&(chk>=1))
    { bee[0] = bee[1] = 1;
      bee[2] = 0;
      if(year[chk-1]==0)
      { year[chk-1]=1;
	total = bee[0]+bee[1]+bee[2];
	for(i=1;i<=chk;i++)
	{ bee[2] = bee[1];
	  bee[1] = total;
	  total = bee[0]+bee[1]+bee[2];
	}
	printf("%d %d\n",bee[1],total);
      }
    }
    scanf("%d",&chk);
  }
}