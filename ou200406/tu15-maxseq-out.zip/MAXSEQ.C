/*
TASK: MAXSEQ
LANG: C
AUTHOR: NATHADOL SAHAWATWONG
CENTER: TU15
*/
#include<stdio.h>
#define MAX 2501
main()
{
	int n,i,input,j,l,k,checkleft=0,checkright=0,left=0,right=0;
	int cursor , max=-1 ,maxleft=-1,maxright=-1,temp = 0;
	int array[MAX];
	scanf("%d",&n);
	for(i = 1 ; i <=n ; i++)
	{
		scanf("%d",&input);
		if(input > 0)	temp = 1;
		array[i]=input;
	}
	if(temp == 1)
	{
	for(j = 1 ; j <=n ; j++)
	{
		if(array[j]>max || max == -1)
		{
			max = array[j];
			cursor = j;
		}
	}
	for(k = 1 ; k<= cursor-1 ; k++)
	{
		for(l = k ; l<= cursor -1 ; l++)
		{
			checkleft+=array[l];
		}
		if(checkleft <= 0)
		{
			checkleft = 0;
		}
		else
		{
			if(checkleft > maxleft  || maxleft == -1)
			{
				maxleft=checkleft;
				left = k;
			}
		}
		checkleft = 0;
	}
	for(k = n ; k>=cursor+1 ; k--)
	{
		for(l = k ; l>=cursor+1 ; l--)
		{
			checkright+=array[l];
		}
		if(checkright<=0)
		{
			checkright = 0 ;
		}
		else
		{
			if(checkright > maxright || maxright == -1)
			{
				maxright = checkright;
				right = k;
			}
		}
		checkright = 0;
	}
	if(right==0)
		right = cursor;
	if(left==0)
		left = cursor;
	for(;left<=right;left++)
		printf("%d ",array[left]);
	if(maxleft > 0)
	max+=maxleft;
	if(maxright > 0)
	max+=maxright;
	printf("\n");
	printf("%d",max);
	}
	else if(temp != 1)
	printf("Empty sequence");
	return 0;
}