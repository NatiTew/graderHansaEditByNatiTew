/*
TASK: WORD
LANG: C
AUTHOR: Prayote Boonchaisuk
CENTER: SUT02
*/
#include<stdio.h>
#include<string.h>
void main(){
	char st[30][30],s[20];
	int i,j,found=1,in0=0,in1=0,l,a[100],b[100],
	    k,m,n;
	scanf(" %d %d",&m,&n);
	for(i=0;i<m;i++)
	   {
	    scanf(" %s",st[i]);
	    strupr(st[i]);
	   }
	scanf(" %d",&k);
	for(i=0;i<k;i++)
	   {
	    in0=0,in1=0;
	    scanf("%s",s);
	    l=strlen(s),strupr(s);
	    while(in0<m)
	       {
		if(s[0]==st[in0][in1])
		       {
			if(in0-(l-1)>=0)
			  {found=0;
			   for(j=1;j<l;j++)
			       if(s[j]!=st[in0-j][in1])
				  {++found;
				   break;}
			  }if(found==0)goto PRI;
			if(in0+(l-1)<m)
			  {found=0;
			   for(j=1;j<l;j++)
			       if(s[j]!=st[in0+j][in1])
				  {++found;
				   break;}
			  }if(found==0)goto PRI;
			if(in1-(l-1)>=0)
			  {found=0;
			   for(j=1;j<l;j++)
			       if(s[j]!=st[in0][in1-j])
				  {++found;
				   break;}
			  }if(found==0)goto PRI;
			if(in1+(l-1)<n)
			  {found=0;
			   for(j=1;j<l;j++)
			       if(s[j]!=st[in0][in1+j])
				  {++found;
				   break;}
			  }if(found==0)goto PRI;
			if(in0-(l-1)>=0&&in1-(l-1)>=0)
			  {found=0;
			   for(j=1;j<l;j++)
			       if(s[j]!=st[in0-j][in1-j])
				  {++found;
				   break;}
			  }if(found==0)goto PRI;
			if(in0+(l-1)<m&&in1+(l-1)<n)
			  {found=0;
			   for(j=1;j<l;j++)
			       if(s[j]!=st[in0+j][in1+j])
				  {++found;
				   break;}
			  }if(found==0)goto PRI;
			if(in0+(l-1)<m&&in1-(l-1)>=0)
			  {found=0;
			   for(j=1;j<l;j++)
			       if(s[j]!=st[in0+j][in1-j])
				  {++found;
				   break;}
			  }if(found==0)goto PRI;
			if(in1-(l-1)<n&&in0+(l-1))
			  {found=0;
			   for(j=1;j<l;j++)
			       if(s[j]!=st[in0-j][in1+j])
				  {++found;
				   break;}
			  }if(found==0)goto PRI;
		       }
		if(++in1%n==0) in0++,in1=0;
	       }
	    PRI:
	    if(found==0)
	       a[i]=in0,b[i]=in1;
	   }
 for(i=0;i<k;i++)
    printf("%d %d\n",a[i],b[i]);
}