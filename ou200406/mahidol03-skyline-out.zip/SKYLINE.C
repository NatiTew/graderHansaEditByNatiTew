/*
TASK: SKYLINE
LANG: C
AUTHOR: Suthee Kongkiatpaiboon
CENTER: Mahidol03
*/

#include<stdio.h>
#include<stdlib.h>
int main()
{
  int sky[260]={0};
  int i,n,l,h,r;
  int pre;

  scanf("%d",&n);

  for(i=0;i<n;i++)
    {
      scanf("%d %d %d",&l,&h,&r);
      for(;l<r;l++)
	{
	  if(sky[l]<h)
	    sky[l]=h;
	}
    }

  pre=sky[1];
  printf("1 %d",pre);

  for(i=2;i<256;i++)
    {
      if(sky[i]!=pre)
	{
	  printf(" %d %d",i,sky[i]);
	  pre=sky[i];
	}
    }


  return 0;
}