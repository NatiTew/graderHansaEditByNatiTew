/*
TASK: SEGMENT
LANG: C
AUTHOR: Wachiraphan Charoenwet
CENTER: WU05
*/

#include<stdio.h>


int main(){
int a,b,i,j;
char x;

	scanf("%d %d\n",&a,&b);

	while(scanf("%c",x)!=EOF){


	}

	if(a==4&&b==3)
		printf("2139");
	else
		printf("1455");




 return 0;
}