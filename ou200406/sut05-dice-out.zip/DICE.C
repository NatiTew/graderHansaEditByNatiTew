/*
TASK: DICE
LANG: C
AUTHOR: Thananon Patinyasakdikul
CENTER: SUT
*/

#include<stdio.h>
int dice[7] = {1,2,3,5,4,6};
int tmp1,tmp2,i,n,a;
char str[6][1001];
void think(char);
void clear();

void main()
{
   scanf("%d",&n);
   for(i=0;i<n;i++)
   scanf("%s",&str[i]);

 for(a=0;a<n;a++){
    clear();
   for(i=0;i<strlen(str[a]);i++)
     think(str[a][i]) ;
   printf("%d ",dice[1]);
  }

}


void think(char x){

     if(x=='B'){
       tmp1 = dice[5];
       dice[5] = dice[3];
       tmp2 = dice[1];
       dice[1] = tmp1;
       tmp1 = dice[0];
       dice[0] = tmp2;
       dice[3] = tmp1;
     } else

     if(x == 'F'){
       tmp1 = dice[3];
       dice[3] = dice[5];
       tmp2 = dice[0];
       dice[0] = tmp1;
       tmp1 = dice[1];
       dice[1] = tmp2;
       dice[5] = tmp1;

     } else

     if(x == 'L'){
       tmp1 = dice[2];
       dice[2] = dice[0];
       tmp2 = dice[5];
       dice[5] = tmp1;
       tmp1 = dice[4];
       dice[4] = tmp2;
       dice[0] = tmp1;

     }    else
     if(x == 'R'){
      tmp1 = dice[4];
       dice[4] = dice[0];
       tmp2 = dice[5];
       dice[5] = tmp1;
       tmp1 = dice[2];
       dice[2] = tmp2;
       dice[0] = tmp1;

     }
	  else
     if(x == 'C'){
       tmp1 = dice[3];
       dice[3] = dice[2];
       tmp2 = dice[4];
       dice[4] = tmp1;
       tmp1 = dice[1];
       dice[1] = tmp2;
       dice[2] = tmp1;

     }    else
      if(x=='D'){
       tmp1 = dice[4];
       dice[4] = dice[1];
       tmp2 = dice[3];
       dice[3] = tmp1;
       tmp1 = dice[2];
       dice[2] = tmp2;
       dice[1] = tmp1;
       }

}

void clear()
{
 dice[0]= 1;
 dice[1] = 2;
 dice[2] = 3;
 dice[3] = 5;
 dice[4] = 4;
 dice[5] = 6;
}