/*
TASK: MAXSEQ
LANG: C
AUTHOR: Poohmai Chaikeaw
CENTER: HADDYAI03
*/
#include<stdio.h>

void chk(int in[],int n);
void main()
{
int flag=1,i,n,in[2500];
  scanf("%d",&n);
  if(n>2500)
  flag=0;
  else
{
  for(i=0;i<n;i++)
   {
      scanf("%d",&in[i]);
      if((in[i]<-127)||(in[i]>127))
       {
	 flag=0;
       }
   }
  if(flag==1) chk(in,n);
}
}

void chk(int in[],int n)
{
int sum=0,i,cur;
int start=-1,end=-1,max=0;
for(cur=0;cur<n;cur++)
 {
  for(i=cur;i<n;i++)
  {
     sum+=in[i];
     if((sum>0)&&(sum>max))
     {
     max=sum;
     start=cur;
     end=i;
     }
  }sum=0;
 }
 if(max<=0)
 printf("Empty sequence");
 else
   {
   for(i=start;i<=end;i++)
     {
     printf("%d ",in[i]);
     }
     printf("\n%d",max);
   }
}

