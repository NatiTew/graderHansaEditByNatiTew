/*
TASK: SEGMENT
LANG: C
AUTHOR: NATHADOL SAHAWATWONG
CENTER: TU15
*/

#include<stdio.h>
#define MAX 10
char array[MAX][MAX];
int number1[20] , number2[20];
main()
{
	int n , m , j , i , k ,a,b, count = 1 , x= 0 , y=0;
	long temp;
	double sum=0,sum2=0;
	char input[MAX],z;
	scanf("%d %d",&n,&m);
	scanf("%c",&z);
	for(i=1 ; i<=n ; i++)
	{
				for(a = 1 ; a<= 6 ; a++)
				for( b = 1 ; b<= 6 ; b++)
					array[a][b]=' ';
		for(j=1 ; j<=3 ; j++)
		{
				gets(input);
				for(k = 0 ; k<= 2 ; k++)
					{
						if(input[k] == ' ')
						array[j][count++] = ' ';
						if(input[k] == '|')
						array[j][count++] = '|';
						if(input[k] == '_')
						array[j][count++] = '_';
					}
				count = 1;
		}
		if(array[1][1] == ' ' && array[1][2] == ' ' && array[1][3]== ' ' && array[2][1] == ' ' && array[2][2] == ' ' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == ' ' && array[3][3] == '|')	number1[x++] = 1;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == ' ' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == '|' && array[3][2] == '_' && array[3][3] == ' ')	number1[x++] = 2;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == ' ' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == '_' && array[3][3] == '|')	number1[x++] = 3;
		if(array[1][1] == ' ' && array[1][2] == ' ' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == ' ' && array[3][3] == '|')	number1[x++] = 4;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == ' ' && array[3][1] == ' ' && array[3][2] == '_' && array[3][3] == '|')	number1[x++] = 5;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == ' ' && array[3][1] == '|' && array[3][2] == '_' && array[3][3] == '|')	number1[x++] = 6;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == ' ' && array[2][2] == ' ' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == ' ' && array[3][3] == '|')	number1[x++] = 7;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == '|' && array[3][2] == '_' && array[3][3] == '|')	number1[x++] = 8;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == '_' && array[3][3] == '|')	number1[x++] = 9;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == ' ' && array[2][3] == '|' && array[3][1] == '|' && array[3][2] == '_' && array[3][3] == '|')	number1[x++] = 0;
	}
	count = 1;
	for(i=1 ; i<=m ; i++)
	{
				for(a = 1 ; a<= 6 ; a++)
				for( b = 1 ; b<= 6 ; b++)
				array[a][b]=' ';

		for(j=1 ; j<=3 ; j++)
		{
				gets(input);
				for(k = 0 ; k<= 2 ; k++)
					{
						if(input[k] == ' ')
						array[j][count++] = ' ';
						if(input[k] == '|')
						array[j][count++] = '|';
						if(input[k] == '_')
						array[j][count++] = '_';
					}
				count = 1;
		}
		if(array[1][1] == ' ' && array[1][2] == ' ' && array[1][3]== ' ' && array[2][1] == ' ' && array[2][2] == ' ' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == ' ' && array[3][3] == '|')	number2[y++] = 1;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == ' ' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == '|' && array[3][2] == '_' && array[3][3] == ' ')	number2[y++] = 2;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == ' ' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == '_' && array[3][3] == '|')	number2[y++] = 3;
		if(array[1][1] == ' ' && array[1][2] == ' ' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == ' ' && array[3][3] == '|')	number2[y++] = 4;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == ' ' && array[3][1] == ' ' && array[3][2] == '_' && array[3][3] == '|')	number2[y++] = 5;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == ' ' && array[3][1] == '|' && array[3][2] == '_' && array[3][3] == '|')	number2[y++] = 6;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == ' ' && array[2][2] == ' ' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == ' ' && array[3][3] == '|')	number2[y++] = 7;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == '|' && array[3][2] == '_' && array[3][3] == '|')	number2[y++] = 8;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == '_' && array[2][3] == '|' && array[3][1] == ' ' && array[3][2] == '_' && array[3][3] == '|')	number2[y++] = 9;
		if(array[1][1] == ' ' && array[1][2] == '_' && array[1][3]== ' ' && array[2][1] == '|' && array[2][2] == ' ' && array[2][3] == '|' && array[3][1] == '|' && array[3][2] == '_' && array[3][3] == '|')	number2[y++] = 0;
	}
	temp = 1;
	for(i = n-1 ; i>=0 ; i--)
	{
		sum+=number1[i]*temp;
		temp = temp*10;
	}

	temp = 1;
	for(i = m-1 ; i>=0 ; i--)
	{
		sum2+=number2[i]*temp;
		temp = temp*10;
	}
	printf("%.0lf",sum+sum2);
	return 0;
}