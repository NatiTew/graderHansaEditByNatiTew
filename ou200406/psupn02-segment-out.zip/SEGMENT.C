/*
TASK: SEGMENT
LANG: C
AUTHOR METHA WANGTHAMMANG
CENTER: PSUPN02
*/
#include<stdio.h>
#include<stdlib.h>
main()
{
long int sum=0,n1,n2;
int size[2]={0},ci,i,j,k,x,y,chk=0,ii,jj,cn;
char temp;
char *nst1,*nst2;
char table[3][50]={0};
char numn[3][3]={32};
char num0[3][3]={32,'_',32,'|',32,'|','|','_','|'};
char num1[3][3]={32,32,32,32,32,'|',32,32,'|'};
char num2[3][3]={32,'_',32,32,'_','|','|','_',32};
char num3[3][3]={32,'_',32,32,'_','|',32,'_','|'};
char num4[3][3]={32,32,32,'|','_','|',32,32,'|'};
char num5[3][3]={32,'_',32,'|','_',32,32,'_','|'};
char num6[3][3]={32,'_',32,'|','_',32,'|','_','|'};
char num7[3][3]={32,'_',32,32,32,'|',32,32,'|'};
char num8[3][3]={32,'_',32,'|','_','|','|','_','|'};
char num9[3][3]={32,'_',32,'|','_','|',32,'_','|'};
nst1=malloc(100);
nst2=malloc(100);
strcpy(nst1,"");
strcpy(nst2,"");
scanf("%d %d",&size[0],&size[1]);
scanf("%c",&temp);
x = (size[0]*3)+size[0];
y= 3;
for(i=0;i<y;i++)
	for(j=0;j<x;j++)
		scanf("%c",&table[i][j]);
/*
for(i=0;i<y;i++)
	for(j=0;j<x;j++)
		printf("%c",table[i][j]);
*/

for(ci=0;ci<200;ci++)
	{
	for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
		for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num1[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"1");
		sum=0;
		//////////////2

		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num2[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"2");
		sum=0;
		////////////////3
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num3[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"3")  ;
		sum=0;
		////////////////4
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num4[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"4") ;
		sum=0;

		////////////////5
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num5[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"5") ;
		sum=0;

		////////////////6
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num6[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"6");
		sum=0;
		////////////////7
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num7[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"7");
		sum=0;
		////////////////8
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num8[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"8");
		sum=0;
		////////////////9
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num9[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"9");
		sum=0;
		////////////////0
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num0[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst1,"0");
		sum=0;
	}//end for ci
//printf("%s",nst1);

for(i=0;i<y;i++)
	for(j=0;j<x;j++)
		scanf("%c",&table[i][j]);
/*
for(i=0;i<y;i++)
	for(j=0;j<x;j++)
		printf("%c",table[i][j]);
*/
scanf("%c",&temp);
for(ci=0;ci<200;ci++)
	{
	for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
		for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num1[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"1");
		sum=0;
		//////////////2

		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num2[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"2");
		sum=0;
		////////////////3
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num3[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"3")  ;
		sum=0;
		////////////////4
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num4[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"4") ;
		sum=0;

		////////////////5
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num5[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"5") ;
		sum=0;

		////////////////6
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num6[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"6");
		sum=0;
		////////////////7
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num7[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"7");
		sum=0;
		////////////////8
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num8[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"8");
		sum=0;
		////////////////9
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num9[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"9");
		sum=0;
		////////////////0
		for(i=ci,ii=0;i<ci+3,ii<3;i++,ii++)
			for(j=ci,jj=0;j<ci+3,jj<3;j++,jj++)
				if(table[i][j]==num0[ii][jj])
					sum++;
		if(sum==9)
			strcat(nst2,"0");
		sum=0;
	}//end for ci
n1=atol(nst1);
n2=atol(nst1);
printf("%ld",n1+n2);
}