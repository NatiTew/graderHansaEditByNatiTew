/*
TASK: DICE
LANG: C
AUTHOR: SARAN LERTPRADIT
CENTER: TU
*/
#include<stdio.h>
main()
{
	int f[]={0,4,1,3,6,5,2},
		b[]={0,2,6,3,1,5,4},
		l[]={0,5,2,1,4,6,3},
		r[]={0,3,2,6,4,1,5},
		c[]={0,1,5,2,3,4,6},
		d[]={0,1,3,4,5,2,6};
	int dice[7],dice2[7];
	int n,i,j,ans[7];
	char ch;
	scanf("%d",&n);
	for(i=0;i<=n;i++)
	{
		dice[1]=1;
		dice[2]=2;
		dice[3]=3;
		dice[4]=5;
		dice[5]=4;
		dice[6]=6;
		while( (ch=getchar()) != 10 )
		{
			switch(ch)
			{
				case 'F' :
					for(j=1;j<=6;j++)
					{
						dice2[j]=f[dice[j]];
					}break;
				case 'B' :
					for(j=1;j<=6;j++)
					{
						dice2[j]=b[dice[j]];
					}break;
				case 'L' :
					for(j=1;j<=6;j++)
					{
						dice2[j]=l[dice[j]];
					}break;
				case 'R' :
					for(j=1;j<=6;j++)
					{
						dice2[j]=r[dice[j]];
					}break;
				case 'C' :
					for(j=1;j<=6;j++)
					{
						dice2[j]=c[dice[j]];
					}break;
				case 'D' :
					for(j=1;j<=6;j++)
					{
						dice2[j]=d[dice[j]];
					}break;
			}
			for(j=1;j<=6;j++)
			{
				dice[j]=dice2[j];
			}
		}
		ans[i]=dice[2];
	}
	for(i=1;i<=n;i++)
	{
		printf("%d ",ans[i]);
	}
	return 0;
}