/*
TASK: BEE
LANG: C
AUTHOR: Poohmai Chaikeaw
CENTER: HADDYAI03
*/
#include<stdio.h>
void cul(int);
void main()
{
int n;
scanf("%d",&n);
do
  {
   cul(n);
   scanf("%d",&n);
  }while((n!=-1)&&(n>0)&&(n<24));
}

void cul(int n)
{
  int sum=1,work=1,sold=0,i;
  for(i=0;i<n;i++)
  {
	work=work+sold;
	if(sold>0)sold=sold-1;
	sold+=work;
	work=work+1;
  }
  sum=work+sold+1;
  printf("%d %d",work,sum);
}