/*
TASK: DICE
LANG: C
AUTHOR: PIRAPAT JAKPAISAL
CENTER: KMITNB-06
*/
#include<stdio.h>
#include<string.h>

typedef struct {
	int textlen;
	char text[1001];
}string;

typedef struct {
	char vertex[6];
	char bon[6];
	int matrix[6][6];
}GRAPH;

GRAPH graph;

void main() {
	int total,i,j,x,y,address;
	string a[6];
	char first;

	graph.bon[0]='B';
	graph.bon[1]='N';
	graph.bon[2]='Z';
	graph.bon[3]='L';
	graph.bon[4]='K';
	graph.bon[5]='D';

	graph.vertex[0]='F';
	graph.vertex[1]='B';
	graph.vertex[2]='L';
	graph.vertex[3]='R';
	graph.vertex[4]='C';
	graph.vertex[5]='D';

	graph.matrix[0][0]=5;
	graph.matrix[0][1]=1;
	graph.matrix[0][2]=3;
	graph.matrix[0][3]=6;
	graph.matrix[0][4]=4;
	graph.matrix[0][5]=2;

	graph.matrix[1][0]=2;
	graph.matrix[1][1]=6;
	graph.matrix[1][2]=3;
	graph.matrix[1][3]=1;
	graph.matrix[1][4]=4;
	graph.matrix[1][5]=5;

	graph.matrix[2][0]=4;
	graph.matrix[2][1]=2;
	graph.matrix[2][2]=1;
	graph.matrix[2][3]=5;
	graph.matrix[2][4]=6;
	graph.matrix[2][5]=3;

	graph.matrix[3][0]=3;
	graph.matrix[3][1]=2;
	graph.matrix[3][2]=6;
	graph.matrix[3][3]=5;
	graph.matrix[3][4]=1;
	graph.matrix[3][5]=4;

	graph.matrix[4][0]=1;
	graph.matrix[4][1]=4;
	graph.matrix[4][2]=2;
	graph.matrix[4][3]=3;
	graph.matrix[4][4]=5;
	graph.matrix[4][5]=6;

	graph.matrix[5][0]=1;
	graph.matrix[5][1]=3;
	graph.matrix[5][2]=5;
	graph.matrix[5][3]=4;
	graph.matrix[5][4]=2;
	graph.matrix[5][5]=6;

	scanf("%d",&total);
	if(total>6 || total<1)
		exit(0);
	for(i=0;i<total;i++) {
		scanf("%s",a[i].text);
		a[i].textlen=strlen(a[i].text);
		if(a[i].textlen>1000 ||a[i].textlen<1)
			exit(0);
	}
	for(i=0;i<total;i++) {
		j=0;
		first=a[i].text[j];
		switch(first) {
				case 'F': first='B'; break;
				case 'B': first='N'; break;
				case 'L': first='Z'; break;
				case 'R': first='L'; break;
				case 'C': first='K'; break;
				case 'D': first='D'; break;
			}
		for(j=1;j<a[i].textlen;i++) {
			x=0;
			y=0;
			while(first!=graph.bon[x])
				x++;
			while(a[i].text[j]!=graph.vertex[y])
				y++;
			address=graph.matrix[x][y];
			switch(address) {
				case 1: first='B'; break;
				case 2: first='N'; break;
				case 3: first='Z'; break;
				case 4: first='L'; break;
				case 5: first='K'; break;
				case 6: first='D'; break;
			}
		}
		printf("%d",address);

	}
}