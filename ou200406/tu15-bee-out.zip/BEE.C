/*
TASK: BEE
LANG: C
AUTHOR: NATHADOL SAHAWATWONG
CENTER: TU15
*/
#include<stdio.h>
#define MAX 25

long i,queen = 1,work = 1,sol = 0,workchild=0,solchild=0;
int array[MAX];

function(int year)
{
	for(i = 1 ; i<= year ; i++)
	{
		if(sol!=0)
		{
		workchild+= sol;
		sol = 0;
		}
		if(queen == 1)
			workchild+= 1;
		if(work!=0)
		{
		solchild+= work;
		workchild+= work;
		work = 0;
		}
		sol+=solchild;
		work+=workchild;
		solchild = 0;
		workchild = 0;
	}
	return 0;
}
main()
{
	int n;
	do{
		scanf("%d",&n);
		if(n==-1)	break;
		if(array[n]!=1)
		{
			function(n);
			printf("%ld ",work);
			printf("%ld\n",work+sol+queen);
		}
		work = 1;
		queen = 1;
		sol = 0;
		array[n]=1;
	}while(n!=-1);
	return 0;
}