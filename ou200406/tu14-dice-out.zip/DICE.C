/*
TASK:DICE
LANG:C
AUTHOR: NATTHANON THANSIRARAK
CENTER: TU14
*/
#include<stdio.h>
void swap(int,int,int,int);
char dice[6];
void main()
{
	int cur=0;
	char str[1000],input,loop,sum[6];
	scanf("%d",&input);
	for(loop=0;loop<input;loop++)
	{
		scanf("%s",str);
		dice[0]=1;
		dice[1]=2;
		dice[2]=3;
		dice[3]=5;
		dice[4]=4;
		dice[5]=6;
		for(cur=0;str[cur]!=NULL;cur++)
		{
			if(str[cur]=='F')
				swap(0,1,5,3);
			else if(str[cur]=='B')
				swap(0,3,5,1);
			else if(str[cur]=='L')
				swap(0,4,5,2);
			else if(str[cur]=='R')
				swap(0,2,5,4);
			else if(str[cur]=='C')
				swap(1,4,3,2);
			else if(str[cur]=='D')
				swap(2,3,4,1);
		}
		sum[loop]=dice[1];
	}
	for(loop=0;loop<input;loop++)
	printf("%d ",sum[loop]);
}
void swap(int a,int b,int c,int d)
{
	int keep=dice[a];
	dice[a]=dice[b];
	dice[b]=dice[c];
	dice[c]=dice[d];
	dice[d]=keep;
}