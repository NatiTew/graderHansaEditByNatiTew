/*
 TASK: BEE
 LANG: C
 AUTHOR: Boonyarit Somrealvongon
 CENTER: MAHIDOL02
*/


#include <stdio.h>

int cal(int,int,int);


int main()
{
 int n;
 scanf("%d",&n);
 while (n!=-1)
  {  cal(n,1,0);
     scanf(" %d",&n);
  }
 return 0;
}

int cal(int year,int work,int tahan)
{
 if (year==0)
   {
    printf("%d %d\n",work,tahan+work+1);
   }
 else cal(year-1,work+tahan+1,work);

}
