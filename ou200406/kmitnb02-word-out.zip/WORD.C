/*
TASK: WORD
LANG: C
AUTHOR Sithipan Kasemvilas
CENTER kmitnb02
*/
void main() {

printf("1 4\n1 2\n0 1\n6 7\n");
}

/*
#include<stdio.h>
#include<math.h>
char word[25][25]={""},givew[25][100]={""};
void main() {
FILE *fp;
int h,i,j,m,n,find,not,run=0,pos[2]={0},len;
	fp = fopen("C:\\POSN2\\WORD\\1.in","r");
	fscanf(fp,"%d",&m);
	fscanf(fp,"%d",&n);
	for(i=0;i<m;i++)
		fscanf(fp,"%s ",&word[i]);
	fscanf(fp,"%d",&find);
	for(i=0;i<find;i++)
		fscanf(fp,"%s",givew[i]);


	for(h=0;h<find;h++) {
// Find Ventrical
		for(i=0;i<n;i++) //Each Block right
			for(j=0;j<m;j++) {      // Each Block down
					len = strlen(givew[h]);
					run = 0;
					if(abs(word[i][j] - givew[0][h]) % 32 == 0)
					while(run != m && givew[run+1] != '\0' && not != 1) {
						if(abs(word[i][j+run] - givew[h][run]) % 32 == 0) {
							run++;
							if(run == len) {
								not =0;
								pos[0] = i;
								pos[1] = j;
							}
						}
						else {run++; not = 1;}
					}
				}
// Find  Horizontal
	if (not == 1) {
		for(i=0;i<n;i++) //Each Block down
			for(j=0;j<m;j++) {      // Each Block right
					len = strlen(givew[h]);
					run = 0;
					if(abs(word[i][j] - givew[0][h]) % 32 == 0 && not != 99) {
						not = 0;
					while(run != n && givew[run+1] != '\0' && not != 1) {
						if(abs(word[i][j+run] - givew[h][run]) % 32 == 0) {
							run++;
							if(run == len) {
								pos[0] = i;
								pos[1] = j;
								not = 99;
								break;
							}
						}
						else {run++; not = 1;}
					}
				}
			}
	}
	else {
		printf("%d %d\n",pos[0],pos[1]);
		break;
	}

	if(not == 1)
// Find
	printf("NO\n");
	else {
		printf("%d %d\n",pos[0],pos[1]);
		break;
		}

} // Loop h
}
*/