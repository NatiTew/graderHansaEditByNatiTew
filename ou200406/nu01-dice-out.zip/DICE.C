/*
TASK: DICE
LANG: C
AUTHOR: Peerapon Jatukanyaprateep
CENTER: NU01
*/
#include <stdio.h>
#include <string.h>

int top=1,left=3,right=4,front=2,back=5,base=6,tmp;

void F(void)
{
  tmp=top;
  top=back;
  back=base;
  base=front;
  front=tmp;
}

void B(void)
{
  tmp=top;
  top=front;
  front=base;
  base=back;
  back=tmp;
}

void L(void)
{
  tmp=top;
  top=right;
  right=base;
  base=left;
  left=tmp;
}

void R(void)
{
  tmp=top;
  top=left;
  left=base;
  base=right;
  right=tmp;
}

void C(void)
{
  tmp=front;
  front=right;
  right=back;
  back=left;
  left=tmp;
}

void D(void)
{
  tmp=front;
  front=left;
  left=back;
  back=right;
  right=tmp;
}

main()
{
  char in[1000];
  int i,j[6],dice,chk=0;
  scanf("%d",&dice);
  while(chk<=dice)
    {
    gets(in);
    for(i=0;i<=strlen(in);i++)
    {
     if(in[i]=='F')
     F();
     else if(in[i]=='B')
     B();
     else if(in[i]=='L')
     L();
     else if(in[i]=='R')
     R();
     else if(in[i]=='C')
     C();
     else if(in[i]=='D')
     D();
    }
    j[chk]=front;
    top=1;
    left=3;
    right=4;
    front=2;
    back=5;
    base=6;
    chk++;
  }
  for(i=1;i<=dice;i++)
  {
	printf("%d ",j[i]);
  }
  return 0;
}