/*
TASK: SKYLINE
LANG: C
AUTHOR: Witcharkorn Wongputorn
CENTER: haddyai05
*/
#include<stdio.h>

void main()
{
 int blocks;
 unsigned char L[3000]={0},H[3000]={0},R[3000]={0};
 int V[256]={0};
 int i,j,l,h,r;

 scanf("%d",&blocks);

 for (i=0;i<blocks;i++)
 {
  scanf("%d %d %d",&l,&h,&r);
  L[i]=(unsigned char)l;
  H[i]=(unsigned char)h;
  R[i]=(unsigned char)r;
  for (j=L[i];j<R[i];j++)
   if (H[i]>=V[j]) V[j]=H[i];
 }
 for (i=1;i<256;i++)
  if (V[i-1]!=V[i])
  {
   printf("%d ",i);
   printf("%d ",V[i]);
  }
}