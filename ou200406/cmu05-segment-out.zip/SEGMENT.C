/*
TASK: SEGMENT
LANG: C
AUTHOR: Pongsakorn Jaiban
CENTER: CMU05
*/

#include<stdio.h>

int main(void)
{
	char num1[3][30],num2[3][30];
	int len1,len2,cou,i,st,ls;
	float num1,num2,sum;
//ex number
	char exnum[11][4][4];
//exnum
	exnum[0][0][0]=' ';
	exnum[0][0][1]='_';
	exnum[0][0][2]=' ';
	exnum[0][1][0]='|';
	exnum[0][1][1]=' ';
	exnum[0][1][2]='|';
	exnum[0][2][0]='|';
	exnum[0][2][1]='_';
	exnum[0][2][2]='|';
	exnum[1][0][0]=' ';
	exnum[1][0][1]=' ';
	exnum[1][0][2]=' ';
	exnum[1][1][0]=' ';
	exnum[1][1][1]=' ';
	exnum[1][1][2]='|';
	exnum[1][2][0]=' ';
	exnum[1][2][1]=' ';
	exnum[1][2][2]='|';
	exnum[2][0][0]=' ';
	exnum[2][0][1]='_';
	exnum[2][0][2]=' ';
	exnum[2][1][0]=' ';
	exnum[2][1][1]='_';
	exnum[2][1][2]='|';
	exnum[2][2][0]='|';
	exnum[2][2][1]='_';
	exnum[2][2][2]=' ';
	exnum[3][0][0]=' ';
	exnum[3][0][1]='_';
	exnum[3][0][2]=' ';
	exnum[3][1][0]=' ';
	exnum[3][1][1]='_';
	exnum[3][1][2]='|';
	exnum[3][2][0]=' ';
	exnum[3][2][1]='_';
	exnum[3][2][2]='|';
	exnum[4][0][0]=' ';
	exnum[4][0][1]=' ';
	exnum[4][0][2]=' ';
	exnum[4][1][0]='|';
	exnum[4][1][1]='_';
	exnum[4][1][2]='|';
	exnum[4][2][0]=' ';
	exnum[4][2][1]=' ';
	exnum[4][2][2]='|';
	exnum[5][0][0]=' ';
	exnum[5][0][1]='_';
	exnum[5][0][2]=' ';
	exnum[5][1][0]='|';
	exnum[5][1][1]='_';
	exnum[5][1][2]=' ';
	exnum[5][2][0]=' ';
	exnum[5][2][1]='_';
	exnum[5][2][2]='|';
	exnum[6][0][0]=' ';
	exnum[6][0][1]='_';
	exnum[6][0][2]=' ';
	exnum[6][1][0]='|';
	exnum[6][1][1]='_';
	exnum[6][1][2]=' ';
	exnum[6][2][0]='|';
	exnum[6][2][1]='_';
	exnum[6][2][2]='|';
	exnum[7][0][0]=' ';
	exnum[7][0][1]='_';
	exnum[7][0][2]=' ';
	exnum[7][1][0]=' ';
	exnum[7][1][1]=' ';
	exnum[7][1][2]='|';
	exnum[7][2][0]=' ';
	exnum[7][2][1]=' ';
	exnum[7][2][2]='|';
	exnum[8][0][0]=' ';
	exnum[8][0][1]='_';
	exnum[8][0][2]=' ';
	exnum[8][1][0]='|';
	exnum[8][1][1]='_';
	exnum[8][1][2]='|';
	exnum[8][2][0]='|';
	exnum[8][2][1]='_';
	exnum[8][2][2]='|';
	exnum[9][0][0]=' ';
	exnum[9][0][1]='_';
	exnum[9][0][2]=' ';
	exnum[9][1][0]='|';
	exnum[9][1][1]='_';
	exnum[9][1][2]='|';
	exnum[9][2][0]=' ';
	exnum[9][2][1]='_';
	exnum[9][2][2]='|';
//end exnum
	scanf("%d %d\n",&len1,&len2);
	for(st=0;st<3;st++)
		for(i=0;i<len1*3;i++)
			num1[st][i]=getc(stdin);
	for(st=0;st<3;st++)
		for(i=0;i<len2*3;i++)
			num2[st][i]=getc(stdin);
//chk 1
	while(len1!=0)
	{
		if(num1[







	return 0;
}