/*
TASK: SKYLINE
LANG: C
AUTHOR: KAMONPOP JARUJIT
CENTER: KKU06
*/
#include <stdio.h>
int main(){
	int l[3000],h[3000],r[3000];
	int n,i,v[3000]={0};
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %d %d",&l[i],&h[i],&r[i]);
		if(r[i-1]<l[i]){v[i*2]=l[i];}
		v[i*2+1]=h[i];
		v[i*2+2]=r[i];
	}for(i=0;i<n*2+1;i++){printf("%d ",v[i]);}
	printf("0");return 0;
}