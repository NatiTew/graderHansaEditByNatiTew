/*
TASK: BEE
LANG: C
AUTHOR: NATCHAPON ANANTARAMPORN
CENTER: NU05
*/
#include <stdio.h>
int main(void)
{
  int year[24];
  int i,j;
  int a=2,b=1,temp=0;
  for(i=0;year[i]!=-1;i++)
  {
    scanf("%d",&year[i]);
    if(year[i]==-1)
      return 0;
    for(j=1;j<year[i];j++)
    {
      if(year[i]!=1)
      {
	temp=a;
	a=a+b+1;
	b=temp;
      }
    }
    printf("%d %d\n",a,a+b+1);
    a=2;
    b=1;
  }
  return 0;
}