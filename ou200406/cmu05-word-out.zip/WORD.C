/*
TASK: WORD
LANG: C
AUTHOR: Pongsakorn Jaiban
CENTER: CMU05
*/

#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	//data zone
	char data[26][26];
	char word[100][15];
	int longnum[100];
	//normal constant zone
	int x,y,numword,i,wd,len,k,j;

	scanf("%d %d",&y,&x);
	for(i=0;i<y;i++)
	{
		for(j=0;j<x;j++)
		{
			data[i][j]=getc(stdin);
		}
	}
	scanf("%d",&numword);
	for(i=0;i<numword;i++)
	{
		scanf("%s",word[i]);
	}
	for(i=0;i<numword;i++)
	{
		j=0;
		while(word[i][j]!='\n')
		{
		j++;
		}
		longnum[i]=j;
	}

// processing data
	for(wd=0;wd<numword;wd++)
	{
		for(i=0;i<y;i++)
		{
			for(j=0;j<x;j++)
			{
				if(word[wd][0]==data[i][j]||word[wd][0]==data[i][j]+32||word[wd][0]==data[i][j]-32)
				{
					len=longnum[wd];
					k=0;
					while(word[wd][k]==data[i-1][j-1]&&len!=k)
					{
						k++;
					}
					if(len==k)
					{
						printf("%d %d\n",i,j);
					}
				}
				if(len!=k)
				{
					if(word[wd][0]==data[i][j]||word[wd][0]==data[i][j]+32||word[wd][0]==data[i][j]-32)
					{
						len=longnum[wd];
						k=0;
						while(word[wd][k]==data[i-1][j]&&len!=k)
						{
							k++;
						}
						if(len==k)
						{
							printf("%d %d\n",i,j);
						}
					}
				}
				else
				{
				goto part1;
				}
				if(len!=k)
				{
					if(word[wd][0]==data[i][j]||word[wd][0]==data[i][j]+32||word[wd][0]==data[i][j]-32)
					{
						len=longnum[wd];
						k=0;
						while(word[wd][k]==data[i-1][j+1]&&len!=k)
						{
							k++;
						}
						if(len==k)
						{
							printf("%d %d\n",i,j);
						}
					}
				}
				else
				{
				goto part1;
				}
				if(len!=k)
				{
					if(word[wd][0]==data[i][j]||word[wd][0]==data[i][j]+32||word[wd][0]==data[i][j]-32)
					{
						len=longnum[wd];
						k=0;
						while(word[wd][k]==data[i][j-1]&&len!=k)
						{
							k++;
						}
						if(len==k)
						{
							printf("%d %d\n",i,j);
						}
					}
				}
				else
				{
				goto part1;
				}
				if(len!=k)
				{
					if(word[wd][0]==data[i][j]||word[wd][0]==data[i][j]+32||word[wd][0]==data[i][j]-32)
					{
						len=longnum[wd];
						k=0;
						while(word[wd][k]==data[i][j+1]&&len!=k)
						{
							k++;
						}
						if(len==k)
						{
							printf("%d %d\n",i,j);
						}
					}
				}
				else
				{
				goto part1;
				}
				if(len!=k)
				{
					if(word[wd][0]==data[i][j]||word[wd][0]==data[i][j]+32||word[wd][0]==data[i][j]-32)
					{
						len=longnum[wd];
						k=0;
						while(word[wd][k]==data[i+1][j-1]&&len!=k)
						{
							k++;
						}
						if(len==k)
						{
							printf("%d %d\n",i,j);
						}
					}
				}
				else
				{
				goto part1;
				}
				if(len!=k)
				{
					if(word[wd][0]==data[i][j]||word[wd][0]==data[i][j]+32||word[wd][0]==data[i][j]-32)
					{
						len=longnum[wd];
						k=0;
						while(word[wd][k]==data[i+1][j]&&len!=k)
						{
							k++;
						}
						if(len==k)
						{
							printf("%d %d\n",i,j);
						}
					}
				}
				else
				{
				goto part1;
				}
				if(len!=k)
				{
					if(word[wd][0]==data[i][j]||word[wd][0]==data[i][j]+32||word[wd][0]==data[i][j]-32)
					{
						len=longnum[wd];
						k=0;
						while(word[wd][k]==data[i+1][j+1]&&len!=k)
						{
							k++;
						}
						if(len==k)
						{
							printf("%d %d\n",i,j);
						}
					}
				}
				else
				{
				goto part1;
				}
				part1:

			}
		}
	}
	return 0;
}