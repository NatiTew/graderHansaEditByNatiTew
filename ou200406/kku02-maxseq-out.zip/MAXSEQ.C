/*
TASK: MAXSEQ
LANG: C
AUTHOR: KHOMSAN PHONSAI
CENTER: KKU02
*/
#include <stdio.h>
char num[2500]={0};
int n,jum;
check(int i){
	int j,sco=0,max=0;
	for(j=i;j<n;j++){
		sco+=num[j];
		if(sco>max){max=sco;jum=j-i;}
	}
	return max;
}
main(){
	int i,max=0,cmax=0,count=0,score=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&num[i]);
	}
	for(i=0;i<n;i++){
		if(check(i)>cmax) {
			max=i;
			cmax=check(i);
			count=jum;
		}
	}
	if(max==0){printf("Empty sequence");return 0;}
	for(i=max;i<=max+count;i++){
		score+=num[i];
		printf("%d ",num[i]);
	}
	printf("\n%d",score);
	return 0;
}