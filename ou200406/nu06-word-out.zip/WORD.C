/*
TASK: WORD
LANG: C
AUTHOR: THEERAPHONG PHUTHONG
CENTER: nu06
*/
#include<stdio.h>

int main()	{
   int m,n,i,k,j,x=0,jj=0;
   char str[60][60]={NULL},sert[60][60];
   scanf("%d %d",&m,&n);
   for(i=0;i<m;i++){
	scanf("%s",&str[i]);
   }
   scanf("%d",&k);
   for(i=0;i<k;i++){
	scanf("%s",&sert[i]);
   }
    // sert
    for(i=0;i<m;i++){
      for(jj=0;jj<n;jj++){
	for(j=jj;j<n;j++){
	  if(sert[j][i]==str[j][i])
	       x++;
	  else {
		j=n;
	  }
	}
      }
    }

return 0 ;	}