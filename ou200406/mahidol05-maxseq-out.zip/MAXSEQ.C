/*
TASK:MAXSEQ
LANG:C
AUTHOR:Sorawit Paiboonrattanakorn
CENTER:mahidol05
*/

#include<stdio.h>

int main()
{
	int i,a[2501],n,first,last,tfirst,tlast;
	long max,temp;
	int count=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]<=0)
		{
			count++;
			if(max<a[i])
			{
				max=a[i];
			}
		}
	}

	if(count==n)
	{
		printf("Empty sequence\n");
		return 0;
	}
	max=a[0];
	first=0;
	last=0;
	tlast=0;
	tfirst=0;
	temp=max;
	for(i=1;i<n;i++)
	{
		if(temp+a[i]>0)
		{
			temp+=a[i];
			tlast=i;
		}
		else if(temp+a[i]<=0)
		{
			if(temp==max)
			{
				max=0;
				first=i+1;
			}
			temp=0;
			tfirst=i+1;
			tlast=i+1;
		}
		if(temp>max)
		{
			max=temp;
			first=tfirst;
			last=tlast;
		}
	}
	for(i=first;i<=last;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n%ld",max);
	return 0;
}