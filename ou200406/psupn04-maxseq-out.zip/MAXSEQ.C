/*
TASK: MAXSEQ
LANG: C
AUTHOR: Peerasak Rattanamanee
CENTER: psupn04
*/
#include<stdio.h>
void main()
{
	int i=0,max,k,total,mem,num[2500]={0},ex[2500]={0},kx,j,l,m,maxset[2500]={0};
	scanf("%d",&mem);
	while(i!=mem)
	{
		scanf("%d",&num[i]);
		i++;
	}
	max=num[0];
	for(i=0;i<mem;i++)
	{
		ex[0]=num[i];
		for(l=0;l<mem-i;l++)
		{
			total=num[i];
			k=0;
			for(j=i+1;j<i+1+l;j++)
			{
				total+=num[j];
				k++;
				ex[k]=num[j];
			}
			if(total>max)
			{
				max=total;
				for(m=0;m<=k;m++)
				{
					maxset[m]=ex[m];
					kx=k;
				}
			}
		}
	}
	if(max<=0)
		printf("Empty sequence");
	else
	{
		for(i=0;i<=kx;i++)
			printf("%d ",maxset[i]);
		printf("\n%d",max);
	}
}
