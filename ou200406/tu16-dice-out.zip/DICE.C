/*
TASK: DICE
LANG: C
AUTHOR: YONGKICT TAECHAYINGYONGCHAI
CENTER: TU16
*/
#include<stdio.h>
#define top 0
#define front 1
#define left 2
#define back 3
#define right 4
#define bottom 5

char a[5][1000];
int n,i,b[6]={1,2,3,5,4,6},temp;
void forward(void)
{
	temp=b[top];
	b[top]=b[back];
	b[back]=b[bottom];
	b[bottom]=b[front];
	b[front]=temp;
}
void backward(void)
{
	temp=b[top];
	b[top]=b[front];
	b[front]=b[bottom];
	b[bottom]=b[back];
	b[back]=temp;
}
void fleft(void)
{
	temp=b[top];
	b[top]=b[right];
	b[right]=b[bottom];
	b[bottom]=b[left];
	b[left]=temp;
}
void fright(void)
{
	temp=b[top];
	b[top]=b[left];
	b[left]=b[bottom];
	b[bottom]=b[right];
	b[right]=temp;
}
void clockwise(void)
{
	temp=b[front];
	b[front]=b[right];
	b[right]=b[back];
	b[back]=b[left];
	b[left]=temp;
}
void counter(void)
{
	temp=b[front];
	b[front]=b[left];
	b[left]=b[back];
	b[back]=b[right];
	b[right]=temp;
}
int f(int dept,int row)
{
	if(a[dept]==NULL)
		return b[front];
	if(a[dept][row]=='F')
	{
		forward();
		f(dept+1,row);
	}
	else if(a[dept][row]=='B')
	{
		backward();
		f(dept+1,row);
	}
	else if(a[dept][row]=='L')
	{
		 fleft();
		 f(dept+1,row);
	}
	else if(a[dept][row]=='R')
	{
		fright();
		f(dept+1,row);
	}
	else if(a[dept][row]=='C')
	{
		clockwise();
		f(dept+1,row);
	}
	else if(a[dept][row]=='D')
	{
		counter();
		f(dept+1,row);
	}
	return b[front];
}

main()
{
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%s",a[i]);
	for(i=0;i<n;i++)
	{
		b[0]=1; b[1]=2; b[2]=3; b[3]=5; b[4]=4; b[5]=6;
		printf("%d ",f(0,i));
	}
	return 0;
}