/*
TASK: DICE
LANG: C
AUTHOR: KUNAKORN TENGCHIANG
CENTER: NU02
*/

#include<stdio.h>

main(){
 int n,i,dick[7],d,j,ans[7];
 char a;

 scanf("%d",&n);
 scanf("%c",&a);

 for(i=1;i<=n;i++){
	for(j=0;j<6;j++)
		dick[j]=j+1;
	do{
	scanf("%c",&a);
	if((a!='\n')&&(a!='\0')){
	switch(a){
		case 'F':       d=dick[0];
				dick[0]=dick[3];
				dick[3]=dick[5];
				dick[5]=dick[1];
				dick[1]=d;
				break;
		case 'B':       d=dick[0];
				dick[0]=dick[1];
				dick[1]=dick[5];
				dick[5]=dick[3];
				dick[3]=d;
				break;
		case 'L':       d=dick[0];
				dick[0]=dick[4];
				dick[4]=dick[5];
				dick[5]=dick[2];
				dick[2]=d;
				break;
		case 'R':       d=dick[0];
				dick[0]=dick[2];
				dick[2]=dick[5];
				dick[5]=dick[4];
				dick[4]=d;
				break;
		case 'C':       d=dick[1];
				dick[1]=dick[4];
				dick[4]=dick[3];
				dick[3]=dick[2];
				dick[2]=d;
				break;
		case 'D':       d=dick[1];
				dick[1]=dick[2];
				dick[2]=dick[3];
				dick[3]=dick[4];
				dick[4]=d;
				break;
	}
	}
	ans[i-1]=dick[1];
	}while((a!='\n')&&(a!='\0'));
 }
 for(j=0;j<n;j++)
	printf("%d ",ans[j]);
 return 0;
}