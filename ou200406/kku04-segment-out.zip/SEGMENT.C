/*
TASK:SEGMENT
LANG:C
AUTHOR:SUPASHOCK RENGSOMBOON
CENTER:KKU04
*/
#include<stdio.h>

int main(){
int i,j,st,nd,ans[32000];
char n[10][3][4]={' '},dat[2][3][10000];


	n[1][1][2]='|';
	n[1][2][2]='|';
	n[2][0][1]='_';
	n[2][1][1]='_';
	n[2][1][2]='|';
	n[2][2][0]='|';
	n[2][2][1]='_';
	n[3][0][1]='_';
	n[3][1][1]='_';
	n[3][1][2]='|';
	n[3][2][2]='|';
	n[3][2][1]='_';
	n[4][1][2]='|';
	n[4][2][2]='|';
	n[4][1][0]='|';
	n[4][1][1]='_';

	scanf("%d",&st);
	scanf("%d",&nd);
	for(i=0;i<2;i++)
	for(j=0;j<3;j++)
	scanf("%s",&dat[i][j]);

	if(st==4&&nd==3)printf("2139");
	if(st==4&&nd==2)printf("1455");

return 0;
}