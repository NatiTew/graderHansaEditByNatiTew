/*
TASK: BEE
LANG: C
AUTHOR: Suthee Kongkiatpaiboon
CENTER: Mahidol03
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
  long n,i,work,sold,all,ans[25][2];

  n=0;

  work=1;
  sold=0;
  all=work+sold+1;

  for(i=1;i<=24;i++)
    {
       sold=work;
       work=all;
       all=work+sold+1;

       ans[i][0]=work;
       ans[i][1]=all;
    }

  while(n!=-1)
    {
      scanf("%ld",&n);
      if(n!=-1)
      {
	if(n<25)
	  printf("%ld %ld\n",ans[n][0],ans[n][1]);
	else
	  {
	    work=ans[24][0];
	    sold=ans[24][1]-work-1;
	    all=ans[24][1];
	    for(i=25;i<=n;i++)
	      {
		sold=work;
		work=all;
		all=work+sold+1;
	      }
	    printf("%ld %ld\n",work,all);
	  }
      }
    }

  return 0;
}