/*
TASK: DICE
LANG: C
AUTHOR: Sarun Gulyanon
CENTER: tu02
*/

#include<stdio.h>


main()
{
	int num;
	int i,j;
	int x,y,z;
	int temp;
	char dice[7];
	char way[7][1001];
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		scanf("%s",way[i]);
	}
	x = 0;
	y = 0;
	z = 0;
	for(i=0;i<num;i++)
	{
		for(j=0;j<6;j++)
		{
			dice[j] = j+1;
		}
		dice[3] = 5;
		dice[4] = 4;

		for(j=0;way[i][j] != '\0' ; j++)
		{
			switch(way[i][j])
			{
				case 'F':
					x++;
					break;
				case 'B':
					x--;
					break;
				case 'L':
					y++;
					break;
				case 'R':
					y--;
					break;
				case 'C':
					z++;
					break;
				case 'D':
					z--;
					break;
			}
		}
			x %= 4;
			y %= 4;
			z %= 4;

			for(;x > 0;x--)
			{
				temp = dice[0];
				dice[0] = dice[3];
				dice[3] = dice[5];
				dice[5] = dice[1];
				dice[1] = temp;
			}
			for(;x < 0;x++)
			{
				temp = dice[0];
				dice[0] = dice[1];
				dice[1] = dice[5];
				dice[5] = dice[3];
				dice[3] = temp;
			}
			for(;y > 0; y--)
			{
				temp = dice[0];
				dice[0] = dice[4];
				dice[4] = dice[5];
				dice[5] = dice[2];
				dice[2] = temp;
			}
			for(;y < 0; y++)
			{
				temp = dice[0];
				dice[0] = dice[2];
				dice[2] = dice[5];
				dice[5] = dice[4];
				dice[4] = temp;
			}
			for(;z > 0;z--)
			{
				temp = dice[1];
				dice[1] = dice[4];
				dice[4] = dice[3];
				dice[3] = dice[2];
				dice[2] = temp;
			}
			for(;z < 0; z++)
			{
				temp = dice[1];
				dice[1] = dice[2];
				dice[2] = dice[3];
				dice[3] = dice[4];
				dice[4] = temp;
			}

		printf("%d ",dice[1]);
	}
	return 0;
}