/*
TASK: MAXSEQ
LANG: C
AUTHOR: Nuttakorn Benjamasutin (Assumption)
CENTER: tc03
*/
#include <stdio.h>

#define MAX 3001


typedef struct
{
	long is;
	long start;
}TYPE;

long input[MAX];
TYPE dat[MAX];

TYPE Fill(long is, long start)
{
	TYPE temp;
	temp.is=is; temp.start=start;
	return temp;
}
int main()
{
	long n;
	long i, max;
	scanf("%ld",&n);
	for(i=1; i<=n; i++)
		scanf("%ld",&input[i]);
	for(i=1, max=1; i<=n; i++)
	{
		if(input[i] > dat[i-1].is + input[i] || i == 1)
			dat[i]=Fill(input[i], i); // New sequence
		else
			dat[i]=Fill(dat[i-1].is + input[i], dat[i-1].start); // Continue

		if(dat[i].is > dat[max].is)
			max=i;
	}
	if(dat[max].is > 0)
	{
		for(i=dat[max].start; i<=max; i++)
			printf("%ld ",input[i]);
		printf("\n%ld",dat[max].is);
	}
	else printf("Empty sequence");
	return 0;
}