/*
TASK: DICE
LANG: C
AUTHOR: Saranyu Koothanapath
CENTER: tu04
*/
#include<stdio.h>
#include<string.h>
struct dice{
	int top,front,bottom,back,left,right;
}d[2];
int main()
{
	int n;
	int i;
	int len;
	int temp,true;
	char way[1050];
	scanf("%d",&n);
	for(;n>0;--n)
	{
		d[0].top=1;
		d[0].front=2;
		d[0].left=3;
		d[0].bottom=6;
		d[0].right=4;
		d[0].back=5;
		scanf("%s",&way);
		len=strlen(way);
		for(i=0;i<len;++i)
		{
			if(i%2==0){temp=0; true=1;}
			else {temp=1; true=0;}
			if(way[i]=='F')
			{
				d[true].top=d[temp].back;
				d[true].front=d[temp].top;
				d[true].bottom=d[temp].front;
				d[true].back=d[temp].bottom;
				d[true].left=d[temp].left;
				d[true].right=d[temp].right;
			}
			else if(way[i]=='B')
			{
				d[true].top=d[temp].front;
				d[true].front=d[temp].bottom;
				d[true].bottom=d[temp].back;
				d[true].back=d[temp].top;
				d[true].left=d[temp].left;
				d[true].right=d[temp].right;
			}
			else if(way[i]=='R')
			{
				d[true].top=d[temp].left;
				d[true].left=d[temp].bottom;
				d[true].bottom=d[temp].right;
				d[true].right=d[temp].top;
				d[true].front=d[temp].front;
				d[true].back=d[temp].back;
			}
			else if(way[i]=='L')
			{
				d[true].top=d[temp].right;
				d[true].left=d[temp].top;
				d[true].bottom=d[temp].left;
				d[true].right=d[temp].bottom;
				d[true].front=d[temp].front;
				d[true].back=d[temp].back;
			}
			else if(way[i]=='D')
			{
				d[true].top=d[temp].top;
				d[true].left=d[temp].back;
				d[true].bottom=d[temp].bottom;
				d[true].right=d[temp].front;
				d[true].front=d[temp].left;
				d[true].back=d[temp].right;
			}
			else if(way[i]=='C')
			{
				d[true].top=d[temp].top;
				d[true].left=d[temp].front;
				d[true].bottom=d[temp].bottom;
				d[true].right=d[temp].back;
				d[true].front=d[temp].right;
				d[true].back=d[temp].left;
			}
		}
		/*
		printf("%d\n",d[true].top);
		printf("%d\n",d[true].front);
		printf("%d\n",d[true].left);
		printf("%d\n",d[true].back);
		printf("%d\n",d[true].right);
		printf("%d\n",d[true].bottom);
		*/
                printf("%d ",d[true].front);
	}
	return 0;
}
