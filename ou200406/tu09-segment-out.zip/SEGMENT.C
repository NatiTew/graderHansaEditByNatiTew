/*
TASK: SEGMENT
LANG: C
AUTHOR: Vanus Vachiratamporn
CENTER: TU09
*/
#include<stdio.h>

int main(void)
{   int x,y,i,j,t;
    char arr[11][3][3],arr2[11][3][3];
    long ans1=0,ans2=0;
    scanf("%d",&x);
    scanf("%d",&y);
    while(getchar()!='\n');
    for(i=0;i<3;i++)
       {
	   for(j=0;j<x;j++)
	      {
		  arr[j][i][0]=getchar();
		  arr[j][i][1]=getchar();
		  arr[j][i][2]=getchar();
		  t=getchar();
	      }
       }
    for(i=0;i<3;i++)
       {   for(j=0;j<y;j++)
	      {   arr2[j][i][0]=getchar();
		  arr2[j][i][1]=getchar();
		  arr2[j][i][2]=getchar();
		  t=getchar();
	      }
       }
    for(i=x-1,j=1;i>=0;i--,j*=10)
       {   if(arr[i][0][1]=='_')
	     {   if(arr[i][1][0]=='|')
		   {   if(arr[i][1][2]=='|')
			 {   if(arr[i][2][0]=='|')
			       t=8;
			     else if(arr[i][1][1]==' ')
			       t=0;
			     else
			       t=9;
			 }
		       else
			 {   if(arr[i][2][0]=='|')
			       t=6;
			     else
			       t=5;
			 }
		   }
		 else
		   {   if(arr[i][2][0]=='|')
			 t=2;
		       else if(arr[i][1][1]=='_')
			 t=3;
		       else
			 t=7;
		   }
	     }
	   else
	     {   if(arr[i][1][0]=='|')
		   t=4;
		 else
		   t=1;
	     }
	   ans1=ans1+(t*j);
       }
    for(i=y-1,j=1;i>=0;i--,j*=10)
       {   if(arr2[i][0][1]=='_')
	     {   if(arr2[i][1][0]=='|')
		   {   if(arr2[i][1][2]=='|')
			 {   if(arr2[i][2][0]=='|')
			       t=8;
			     else if(arr2[i][1][1]==' ')
			       t=0;
			     else
			       t=9;
			 }
		       else
			 {   if(arr2[i][2][0]=='|')
			       t=6;
			     else
			       t=5;
			 }
		   }
		 else
		   {   if(arr2[i][2][0]=='|')
			 t=2;
		       else if(arr2[i][1][1]=='_')
			 t=3;
		       else
			 t=7;
		   }
	     }
	   else
	     {   if(arr2[i][1][0]=='|')
		   t=4;
		 else
		   t=1;
	     }
	   ans2=ans2+(t*j);
       }
    printf("%ld",ans1+ans2);
    return 0;
}