#include<stdio.h>
/*
TASK: WORD
LANG: C
AUTHOR: Prayook Jatesiktat
CENTER: mahidol04
*/
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
void main()
{
   char **a,**find;
   int n,m,f,l,i,j,k,x,y,p;
   scanf("%d%d",&n,&m);
   a=(char **)malloc(sizeof(char *)*n);
   for(i=0;i<n;i++)
   {
      a[i]=(char *)malloc(sizeof(char)*m);
   }
   for(i=0;i<n;i++)
     scanf("%s",a[i]);
   for(i=0;i<n;i++)
   {
      for(j=0;j<n;j++)
      {
	 if(isupper(a[i][j]))
	  tolower(a[i][j]);
      }
   }
   scanf("%d",&f);
   a=(char **)malloc(sizeof(char *)*f);
   for(i=0;i<f;i++)
   {
      find[i]=(char *)malloc(sizeof(char)*16);
   }
   for(i=0;i<f;i++)
   {
     scanf("%s",find[i]);
     l=strlen(find[i]);
     for(j=0;j<l;j++)
     {
       if(isupper(find[i][j]))
	tolower(find[i][j]);
     }
   }
   for(k=0;k<f;k++)
   {
      l=strlen(find[k]);
      for(i=0;i<n;i++)
      {
	 for(j=0;j<m;j++)
	 {
	    p=0;
	    x=i;
	    y=j;
	    while(find[k][p]==a[x][y])
	    {
	       p++;
	       y++;
	       if(p==l)
	       {
		 printf("%d %d\n",i,j);
		 goto next;
	       }
	    }
	    p=0;
	    x=i;
	    y=j;
	    while(find[k][p]==a[x][y])
	    {
	       p++;
	       y--;
	       if(p==l)
	       {
		 printf("%d %d\n",i,j);
		 goto next;
	       }
	    }
	    p=0;
	    x=i;
	    y=j;
	    while(find[k][p]==a[x][y])
	    {
	       p++;
	       x++;
	       if(p==l)
	       {
		 printf("%d %d\n",i,j);
		 goto next;
	       }
	    }
	    p=0;
	    x=i;
	    y=j;
	    while(find[k][p]==a[x][y])
	    {
	       p++;
	       x--;
	       if(p==l)
	       {
		 printf("%d %d\n",i,j);
		 goto next;
	       }
	    }
	    p=0;
	    x=i;
	    y=j;
	    while(find[k][p]==a[x][y])
	    {
	       p++;
	       x--;
	       y++;
	       if(p==l)
	       {
		 printf("%d %d\n",i,j);
		 goto next;
	       }
	    }
	    p=0;
	    x=i;
	    y=j;
	    while(find[k][p]==a[x][y])
	    {
	       p++;
	       x++;
	       y++;
	       if(p==l)
	       {
		 printf("%d %d\n",i,j);
		 goto next;
	       }
	    }
	    p=0;
	    x=i;
	    y=j;
	    while(find[k][p]==a[x][y])
	    {
	       p++;
	       x++;
	       y--;
	       if(p==l)
	       {
		 printf("%d %d\n",i,j);
		 goto next;
	       }
	    }
	    p=0;
	    x=i;
	    y=j;
	    while(find[k][p]==a[x][y])
	    {
	       p++;
	       x--;
	       y--;
	       if(p==l)
	       {
		 printf("%d %d\n",i,j);
		 goto next;
	       }
	    }
	 }
      }
      next:
   }
}