/*
TASK: BEE
LANG: C
AUTHOR: Veerakorn Poonsilp
CENTER: PSUPN05
*/
#include<stdio.h>
void main(){
 int soldier=1,workbee=1,i,time,total,item1,item2;
 scanf("%d",&time);
 for(i=1;i<=time;i++){
    item1=soldier;
    item2=workbee;
    workbee+=1+item1+2*item2;
    soldier+=2*item2;
    soldier-=item1;
    workbee-=item2;
 }
 total=1+soldier+workbee;
 printf("%d\n%d\n",workbee,total);
}