/*
TASK: BEE
LANG: C
AUTHOR: CHANTAT EKSOMBATCHAI
CENTER: TU06
*/
#include<stdio.h>
main()
{
	long tmp,soilder,worker,i,ts,tw;
	for(;;)
	{
		scanf("%ld",&tmp);
		if(tmp==-1)
			break;
		worker=1;soilder=0;
		for(i=0;i<tmp;i++)
		{
			ts = soilder;
			tw = worker;
			soilder = tw;
			worker = ts+tw+1;
		}
		printf("%ld %ld\n",worker,worker+soilder+1);
	}
	return 0;
}


