/*
TASK: SEQMENT
LANG: C
AUTHOR: Suthee Kongkiatpaiboon
CENTER: Mahidol03
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
  int n1,n2,i,j,shift;
  double num1,num2;
  char a1[4][50]={{0}};

//  FILE *fi;
//  fi=fopen("c:\\posn2\\seq1.in","r");
//  fi=stdin;

  num1=0.0;
  num2=0.0;

  scanf("%d %d",&n1,&n2);

  for(i=0;i<4;i++)
    {
      j=0;
      while(a1[i][j]!='\n')
	{
	  j++;
	  scanf("%c",&a1[i][j]);
	  if(a1[i][j]!=' ')
	   if(a1[i][j]!='_')
	    if(a1[i][j]!='\n')
	     a1[i][j]='|';

	}
    }

  for(i=0;i<n1;i++)
    {
       if(i==0)
	 shift=0;
       else
	 shift=i*4;


       if( a1[2][shift+2] == ' ')
	 {
	   if( a1[1][shift+2] == ' ')
	     {
	       num1=num1*10+1;
	     }
	   else if( a1[3][shift+2] == '_')
	     {
	       num1=num1*10;
	     }
	   else num1=num1*10+7;
	 }
       else if( a1[3][shift+1] == '|')
	 {
	   if( a1[2][shift+1] == ' ')
	     num1=num1*10+2;
	   else if( a1[2][shift+3] == '|')
	     num1=num1*10+8;
	   else num1=num1*10+6;
	 }
       else if( a1[1][shift+2] == '_')
	 {
	   if( a1[2][shift+1] == ' ')
	     num1=num1*10+3;
	   else if( a1[2][shift+3] == '|')
	     num1=num1*10+9;
	   else num1=num1*10+5;
	 }
       else num1=num1*10+4;
    }
  num2=num1;
  num1=0.0;
  for(i=0;i<3;i++)
    {
      j=0;
      while(a1[i][j]!='\n')
	{
	  j++;
	  scanf("%c",&a1[i][j]);
	}
    }

  for(i=0;i<n2;i++)
    {
       if(i==0)
	 shift=0;
       else
	 shift=i*4;


       if( a1[1][shift+2] == ' ')
	 {
	   if( a1[0][shift+2] == ' ')
	     {
	       num1=num1*10+1;
	     }
	   else if( a1[2][shift+2] == '_')
	     {
	       num1=num1*10;
	     }
	   else num1=num1*10+7;
	 }
       else if( a1[2][shift+1] == '|')
	 {
	   if( a1[1][shift+1] == ' ')
	     num1=num1*10+2;
	   else if( a1[1][shift+3] == '|')
	     num1=num1*10+8;
	   else num1=num1*10+6;
	 }
       else if( a1[0][shift+2] == '_')
	 {
	   if( a1[1][shift+1] == ' ')
	     num1=num1*10+3;
	   else if( a1[1][shift+3] == '|')
	     num1=num1*10+9;
	   else num1=num1*10+5;
	 }
       else num1=num1*10+4;
    }

  printf("%.0f",num1+num2);


  return 0;
}