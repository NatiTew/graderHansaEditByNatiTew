/*
TASK: WORD
LANG: C
AUTHOR: CHANTAT EKSOMBATCHAI
CENTER: TU06
*/
#include<Stdio.h>
#include<string.h>
main()
{
	int n,m,i,j,x,y,number,posx,posy,len,flag,found;
	char a[30][30],tmp[30];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%s",a[i]);
		for(j=0;j<m;j++)
		{
			if((a[i][j] <= 90)&&(a[i][j]>=65))
				a[i][j] = a[i][j] + 32;
		}

	}

	scanf("%d",&number);
	for(i=0;i<number;i++)
	{
		scanf("%s",tmp);
		len = strlen(tmp);
		for(j=0;j<len;j++)
		{
			if((tmp[j] <=90)&&(tmp[j]>=65))
				tmp[j] = tmp[j] + 32;
		}
		found=0;
		for(x=0;x<n;x++)
		{
			for(y=0;y<m;y++)
			{
				if(a[x][y] == tmp[0])
				{
					flag=0;
					for(j=0;j<len;j++)
					{
						if((a[x][y+j] != tmp[j])||(y+j>=m))
						{
							flag=1;
							break;
						}
					}
					if(flag==0)
					{
						posx=x;
						posy=y;
						found=1;
					}
					flag=0;
					for(j=0;j<len;j++)
					{
						if((a[x+j][y] != tmp[j])||(x+j>=n))
						{
							flag=1;
							break;
						}
					}
					if(flag==0)
					{
						posx=x;
						posy=y;
						found=1;
					}
					flag=0;
					for(j=0;j<len;j++)
					{
						if((a[x][y-j] != tmp[j])||(y-j<0))
						{
							flag=1;
							break;
						}
					}
					if(flag==0)
					{
						posx=x;
						posy=y;
						found=1;
					}
					flag=0;
					for(j=0;j<len;j++)
					{
						if((a[x-j][y] != tmp[j])||(x-j<0))
						{
							flag=1;
							break;
						}
					}
					if(flag==0)
					{
						posx=x;
						posy=y;
						found=1;
					}
					flag=0;
					for(j=0;j<len;j++)
					{
						if((a[x+j][y+j] != tmp[j])||(x+j>=n)||(y+j>=m))
						{
							flag=1;
							break;
						}
					}
					if(flag==0)
					{
						posx=x;
						posy=y;
						found=1;
					}
					flag=0;
					for(j=0;j<len;j++)
					{
						if((a[x+j][y-j] != tmp[j])||(x+j>=n)||(y-j<0))
						{
							flag=1;
							break;
						}
					}
					if(flag==0)
					{
						posx=x;
						posy=y;
						found=1;
					}
					flag=0;
					for(j=0;j<len;j++)
					{
						if((a[x-j][y+j] != tmp[j])||(x-j<0)||(y+j>=m))
						{
							flag=1;
							break;
						}
					}
					if(flag==0)
					{
						posx=x;
						posy=y;
						found=1;
					}
					flag=0;
					for(j=0;j<len;j++)
					{
						if((a[x-j][y-j] != tmp[j])||(x-j<0)||(y-j<0))
						{
							flag=1;
							break;
						}
					}
					if(flag==0)
					{
						posx=x;
						posy=y;
						found=1;
					}
				}
				if(found==1)
					break;
			}
			if(found==1)
				break;
		}
		printf("%d %d\n",posx,posy);
	}
	return 0;
}

