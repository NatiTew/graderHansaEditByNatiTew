/*
TASK:BEE
LANG:C
AUTHOR:SUTTIKORN POTHONGKOM
CENTER:SU05
*/
#include<stdio.h>
int s,e,ans[2];     //0=work 1=sum
void year(int y)
{
	switch(y)
	{
		case 1:	ans[0]+=2;	ans[1]+=4;
			printf("%d %d\n",ans[0],ans[1]);   break;
		case 2:	ans[0]+=5;	ans[1]+=8;
			printf("%d %d\n",ans[0],ans[1]);   break;
		case 3:	ans[0]+=6;	ans[1]+=10;
			printf("%d %d\n",ans[0],ans[1]);   break;
	}
}
int main()
{
	int i,nul,y;
	scanf("%d %d %d",&s,&e,&nul);
	for(i=s;i<e;i++)
	{
		y=i;
		year(y);
	}
	return 0;
}
