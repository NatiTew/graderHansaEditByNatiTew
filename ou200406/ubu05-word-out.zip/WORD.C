/*
TASK: WORD
LANG: C
AUTHOR: Withee Pongsawadarn
CENTER: UBU05
*/

#include<stdio.h>
#include<ctype.h>
#include<string.h>



int main(int argc, char *argv[])
{
	int row,cols,i,j,num,k,l, size,round;
	char data[25][25],keyw[100][15],bing[100][15];	

	FILE *fp = fopen(argv[1],"r+t");


	fscanf(fp,"%d%d",&row,&cols);
	for(i=0; i<row; i++)
	{
		fscanf(fp,"%s",data[i]);
		for(j=0; j<strlen(data[i]);j++)
		{
		 data[i][j] = toupper(data[i][j]);
		}
		

		//printf("%s\n",data[i]);
	}
/*-----------------------------------------------------------------------------------*/
	fscanf(fp,"%d",&num);
	for(i=0; i<num; i++)
	{
		fscanf(fp,"%s",keyw[i]);
		for(j=0; j<strlen(keyw[i]);j++)
		{
		 keyw[i][j] = toupper(keyw[i][j]);
		}
		

		//printf("%s\n",keyw[i]);
	}
/*---------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------*/
for(i=0; i<row; i++)
{
	k=j=0;
	size = strlen(keyw[i]);
	
	
		if(keyw[i][j] == data[k][j] ) 	
		{
			if(keyw[i][j+1] == data[k+1][j])//top
			{
				for(round=0; round<size; round++)
				{bing[i][round] = data[k][round];
				bing[i][round+1]=data[k+1][round]; k++;}
				if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
				else{j++; i--;}
			}
			else if(keyw[i][j+1] == data[k][j-1])//left
			{
				for(round=0; round<size; round++)
				{bing[i][round] = data[k][round];
				bing[i][round+1]=data[k][round-1];}
				if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
				else{j++; i--;}
			}
			else if(keyw[i][j+1] == data[k][j+1])//right
			{
				for(round=0; round<size; round++)
				{bing[i][round] = data[k][round];
				bing[i][round+1]=data[k][round+1]; k++;}
				if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
				else{j++; i--;}
			}
		
		}
		else
		{j++;}
		/*else if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[i][j+1])   //right
		{
			for(round=0; round<size; round++)
			{
				bing[i][round] = data[k][round];
				bing[i][round+1]=data[k][round-1];
				
			}
		
		}




	
}


*/
/*----------------------------------------------------------------------------------*/
/*	//i = j = k =0;
//	while(i != row && j != cols)
	for(i=0; i<row; i++)
	{	//k=i;
		if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[i-1][j]) 	//top
		{
			for(round=i; round>=0; round--)
			{	//if(keyw[round][j+1]==data[round-1][j])
				//{
					bing[i][j] = data[i][j];
					bing[i][j+1] = data[i-1][j];
					//i--;
				//}
				//else{break;}
			}
			if(keyw==bing)
				{
					printf("%d %d",i,j);
			}
			else{j++; i--;}
			//i++;
			//j++; 
		}
		else if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[i][j+1])   //right
		{
			for(round=i; round>=0; round--)
			{	//if(keyw[i][j+1]==data[i][j+1])
				//{
					bing[i][j] = data[i][j];
					bing[i][j+1] = data[i-1][j];
				//}
				//else{break;}
			}
			if(keyw==bing)
				{
					printf("%d %d",i,j);
			}
			else{j++; i--;}
		}
		else if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[k][j-1]) //left
		{
			for(round=i; round>=0; round--)
			{//	if(keyw[i][j+1]==data[i-1][j])
			//	{
					bing[i][j] = data[k][j];
					bing[i][j+1] = data[k-1][j];
			//	}
			//	else{break;}
			}
			if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
			else{j++; i--;}
		}
		if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[k+1][j])	//down
		{
			for(round=i; round>=0; round--)
			{	//if(keyw[i][j+1]==data[i-1][j])
				//{
					bing[i][j] = data[k][j];
					bing[i][j+1] = data[k-1][j];
				//}
				//else{break;}
			}
			if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
			else{j++; i--;}
			
		}
		if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[k-1][j+1])	//tright
		{
			for(round=i; round>=0; round--)
			{	//if(keyw[i][j+1]==data[i-1][j])
			//	{
					bing[i][j] = data[k][j];
					bing[i][j+1] = data[k-1][j];
			//	}
			//	else{break;}
			}
			if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
			else{j++; i--;}
			
		}
		if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[k-1][j-1])	//tleft
		{
			for(round=i; round>=0; round--)
			{//	if(keyw[i][j+1]==data[i-1][j])
			//	{
					bing[i][j] = data[k][j];
					bing[i][j+1] = data[k-1][j];
			//	}
			//	else{break;}
			}
			if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
			else{j++; i--;}
			
		}
		if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[k+1][j+1])	//dright
		{
			for(round=i; round>=0; round--)
			{//	if(keyw[i][j+1]==data[i-1][j])
			//	{
					bing[i][j] = data[k][j];
					bing[i][j+1] = data[k-1][j];
			//	}
			//	else{break;}
			}
			if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
			else{j++; i--;}
			
		}
		if(keyw[i][j] == data[i][j] && keyw[i][j+1]==data[k-1][j-1])	//dleft
		{
			for(round=i; round>=0; round--)
			{	//if(keyw[i][j+1]==data[i-1][j])
			//	{
					bing[i][j] = data[k][j];
					bing[i][j+1] = data[k-1][j];
			//	}
			//	else{break;}
			}
			if(keyw==bing)
				{
					printf("%d %d",i,j);
				}
				else{j++; i--;}
		}   */
	}



fclose(fp);
return 0;
}

