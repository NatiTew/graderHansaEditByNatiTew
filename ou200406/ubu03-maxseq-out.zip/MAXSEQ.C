/*
TASK: MAXSEQ
LANG: C
AUTHOR: THAWATCHAI MUKMANEE
CENTER: ubu03
*/
#include <stdio.h>
int main()
{
long max2,min=0;
int max[2500],num[2];
int i,j,n;
scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	scanf("%d",&max[i]);
	}
		max2=0;
		for(i=0;i<n;i++)
		{
		min=0;
			if(max[i]>=0)
			{
			j=i;
			 while(j<n)
			 {
			      min=min+max[j];
			      if(max2<=min)
			      {
			      max2=min;
			      num[0]=i;
			      num[1]=j;
			      }
			 j++;
			 }
			}
		  }
	if(max2>0)
	{
		while(num[0]<=num[1])
		{
		printf("%d",max[num[0]]);
		if(num[0]==num[1])
		printf("\n");
		else
		printf(" ");

		num[0]=num[0]+1;
		}
		printf("%ld\n",max2);
	}
	else
	printf("Empty sequence\n");
	return 0;
}