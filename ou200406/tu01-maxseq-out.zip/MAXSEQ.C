/*
TASK: MAXSEQ
LANG: C
AUTHOR: PANOT CHAIMONGKOL
CENTER: TU01
*/

#include <stdio.h>

void main()
{
	int n;
	char num[2500],empty=1;
	int i,j,I,J;
	long sum,max;
	scanf("%d",&n);
	for (i=0;i<n;i++)
	{
		scanf("%d",&num[i]);
		if (num[i]>0)
			empty=0;
	}
	if (empty)
	{
		printf("Empty sequence");
		return;
	}
	max = num[0];
	I=J=0;
	for (i=0;i<n;i++)
	{
		sum=0;
		for (j=i;j<n;j++)
		{
			sum+=num[j];
			if (sum>max)
			{
				max = sum;
				I = i;
				J = j;
			} //if
		} //sum
	} //for
	for (i=I;i<=J;i++)
		printf("%d ",num[i]);
	printf("\n%ld",max);
} //main