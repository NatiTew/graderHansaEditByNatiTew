/*
TASK: BEE
LANG: C
AUTHOR: ISRANU SAENGSUWAN
CENTER: SAMSEN18
*/
#include <stdio.h>

main()
{
	int input[30];
	int year=0, worker=1, soldier=0;
	int workernew, soldiernew, workerdead, soldierdead, maxyear=0;
	int maxdata=0, i, j;
	maxyear = 0;
	while (input[maxdata-1] != -1)
	{
		scanf ("%d", &input[maxdata]);
		if (input[maxdata]>maxyear) maxyear = input[maxdata];
		maxdata++;
	}
	maxdata--;
	for (i=0;i<maxyear;i++)
	{
		workernew = 0;
		soldiernew = 0;
		workerdead = 0;
		soldierdead = 0;
		//Worker
		for (j=0;j<worker;j++)
		{
			soldiernew++;
			workernew++;
			if (worker>0) workerdead++;
		}
		//Soldier
		for (j=0;j<soldier;j++)
		{
			workernew++;
			if (soldier>0) soldierdead++;
		}
		//Queen
		workernew++;
		worker += workernew;
		worker -= workerdead;
		soldier += soldiernew;
		soldier -= soldierdead;
		year++;
		for (j=0;j<maxdata;j++)
			if (input[j]==year)
				printf ("%d %d\n", worker, worker+soldier+1);
	}
	return 0;
}