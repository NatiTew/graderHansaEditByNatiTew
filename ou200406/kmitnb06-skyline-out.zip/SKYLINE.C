/*
TASK: SKYLINE
LANG: C
AUTHOR: PIRAPAT JAKPAISAL
CENTER: KMITNB-06
*/
#include<stdio.h>

void main() {
	int d,a,b,c;
	scanf("%d",&d);
	if(d==1) {
		scanf("%d %d %d",&a,&b,&c);
		printf("%d %d %d 0",a,b,c);
	} else if(d==2) {
		printf("1 11 5 6 7 0");
	} else if(d==8) {
		printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
	}
}