/*
TASK: BEE
LANG: C
AUTHOR: PANOT CHAIMONGKOL
CENTER: TU01
*/

#include <stdio.h>

void main()
{
	long w[25],m[25],t;
	int y,i;
	w[0]=1;
	m[0]=0;
	for (i=1;i<=24;i++)
	{
		w[i] = w[i-1]+m[i-1]+1;
		m[i] = w[i-1];
	} //for
	scanf("%d",&y);
	while (y!=-1)
	{
		t = w[y]+m[y]+1;
		printf("%ld %ld\n",w[y],t);
		scanf("%d",&y);
	} //while
} //main