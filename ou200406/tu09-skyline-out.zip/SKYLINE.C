/*
TASK: SKYLINE
LANG: C
AUTHOR: Vanus Vachiratamporn
CENTER: TU09
*/
#include<stdio.h>

void swap(int *a,int *b)
{   int t;
    t=*a;
    *a=*b;
    *b=t;
}

int main(void)
{   int n,L[3001],H[3001],R[3001],i,j,skyline[6001][2],s,ch;
    scanf("%d",&n);
    for(i=0;i<n;i++)
       {   scanf("%d",&L[i]);
	   scanf("%d",&H[i]);
	   scanf("%d",&R[i]);
       }
    for(i=0;i<n;i++)
       for(j=i+1;j<n;j++)
	  {   if(L[i]>L[j])
		{   swap(&L[i],&L[j]);
		    swap(&H[i],&H[j]);
		    swap(&R[i],&R[j]);
		}
	  }
    skyline[0][0]=L[0];
    skyline[0][1]=H[0];
    for(i=0,s=1,ch=1;ch!=0;)
       {   for(j=i+1,ch=0;j<n;j++)
	      {   if(R[i]>L[j]&&H[i]<H[j])
		    {   skyline[s][0]=L[j];
			skyline[s][1]=H[j];
			s++;
			i=j;
			ch=1;
			break;
		    }
	      }
	   if(ch==0)
	      {   for(j=i-1,ch=0;j<n;j++)
		     {   if(L[j]>L[i]&&L[j]<=R[i]&&R[j]>R[i]&&H[j]<H[i])
			   {    skyline[s][0]=R[i];
				skyline[s][1]=H[j];
				s++;
				i=j;
				ch=1;
				break;
			   }
		     }
	      }
	   if(ch==0)
	      {    skyline[s][0]=R[i];
		   skyline[s][1]=0;
		   s++;
		   for(j=i+1,ch=0;j<n;j++)
		      {   if(L[j]>R[i])
			    {   skyline[s][0]=L[j];
				skyline[s][1]=H[j];
				s++;
				i=j;
				ch=1;
				break;
			    }
		      }
	      }
       }
    for(i=0;i<s;i++)
       {   if(i!=0)
	     printf(" ");
	   printf("%d %d",skyline[i][0],skyline[i][1]);
       }
    return 0;
}