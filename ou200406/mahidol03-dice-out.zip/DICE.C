/*
TASK: DICE
LANG: C
AUTHOR: Suthee Kongkiatpaiboon
CENTER: Mahidol03
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
  int n,i,len,j,now,a[6][6]={{0}};
  char s[1010]={0};

  a[0][0]=5;
  a[0][1]=2;
  a[0][2]=4;
  a[0][3]=3;
  a[0][4]=1;
  a[0][5]=1;

  a[1][0]=1;
  a[1][1]=6;
  a[1][2]=2;
  a[1][3]=2;
  a[1][4]=4;
  a[1][5]=3;

  a[2][0]=3;
  a[2][1]=3;
  a[2][2]=1;
  a[2][3]=6;
  a[2][4]=2;
  a[2][5]=5;

  a[3][0]=4;
  a[3][1]=4;
  a[3][2]=6;
  a[3][3]=1;
  a[3][4]=5;
  a[3][5]=2;

  a[4][0]=6;
  a[4][1]=1;
  a[4][2]=5;
  a[4][3]=5;
  a[4][4]=3;
  a[4][5]=4;

  a[5][0]=2;
  a[5][1]=5;
  a[5][2]=3;
  a[5][3]=4;
  a[5][4]=6;
  a[5][5]=6;

  scanf("%d",&n);

  for(i=0;i<n;i++)
    {
      scanf("%s",s);
      now=1;

      len=strlen(s);

      for(j=0;j<len;j++)
	{
	  if(s[j]=='F')
	    now=a[now][0]-1;
	  else if(s[j]=='B')
	    now=a[now][1]-1;
	  else if(s[j]=='L')
	    now=a[now][2]-1;
	  else if(s[j]=='R')
	    now=a[now][3]-1;
	  else if(s[j]=='C')
	    now=a[now][4]-1;
	  else if(s[j]=='D')
	    now=a[now][5]-1;
	}
      if(i==0)
       printf("%d",now+1);
      else printf(" %d",now+1);
    }


  return 0;
}
