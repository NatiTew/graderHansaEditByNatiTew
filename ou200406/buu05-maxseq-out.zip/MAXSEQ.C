/*
TASK: MAXSEQ
LANG: C
AUTHOR: Napat Hataivichian
CENTER: buu05
*/
#include <stdio.h>
#include <stdlib.h>

int sort_function(const void *a,const void *b);

int main (void)
{
 int r,*num,i,*ans,j,k=0,l,tmp[2],sum,bre=0,n;
  scanf("%d",&r);
  num = (int *)malloc(sizeof(int)*r);
  ans = (int *)malloc(sizeof(int)*(((1+(r-1))*r-1)/2));
  for(i=0;i<r;i++)
	 scanf("%d",&num[i]);
  for(i=0;i<r;i++)
	 for(j=i+1;j<r;j++)
	  {
		ans[k] = 0;
		for(l=i;l<=j;l++)
		  ans[k] = ans[k] + num[l];
		k++;
	  }
  qsort((void *)ans,k,sizeof(int),sort_function);
  for(i=0;i<r;i++)
	{
	 if(bre == 1)
		break;
	 for(j=i+1;j<r;j++)
	  {
		sum = 0;
		if(bre == 1)
		  break;
		for(l=i;l<=j;l++)
		 {
		  sum = sum + num[l];
		  if(sum == ans[k-1])
			{
			 tmp[0] = i;
			 tmp[1] = j;
			 bre = 1;
			 break;
			}
		 }
	  }
	}
  if(ans[k-1] < 1)
	 printf("Empty sequence");
  else
	{
	 for(n=tmp[0];n<=tmp[1];n++)
		printf("%d ",num[n]);
	 printf("\n%d",ans[k-1]);
	}
 return 0;
}

int sort_function(const void *a,const void *b)
{
  return *(int *)a - *(int *)b;
}