/*
TASK: BEE
LANG: C
AUTHOR: Songkiet Kunopakarnphan
CENTER: cmu02
*/

#include<stdio.h>

int main()
{
	int work,q,sod,order,i,keep,keep2,again;
	while(order!=-1)
	{
		scanf("%d",&order);
		if(order==-1)
			return 0;
		q=work=1;
		sod=0;
		for(i=0;i<order;i++)
		{
			keep=work;
			if(q>0)
			{
				work=work+q;
			}
			keep2=sod;
			if(keep>0)
			{
				sod=sod+keep;
			}
			if(keep2>0)
			{
				work=work+keep2;
				sod=sod-keep2;
			}

		}
		printf("%d %d\n",work,q+work+sod);
	}
	return 0;
}