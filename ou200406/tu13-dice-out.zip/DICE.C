/*
TASK: DICE
LANG: C
AUTHOR: Supawan Phuangphairoj
CENTER: tu13
*/

#include<stdio.h>
#include<stdlib.h>

int a[10],ans[10],n;
char word[1005];

void swapf()
{
	int z;
	z = a[1];
	a[1] = a[4];	a[4] = a[6];
	a[6] = a[2];	a[2] = z;
	return;		}
void swapb()
{
	int z;
	z = a[1];
	a[1] = a[2];	a[2] = a[6];
	a[6] = a[4];	a[4] = z;
	return;		}
void swapl()
{
	int z;
	z = a[1];
	a[1] = a[5];	a[5] = a[6];
	a[6] = a[3];	a[3] = z;
	return;		}
void swapr()
{
	int z;
	z = a[1];
	a[1] = a[3];	a[3] = a[6];
	a[6] = a[5];	a[5] = z;
	return;		}
void swapc()
{
	int z;
	z = a[2];
	a[2] = a[5];	a[5] = a[4];
	a[4] = a[3];	a[3] = z;
	return;		}
void swapd()
{
	int z;
	z = a[2];
	a[2] = a[3];	a[3] = a[4];
	a[4] = a[5];	a[5] = z;
	return;		}

void process(int j)
{       int i;
	for(i=0;i<strlen(word);i++)
	{
		switch (word[i])
		{
			case 'F' : swapf();	break;
			case 'B' : swapb();	break;
			case 'L' : swapl();	break;
			case 'R' : swapr();	break;
			case 'C' : swapc();	break;
			case 'D' : swapd();	break;
		}
	}
	ans[j] = a[2];
	return;
}

void set()
{       char i;
	for(i=1;i<=3;i++)
	{	a[i] = i;	}
	a[4] = 5;
	a[5] = 4;
	a[6] = 6;
}
int main()
{       int i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{       set();
		scanf("%s",&word[0]);
		process(i);
	}
	for(i=0;i<n;i++)
	{	printf("%d ",ans[i]);	}
	return 0;
}