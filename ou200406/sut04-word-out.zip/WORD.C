/*
TASK: WORD
LANG: C
AUTHER: Pattaravut Maleehuan
CENTER: SUT04
*/
#include<stdio.h>
#include<ctype.h>
#include<string.h>
char data[26][26];
char ans[100][17];

int mark[26][26];
int tack[100][2];

int w,i,j,t,u,n,m,k;

int search(int);
int think(int,int,int,int);


void main()
{
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
		scanf("%s",data[i]);
	scanf("%d",&k);
	for(i=0;i<k;i++)
		scanf("%s",ans[i]);
	for(w=0;w<k;w++)
	{
		search(w);
		printf("%d %d %s\n",tack[w][0],tack[w][1],ans[w]);
	}
}


int search(int in){
	tack[in][0]=0;
	tack[in][1]=0;
	t=strlen(ans[in])-1;
	u=0;
	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
			if(tolower(ans[in][0]) == tolower(data[i][j])){
					tack[in][0]=i;
					tack[in][1]=j;
					if(think(i,j,in,0)) return 0;
				}
	return 0;
}

int think(int x,int y,int it,int md)
{
	if(x >= 0 && x <= m-1 && y >=0 && y <= n-1 && mark[x][y] == 0 && u < t && md < 8)
	{
		mark[x][y]=1;
		if(tolower(ans[it][u]) == tolower(data[x][y])) u++;
		else md++;

		if(md == 0) x--;
		else if(md == 1){
			x--;
			y++;
		}else if(md == 2) y++;
		else if(md == 3){
			y++;
			x++;
		}else if(md == 4) x++;
		else if(md == 5){
			x++;
			y--;
		}else if(md == 6) y--;
		else if(md == 7){
			x++;
			y--;
		}
		think(x,y,it,md);
		mark[x][y]=0;
	}
	if(u == t) return 1;
	u=0;
	return 1;
}







