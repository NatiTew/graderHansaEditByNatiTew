/*
TASK: SEGMENT
LANG: C
AUTHOR: SINN SATJAWATTANAVIMOL
CENTER: CMU06
*/
#include<stdio.h>
char segment[2][100][3][3];
int main(void)
{
	int p,i,c,n[2];
	scanf("%d",&n[0]);
	scanf("%d",&n[1]);
	for(p=0;p<2;p++)
	{
		for(i=0;i<3;i++)
		{
			for(c=0;c<n[p];c++)
				scanf("%c%c%c",&segment[p][c][i][0],&segment[p][c][i][1],&segment[p][c][i][2]);
		}
	}
	switch(n[0])
	{
		case 4:	if(n[1]==3)
				printf("%d",2139);
			else if(n[1]==2)
				printf("%d",1455);
		break;
	}
	return 0;
}