/*
TASK: WORD
LANG: C
AUTHOR: Nopphorn Pitaksuebpon
CENTER: buu06
*/
#include <stdio.h>
#include <string.h>

int main(void)
{
   int i,j,l,m,n,k,o,con;
   char get[25][26],search[16];
   scanf("%d %d",&m,&n);
   for(i=0;i<m;i++)
   {
      scanf("%s",get[i]);
      strlwr(get[i]);
   }
   scanf("%d",&k);
   for(i=0;i<k;i++)
   {
      con=0;
      scanf("%s",search);
      strlwr(search);
      for(j=0;j<m;j++)
      {
	 for(l=0;l<n-1;l++)
	 {
	    if(get[j][l]==search[0])
	    {
	       if(get[j][l+1]==search[1])
	       {
		  o=1;
		  do{
		     o++;
		     if((get[j][l+o]!=search[o])||(search[o]=='\0'))
			break;
		  }while(1);
		  if(search[o]=='\0')
		  {
		     printf("%d %d\n",j,l);
		     con=1;
		  }
	       }
	       if((get[j+1][l]==search[1])&&(con<1))
	       {
		  o=1;
		  do{
		     o++;
		     if((get[j+o][l]!=search[o])||(search[o]=='\0'))
			break;
		  }while(1);
		  if(search[o]=='\0')
		  {
		     printf("%d %d\n",j,l);
		     con=1;
		  }
	       }
	       if((get[j+1][l+1]==search[1])&&(con==0))
	       {
		  o=1;
		  do{
		     o++;
		     if((get[j+o][l+o]!=search[o])||(search[o]=='\0'))
			break;
		  }while(1);
		  if(search[o]=='\0')
		  {
		     printf("%d %d\n",j,l);
		     con=1;
		  }
	       }
	       if((get[j-1][l+1]==search[1])&&(con==0))
	       {
		  o=1;
		  do{
		     o++;
		     if((get[j-o][l+o]!=search[o])||(search[o]=='\0'))
			break;
		  }while(1);
		  if(search[o]=='\0')
		  {
		     printf("%d %d\n",j,l);
		     con=1;
		  }
	       }
	       if((get[j-1][l]==search[1])&&(con==0))
	       {
		  o=1;
		  do{
		     o++;
		     if((get[j-o][l]!=search[o])||(search[o]=='\0'))
			break;
		  }while(1);
		  if(search[o]=='\0')
		  {
		     printf("%d %d\n",j,l);
		     con=1;
		  }
	       }
	       if((get[j-1][l-1]==search[1])&&(con==0))
	       {
		  o=1;
		  do{
		     o++;
		     if((get[j-o][l-o]!=search[o])||(search[o]=='\0'))
			break;
		  }while(1);
		  if(search[o]=='\0')
		  {
		     printf("%d %d\n",j,l);
		     con=1;
		  }
	       }
	       if((get[j][l-1]==search[1])&&(con==0))
	       {
		  o=1;
		  do{
		     o++;
		     if((get[j][l-o]!=search[o])||(search[o]=='\0'))
			break;
		  }while(1);
		  if(search[o]=='\0')
		  {
		     printf("%d %d\n",j,l);
		     con=1;
		  }
	       }
	       if((get[j+1][l-1]==search[1])&&(con==0))
	       {
		  o=1;
		  do{
		     o++;
		     if((get[j+o][l-o]!=search[o])||(search[o]=='\0'))
			break;
		  }while(1);
		  if(search[o]=='\0')
		  {
		     printf("%d %d\n",j,l);
		     con=1;
		  }
	       }
	    }
	    if(con==1)
	    {
	       break;
	    }
	 }
	 if(con==1)
	 {
	    break;
	 }
      }
   }
   return 0;
}