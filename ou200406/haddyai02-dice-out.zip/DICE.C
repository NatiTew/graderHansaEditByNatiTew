/*
Task:DICE
LANG:C
AUTHOR:PHONGRAPEE PHONGVIVAT
CENTER:HATYAI02
*/

#include<stdio.h>
#include<string.h>

void main()
{int d[6][6],n,i,j,temp;
 char ch[6][1001];

 scanf("%d",&n);

 for(i=0;i<n;i++)
  { for(j=0;j<6;j++)
     d[i][j]=j+1;
   }


 for(i=0;i<n;i++)
 { scanf("%s",ch[i]);
  }

for(i=0;i<n;i++)
 { for(j=0;j<strlen(ch[i]);j++)
    {switch(ch[i][j])
      { case 'F':
	 {temp=d[i][5];
	  d[i][5]=d[i][1];
	  d[i][1]=d[i][0];
	  d[i][0]=d[i][4];
	  d[i][4]=temp;
	 }
	 break;

     case 'B':
	 {temp=d[i][4];
	  d[i][4]=d[i][0];
	  d[i][0]=d[i][1];
	  d[i][1]=d[i][5];
	  d[i][5]=temp;
	 }
     break;

     case 'L':
	 {temp=d[i][3];
	  d[i][3]=d[i][5];
	  d[i][5]=d[i][2];
	  d[i][2]=d[i][0];
	  d[i][0]=temp;
	 }
     break;

     case 'R':
     {temp=d[i][3];
	  d[i][3]=d[i][0];
	  d[i][0]=d[i][2];
	  d[i][2]=d[i][5];
	  d[i][5]=temp;
	 } break;

     case 'C':
     {temp=d[i][3];
	  d[i][3]=d[i][4];
	  d[i][4]=d[i][2];
	  d[i][2]=d[i][1];
	  d[i][1]=temp;
	 } break;

     case 'D':
     {temp=d[i][3];
	  d[i][3]=d[i][1];
	  d[i][1]=d[i][2];
	  d[i][2]=d[i][4];
	  d[i][4]=temp;
	 } break;
      }
     }
    printf("%d ",d[i][1]);
    }
}