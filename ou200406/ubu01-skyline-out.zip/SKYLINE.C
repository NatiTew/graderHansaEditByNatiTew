/*
TASK: SKYLINE
LANG: C
AUTHOR: RIVINWIT AKKARANGSRI
CENTER: UBON
*/
#include<stdio.h>

int main(){
	int a[256];
	int l,h,r;
	int max_r=1;
	int n,i;
	int before;

	scanf("%d",&n);
	for(i=0;i<=255;i++)
		a[i]=0;
	while(n>0){
		scanf("%d",&l);
		scanf("%d",&h);
		scanf("%d",&r);
		//process
		if(r>max_r)
			max_r=r;
		for(i=l;i<r;i++){
			if(a[i]<h)
				a[i]=h;
		}
		n--;
	}
	//-- print
	before=0;
	for(i=1;i<=max_r;i++){
		if(a[i]!=before){
			printf("%d %d ",i,a[i]);
			before=a[i];
		}
	}
	printf("\n");
	return 0;
}