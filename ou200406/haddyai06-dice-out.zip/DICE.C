/*
TASK: DICE
LANG: C
AUTHOR: SARAN SONGYOD
CENTER: HADDYAI06
*/
#include<stdio.h>
void main()
{int d[6] = {1,2,3,5,4,6};
 int stack[6];
 int temp[6];
 int i,n,j=0;
 char chk;
 scanf("%d",&n);
 scanf("%c",&chk);
 for(i=0;i<n;i++)
 { scanf("%c",&chk);
	d[0] = 1;
	d[1] = 2;
	d[2] = 3;
	d[3] = 5;
	d[4] = 4;
	d[5] = 6;
   while(chk!='\n')
   { if(chk=='F')
     {  temp[2] = d[2];
	temp[4] = d[4];
	temp[0] = d[3];
	temp[1] = d[0];
	temp[3] = d[5];
	temp[5] = d[1];
     }
   if(chk=='B')
     {  temp[2] = d[2];
	temp[4] = d[4];
	temp[0] = d[1];
	temp[1] = d[5];
	temp[3] = d[0];
	temp[5] = d[3];
     }
   if(chk=='L')
     {  temp[0] = d[4];
	temp[1] = d[1];
	temp[2] = d[0];
	temp[3] = d[3];
	temp[4] = d[5];
	temp[5] = d[2];
     }
   if(chk=='R')
     {  temp[0] = d[2];
	temp[1] = d[1];
	temp[2] = d[5];
	temp[3] = d[3];
	temp[4] = d[0];
	temp[5] = d[4];
     }
   if(chk=='C')
     {  temp[0] = d[0];
	temp[1] = d[4];
	temp[2] = d[1];
	temp[3] = d[2];
	temp[4] = d[3];
	temp[5] = d[5];
     }
   if(chk=='D')
     {  temp[0] = d[0];
	temp[1] = d[2];
	temp[2] = d[3];
	temp[3] = d[4];
	temp[4] = d[1];
	temp[5] = d[5];
     }
	d[0] = temp[0];
	d[1] = temp[1];
	d[2] = temp[2];
	d[3] = temp[3];
	d[4] = temp[4];
	d[5] = temp[5];
   scanf("%c",&chk);
   }
   stack[j] = d[1];
   j++;
 }
  for(i=0;i<j;i++)
   { printf("%d",stack[i]);
     if(i<j-1)
       printf(" ");
   }
}