/*
TASK: SEGMENT
LANG: C
AUTHOR: Peerapon Jatukanyaprateep
CENTER: NU01
*/
#include <stdio.h>
#include <math.h>

int is1(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]==' ')
    if(a[i][j+2]==' ')
    if(a[i+1][j]==' ')
    if(a[i+1][j+1]==' ')
    if(a[i+1][j+2]=='|')
    if(a[i+2][j]==' ')
    if(a[i+2][j+1]==' ')
    if(a[i+2][j+2]=='|')
    return 1;
  }
  return 0;
}

int is2(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]=='_')
    if(a[i][j+2]==' ')
    if(a[i+1][j]==' ')
    if(a[i+1][j+1]=='_')
    if(a[i+1][j+2]=='|')
    if(a[i+2][j]=='|')
    if(a[i+2][j+1]=='_')
    if(a[i+2][j+2]==' ')
    return 2;
  }
  return 0;
}

int is3(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]=='_')
    if(a[i][j+2]==' ')
    if(a[i+1][j]==' ')
    if(a[i+1][j+1]=='_')
    if(a[i+1][j+2]=='|')
    if(a[i+2][j]==' ')
    if(a[i+2][j+1]=='_')
    if(a[i+2][j+2]=='|')
    return 3;
  }
  return 0;
}

int is4(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]==' ')
    if(a[i][j+2]==' ')
    if(a[i+1][j]=='|')
    if(a[i+1][j+1]=='_')
    if(a[i+1][j+2]=='|')
    if(a[i+2][j]==' ')
    if(a[i+2][j+1]==' ')
    if(a[i+2][j+2]=='|')
    return 4;
  }
  return 0;
}

int is5(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]=='_')
    if(a[i][j+2]==' ')
    if(a[i+1][j]=='|')
    if(a[i+1][j+1]=='_')
    if(a[i+1][j+2]==' ')
    if(a[i+2][j]==' ')
    if(a[i+2][j+1]=='_')
    if(a[i+2][j+2]=='|')
    return 5;
  }
  return 0;
}

int is6(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]=='_')
    if(a[i][j+2]==' ')
    if(a[i+1][j]=='|')
    if(a[i+1][j+1]=='_')
    if(a[i+1][j+2]==' ')
    if(a[i+2][j]=='|')
    if(a[i+2][j+1]=='_')
    if(a[i+2][j+2]=='|')
    return 6;
  }
  return 0;
}

int is7(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]=='_')
    if(a[i][j+2]==' ')
    if(a[i+1][j]==' ')
    if(a[i+1][j+1]==' ')
    if(a[i+1][j+2]=='|')
    if(a[i+2][j]==' ')
    if(a[i+2][j+1]==' ')
    if(a[i+2][j+2]=='|')
    return 7;
  }
  return 0;
}

int is8(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]=='_')
    if(a[i][j+2]==' ')
    if(a[i+1][j]=='|')
    if(a[i+1][j+1]=='_')
    if(a[i+1][j+2]=='|')
    if(a[i+2][j]=='|')
    if(a[i+2][j+1]=='_')
    if(a[i+2][j+2]=='|')
    return 8;
  }
  return 0;
}

int is9(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]=='_')
    if(a[i][j+2]==' ')
    if(a[i+1][j]=='|')
    if(a[i+1][j+1]=='_')
    if(a[i+1][j+2]=='|')
    if(a[i+2][j]==' ')
    if(a[i+2][j+1]=='_')
    if(a[i+2][j+2]=='|')
    return 9;
  }
  return 0;
}

int is0(char a[3][40],int i,int j)
{
  if(a[i][j]==' ')
  {
    if(a[i][j+1]=='_')
    if(a[i][j+2]==' ')
    if(a[i+1][j]=='|')
    if(a[i+1][j+1]==' ')
    if(a[i+1][j+2]=='|')
    if(a[i+2][j]=='|')
    if(a[i+2][j+1]=='_')
    if(a[i+2][j+2]=='|')
    return 0;
  }
  return 0;
}

void main(void)
{
  int a=0,b=0,i,j,oh;
  long int aa=0,bb=0,power=0;
  char A[3][50],B[3][50];
  scanf("%d %d",&a,&b);
  for(i=0;i<=3;i++)
  {
  /*  for(j=0;j<a*3+a;j++)
    {
      scanf("%c",&A[i][j]);
    } */
    gets(A[i]);
  }
  for(i=0;i<=3;i++)
  {
 /*   for(j=0;j<b*3+b;j++)
    {
      scanf("%c",&B[i][j]);
    } */
    gets(B[i]);
  }
/*  printf("*****************\n");
  for(i=0;i<=3;i++)
  {
//   for(j=0;j<a*3+a;j++)
    printf("%s",A[i]);
    printf("\n");
  }
  printf("*****************\n");
  for(i=0;i<=3;i++)
  {
//   for(j=0;j<b*3+b;j++)
    printf("%s",B[i]);
    printf("\n");
  }
  */
  oh=a-1;
//  for(i=0;i<3;i++)
  i=0;
  aa=0;
  bb=0;
  {
    for(j=0;j<a*3+a;j+=4)
    {
     power=pow(10,oh);
      aa=aa+(is0(A,i,j)* power);
      aa=aa+(is1(A,i,j)* power);
      aa=aa+(is2(A,i,j)* power);
      aa=aa+(is3(A,i,j)* power);
      aa=aa+(is4(A,i,j)* power);
      aa=aa+(is5(A,i,j)* power);
      aa=aa+(is6(A,i,j)* power);
      aa=aa+(is7(A,i,j)* power);
      aa=aa+(is8(A,i,j)* power);
      aa=aa+(is9(A,i,j)* power);
      oh--;
    }
  }
  i=0;
  oh=b-1;
  {
    for(j=0;j<a*3+a;j+=4)
    {
     power=pow(10,oh);
      bb=bb+(is0(B,i,j)*power);
      bb=bb+(is1(B,i,j)*power);
      bb=bb+(is2(B,i,j)*power);
      bb=bb+(is3(B,i,j)*power);
      bb=bb+(is4(B,i,j)*power);
      bb=bb+(is5(B,i,j)*power);
      bb=bb+(is6(B,i,j)*power);
      bb=bb+(is7(B,i,j)*power);
      bb=bb+(is8(B,i,j)*power);
      bb=bb+(is9(B,i,j)*power);

      oh--;
    }
  }
  printf("%ld",aa+bb);
}