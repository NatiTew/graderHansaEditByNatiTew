/*
TASK: DICE
LANG: C
AUTHOR: Sorawit Boonyathee
CENTER: cmu01
*/

#include <stdio.h>
#include <string.h>

int main()
{
	int n,i,top,front,left,back,right,bottom;
	int t1,t2,t3,t4,t5,t6,len,j;
	char cmd[1001];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",cmd);
		//Set Stage
		top=1;
		front=2;
		left=3;
		back=5;
		right=4;
		bottom=6;
		len=strlen(cmd);
		for(j=0;j<len;j++)
		{
			t1=top;
			t2=front;
			t3=left;
			t4=back;
			t5=right;
			t6=bottom;
			if(cmd[j]=='F')
			{
				top=t4;
				front=t1;
				back=t6;
				bottom=t2;
			}else if(cmd[j]=='B')
			{
				top=t2;
				front=t6;
				back=t1;
				bottom=t4;
			}else if(cmd[j]=='L')
			{
				top=t5;
				left=t1;
				right=t6;
				bottom=t3;
			}else if(cmd[j]=='R')
			{
				top=t3;
				left=t6;
				right=t1;
				bottom=t5;
			}else if(cmd[j]=='C')
			{
				front=t5;
				left=t2;
				back=t3;
				right=t4;
			}else if(cmd[j]=='D')
			{
				front=t3;
				left=t4;
				back=t5;
				right=t2;
			}
		}
		printf("%d ",front);
	}
	return 0;
}