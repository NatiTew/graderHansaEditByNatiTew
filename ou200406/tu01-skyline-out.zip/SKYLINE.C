/*
TASK: SKYLINE
LANG: C
AUTHOR: PANOT CHAIMONGKOL
CENTER: TU01
*/

#include <stdio.h>
#define max(a,b) (a>b?a:b)

void main()
{
	int sky[256],num,i,j;
	int x,y,z,prev=0;
	scanf("%d",&num);
	for (i=0;i<256;i++)
		sky[i]=0;
	for (i=0;i<num;i++)
	{
		scanf("%d %d %d",&x,&y,&z);
		z--;
		for (j=x;j<=z;j++)
			sky[j] = max(sky[j],y);
	} //for
	for (i=0;i<256;i++)
		if (sky[i]!= prev)
		{
			prev = sky[i];
			printf("%d %d ",i,sky[i]);
		} //if
} //main