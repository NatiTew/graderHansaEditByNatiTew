/*
TASK: MAXSEQ
LANG: C
AUTHOR: KUNAKORN TENGCHIANG
CENTER: NU02
*/

#include<stdio.h>

main(){
 int n,i,j,l,f,k,p;
 int num[60],sum=0,check=-1;

 scanf("%d",&n);
 for(i=0;i<n;i++){
	scanf("%d",&num[i]);
 }

 for(i=0;i<n;i++){
	sum=num[i];
	k=sum;
	for(j=i+1;j<n;j++){
		k+=num[j];
		if(k>sum){
		       p=j;
		       sum=k;
		}
	}
	if(sum>check){
		f=i;
		l=p;
		check=sum;
	}
 }
 if(check>=0){
	 for(i=f;i<=l;i++){
		printf("%d ",num[i]);
	 }
 }
 else{
	printf("Empty sequence");
 }

 return 0;
}