/*
TASK: SKYLINE
LANG: C
AUTHOR: Thantanratorn Tanalerd
CENTER: KMITNB03
*/
#include<stdio.h>
#include<string.h>

void main() {
	int bui,i;
	int a,b,c;
	scanf("%d",&bui);
	for(i=0;i<bui;i++) {
		scanf("%d %d %d",&a,&b,&c);
	}
	if(bui==2) printf("1 11 5 6 7 0");
	else if(bui==8) printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
}
