/*
TASK: SKYLINE
LANG: C
AUTHOR: Worakan Jeeprabnan
CENTER: CMU03
*/
#include<stdio.h>
int main()
{
  static int line[3001];
  int n,i,j,s,h,e;
  int chk=0;
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
    scanf("%d %d %d",&s,&h,&e);
    for(j=s;j<e;j++)
    {
      line[j]=h;
    }
  }
  for(i=1;i<3001;i++)
  {
    if(line[i]!=line[i-1])
    {
      printf("%d %d ",i,line[i]);
    }
  }
  return 0;
}