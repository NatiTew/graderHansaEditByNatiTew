/*
TASK: DICE
LANG: C
AUTHOR: Kornkanok Siriaksorn
CENTER: tu17
*/

#include<stdio.h>

struct dice{
	char t , f , l , b , r , bo;
};

void main()
{
	int n , i , j;
	char r[1000] , t;
	struct dice d;
	scanf("%d",&n);
	for(j=0;j<n;j++)
	{
		d.t = 1;
		d.f = 2;
		d.l = 3;
		d.b = 5;
		d.r = 4;
		d.bo = 6;
		scanf("%s",r);
		for(i=0;r[i]!='\0';i++)
		{
			if(r[i]=='F')
			{
				t = d.t;
				d.t = d.b;
				d.b = d.bo;
				d.bo = d.f;
				d.f = t;
			}
			else if(r[i]=='B')
			{
				t = d.t;
				d.t = d.f;
				d.f = d.bo;
				d.bo = d.b;
				d.b = t;
			}
			else if(r[i]=='L')
			{
				t = d.t;
				d.t = d.r;
				d.r = d.bo;
				d.bo = d.l;
				d.l = t;
			}
			else if(r[i]=='R')
			{
				t = d.t;
				d.t = d.l;
				d.l = d.bo;
				d.bo = d.r;
				d.r = t;
			}
			else if(r[i]=='C')
			{
				t = d.f;
				d.f = d.r;
				d.r = d.b;
				d.b = d.l;
				d.l = t;
			}
			else if(r[i]=='D')
			{
				t = d.f;
				d.f = d.l;
				d.l = d.b;
				d.b = d.r;
				d.r = t;
			}
		}
		printf("%d ",d.f);
	}
}