/*
TASK: BEE
LANG: C
AUTHOR: Napat Hataivichian
CENTER: buu05
*/
#include <stdio.h>

int main (void)
{
 int num,j,w=1,s=0,k,tmpw,tmps,sum;
  while(1)
  {
	w = 1;
	s = 0;
	scanf("%d",&num);
	if(num == -1)
	  break;
	for(j=0;j<num;j++)
	 {
	  tmpw = w;
	  tmps = s;
		//soldier
	  for(k=0;k<tmps;k++)
		{
		 w++;
		 s--;
		}
		//work
	  for(k=0;k<tmpw;k++)
		  s++;
		//queen
	  w++;
	 }
	sum = w+s+1;
	printf("\n%d %d",w,sum);
  }
 return 0;
}