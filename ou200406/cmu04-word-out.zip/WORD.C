/*
TASK: WORD
LANG: C
AUTHOR: Naksit Anantalapochai
CENTER: cmu04
*/
#include <stdio.h>
#include <string.h>
struct word1{
	char word[26];
}w[26];
struct find1{
	char find[16];
}f[101];
int main()
{
	int m,n,i,k,j,l,a,z,b,c,count,y,ans;
	char temp,fw[15];
	scanf("%d %d",&m,&n);
	scanf("%c",&temp);
	for(i=0;i<m;i++){
		gets(w[i].word);
		for(j=0;j<n;j++){
			if(w[i].word[j]>90){
				w[i].word[j]= w[i].word[j]-32;
			}
		}
	}
	scanf("%d",&k);
	scanf("%c",&temp);
	for(i=0;i<k;i++){
		gets(f[i].find);
		for(j=0;j<n;j++){
			if(f[i].find[j]>90){
				f[i].find[j]= f[i].find[j]-32;
			}
		}
	}
	for(l=0;l<k;l++){
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			if(w[i].word[j]==f[l].find[0]){
				a=j;
				b=0;
				do{
					fw[b]=w[i].word[a];
					a++;
					b++;
				}while(a!=strlen(f[l].find));
				ans=0;
				for(y=0;y<strlen(f[l].find);y++){
					if(fw[y]==f[l].find[y]){
						ans++;
					}
					if(ans==strlen(f[l].find)){
						printf("%d %d\n",i,j);
					}
				}
				a=j;
				b=0;
				c=j;
				do{
					fw[b]=w[i].word[c];
					a++;
					b++;
					c--;
				}while(a!=strlen(f[l].find));
				ans=0;
				for(y=0;y<strlen(f[l].find);y++){
					if(fw[y]==f[l].find[y]){
						ans++;
					}
					if(ans==strlen(f[l].find)){
						printf("%d %d\n",i,j);
					}
				}
				a=j;
				c=i;
				b=0;
				count=0;
				do{
					fw[b]=w[c].word[a];
					c++;
					b++;
					count++;
				}while(count!=strlen(f[l].find));
				ans=0;
				for(y=0;y<strlen(f[l].find);y++){
					if(fw[y]==f[l].find[y]){
						ans++;
					}
					if(ans==strlen(f[l].find)){
						printf("%d %d\n",i,j);
					}
				}
				a=j;
				c=i;
				b=0;
				count=0;
				do{
					fw[b]=w[c].word[a];
					c--;
					b++;
					count++;
				}while(count!=strlen(f[l].find));
				ans=0;
				for(y=0;y<strlen(f[l].find);y++){
					if(fw[y]==f[l].find[y]){
						ans++;
					}
					if(ans==strlen(f[l].find)){
						printf("%d %d\n",i,j);
					}
				}
				a=j;
				c=i;
				b=0;
				count=0;
				do{
					fw[b]=w[c].word[a];
					c++;
					a++;
					b++;
					count++;
				}while(count!=strlen(f[l].find));
				ans=0;
				for(y=0;y<strlen(f[l].find);y++){
					if(fw[y]==f[l].find[y]){
						ans++;
					}
					if(ans==strlen(f[l].find)){
						printf("%d %d\n",i,j);
					}
				}
				a=j;
				c=i;
				b=0;
				count=0;
				do{
					fw[b]=w[c].word[a];
					c++;
					b++;
					a--;
					count++;
				}while(count!=strlen(f[l].find));
				ans=0;
				for(y=0;y<strlen(f[l].find);y++){
					if(fw[y]==f[l].find[y]){
						ans++;
					}
					if(ans==strlen(f[l].find)){
						printf("%d %d\n",i,j);
					}
				}
			}
		}
	}
	}
	return 0;
}