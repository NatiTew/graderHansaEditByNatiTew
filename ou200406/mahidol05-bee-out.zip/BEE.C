/*
TASK:BEE
LANG:C
AUTHOR:Sorawit Paiboonrattanakorn
CENTER: mahidol05
*/

#include<stdio.h>
//#include<stdlib.h>

int main()
{
	int i,y=0;
	long double work,soldier,temp;
	while(y!=-1)
	{
		work=1;
		soldier=0;
		scanf("%d",&y);
		for(i=0;i<y;i++)
		{
			temp=work;
			work=work+1+soldier;
			soldier=temp;
		}
		if(y!=-1)
		{
			printf("%.0Lf %.0Lf\n",work,work+soldier+1);
		}
	}
	return 0;
}