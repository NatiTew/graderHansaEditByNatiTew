/*
TASK: DICE
LANG: C
AUTHOR: NATCHAPON ANANTARAMPORN
CENTER: NU05
*/
#include <stdio.h>
#include <string.h>
int main(void)
{
  char way[6][1000];
  int i,j,n;
  int start[6]={1,2,3,5,4,6},dice[6]={NULL},f[6];
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
    scanf("%s",&way[i]);
  }
  for(i=0;i<n;i++)
  {
    start[0]=1;
    start[1]=2;
    start[2]=3;
    start[3]=5;
    start[4]=4;
    start[5]=6;
    for(j=0;j<strlen(way[i]);j++)
    {
      if(way[i][j]=='F')
      {
	dice[0]=start[3];
	dice[1]=start[0];
	dice[2]=start[2];
	dice[3]=start[5];
	dice[4]=start[4];
	dice[5]=start[1];
	start[0]=dice[0];
	start[1]=dice[1];
	start[2]=dice[2];
	start[3]=dice[3];
	start[4]=dice[4];
	start[5]=dice[5];
	f[i]=dice[1];
      }
      else if(way[i][j]=='B')
      {
	dice[0]=start[1];
	dice[1]=start[5];
	dice[2]=start[2];
	dice[3]=start[0];
	dice[4]=start[4];
	dice[5]=start[3];
	start[0]=dice[0];
	start[1]=dice[1];
	start[2]=dice[2];
	start[3]=dice[3];
	start[4]=dice[4];
	start[5]=dice[5];
	f[i]=dice[1];
      }
      else if(way[i][j]=='L')
      {
	dice[0]=start[4];
	dice[1]=start[1];
	dice[2]=start[0];
	dice[3]=start[3];
	dice[4]=start[5];
	dice[5]=start[2];
	start[0]=dice[0];
	start[1]=dice[1];
	start[2]=dice[2];
	start[3]=dice[3];
	start[4]=dice[4];
	start[5]=dice[5];
	f[i]=dice[1];
      }
      else if(way[i][j]=='R')
      {
	dice[0]=start[2];
	dice[1]=start[1];
	dice[2]=start[5];
	dice[3]=start[3];
	dice[4]=start[0];
	dice[5]=start[4];
	start[0]=dice[0];
	start[1]=dice[1];
	start[2]=dice[2];
	start[3]=dice[3];
	start[4]=dice[4];
	start[5]=dice[5];
	f[i]=dice[1];
      }
      else if(way[i][j]=='C')
      {
	dice[0]=start[0];
	dice[1]=start[4];
	dice[2]=start[1];
	dice[3]=start[2];
	dice[4]=start[3];
	dice[5]=start[5];
	start[0]=dice[0];
	start[1]=dice[1];
	start[2]=dice[2];
	start[3]=dice[3];
	start[4]=dice[4];
	start[5]=dice[5];
	f[i]=dice[1];
      }
      else if(way[i][j]=='D')
      {
	dice[0]=start[0];
	dice[1]=start[2];
	dice[2]=start[3];
	dice[3]=start[4];
	dice[4]=start[1];
	dice[5]=start[5];
	start[0]=dice[0];
	start[1]=dice[1];
	start[2]=dice[2];
	start[3]=dice[3];
	start[4]=dice[4];
	start[5]=dice[5];
	f[i]=dice[1];
      }
    }
  }
  for(i=0;i<n;i++)
  {
    printf("%d ",f[i]);
  }
  return 0;
}