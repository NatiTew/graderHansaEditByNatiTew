/*
TASK: MAXSEQ
LANG: C
AUTHOR: Supawan phuangphairoj
Center: tu13
*/

#include<stdio.h>

int x,y,n;
char num[2502];
long max=0;
void process()
{       long temp=0;
	int i,j;
	for(i=0;i<n;i++)
	{       temp = 0;
		if(num[i]>0)
		{	for(j=i;j<n;j++)
			{	temp += num[j];
				if(temp>max)
				{       max = temp;
					x = i;	y = j;	}	}
		}
	}
}

int main()
{       int i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{	scanf("%d",&num[i]);	}
	process();
	if(max>0)
	{	for(i=x;i<=y;i++)
			printf("%d ",num[i]);
		printf("\n%ld",max);	}
	else
		printf("Empty sequence");
	return 0;
}