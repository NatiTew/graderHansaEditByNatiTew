/*
TASK: SKYLINE
LANG: C
AUTHOR: Taksapaun Kittiakrastien
CENTER: tu08
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
  int n;
  int i,j;
  int build[3000][3];
  int max[257];
  int lastmax = -1;

//  freopen("test.in", "r", stdin);

  for(i=0;i<257;i++)
    max[i]=0;
  scanf("%d", &n);
  for(i=0;i<n;i++)
  {
   scanf("%d", &build[i][0]);
   scanf("%d", &build[i][1]);
   scanf("%d", &build[i][2]);
   for(j=build[i][0];j<build[i][2];j++)
   {
     if(max[j] < build[i][1])
       max[j]= build[i][1];
   }

  }

  for(i=1;i<256;i++)
  {
    if(max[i]!=lastmax)
    {
      printf("%d %d ", i, max[i]);
      lastmax = max[i];
    }
  }

  return 0;
}