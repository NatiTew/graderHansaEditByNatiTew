/*
TASK: MAXSEQ
LANG: C
AUTHOR: Pattaravut Maleehuan
CENTER: SUT04
*/
#include<stdio.h>

char data[2500],tack[2];

int i,n,i,j;
long int sum=0,max=-127;

int main()
{
	scanf("%d\n",&n);
	for(i=0;i<n;i++)
		scanf("%d",&data[i]);


	for(i=0;i<n;i++,sum=0)
		for(j=i;j<n;j++)
		{
			sum+=data[j];
			if(sum >= max)
			{
				max=sum;
				tack[0]=i;
				tack[1]=j;
			}
		}
	if(max < 0)
	{
		printf("Empty sequence");
		return 0;
	}
	for(i=tack[0];i<=tack[1];i++)
		printf("%d ",data[i]);
	printf("\n%d",max);
	return 0;
}