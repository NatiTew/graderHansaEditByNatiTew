/*
TASK: SEGMENT
LANG: C
AUTHOR: Prayook Jatesiktat
CENTER: mahidol04
*/
#include<stdio.h>
#include<stdlib.h>
int digit(char a1,char a2,char a3,char a4,char a5,char a6,char a7,char a8,char a9)
{
  if(a1==' '&&a2==' '&&a3==' '&&a4==' '&&a5==' '&&a6=='|'&&a7==' '&&a8==' '&&a9=='|')
  {
     return 1;
  }
  else if(a1==' '&&a2=='_'&&a3==' '&&a4==' '&&a5=='_'&&a6=='|'&&a7=='|'&&a8=='_'&&a9==' ')
  {
     return 2;
  }
  else if(a1==' '&&a2=='_'&&a3==' '&&a4==' '&&a5=='_'&&a6=='|'&&a7==' '&&a8=='_'&&a9=='|')
  {
     return 3;
  }
  else if(a1==' '&&a2==' '&&a3==' '&&a4=='|'&&a5=='_'&&a6=='|'&&a7==' '&&a8==' '&&a9=='|')
  {
     return 4;
  }
  else if(a1==' '&&a2=='_'&&a3==' '&&a4=='|'&&a5=='_'&&a6==' '&&a7==' '&&a8=='_'&&a9=='|')
  {
     return 5;
  }
  else if(a1==' '&&a2=='_'&&a3==' '&&a4=='|'&&a5=='_'&&a6==' '&&a7=='|'&&a8=='_'&&a9=='|')
  {
     return 6;
  }
  else if(a1==' '&&a2=='_'&&a3==' '&&a4==' '&&a5==' '&&a6=='|'&&a7==' '&&a8==' '&&a9=='|')
  {
     return 7;
  }
  else if(a1==' '&&a2=='_'&&a3==' '&&a4=='|'&&a5==' '&&a6=='|'&&a7=='|'&&a8=='_'&&a9=='|')
  {
     return 8;
  }
  else if(a1==' '&&a2=='_'&&a3==' '&&a4=='|'&&a5=='_'&&a6=='|'&&a7==' '&&a8=='_'&&a9=='|')
  {
     return 9;
  }
  else if(a1==' '&&a2=='_'&&a3==' '&&a4=='|'&&a5==' '&&a6=='|'&&a7=='|'&&a8=='_'&&a9=='|')
  {
     return 0;
  }
  else
    return -1;
}
void main()
{
  int n1,n2,i,j;
  char a[3][41],b[3][41];
  unsigned long na=0,nb=0;
  scanf("%d%d",&n1,&n2);
  for(i=0;i<3;i++)
  {
    for(j=1;j<=n1*4;j++)
    {
       scanf("%c",&a[i][j]);
    }
  }
  for(i=0;i<3;i++)
  {
    for(j=1;j<n2*4;j++)
    {
       scanf("%c",&b[i][j]);
    }
  }
  for(i=1;i<=n1;i++)
  {
    na=na+pow(10,n1-i)*digit(a[0][4*i-3],a[0][4*i-2],a[0][4*i-1],a[1][4*i-3],a[1][4*i-2],a[1][4*i-1],a[2][4*i-3],a[2][4*i-2],a[2][4*i-1]);
  }
  for(i=1;i<=n2;i++)
  {
    nb=nb+pow(10,n1-i)*digit(b[0][4*i-3],b[0][4*i-2],b[0][4*i-1],b[1][4*i-3],b[1][4*i-2],b[1][4*i-1],b[2][4*i-3],b[2][4*i-2],b[2][4*i-1]);
  }
  printf("%lu",na+nb);

}