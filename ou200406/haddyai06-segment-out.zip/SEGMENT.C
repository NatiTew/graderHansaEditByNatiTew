/*
TASK: SEGMENT
LANG: C
AUTHOR: SARAN SONGYOD
CENTER: HADDYAI06
*/
#include<stdio.h>
#include<math.h>

void main()
{ char base[10][9] = { {' ','_',' ','|',' ','|','|','_','|'},//0
       {' ',' ',' ',' ',' ','|',' ',' ','|'},//1
       {' ','_',' ',' ','_','|','|','_',' '},                //2
       {' ','_',' ',' ','_','|',' ','_','|'}, //3
       {' ',' ',' ','|','_','|',' ',' ','|'}, //4
       {' ','_',' ','|','_',' ',' ','_','|'},//5
       {' ','_',' ','|','_',' ','|','_','|'}, //6
       {' ','_',' ',' ',' ','|',' ',' ','|'},//7
       {' ','_',' ','|','_','|','|','_','|'},//8
       {' ','_',' ','|','_','|',' ','_','|'}};//9
 int i,j,k,l,n,m,flag;
 char tmp_num[10][9],jk;
 long int num1=0,num2=0,sum,degree;
 for(i=0;i<10;i++)
  for(j=0;j<9;j++)
    tmp_num[i][j]=' ';
 scanf("%d",&n);
 scanf("%d",&m);
 degree = pow10(n-1);
 scanf("%c",&jk);
 for(k=0;k<3;k++)
 { for(i=0,l=0;i<n;i++,l++)
   { for(j=3*k;j<3*k+3;j++)
     {if(j==-1)j++;
      scanf("%c",&tmp_num[l][j]);
     }
    scanf("%c",&jk);

   }

 }

  for(k=0;k<n;k++)
  { for(i=0;i<10;i++)
   { flag=1;
     for(j=0;((j<9)&&(flag));j++)
     { if(base[i][j]!=tmp_num[k][j])
	 flag=0;
     }
     if(flag==1)
       break;
   }

   num1 += i*degree;
   degree/=10;
  }
 degree = pow10(m-1);
// scanf("%c",&jk);
 for(i=0;i<10;i++)
  for(j=0;j<9;j++)
    tmp_num[i][j]=' ';
 for(k=0;k<3;k++)
 { for(i=0,l=0;i<m;i++,l++)
   { for(j=3*k;j<3*k+3;j++)
     {if(j==-1)j++;
      scanf("%c",&tmp_num[l][j]);
     }
    scanf("%c",&jk);

   }

 }

  for(k=0;k<m;k++)
  { for(i=0;i<10;i++)
   { flag=1;
     for(j=0;((j<9)&&(flag));j++)
     { if(base[i][j]!=tmp_num[k][j])
	 flag=0;
     }
     if(flag==1)
       break;
   }

   num2 += i*degree;
   degree/=10;
  }
  printf("%d",num1+num2);
}