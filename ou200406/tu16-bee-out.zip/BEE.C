/*
TASK: BEE
LANG: C
AUTHOR: YONGKICT TAECHAYINGYONGCHAI
CENTER: TU16
*/
#include <stdio.h>
#define q 1

int n,i,j,a[24],temp;
unsigned int s,w;
main()
{
	for(n=0;;n++)
	{
		scanf("%d",&a[n]);
		if(a[n]==-1)	break;
	}
	for(i=0;i<n;i++)
	{
		w=1; s=0;
		for(j=1;j<=a[i];j++)
		{
			temp=w;
			w=q+w+s;
			s=temp;
		}
		printf("%u %u\n",w,q+w+s);
	}
	return 0;
}