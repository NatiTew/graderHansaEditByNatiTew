/*
TASK: MAXSEQ
LANG: C
AUTHOR: Naksit Anantalapochai
CENTER: cmu04
*/
#include <stdio.h>

int main(void)
{
	static int a[2500],i,j,max=-127,n,k,x=0,ans[2500],last,front;
	scanf("%d",&j);
	j--;
	for(i=0;i<=j;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<=j;i++){
		for(n=j;n>=i;n--){
			for(k=i;k<=n;k++){
				x=x+a[k];
			}
			if(x>max){
				max=x;
				for(k=0;k<=n;k++){
					ans[k]=a[k];
				}
				last=n;
				front=i;
			}
			x=0;
		}
	}
	if(max>0){
		for(;front<=last;front++){
			printf("%d ",ans[front]);
		}
		printf("\n%d",max);
	}else{
		printf("Empty sequence");
	}
	return 0;
}