/*
TASK: MAXSEQ
LANG: C
AUTHOR: NAKARA KITTISIRIKUL
CENTER: tu05
*/
#include<stdio.h>
#define max 2505
main()
{
	long arr[max],tmp[max],n,count,count2,sPos,ePos,maxN;
	scanf("%ld",&n);
	for(count = 0; count < n; count++)
	{
		scanf("%ld",&arr[count]);
		tmp[count] = 0;
	}
	maxN = arr[n-1];
	sPos = ePos = n-1;
	for(count = n-1; count >=0; count--)
		for(count2 = n-1;count2 >= count; count2--)
		{
			tmp[count2] += arr[count];
			if(tmp[count2] >= maxN)
			{
				sPos = count;
				ePos = count2;
				maxN = tmp[count2];
			}
		}
	if(maxN > 0)
	{
		for(count = sPos; count <= ePos; count++)
			printf("%ld ",arr[count]);
		printf("\n%ld",maxN);
	}
	else
		printf("Empty sequence");
	return 0;
}