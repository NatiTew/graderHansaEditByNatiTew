/*
TASK: WORD
LANG: C
AUTHOR: NUTTAWOOT YOTINOOPAMAI
CENTER: KMITNB01
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>

int n(char table[25][25],int row,int col,char word[15]);
int s(char table[25][25],int row,int col,char word[15],int size);

void main() {
	int i,j,k,row,col,nw,chk,m;
	char table[25][25],word[15];
	FILE *fp=fopen("1.in","r");
	fscanf(fp,"%d%d",&row,&col);
	fgetc(fp);
	for(i=0;i<row;i++,fgetc(fp))
		for(j=0;j<col;j++) {

			fscanf(fp,"%c",&table[i][j]);
			table[i][j]=tolower(table[i][j]);
		}
	fscanf(fp,"%d",&nw);
	for(k=0;k<nw;k++) {
		fscanf(fp,"%s",word);
		for(m=0;m<strlen(word);m++)
		word[m]=tolower(word[m]);
		for(chk=0,i=0;i<row;i++)
			for(j=0;j<col;j++)
				if(word[0]==table[i][j]) {
					chk=n(table,i,j,word);
					if(!chk) chk=ne(table,i,j,word,col);
					if(!chk) chk=e(table,i,j,word);
					if(!chk) chk=nnw(table,i,j,word);
					if(!chk) chk=s(table,i,j,word,row);
					if(!chk) chk=sw(table,i,j,word);
					if(!chk) chk=w(table,i,j,word,col);
					if(!chk) chk=se(table,i,j,word);
					if(chk) {
						i=row;
						break;
					}
				}
	}

}

int n(char table[25][25],int row,int col,char word[15]) {
	int i,k=0;
	if(row+1>=strlen(word)) {
		for(i=row;i<strlen(word)+row;i--,k++)
			if(word[k]!=table[i][col])
				return 0;
		if(k==strlen(word)) {
			printf("%d %d\n",row,col);
			return 1;
		}
	}
	return 0;
}

int ne(char table[25][25],int row,int col,char word[15],int size) {
	int i,k=0,c=col;
	if((row+1>=strlen(word))&&(col+strlen(word)<size)) {
		for(i=row;i<strlen(word)+row;i--,k++,c++)
			if(word[k]!=table[i][c])
				return 0;
		if(k==strlen(word)) {
			printf("%d %d\n",row,col);
			return 1;
		}
	}
	return 0;
}

int nnw(char table[25][25],int row,int col,char word[15],int size) {
	int i,k=0,c=col;
	if((row+1>=strlen(word))&&(col+1>=strlen(word))) {
		for(i=row;i<strlen(word)+row;i--,k++,c--)
			if(word[k]!=table[i][c])
				return 0;
		if(k==strlen(word)) {
			printf("%d %d\n",row,col);
			return 1;
		}
	}
	return 0;
}


int s(char table[25][25],int row,int col,char word[15],int size) {
	int i,k=0;
	if(row+strlen(word)<size) {
		for(i=row;i<strlen(word)+row;i++,k++)
			if(word[k]!=table[i][col])
				return 0;
		if(k==strlen(word)) {
			printf("%d %d\n",row,col);
			return 1;
		}
	}
	return 0;
}

int sw(char table[25][25],int row,int col,char word[15],int size) {
	int i,k=0,c=col;
	if((row+strlen(word)<size)&&(col+1>=strlen(word))) {
		for(i=row;i<strlen(word)+row;i++,k++,c--)
			if(word[k]!=table[i][c])
				return 0;
		if(k==strlen(word)) {
			printf("%d %d\n",row,col);
			return 1;
		}
	}
	return 0;
}


int e(char table[25][25],int row,int col,char word[15],int size) {
	int i,k=0;
	if(col+strlen(word)<size) {
		for(i=col;i<strlen(word)+col;i++,k++)
			if(word[k]!=table[row][i])
				return 0;
		if(k==strlen(word)) {
			printf("%d %d\n",row,col);
			return 1;
		}
	}
	return 0;
}

int w(char table[25][25],int row,int col,char word[15]) {
	int i,k=0;
	if(col+1>=strlen(word)) {
		for(i=col;i>col-strlen(word);i--,k++)
			if(word[k]!=table[row][i])
				return 0;
		if(k==strlen(word)) {
			printf("%d %d\n",row,col);
			return 1;
		}
	}
	return 0;
}

int se(char table[25][25],int row,int col,char word[15],int size) {
	int i,k=0,c=col;
	if((row+strlen(word)<size)&&(col+strlen(word)<size)) {
		for(i=row;i<strlen(word)+row;i++,k++,c++)
			if(word[k]!=table[i][c])
				return 0;
		if(k==strlen(word)) {
			printf("%d %d\n",row,col);
			return 1;
		}
	}
	return 0;
}

