/*
TASK: MAXESQ
LANG: C
AUTHOR: THEERAPHONG PHUTHONG
CENTER: nu06
*/
#include<stdio.h>

int main()	{
	int n,i,num[50],sum=0,max=0,cound[50];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&num[i]);
	}
	for(i=0;i<n;i++){
		sum=num[i]+num[i+1]+num[i+2];
		if(sum>max){
			max=sum;
			cound[0]=num[i];
			cound[1]=num[i+1];
			cound[2]=num[i+2];
		}
	}
	if(max<=0){
		printf("Empty sequence");
	}
	else{
		for(i=0;i<3;i++){
			printf("%d ",cound[i]);
		}
		printf("\n%d",max);
	}
return 0;	}