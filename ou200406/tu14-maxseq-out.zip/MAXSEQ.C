/*
TASK: MAXSEQ
LANG: C
AUTHOR: NATTHANON THAMSIRARAK
CENTER: TU14
*/
#include<stdio.h>
void main()
{
	int input,loop,loop2,loop3,head=0,foot=0;
	int arr[2500];
	long sum=0,max=0;
	scanf("%d",&input);
	for(loop=0;loop<input;loop++)
	{
		scanf("%d",&arr[loop]);
		if(max>0)
			loop3=head;
		else
			loop3=loop;
		for(;loop3<=loop;loop3++)
		{
			sum=0;
			for(loop2=loop3;loop2<=loop;loop2++)
			{
				sum+=arr[loop2];
				if(sum>max)
				{
					max=sum;
					head=loop3;
					foot=loop2;
				}
			}
		}
	}
	if(max>0)
	{
		for(loop=head;loop<=foot;loop++)
			printf("%d ",arr[loop]);
		printf("\n%ld",max);
	}
	else
		printf("Empty sequence");
}