/*
TASK: DICE
LANG: C
AUTHOR: Pongsakorn Jaiban
CENTER: CMU05
*/

#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int dice[6]={1,2,3,5,4,6};
	int len,i,n,tmp;
	char act[1001];
	scanf("%d",&i);
	while(i!=0)
	{
		scanf("%s",act);
		len=strlen(act);
		for(n=0;n<len;n++)
		{
			switch(act[n])
			{
				case 'F' :{
					tmp=dice[0];
					dice[0]=dice[3];
					dice[3]=dice[5];
					dice[5]=dice[1];
					dice[1]=tmp;
					break;
					}
				case  'B':{
					tmp=dice[0];
					dice[0]=dice[1];
					dice[1]=dice[5];
					dice[5]=dice[3];
					dice[3]=tmp;
					break;
					}
				case  'L':{
					tmp=dice[0];
					dice[0]=dice[4];
					dice[4]=dice[5];
					dice[5]=dice[2];
					dice[2]=tmp;
					break;
					}
				case  'R': {
					tmp=dice[0];
					dice[0]=dice[2];
					dice[2]=dice[5];
					dice[5]=dice[4];
					dice[4]=tmp;
					break;
					}
				case  'C': {
					tmp=dice[1];
					dice[1]=dice[4];
					dice[4]=dice[3];
					dice[3]=dice[2];
					dice[2]=tmp;
					break;
					}
				case  'D': {
					tmp=dice[1];
					dice[1]=dice[2];
					dice[2]=dice[3];
					dice[3]=dice[4];
					dice[4]=tmp;
					break;
					}
			}
		}
		printf("%d ",dice[1]);
		i--;
		dice[0]=1;
		dice[1]=2;
		dice[2]=3;
		dice[3]=5;
		dice[4]=4;
		dice[5]=6;
	}
	return 0;
}