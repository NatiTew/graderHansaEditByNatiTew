/*
TASK: DICE
LANG: C
AUTHOR: Passakorn Phannachitta
CENTER: BUU03
*/

#include <stdio.h>

const char def[6] = {'F','B','L','R','C','D'};

		int dic[6][6] ={5,1,3,6,4,2,
							 2,6,3,1,4,5,
							 4,2,1,5,6,3,
							 3,2,6,5,1,4,
							 1,4,2,3,5,6,
							 1,3,5,4,2,6
							};

		int initdic[6][6] =  {5,1,3,6,4,2,
									 2,6,3,1,4,5,
									 4,2,1,5,6,3,
									 3,2,6,5,1,4,
									 1,4,2,3,5,6,
									 1,3,5,4,2,6
									};

void preinit()
{
	int i,j;
	for(i=0 ; i<6 ; i++) {
		for(j=0 ; j<6 ; j++) {
			dic[i][j] = initdic[i][j];
		}
	}

}

void init(char c,int recent[6])
{
	int i,j;

	for(i=0 ; i<6 ; i++) {
		if(c==def[i]) break;
	}

	for(j=0 ; j<6 ; j++) {
		recent[j] = dic[i][j] ;
	}
}

void gen(int recent[6])
{
	int i,j;
	int tmpdef[6][6],tmprec[6];

//	for(i=0 ; i<6 ; i++) tmprec[i] = recent[i];
/*
	for(i=0 ; i<6 ; i++) {
		for(j=0 ; j<6 ; j++) {
			tmpdef[i][j] = dic[i][j];
		}
	}
*/
	dic[0][0] = recent[3]; 	dic[0][1] = recent[0];
	dic[0][2] = recent[2];  dic[0][3] = recent[5];
	dic[0][4] = recent[4];  dic[0][5] = recent[1];

	dic[1][0] = recent[1]; 	dic[1][1] = recent[5];
	dic[1][2] = recent[2];  dic[1][3] = recent[0];
	dic[1][4] = recent[4];  dic[1][5] = recent[3];

	dic[2][0] = recent[4]; 	dic[2][1] = recent[1];
	dic[2][2] = recent[0];  dic[2][3] = recent[3];
	dic[2][4] = recent[5];  dic[2][5] = recent[2];

	dic[3][0] = recent[2]; 	dic[3][1] = recent[1];
	dic[3][2] = recent[5];  dic[3][3] = recent[3];
	dic[3][4] = recent[0];  dic[3][5] = recent[4];

	dic[4][0] = recent[0]; 	dic[4][1] = recent[4];
	dic[4][2] = recent[1];  dic[4][3] = recent[2];
	dic[4][4] = recent[3];  dic[4][5] = recent[5];

	dic[5][0] = recent[0]; 	dic[5][1] = recent[2];
	dic[5][2] = recent[3];  dic[5][3] = recent[4];
	dic[5][4] = recent[1];  dic[5][5] = recent[5];
/*
	for(i=0 ; i<6 ; i++) {
		for(j=0 ; j<6 ; j++) {
			dic[i][j] = tmpdef[i][j];
		}
	}
*/
}

int main(void)
{
	int recent[6] ={0};

	int rnd,i,j;

	char c;

	scanf("%d\n",&rnd);

	for(i=1 ; i<rnd ; i++) {

		preinit();
		c = getchar();
		init(c,recent);
//		for(j=0 ; j<6 ; j++) recent[j] = 0;

		while( (c = getchar() ) != '\n') {
			gen(recent);
			init(c,recent);
		}
		printf("%d ",recent[1]);
	}

	preinit();
	c = getchar();
	init(c,recent);

	while( (c = getchar() ) != '\n') {
		gen(recent);
		init(c,recent);
	}
	printf("%d\n",recent[1]);

	return 0;
}