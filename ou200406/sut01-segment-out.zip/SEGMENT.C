/*
TASK: SEGMENT
LANG: C
AUTHOR; NUTDANAI PHANSOOKSAI
CENTER: SUT01
*/
#include<stdio.h>
#include<math.h>
void main(){
	long int sum = 0;
	char table[4][50];
	int n1,n2,i,count;
	scanf("%d%d",&n1,&n2);
	for(i = 0;i <= 3;i++) gets(table[i]);
	count = 1;
	for(i = 1;i <= (n1*3)+1;i+=4){
		if(table[1][i] == ' ' && table[2][i-1] == ' '
		&& table[2][i] == ' '
		&& table[2][i+1] == '|' && table[3][i-1] == ' '
		&& table[3][i] == ' '
		&& table[3][i+1] == '|') sum += 1 * pow(10,n1-count++);
		else if(table[1][i] == '_' && table[2][i-1] == ' '
			 && table[2][i] == '_'
			 && table[2][i+1] == '|'  && table[3][i-1] == '|'
			 && table[3][i] == '_' && table[3][i+1] != '|')
			 sum += 2 * pow(10,n1-count++);
		else if(table[1][i] == '_' && table[2][i-1] == ' '
			 && table[2][i] == '_'
			 && table[2][i+1] == '|' && table[3][i-1] == ' '
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 3 * pow(10,n1-count++);
		else if(table[1][i] == ' ' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] == '|' && table[3][i-1] == ' '
			 && table[3][i] == ' ' && table[3][i+1] == '|')
			 sum += 4 * pow(10,n1-count++);
		else if(table[1][i] == '_' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] != '|' && table[3][i-1] == ' '
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 5 * pow(10,n1-count++);
		else if(table[1][i] == '_' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] != '|' && table[3][i-1] == '|'
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 6 * pow(10,n1-count++);
		else if(table[1][i] == '_' && table[2][i-1] == ' '
			 && table[2][i] == ' '
			 && table[2][i+1] == '|' && table[3][i-1] == ' '
			 && table[3][i] == ' ' && table[3][i+1] == '|')
			 sum += 7 * pow(10,n1-count++);
		else if(table[1][i] == '_' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] == '|' && table[3][i-1] == '|'
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 8 * pow(10,n1-count++);
		else if(table[1][i] == '_' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] == '|' && table[3][i-1] == ' '
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 9 * pow(10,n1-count++);
	}
	for(i = 1;i <= 3;i++) gets(table[i]);
	count = 1;
	for(i = 1;i <= (n2*3)+1;i+=4){
		if(table[1][i] == ' ' && table[2][i-1] == ' '
		&& table[2][i] == ' '
		&& table[2][i+1] == '|' && table[3][i-1] == ' '
		&& table[3][i] == ' '
		&& table[3][i+1] == '|') sum += 1 * pow(10,n2-count++);
		else if(table[1][i] == '_' && table[2][i-1] == ' '
			 && table[2][i] == '_'
			 && table[2][i+1] == '|'  && table[3][i-1] == '|'
			 && table[3][i] == '_' && table[3][i+1] != '|')
			 sum += 2 * pow(10,n2-count++);
		else if(table[1][i] == '_' && table[2][i-1] == ' '
			 && table[2][i] == '_'
			 && table[2][i+1] == '|' && table[3][i-1] == ' '
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 3 * pow(10,n2-count++);
		else if(table[1][i] == ' ' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] == '|' && table[3][i-1] == ' '
			 && table[3][i] == ' ' && table[3][i+1] == '|')
			 sum += 4 * pow(10,n2-count++);
		else if(table[1][i] == '_' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] != '|' && table[3][i-1] == ' '
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 5 * pow(10,n2-count++);
		else if(table[1][i] == '_' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] != '|' && table[3][i-1] == '|'
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 6 * pow(10,n2-count++);
		else if(table[1][i] == '_' && table[2][i-1] == ' '
			 && table[2][i] == ' '
			 && table[2][i+1] == '|' && table[3][i-1] == ' '
			 && table[3][i] == ' ' && table[3][i+1] == '|')
			 sum += 7 * pow(10,n2-count++);
		else if(table[1][i] == '_' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] == '|' && table[3][i-1] == '|'
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 8 * pow(10,n2-count++);
		else if(table[1][i] == '_' && table[2][i-1] == '|'
			 && table[2][i] == '_'
			 && table[2][i+1] == '|' && table[3][i-1] == ' '
			 && table[3][i] == '_' && table[3][i+1] == '|')
			 sum += 9 * pow(10,n2-count++);
	}
	printf("%ld",sum);
}