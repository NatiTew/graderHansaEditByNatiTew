/*
TASK: DICE
LANG: C
AUTHOR: ISARAPONG JIROJWONG
CENTER: KMITNB05
*/

#include<stdio.h>
#include<string.h>

int dice[6];


void swap(int input1,int input2);


void main()
{
	int loop1,max,loop2,out[6];
	char input[1010];


	scanf("%d",&max);
	if(max>6||max<1)
		exit(0);
	for(loop1=0;loop1<max;loop1++)
	{
		for(loop2=0;loop2<6;loop2++)
			dice[loop2]=loop2+1;
		swap(3,4);
		scanf("%s",&input);
		if(strlen(input)>1000)
			exit(0);
		for(loop2=0;input[loop2]!='\0';loop2++)
		{
			switch(input[loop2])
			{
				case 'F':{
					swap(0,1);
					swap(0,5);
					swap(0,3);
					break;
				}case 'B':{
					swap(0,1);
					swap(1,3);
					swap(1,5);
					break;
				}case 'L':{
					swap(0,4);
					swap(2,4);
					swap(2,5);
					break;
				}case 'R':{
					swap(0,4);
					swap(0,5);
					swap(0,2);
					break;
				}case 'C':{
					swap(1,4);
					swap(4,3);
					swap(2,3);
					break;
				}case 'D':{
					swap(1,2);
					swap(2,4);
					swap(2,3);
					break;
				}default :exit(0);
			}
			input[loop2]='\0';
		}
		out[loop1]=dice[1];

	}
	for(loop1=0;loop1<max;loop1++)
		printf("%d ",out[loop1]);

}

void swap(int input1,int input2)
{
	int tmp=dice[input1];
	dice[input1]=dice[input2];
	dice[input2]=tmp;
}