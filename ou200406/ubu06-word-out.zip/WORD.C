/*
TASK: WORD
LANG: C
AUTHOR: Sujin Kraiyasin
CENTER: Ubon 06
*/
#include <stdio.h>
#include <string.h>

char input[25][25],word[100][15];
int row,width,wordcount,wf[100]={0},found=0,fposx[100],fposy[100];

void search(char wrd[15])
{
	int j,x,y,i;
	//LOOP SEARCH
	for (i=0;i<wordcount;i++)
	{
		for (y=0;y<row;y++)
		{
			for (x=0;x<width;x++)
			{
				if (input[y][x]==wrd[0])
				{
					//search in row ->
					if (input[y][x+1]==wrd[1])
						for (j=2;j<strlen(wrd);j++)
						{
							if (wrd[j]==input[y][x+j])
								found=1;
							else if (wrd[j]!=input[y][x+j])
								found=0;
							if (found==0)
								break;
							if (j==(strlen(wrd))-1&&found==1)
							{
								wf[i]++;
								if(wf[i]==1)
								{
									fposx[i]=x;
									fposy[i]=y;
								}
							}
						}
					//search in column (Down)
					else if (input[y+1][x]==wrd[1])
						for (j=2;j<strlen(wrd);j++)
						{
							if (wrd[j]==input[y+j][x])
								found=1;
							else if (wrd[j]!=input[y+j][x])
								found=0;
							if (found==0)
								break;
							if (j==(strlen(wrd))-1&&found==1)
							{
								wf[i]++;
								if(wf[i]==1)
								{
									fposx[i]=x;
									fposy[i]=y;
								}
							}
						}
					//search in direction \
					else if (input[y+1][x+1]==wrd[1])
						for (j=2;j<strlen(wrd);j++)
						{
							if (wrd[j]==input[y+j][x+j])
								found=1;
							else if (wrd[j]!=input[y+j][x+j])
								found=0;
							if (found==0)
								break;
							if (j==(strlen(wrd))-1&&found==1)
							{
								wf[i]++;
								if(wf[i]==1)
								{
									fposx[i]=x;
									fposy[i]=y;
								}
							}
						}
					//search in direction /
					else if (input[y+1][x-1]==wrd[1])
						for (j=2;j<strlen(wrd);j++)
						{
							if (wrd[j]==input[y+j][x-j])
								found=1;
							else if (wrd[j]!=input[y+j][x-j])
								found=0;
							if (found==0)
								break;
							if (j==(strlen(wrd))-1&&found==1)
							{
								wf[i]++;
								if(wf[i]==1)
								{
									fposx[i]=x;
									fposy[i]=y;
								}
							}
						}
				}
			}
		}
	}
}

int main()
{
	int i;
	scanf("%d",&row);
	scanf("%d",&width);
	for (i=0;i<row;i++)
	{
		scanf("%s",input[i]);
		strupr(input[i]);
	}
	//read word chk
	scanf("%d",&wordcount);
	for (i=0;i<wordcount;i++)
	{
		scanf("%s",word[i]);
		strupr(word[i]);
	}
	for (i=0;i<wordcount;i++)
	{
		search(word[i]);
		strrev(word[i]);
		search(word[i]);
	}

	//TMP Debug OUT
	for (i=0;i<wordcount;i++)
	{
		printf("%d %d\n",fposy[i],fposx[i]);
	}

	return (0);
}