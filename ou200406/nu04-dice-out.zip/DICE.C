/*
TASK: DICE
LANG: C
AUTHOR: Tawan Sangsue
CENTER: NU04
*/
#include<stdio.h>
#include<string.h>
#define MAX 1000

int main(void)
{
	int dicenum;
	int i,j;
	int stddice[6]={1,2,3,5,4,6};
	int dice[6][6],tempdice[6][6];
	char command[6][MAX];

	scanf("%d",&dicenum);

	if(dicenum<=6)
	{
		for(i=0;i<dicenum;i++)
		{
			scanf("%s",command[i]);
		}
		for(i=0;i<dicenum;i++)
		{
			for(j=0;j<6;j++)
			{
				tempdice[i][j] = stddice[j];
			}

			for(j=0;j<strlen(command[i]);j++)
			{
				if(command[i][j]=='F')
				{
					dice[i][0] = tempdice[i][3];
					dice[i][1] = tempdice[i][0];
					dice[i][2] = tempdice[i][2];
					dice[i][3] = tempdice[i][5];
					dice[i][4] = tempdice[i][4];
					dice[i][5] = tempdice[i][1];

					tempdice[i][0] = dice[i][0];
					tempdice[i][1] = dice[i][1];
					tempdice[i][2] = dice[i][2];
					tempdice[i][3] = dice[i][3];
					tempdice[i][4] = dice[i][4];
					tempdice[i][5] = dice[i][5];
				}
				else if(command[i][j]=='B')
				{
					dice[i][0] = tempdice[i][1];
					dice[i][1] = tempdice[i][5];
					dice[i][2] = tempdice[i][2];
					dice[i][3] = tempdice[i][0];
					dice[i][4] = tempdice[i][4];
					dice[i][5] = tempdice[i][3];

					tempdice[i][0] = dice[i][0];
					tempdice[i][1] = dice[i][1];
					tempdice[i][2] = dice[i][2];
					tempdice[i][3] = dice[i][3];
					tempdice[i][4] = dice[i][4];
					tempdice[i][5] = dice[i][5];

				}
				else if(command[i][j]=='L')
				{
					dice[i][0] = tempdice[i][4];
					dice[i][1] = tempdice[i][1];
					dice[i][2] = tempdice[i][0];
					dice[i][3] = tempdice[i][3];
					dice[i][4] = tempdice[i][5];
					dice[i][5] = tempdice[i][2];

					tempdice[i][0] = dice[i][0];
					tempdice[i][1] = dice[i][1];
					tempdice[i][2] = dice[i][2];
					tempdice[i][3] = dice[i][3];
					tempdice[i][4] = dice[i][4];
					tempdice[i][5] = dice[i][5];
				}
				else if(command[i][j]=='R')
				{
					dice[i][0] = tempdice[i][2];
					dice[i][1] = tempdice[i][1];
					dice[i][2] = tempdice[i][5];
					dice[i][3] = tempdice[i][3];
					dice[i][4] = tempdice[i][0];
					dice[i][5] = tempdice[i][4];

					tempdice[i][0] = dice[i][0];
					tempdice[i][1] = dice[i][1];
					tempdice[i][2] = dice[i][2];
					tempdice[i][3] = dice[i][3];
					tempdice[i][4] = dice[i][4];
					tempdice[i][5] = dice[i][5];
				}
				else if(command[i][j]=='C')
				{
					dice[i][0] = tempdice[i][0];
					dice[i][1] = tempdice[i][4];
					dice[i][2] = tempdice[i][1];
					dice[i][3] = tempdice[i][2];
					dice[i][4] = tempdice[i][3];
					dice[i][5] = tempdice[i][5];

					tempdice[i][0] = dice[i][0];
					tempdice[i][1] = dice[i][1];
					tempdice[i][2] = dice[i][2];
					tempdice[i][3] = dice[i][3];
					tempdice[i][4] = dice[i][4];
					tempdice[i][5] = dice[i][5];
				}
				else if(command[i][j]=='D')
				{
					dice[i][0] = tempdice[i][0];
					dice[i][1] = tempdice[i][2];
					dice[i][2] = tempdice[i][3];
					dice[i][3] = tempdice[i][4];
					dice[i][4] = tempdice[i][1];
					dice[i][5] = tempdice[i][5];

					tempdice[i][1] = dice[i][1];
					tempdice[i][2] = dice[i][2];
					tempdice[i][3] = dice[i][3];
					tempdice[i][4] = dice[i][4];
					tempdice[i][5] = dice[i][5];
					tempdice[i][6] = dice[i][6];

					tempdice[i][0] = dice[i][0];
					tempdice[i][1] = dice[i][1];
					tempdice[i][2] = dice[i][2];
					tempdice[i][3] = dice[i][3];
					tempdice[i][4] = dice[i][4];
					tempdice[i][5] = dice[i][5];
				}
			}
			printf("%d ",dice[i][1]);
		}
	}
	else
	{
		return(0);
	}

	return(0);
}


