/*
TASK: DICE
LANG: C
AUTHOR: Tamsadet Kaosal
CENTER: SU-01
*/

#include<stdio.h>
#include<string.h>
struct dice{
		int t;
		int f;
		int l;
}D[6];
int n=0, x=0, tmp_t=0,tmp_f=0,tmp_l=0, i=0, j=0;
char s[1001]={'\0'};
int main()
{
	scanf("%d",&n);
	if(n!=NULL&&n>=1&&n<=6)
	for(i=0;i<n;i++){
		D[i].t=1;
		D[i].f=2;
		D[i].l=3;
		scanf("%s",s);
		x=strlen(s);

		/*
		F orward
		B ackward
		L eft
		R ight
		C lockwise
		D couter clockwise

		*/
		for(j=0;j<x;j++){
			switch(s[j]){
				/* forward */
				case 'F':
					tmp_t=D[i].t;
					tmp_f=D[i].f;


					D[i].t=tmp_f-7;
					D[i].f=tmp_t;
					if((D[i].t) <0)
						D[i].t*=-1;
					break;
				/* backward */
				case 'B':
					tmp_t=D[i].t;
					tmp_f=D[i].f;

					D[i].f=tmp_t-7;
					D[i].t=tmp_f;
					if((D[i].f) <0)
						D[i].f*=-1;
					break;

				/* Left */
				case 'L':
					tmp_t=D[i].t;
					tmp_l=D[i].l;

					D[i].t=tmp_l-7;
					D[i].l=tmp_t;
					if((D[i].t)<0)
						D[i].t*=-1;
					break;

				/* Right */
				case 'R':
					tmp_f=D[i].f;
					tmp_l=D[i].l;

					D[i].l=tmp_t-7;
					D[i].t=tmp_l;
					if((D[i].l)<0)
						D[i].l*=-1;
					break;
				/* clock wise */
				case 'C':
					tmp_f=D[i].f;
					tmp_l=D[i].l;

					D[i].f=tmp_l-7;
					D[i].l=tmp_f;
					if((D[i].f)<0)
						D[i].f*=-1;
					break;
				/* couter clockwise */
				case 'D':
					tmp_f=D[i].f;
					tmp_l=D[i].l;

					D[i].f=tmp_l;
					D[i].l=tmp_f-7;
					if((D[i].l)<0)
						D[i].l*=-1;
					break;

			}/* end command */
		}    /* for each command */
		printf("%d ",D[i].f);

	}        /* for each dice*/
	return 0;
}