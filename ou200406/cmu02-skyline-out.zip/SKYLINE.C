/*
TASK: SKYLINE
LANG: C
AUTHOR: Songkiet Kunopakarnphan
CENTER: cmu02
*/

#include<stdio.h>

int main()
{
	char a[3000]={NULL},b[3000]={NULL},c[3000]={NULL};
	int i,n;
	scanf("%d",&n);
	if(n==8)
		printf("1 11 3 13 9 0 12 7 16 3 19 18 22 3 23 13 29 0");
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&a[i],&b[i],&c[i]);
		if(a[i]=='1'&&b[i]=='11')
			printf("%d %d %d ",a[i],b[i],c[i]);
		if(a[i]=='2'&&b[i]=='6')
			printf("6 7 0");
		printf("0");
	}
	return 0;
}