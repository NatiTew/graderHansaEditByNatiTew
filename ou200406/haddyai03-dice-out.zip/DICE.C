/*
TASK: DICE
LANG: C
AUTHOR: Poohmai Chaikeaw
CENTER: HADDYAI03
*/
#include<stdio.h>
#include<string.h>
void swap(int dic[],int,int);
void chan(char con[]);
void main()
{
int n,i;
char con[1000];
scanf("%d",&n);
if((n>6)||(n<1));
else
  {
  for(i=0;i<n;i++)
    {
       scanf("%s",con);
       chan(con);
    }
  }
}

void chan(char con[])
{
int i,dic[6]={1,2,3,4,5,6};
for(i=0;i<strlen(con);i++)
  {
    switch(con[i])
      {
      case 'F': swap(dic,0,1);
		swap(dic,0,5);
		swap(dic,0,4);break;
      case 'B': swap(dic,0,1);
		swap(dic,1,5);
		swap(dic,5,4);break;
      case 'D': swap(dic,3,1);
		swap(dic,2,1);
		swap(dic,2,4);break;
      case 'C': swap(dic,3,1);
		swap(dic,4,3);
		swap(dic,2,4);break;
      case 'L': swap(dic,0,2);
		swap(dic,0,3);
		swap(dic,5,3);break;
      case 'R': swap(dic,0,3);
		swap(dic,0,2);
		swap(dic,5,3);break;
      }
  }
  printf("%d ",dic[1]);
}
void swap(int dic[],int a,int b)
{
int temp;
temp=dic[a];
dic[a]=dic[b];
dic[b]=temp;
}

