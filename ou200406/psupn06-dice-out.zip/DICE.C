/*
TASK:DICE
LANG: C
AUTHOR: SITTHITHEP NARATHONG
CENTER: PSUPN06
*/

#include<stdio.h>
void main(){
	int num,i,t[6],temp,k=0,m=0,j,ans[1000];
	char check,wt[1000];
	scanf("%d",&num);
	for(i=0;i<num;i++){
		scanf("%s",wt);
		t[0]=1;t[1]=2;t[2]=3;t[3]=5;t[4]=4;t[5]=6;
		k=0;
		while(wt[k]!='\0'){
			switch(wt[k]){
				case 'F':temp=t[1];
					 t[1]=t[0];
					 t[0]=t[3];
					 t[3]=t[5];
					 t[5]=temp;break;
				case 'B':temp=t[1];
					 t[1]=t[5];
					 t[5]=t[3];
					 t[3]=t[0];
					 t[0]=temp;break;
				case 'L':temp=t[2];
					 t[2]=t[0];
					 t[0]=t[4];
					 t[4]=t[5];
					 t[5]=temp;break;
				case 'R':temp=t[4];
					 t[4]=t[0];
					 t[0]=t[2];
					 t[2]=t[5];
					 t[5]=temp;break;
				case 'C':temp=t[1];
					 t[1]=t[4];
					 t[4]=t[3];
					 t[3]=t[2];
					 t[2]=temp;break;
				case 'D':temp=t[1];
					 t[1]=t[2];
					 t[2]=t[3];
					 t[3]=t[4];
					 t[4]=temp;break;
			}
		k++;
		}
		ans[m]=t[1];
		m++;
	}
	for(i=0;i<m;i++)
		printf("%d ",ans[i]);
}



