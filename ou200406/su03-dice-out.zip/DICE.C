/*
TASK: DICE
LANG: C
AUTHOR: SUTUTTA SEANGTHONG
CENTER: SU-03
*/


#include <stdio.h>
#include <string.h>
#define MAX 1001

int f,b,l,r,t,d,tmp;

void SetCub()
{	t=1;
	f=2;
	l=3;
	b=5;
	r=4;
	d=6;
}


int main()
{  int n,i,j,len,tmp,ans[MAX];
   char order[MAX];
	scanf("%d",&n);
	if (n>=1&&n<=6)
	{	for (i=1;i<=n;i++)
		{	SetCub();
			//gets(order);
			scanf("%s",order);
			len=strlen(order);
			for (j=0;j<len;j++)
			{	if (order[j]=='F')
				{	tmp=f;
					f=t;
					t=b;
					b=d;
					d=tmp;
				}
				else if (order[j]=='B')
				{	tmp=f;
					f=d;
					d=b;
					b=t;
					t=tmp;
				}
				else if (order[j]=='L')
				{	tmp=t;
					t=r;
					r=d;
					d=l;
					l=tmp;

				}
				else if (order[j]=='R')
				{	tmp=t;
					t=l;
					l=d;
					d=r;
					r=tmp;
				}
				else if (order[j]=='C')
				{	tmp=f;
					f=r;
					r=b;
					b=l;
					l=tmp;
				}
				else if (order[j]=='D')
				{	tmp=f;
					f=l;
					l=b;
					b=r;
					r=tmp;
				}
			}
			ans[i-1]=f;
			SetCub();
		}
		for (j=0;j<i-1;j++)
			printf("%d ",ans[j]);
	}

   return 0;
}