/*
TASK: DICE
LANG: C
AUTHOR: GAIPEACH SUCHARTKULVIT
CENTER: ASSUMPTION COLLEGE SRIRACHA - buu01
*/
#include <stdio.h>
#include <string.h>

int set[6]={1,2,3,4,5,6};
int dice[6];

void setdice(void)
{
	int i;
	for(i=0;i<6;i++)
		dice[i]=set[i];
}
void forward(void)
{
	int predice[6];
	int i;
	for(i=0;i<6;i++)
	{
		predice[i]=dice[i];
	}
	dice[0]=predice[3];
	dice[1]=predice[0];
	dice[3]=predice[5];
	dice[5]=predice[1];
}
void backward(void)
{
	int predice[6];
	int i;
	for(i=0;i<6;i++)
	{
		predice[i]=dice[i];
	}
	dice[0]=predice[1];
	dice[1]=predice[5];
	dice[3]=predice[0];
	dice[5]=predice[3];
}
void right(void)
{
	int predice[6];
	int i;
	for(i=0;i<6;i++)
	{
		predice[i]=dice[i];
	}
	dice[0]=predice[2];
	dice[2]=predice[5];
	dice[4]=predice[0];
	dice[5]=predice[4];
}
void left(void)
{
	int predice[6];
	int i;
	for(i=0;i<6;i++)
	{
		predice[i]=dice[i];
	}
	dice[0]=predice[4];
	dice[2]=predice[0];
	dice[4]=predice[5];
	dice[5]=predice[2];
}
void clock(void)
{
	int predice[6];
	int i;
	for(i=0;i<6;i++)
	{
		predice[i]=dice[i];
	}
	dice[1]=predice[4];
	dice[2]=predice[1];
	dice[3]=predice[2];
	dice[4]=predice[3];
}
void dclock(void)
{
	int predice[6];
	int i;
	for(i=0;i<6;i++)
	{
		predice[i]=dice[i];
	}
	dice[1]=predice[2];
	dice[2]=predice[3];
	dice[3]=predice[4];
	dice[4]=predice[1];
}
int main(void)
{
	char turn[1100];
	int n;
	int i,j;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		setdice();
		scanf("%s",turn);
		for(j=0;j<strlen(turn);j++)
		{
			switch(turn[j])
			{
				case'F': forward();break;
				case'B': backward();break;
				case'L': left();break;
				case'R': right();break;
				case'C': clock();break;
				case'D': dclock();break;
			}
		}
		printf("%d ",dice[1]);
	}
	return 0;
}