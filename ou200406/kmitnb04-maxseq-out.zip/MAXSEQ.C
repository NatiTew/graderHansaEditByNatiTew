/*
TASK: MAXSEQ
LANG: C
AUTHOR: Mr.Pichayawat Karnjanaves
CENTER: KMITNB04
*/

#include<stdio.h>

int main()
{
	int i,j,n,total,max=0,sum=0,fp=0,lp=0,a[3000],k;
	scanf("%d",&total);
	n=total;

	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
		}

	for(i=total-1;i>0;i--) {
		if(a[i]<=0)
			n=n-1;
		else
		if(a[i]+a[i-1] <=0)
			n=n-2;
		else
			break;
		}
	for(i=0;i<n;i++) {
		for(j=i;j<n;n--) {
			for(k=j;k<n;k++) {
				sum=sum+a[k];
			}
			if(sum>max) {
				max=sum;
				fp=j;
				lp=n;
			}
			sum=0;
		}
		n=total;
	}
	if(max<=0)
		printf("Empty sequence");
	else {
		for(i=fp;i<lp;i++)
			printf("%d ",a[i]);
		printf("\n%d",max);
	}
	return 0;
}

