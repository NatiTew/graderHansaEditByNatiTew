/*
Task:word
Lang:c
author:Phongrapee Phongvivat
center:haddyai02
*/

#include<stdio.h>
#include<ctype.h>
#include<string.h>

void main()
{int i,j,m,n,k,a,x,y,chk=0,xx=0,yy=0,zz;
 char table[27][27],word[16],word1[16];
 FILE *fp;
 if((fp=fopen("c:/posn2/word.txt","r"))==NULL)
  printf("cannot");
 else
 {fscanf(fp,"%d %d",&m,&n);

 for(i=0;i<m;i++)
   {for(j=0;j<=n;j++)
      {  fscanf(fp,"%c",&table[i][j]);
	 table[i][j]=toupper(table[i][j]);
	 printf("%c",table[i][j]);
	}//for j
     }//for i

  fscanf(fp,"%d",&a);
    for(i=0;i<a;i++)
     { fscanf(fp,"%s",word);

       for(j=0;j<strlen(word);j++)
       word[j]=toupper(word[j]);

       printf("\n%s",word);

       for(j=0;j<m;j++)
	{for(k=0;k<n;k++)
	  {chk=0;
	   word1[0]=NULL;
	  if(word[0]==table[j][k])
	    {if(strlen(word)+j<m)
	      {for(xx=j,zz=0;xx<strlen(word)+j;xx++,zz++)
		word1[zz]=table[xx][k];

	       if(strcmp(word1,word)==0)
		{chk=1;break;}
	       }
	  /*   if(m-strlen(word)>=0)
	     if(strlen(word)+k<n)
	     if(k-strlen(word)>=0)
	     if(strlen(word)+j>0)
	     if(strlen(word)+j>0)  */
	     }//if
	   if(chk==1)
	    break;
	   }//for k
	   if(chk==1)
	    break;
	 }//for j
	  printf("%d %d ",j,k);
       }//for i
  }//else
}