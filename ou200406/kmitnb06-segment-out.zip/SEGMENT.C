/*
TASK: SEGMENT
LANG: C
AUTHOR: PIRAPAT JAKPAISAL
CENTER: KMITNB-06
*/
#include<stdio.h>

void main() {
	int d,e;
	scanf("%d %d",&d,&e);
	if(e==2) {
		printf("1455");
	} else if(e==3) {
		printf("2139");
	}
}