/*
TASK:WORD
LANG:C
AUTHOR:SUPASHOCK RENGSOMBOON
CENTER:KKU04
*/
#include<stdio.h>
#include<string.h>



int main(){
int i,j,r,c,w,k,l,sc=0;
char dat[26][26],word[100][16];

	scanf("%d",&r);
	scanf("%d",&c);

	for(i=0;i<r;i++){
	scanf("%s",&dat[i]);
	}
	scanf("%d",&w);

	for(k=0;k<w;k++){
	scanf("%s",&word[k]); }
	for(k=0;k<w;k++){
	for(i=0;i<r;i++){
	for(j=0;j<c;j++){
	 if((word[k][0]==dat[i][j])||(word[k][0]==dat[i][j]-32)||(word[k][0]==dat[i][j]+32)){
	     if((word[k][1]==dat[i][j+1])||(word[k][1]==dat[i][j+1]-32)||(word[k][1]==dat[i][j+1]+32)){

	     for(l=0;l<strlen(word[k]);l++){
	     if(word[k][l]==dat[i][j+l]){sc++;}
	     else {sc=0;break;}
	     }
	     if (sc==strlen(word[k])){printf("%d %d\n",i,j);sc=0;break;}

	     }
	     else if((word[k][1]==dat[i-1][j+1])||(word[k][1]==dat[i-1][j+1]-32)||(word[k][1]==dat[i-1][j+1]+32)){

	     for(l=0;l<strlen(word[k]);l++){
	     if(word[k][l]==dat[i-l][j+l]){sc++;}
	     else {sc=0;break;}
	     }
	     if (sc==strlen(word[k])){printf("%d %d\n",i,j);sc=0;break;}

	     }

	     else if((word[k][1]==dat[i-1][j])||(word[k][1]==dat[i-1][j]-32)||(word[k][1]==dat[i-1][j]+32)){

	     for(l=0;l<strlen(word[k]);l++){
	     if(word[k][l]==dat[i-l][j]){sc++;}
	     else {sc=0;break;}
	     }
	     if (sc==strlen(word[k])){printf("%d %d\n",i,j);sc=0;break;}

	     }
	     else if((word[k][1]==dat[i-1][j-1])||(word[k][1]==dat[i-1][j-1]-32)||(word[k][1]==dat[i-1][j-1]+32)){

	     for(l=0;l<strlen(word[k]);l++){
	     if(word[k][l]==dat[i-l][j-l]){sc++;}
	     else {sc=0;break;}
	     }
	     if (sc==strlen(word[k])){printf("%d %d\n",i,j);sc=0;break;}

	     }
	     else if((word[k][1]==dat[i][j-1])||(word[k][1]==dat[i][j-1]-32)||(word[k][1]==dat[i][j-1]+32)){

	     for(l=0;l<strlen(word[k]);l++){
	     if(word[k][l]==dat[i][j-l]){sc++;}
	     else {sc=0;break;}
	     }
	     if (sc==strlen(word[k])){printf("%d %d\n",i,j);sc=0;break;}

	     }
	     else if((word[k][1]==dat[i+1][j-1])||(word[k][1]==dat[i+1][j-1]-32)||(word[k][1]==dat[i+1][j-1]+32)){

	     for(l=0;l<strlen(word[k]);l++){
	     if(word[k][l]==dat[i+l][j-l]){sc++;}
	     else {sc=0;break;}
	     }
	     if (sc==strlen(word[k])){printf("%d %d\n",i,j);sc=0;break;}

	     }
	     else if((word[k][1]==dat[i-1][j])||(word[k][1]==dat[i-1][j]-32)||(word[k][1]==dat[i-1][j]+32)){

	     for(l=0;l<strlen(word[k]);l++){
	     if(word[k][l]==dat[i-l][j]){sc++;}
	     else {sc=0;break;}
	     }
	     if (sc==strlen(word[k])){printf("%d %d\n",i,j);sc=0;break;}

	     }
	     else if((word[k][1]==dat[i+1][j+1])||(word[k][1]==dat[i+1][j+1]-32)||(word[k][1]==dat[i+1][j+1]+32)){

	     for(l=0;l<strlen(word[k]);l++){
	     if(word[l]==dat[i+l][j+l]){sc++;}
	     else {sc=0;break;}
	     }
	     if (sc==strlen(word[k])){printf("%d %d\n",i,j);sc=0;break;}

	     }
					}
			}


			 }
	}





return 0;
}