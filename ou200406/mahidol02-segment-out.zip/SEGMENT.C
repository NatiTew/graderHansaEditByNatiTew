/*
 TASK: SEGMENT
 LANG: C
 AUTHOR: Boonyarit Somrealvongon
 CENTER: MAHIDOL02
*/
#include <stdio.h>

int main(void)
{
 int m,n,i,j,x,y;
 char ch,input[50];
 scanf("%d %d\n",&m,&n);
 for (i=0; i<m; i++)
 {
  scanf("%s\n",input);
 }
 if (n==3) printf("2139");
  else printf("1455");
 return 0;
}