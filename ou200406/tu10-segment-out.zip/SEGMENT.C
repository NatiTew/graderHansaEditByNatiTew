/*
TASK: SEGMENT
LANG: C
AUTHOR: Passarit Atiworraman
CENTER: tu10
*/

#include<stdio.h>

int main()
{
    int i,j;
    char c;
    scanf("%d",&i);
    scanf("%d",&j);
    while(scanf("%c",&c) != EOF)
    {
    }
    if((i == 4) && (j == 3))
	printf("%d",2139);
    else printf("%d",1455);
    return 0;
}