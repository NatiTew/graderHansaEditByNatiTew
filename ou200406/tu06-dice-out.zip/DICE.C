/*
TASK: DICE
LANG: C
AUTHOR: CHANTAT EKSOMBATCHAI
CENTER: TU06
*/
#include<stdio.h>
#include<string.h>
main()
{
	int a[7],n,i,j,tmp[7],len,k;
	char str[1010];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		a[0] = 1;
		a[1] = 2;
		a[2] = 3;
		a[3] = 5;
		a[4] = 4;
		a[5] = 6;
		scanf("%s",str);
		len = strlen(str);
		for(j=0;j<len;j++)
		{
			if(str[j] == 'F')
			{
				tmp[0] = a[3];
				tmp[1] = a[0];
				tmp[2] = a[2];
				tmp[3] = a[5];
				tmp[4] = a[4];
				tmp[5] = a[1];
			}
			else if(str[j] == 'B')
			{
				tmp[0] = a[1];
				tmp[1] = a[5];
				tmp[2] = a[2];
				tmp[3] = a[0];
				tmp[4] = a[4];
				tmp[5] = a[3];
			}
			else if(str[j] == 'L')
			{
				tmp[0] = a[4];
				tmp[1] = a[1];
				tmp[2] = a[0];
				tmp[3] = a[3];
				tmp[4] = a[5];
				tmp[5] = a[2];
			}
			else if(str[j] == 'R')
			{
				tmp[0] = a[2];
				tmp[1] = a[1];
				tmp[2] = a[5];
				tmp[3] = a[3];
				tmp[4] = a[0];
				tmp[5] = a[4];
			}
			else if(str[j] == 'C')
			{
				tmp[0] = a[0];
				tmp[1] = a[4];
				tmp[2] = a[1];
				tmp[3] = a[2];
				tmp[4] = a[3];
				tmp[5] = a[5];
			}
			else if(str[j] == 'D')
			{
				tmp[0] = a[0];
				tmp[1] = a[2];
				tmp[2] = a[3];
				tmp[3] = a[4];
				tmp[4] = a[1];
				tmp[5] = a[5];
			}
			for(k=0;k<6;k++)
				a[k] = tmp[k];
		}
		printf("%d ",a[1]);
	}
	return 0;
}

