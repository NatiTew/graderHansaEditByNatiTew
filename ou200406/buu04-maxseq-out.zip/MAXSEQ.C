/*
TASK: MAXSEQ
LANG: C
AUTHOR: Sirawit Phutrakul
CENTER: BUU
*/
#include<stdio.h>
#include<stdlib.h>
int main(void){
	int i ,j ,k ,n ,sen;
	int *num;
	long max = 0 ,sum;
	int head ,len;
	scanf("%d",&n);
	if((1<=n)&&(n<=2500)) {
		num = (int *)malloc(sizeof(int)*n);
		sen = 1;
		for(i=0;i<n;i++) {
			scanf("%d",&num[i]);
			if((num[i] < -127)||(num[i] > 127)) {
				sen = 0;
				break;
			}
		}
		if(sen==1) {	
	
	for(i=1;i<=n;i++) {
		for(j=0;j+i<=n;j++) {
			sum = 0;
			for(k=j;k<j+i;k++)
				sum += num[k];
			if(sum>max) {
				max = sum;
				head = j;
				len = i;
			}
		}
	}

			if(max>0) {
				for(i=0;i<len;i++) {
					printf("%d ",num[head]);
					head++;
				}
				printf("\n%ld",max);
			}
			else
				printf("Empty sequence");
                } /*else
			printf("Empty sequence");*/
		free(num);
	}
	return 0;
}
