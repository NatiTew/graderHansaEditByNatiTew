/*
TASK: SKYLINE
LANG: C
AUTHOR: THAWATCHAI MUKMANEE
CENTER: ubu03
*/
#include <stdio.h>
int main()
{
int sky[256]={0},r[3];
int n,i,j,max=0,min=255,x,zero=0;
scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<3;j++)
		{
		scanf("%d",&r[j]);
		}
		j=r[0];
		while(j<r[2])
		{
		if(sky[j]<r[1])
		sky[j]=r[1];
		if(max<r[2])
		max=r[2];
		if(min>r[0])
		min=r[0];

		j++;
		}
	}
	while(min<max)
	{
	x=0;
	printf("%d ",min);
		while(x==0)
		{
		if(sky[min]!=sky[min+1])
		{
		printf("%d ",sky[min]);
		x++;
		}
		min++;
		}
	}
	if(min!=256)
	printf("%d 0\n",min);
return 0;
}