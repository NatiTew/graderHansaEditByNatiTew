/*
TASK: MAXSEQ
LANG: C
AUTHOR: Tamsadet Kaosal
CENTER: SU-01
*/
#include<stdio.h>
#include<stdlib.h>
int a[2502];
int n=0, i,j, flag=0, loc=0;
int max_val=0,sta_val=0,end_val=0;
int sta,end=0,sum=0,tmp=-32760;
int main()
{   flag=0;
	scanf("%d",&n);

	if(n!=NULL&n>=1&&n<=2500){
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);

	}
	/*start to find gold*/
	i=0;
	while(a[i]<0)
		i++;
	sta = i;
	/* end of gold */
	i=n-1;
	while(a[i]<0)
		i--;
	end = i;

	/* begin */
	for(i=sta;i<=end;i++){
		loc=i;
		sum=0;
		if(a[i]<0)
			continue;

		for(j=i;j<=end;j++){
			sum+=a[j];
			if(sum>max_val&&sum!=0)
			{   flag=1;
				loc=j;
				sta_val=i;
				end_val=loc;
				max_val=sum;
			}
		}
	}
	if(flag==1)
	{
		for(i=sta_val;i<=end_val;i++)
		{	printf("%d ",a[i]);

		}
		printf("\n%d",max_val);
	}
	else
		printf("Empty Sequence\n");

	}/* end big if */
	return 0;

}