/*
Task:BEE
LANG:C
AUTHOR:PHONGRAPEE PHONGVIVAT
CENTER:HATYAI02
*/

#include<stdio.h>
void main()
{long int a[5]={1,0,1,0,0},b[5],y,n,i;

 scanf("%ld",&y);
 while(y!=-1)
 {  for(n=0;n<y;n++)
     {
       for(i=0;i<5;i++)
       b[i]=a[i];

       a[1]=b[0];
       a[2]=b[1]+b[2]+b[3];
       a[3]=b[4];
       a[4]=b[1]+b[2]+b[3];

       }

  printf("%ld %ld",a[1]+a[2]+a[3],a[0]+a[1]+a[2]+a[3]+a[4]);

  scanf("%ld",&y);
    a[0]=b[0]=1;
    a[1]=b[1]=0;
    a[2]=b[2]=1;
    a[3]=b[3]=0;
    a[4]=b[4]=0;
  }
}