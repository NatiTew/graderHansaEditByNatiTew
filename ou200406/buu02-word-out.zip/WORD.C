/*
TASK: WORD
LANG: C
AUTHOR: Khakhana Thimachai
CENTER: buu02
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char tw[25][25];
char test[25];
int m,n;
int check(void);
int checkad(int y,int x);
int main(void){
	int i;
	int ns;
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++){
		scanf("%s",tw[i]);
		strlwr(tw[i]);
	}
	//for(i=0;i<m;i++){
       //		printf("%s\n",tw[i]);
       //	}
	scanf("%d",&ns);
	i=0;
	while(i<ns){
		scanf("%s",test);
		strlwr(test);
		check();
		i++;
	}
	return 0;
}

int check(void){
	int i,j;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			if(tw[i][j]==test[0]){
				//printf("++++++++++\n");
				if(checkad(i,j))
					return 0;
			}
		}
	}
	return 0;
}

int  checkad(int y,int x){
	int i,j,k;
	int ex=0;
	int len;
	len = strlen(test);
	for(i=x,j=0;i<n&&j<len;i++,j++){
		if(tw[y][i]!=test[j])
			ex=1;
	}
	if(i>=n&&j<len)
		ex=1;
	if(ex==0){
		printf("%d %d\n",y,x);
		return 1;
	}
	if(ex){
		ex=0;
		for(i=x,j=0;i>=0&&j<len;i--,j++){
			if(tw[y][i]!=test[j])
				ex=1;
		}
		if(i<0&&j<len)
			ex=1;
		if(ex==0){
			printf("%d %d\n",y,x);
			return 1;
		}
	}
	if(ex){
		ex=0;
		for(i=y,j=0;i<m&&j<len;i++,j++){
			if(tw[i][x]!=test[j])
				ex=1;
		}
		if(i>=m&&j<len)
			ex=1;
		if(ex==0){
			printf("%d %d\n",y,x);
			return 1;
		}
	}
	if(ex){
		ex=0;
		for(i=y,j=x,k=0;i<m&&j<n&&k<len;i++,j++,k++){
			if(tw[i][j]!=test[k])
				ex=1;
		}
		if(!(i<m&&j<n)&&k<len)
			ex=1;
		if(ex==0){
			printf("%d %d\n",y,x);
			return 1;
		}
	}
	if(ex){
		ex=0;
		for(i=y,j=x,k=0;i<m&&j>=0&&k<len;i++,j--,k++){
			if(tw[i][j]!=test[k])
				ex=1;
		}
		if(!(i<m&&j>=0)&&k<len)
			ex=1;
		if(ex==0){
			printf("%d %d\n",y,x);
			return 1;
		}
	}
	if(ex){
		ex=0;
		for(i=x,j=y,k=0;i<m&&j>=0&&k<len;i++,j--,k++){
			if(tw[j][i]!=test[k])
				ex=1;
		}
		if(!(i<m&&j>=0)&&k<len)
			ex=1;
		if(ex==0){
			printf("%d %d\n",y,x);
			return 1;
		}
	}
	if(ex){
		ex=0;
		for(i=y,j=x,k=0;i>=0&&j>=0&&k<len;i--,j--,k++){
			if(tw[i][j]!=test[k])
				ex=1;
		}
		if(!(i>=0&&j>=0)&&k<len)
			ex=1;
		if(ex==0){
			printf("%d %d\n",y,x);
			return 1;
		}
	}

	return 0;
}
