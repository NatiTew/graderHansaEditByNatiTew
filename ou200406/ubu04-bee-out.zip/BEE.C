/*
TASK: BEE
LANG: C
AUTHOR: Mr.Krita Tonguan
CENTER: ubu04
*/

#include<stdio.h>

int main(){
	int round;
	int i;
	long work, harn, tmpwork, tmpharn;

	scanf("%d" , &round);
	while(round != -1 && round > 0){
			work = 1;
			harn = 0;
		for(i=0;i<round;i++){
			tmpwork = 0;
			tmpharn = 0;
			//king
			tmpwork++;
			//work;
			tmpwork+=work;
			tmpharn+=work;
			//harn;
			tmpwork+=harn;

			work = tmpwork;
			harn = tmpharn;
		}
		printf("%ld %ld\n", work, work+harn+1);
		scanf("%d", &round);
	}
	return 0;
}