/*
TASK: MAXSEQ
LANG: C
AUTHOR: NUTTAWUT MANEEKASORN
CENTER: PSUPN-01
*/

#include <stdio.h>

int main(){
  int max,start=0,end=0,cnt=0;
  int i,j,k;
  int lst[2600];
  int sum=0;

  scanf("%d",&cnt);
  for(i=0;i<cnt;i++){
      scanf("%d",&lst[i]);
  }

  max = 0;
  for(i=0;i<cnt-1;i++){
      for(j=i+1;j<cnt;j++){
	  sum = 0;
	  for(k=i;k<j;k++){
	      sum+= lst[k];
	  }
	  if(sum>max){
	     max = sum;
	     start = i;
	     end = j;
	  }
      }
  }
  if(max>0){
    for(k=start;k<end;k++){
      printf("%d ",lst[k]);
    }
    printf("\n%d",max);
  }
  else{
      printf("Empty sequence");
  }
  return 0;
}