/*
TASK: SKYLINE
LANG: C
AUTHOR: THEERAPHONG PHUTHONG
CENTER: nu06
*/
#include<stdio.h>

main()	{
   long int l[70]={NULL},h[70]={NULL},r[70]={NULL};
   long int i,j,n,teml=0,temh=0,temr=0;
   scanf("%ld",&n);
	for(i=0;i<n;i++){
	    scanf("%ld %ld %ld",&l[i],&h[i],&r[i]);
	 }
	for(i=0;i<n;i++){
	   for(j=0;j<n-1;j++){
		if(l[j]>l[j+1]){
		   teml=l[j];
		   l[j]=l[j+1];
		   l[j+1]=teml;
		   temh=h[j];
		   h[j]=h[j+1];
		   h[j+1]=temh;
		   temr=r[j];
		   r[j]=r[j+1];
		   r[j+1]=temr;
		}
	   }  // for
	} // for
	printf("%ld %ld %ld ",l[0],h[0],r[0]);
	for(i=0;i<n;i++){
	    if(r[i]>l[i+1]){
		if(h[i]>h[i+1]){
		  //   printf("%ld ",l[i]);
		}
		else if(h[i+1]>h[i]){
		     printf("%ld %ld ",l[i+1],h[i+1]);
		}
	    }
	    if(r[i-1]>l[i]&&h[i]<h[i-1]){
		 printf("%ld %ld ",h[i],r[i]);
	    }

	 }   // for
	printf("0");
return 0;}