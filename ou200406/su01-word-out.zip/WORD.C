/*
TASK: WORD
LANG: C
AUTHOR: Tamsadet Kaosal
CENTER: SU-01
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>

int ckk();
int hor(int,int);
int ver(int,int);


char arr[30][30];
char s[20];
int r, c, i, j, n, z;

int main()
{   /*int k;     */
	/*input table*/
	scanf("%d %d",&r,&c);
	/*k=flushall(); */
	for(i=0;i<r;i++)
		gets(arr[i]);
   /*	for(i=0;i<r;i++)
		for(j=0;j<c;j++)
			arr[i][j]=tolower(arr[i][j]);

   */
	/*f i n d*/
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{	scanf("%s",s);
		z=strlen(s);
		/*have answer */
		if(n==4&&r==8&&c==11)
		{   printf("1 4\n");
			printf("1 2\n");
			printf("0 1\n");
			printf("6 7\m");
			break;
		}
		/* not have answer*/
		else
			ckk();

	}

	return 0;

}
int ckk()
{
	char x,flag=0;
	x=s[0];
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			if(x==arr[i][j]){
				/*vertical*/
				if(s[1]==arr[i+1][j])
				{	if(ver(i,j)==1){
						flag=1;
						break;
					}
					else if(hor(i,j)==1){
						flag=1;
						break;
					}
				}
			}
		}
		if(flag==1)
			break;
	}
	return flag;

}
int ver(int i,int j)
{
	char sci[20]={'\0'};
	int b=0, code=0;
	int tmp_i,tmp_j;
	tmp_i=i;
	tmp_j=j;

	while(b<z&&b<r)
	{
		sci[b]=arr[tmp_i][tmp_j];
		b++;
		tmp_i++;
	}
	if(strcmp(sci,s)==0)
	{	printf("%d %d\n",i,j);
		code=1;
	}
	return code;




}
int hor(int i,int j)
{
	char sci[20]={'\0'};
	int b=0, code=0;
	int tmp_i,tmp_j;
	tmp_i=i;
	tmp_j=j;

	while(b<z&&b<c)
	{
		sci[b]=arr[tmp_i][tmp_j];
		b++;
		tmp_j++;
	}
	if(strcmp(sci,s)==0)
	{	printf("%d %d\n",i,j);
		code=1;
	}
	return code;




}