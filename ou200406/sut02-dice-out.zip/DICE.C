/*
TASK: DICE
LANG: C
AUTHOR: Prayote Boonchaisuk
CENTER: SUT02
*/
#include<stdio.h>
#include<string.h>
int d[6]={1,2,3,5,4,6},s[6],t[6]={1,2,3,5,4,6},r[6];
void main(){
	int n,i,j,k;
	char st[1001];
	scanf(" %d", &n);
	for(i=0;i<n;i++)
	       {
		for(j=0;j<6;j++)
			t[j]=d[j];
		scanf("%s",st);
		for(j=0;j<strlen(st);j++)
		   {
		    if(st[j]=='F')
{ for(k=0;k<6;k++)
	{s[k]=t[k];}
 s[0]=t[3];
 s[1]=t[0];
 s[3]=t[5];
 s[5]=t[1];
 for(k=0;k<6;k++)
	{t[k]=s[k];}}
		    if(st[j]=='B')
{ for(k=0;k<6;k++)
	{s[k]=t[k];}
 s[0]=t[1];
 s[1]=t[5];
 s[3]=t[0];
 s[5]=t[3];
 for(k=0;k<6;k++)
	{t[k]=s[k];}}
		    if(st[j]=='L')
{ for(k=0;k<6;k++)
	{s[k]=t[k];}
 s[0]=t[4];
 s[2]=t[0];
 s[4]=t[5];
 s[5]=t[3];
 for(k=0;k<6;k++)
	{t[k]=s[k];}}
		    if(st[j]=='R')
{ for(k=0;k<6;k++)
	{s[k]=t[k];}
 s[0]=t[2];
 s[2]=t[5];
 s[4]=t[0];
 s[5]=t[4];
 for(k=0;k<6;k++)
	{t[k]=s[k];}}
		    if(st[j]=='C')
{ for(k=0;k<6;k++)
	{s[k]=t[k];}
 s[1]=t[4];
 s[2]=t[1];
 s[3]=t[2];
 s[4]=t[3];
 for(k=0;k<6;k++)
	{t[k]=s[k];}}
		    if(st[j]=='D')
{for(k=0;k<6;k++)
	{s[k]=t[k];}
 s[1]=t[2];
 s[2]=t[3];
 s[3]=t[4];
 s[4]=t[1];
 for(k=0;k<6;k++)
	{t[k]=s[k];}}
		   }
		r[i]=t[1];
	       }
	for(i=0;i<n;i++)  printf("%d ",r[i]);
}
