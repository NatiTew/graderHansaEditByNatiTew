/*
TASK: WORD
LANG: C
AUTHOR: NUTTAWUT MANEEKASORN
CENTER: PSUPN-01
*/

#include <stdio.h>
#include <string.h>
void main(){
  int i,j,k,p,x,y,cur_word;
  int w,h;
  int dconfig[8][2] = {{0,-1},{1,-1},{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1}};
  int TrueHit,cur_len,wordcnt;
  char Table[30][30];
  char word[110][20];


  scanf("%d %d",&h,&w);
  for(i=0;i<h;i++)
      scanf("%s",Table[i]);
  scanf("%d",&wordcnt);

  for(i=0;i<wordcnt;i++)
      scanf("%s",word[i]);


for(cur_word=0;cur_word<wordcnt;cur_word++){

  for(j=0;j<h;j++){
      for(i=0;i<w;i++){
	  for(k=0;k<8;k++){
	      TrueHit = 1;
	      cur_len = strlen(word[cur_word]);
	      x = i;
	      y = j;
	      for(p=0;p<cur_len;p++){
		  if(tolower(word[cur_word][p])!=tolower(Table[y][x])){
		     TrueHit = 0;
		     break;
		  }
		  x += dconfig[k][0];
		  y += dconfig[k][1];
	      }
	      if(TrueHit==1){
		 printf("%d %d\n",j,i);
		 i = w;
		 j = h;
		 break;
	      }
	  }

      }
  }



}




}