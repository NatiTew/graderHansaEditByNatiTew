/*
TASK: BEE
LANG: C
AUTHOR: SAUTUTTA SEANGTHONG
CENTER: SU-03
*/

#include <stdio.h>
#define MAX 24

int year;

struct BEE{
	int work_b;
	int sum_b;
}B[MAX];

int main()
{  int y,i,sum_old,work_old;
	scanf("%d",&year);
	y=0;
	while (year!=-1)
	{   if (year>=1&&year<=MAX&&y<=MAX)
	    {	for (i=1;i<=year;i++)
		{	if (i==1)
			{   	B[y].work_b=2;
				B[y].sum_b=4;
				sum_old=B[y].sum_b;
				work_old=B[y].work_b;
			}
			else
			{	B[y].work_b=sum_old;
				B[y].sum_b=(work_old*2)+(sum_old-work_old)+1;
				work_old=B[y].work_b;
				sum_old=B[y].sum_b;
			}
		}
	    }
	    y++;
	    scanf("%d",&year);
	}
	for (i=0;i<y;i++)
		printf("%d %d\n",B[i].work_b,B[i].sum_b);
   return 0;
}