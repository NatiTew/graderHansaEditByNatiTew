/*
TASK: DICE
LANG: C
AUTHOR: NUTTAWOOT YOTINOOPAMAI
CENTER: KMITNB01
*/
#include<stdio.h>
#include<string.h>

void main() {
	int i,j,n,tao[6],temp;
	char rot[1000];
	scanf("%d",&n);
	for(i=0;i<n;i++) {
		tao[0]=1;
		tao[1]=2;
		tao[2]=3;
		tao[3]=5;
		tao[4]=4;
		tao[5]=6;
		scanf("%s",rot);
		for(j=0;j<strlen(rot);j++) {
			if(rot[j]=='C') {
				temp=tao[4];
				tao[4]=tao[3];
				tao[3]=tao[2];
				tao[2]=tao[1];
				tao[1]=temp;
			} else if(rot[j]=='D') {
				temp=tao[1];
				tao[1]=tao[2];
				tao[2]=tao[3];
				tao[3]=tao[4];
				tao[4]=temp;
			} else if(rot[j]=='R') {
				temp=tao[0];
				tao[0]=tao[2];
				tao[2]=tao[5];
				tao[5]=tao[4];
				tao[4]=temp;
			} else if(rot[j]=='L') {
				temp=tao[0];
				tao[0]=tao[4];
				tao[2]=temp;
				tao[4]=tao[5];
				tao[5]=tao[2];
			} else if(rot[j]=='F') {
				temp=tao[0];
				tao[0]=tao[3];
				tao[3]=tao[5];
				tao[5]=tao[1];
				tao[1]=temp;
			} else if(rot[j]=='B') {
				temp=tao[0];
				tao[0]=tao[1];
				tao[1]=tao[5];
				tao[5]=tao[3];
				tao[3]=temp;
			}
		}
		printf("%d ",tao[1]);
	}
}