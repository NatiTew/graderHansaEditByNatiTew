/*
TASK: SEGMENT
LANG: C
AUTHOR: PIYAWAT MATRAKOOL
CENTER: mahidol06
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
 long re1,re2;
 int a,b,i,j,k=0;
 int **a1,**b1;
 char c,aa[11],bb[11];
 scanf("%d %d",&a,&b);
 a1=(int**)calloc(sizeof(int),a*3);
 for(i=0;i<3;i++)
  {
   a1[i]=(int*)calloc(sizeof(int),a*3);
  }
 b1=(int**)calloc(sizeof(int),b*3);
 for(i=0;i<3;i++)
  {
   b1[i]=(int*)calloc(sizeof(int),b*3);
  }
 scanf("%c",&c);
 for(j=0;j<3;j++)
  {
   for(i=0,k=0;i<=a*3;i++)
    {
     if(k!=3)
      {
       scanf("%c",&c);
       if(c==' ')
	{
	 a1[j][i]=0;
	}
       else if(c!='\n')
	{
	 a1[j][i]=1;
	}
       k++;
      }
     else
      {
       k=0;
       scanf("%c",&c);
       if(c=='\n') break;
       i--;
      }
    }
  }
 for(j=0;j<3;j++)
  {
   for(i=0,k=0;i<=b*3;i++)
    {
     if(k!=3)
      {
       scanf("%c",&c);
       if(c==' ')	      b1[j][i]=0;
       else if(c!='\n')   b1[j][i]=1;
       k++;
      }
     else
      {
       k=0;
       scanf("%c",&c);
       if(c=='\n') break;
       i--;
      }
    }
  }
 for(i=0;i<a;i++)
  {
   if(a1[0][1+(i*3)]==0)
    {
     if(a1[1][1+(i*3)]==0)
      aa[i]='1';
     else aa[i]='4';
    }
   else if(a1[1][1+(i*3)]==0)
    {
     if(a1[2][1+(i*3)]==0)
	aa[i]='7';
     else aa[i]='0';
    }
   else if(a1[2][2+(i*3)]==0)
    {
     aa[i]='2';
    }
   else if(a1[1][2+(i*3)]==0)
    {
     if(a1[2][(i*3)]==0)
      aa[i]='5';
     else aa[i]='6';
    }
   else if(a1[2][(i*3)]==0)
    {
     if(a1[1][(i*3)]==0)
      aa[i]='3';
     else aa[i]='9';
    }
   else aa[i]='8';
  }


 for(i=0;i<b;i++)
  {
   if(b1[0][1+(i*3)]==0)
    {
     if(b1[1][1+(i*3)]==0)
      bb[i]='1';
     else bb[i]='4';
    }
   else if(b1[1][1+(i*3)]==0)
    {
     if(b1[2][1+(i*3)]==0)
	bb[i]='7';
     else bb[i]='0';
    }
   else if(b1[2][2+(i*3)]==0)
    {
     bb[i]='2';
    }
   else if(b1[1][2+(i*3)]==0)
    {
     if(b1[2][(i*3)]==0)
      bb[i]='5';
     else bb[i]='6';
    }
   else if(b1[2][(i*3)]==0)
    {
     if(b1[1][(i*3)]==0)
      bb[i]='3';
     else bb[i]='9';
    }
   else bb[i]='8';
  }

 re1=atol(aa);
 re2=atol(bb);
 printf("%Ld %Ld %Ld",re1+re2);
 return 0;
}