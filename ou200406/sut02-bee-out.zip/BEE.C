/*
TASK: BEE
LANG: C
AUTHOR: Prayote Boonchaisuk
CENTER: SUT02
*/
#include<stdio.h>
void main(){
int bwork[24]={2,4, 7,11,16,22,29, 37, 46, 56, 67, 79, 92,105,119,134,154,175, 197, 220, 244},
    bsum[24] ={4,7,12,20,32,49,72,102,140,187,244,212,292,395,501,621,756,911,1109,1307,1522},
    n[24]={0},i,N;
    for(i=0;i<24;i++)
	{
	 scanf(" %d",&n[i]);
	 if(n[i]==-1)break;
	}
    N=i;
    for(i=0;i<N;i++)
	printf("%d %d\n",bwork[n[i]-1],bsum[n[i]-1]);
}