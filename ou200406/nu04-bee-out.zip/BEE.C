/*
TASK: BEE
LANG: C
AUTHOR: Tawan Sangsue
CENTER: NU04
*/
#include<stdio.h>

int main(void)
{

	int i;
	int qun,wkr,sld;
	int tmpqun,tmpwkr,tmpsld;
	int wkrcnt[1000],allcnt[1000];
	int year = 0;
	int count = 0;

	while(year!=-1&&year<=24)
	{
		scanf("%d",&year);
		qun = 1;
		wkr = 1;
		sld = 0;

		for(i=1;i<=year;i++)
		{
			tmpqun = qun;
			tmpwkr = wkr;
			tmpsld = sld;

			qun = tmpqun;
			wkr = tmpqun+tmpsld+tmpwkr;
			sld = tmpwkr;
		}

		wkrcnt[count] = wkr;
		allcnt[count] =	qun+wkr+sld;
		count++;

	}
	for(i=0;i<count-1;i++)
	{
		printf("%d %d\n",wkrcnt[i],allcnt[i]);
	}

	return(0);
}
