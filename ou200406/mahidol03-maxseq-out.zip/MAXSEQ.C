/*
TASK: MAXSEQ
LANG: C
AUTHOR: Suthee Kongkiatpaiboon
CENTER: Mahidol03
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
  int n,i,maxin;
  long *b,num,max;
  char *a;

  max=0;
  maxin=0;
  num=0;

  scanf("%d",&n);

  a=(char *) calloc (n+2,sizeof(char));
  b=(long *) calloc (n+2,sizeof(long));
//  c=(int *) calloc (n,sizeof(int));

  for(i=1;i<=n;i++)
    {
      scanf("%d",&a[i]);
    }

  for(i=n;i>=1;i--)
    {
      if( b[i+1] > 0 )
	{
	  b[i]=b[i+1]+a[i];
	}
      else
	b[i]=a[i];
    }

  for(i=n;i>=1;i--)
    {
       if(max<=b[i])
	 {
	   max=b[i];
	   maxin=i;
	 }
    }
  if(max>0)
  {
	  num=max;
	  while(num!=0)
	    {
	      if(num==max)
		printf("%d",a[maxin]);
	      else printf(" %d",a[maxin]);

	      num=num-a[maxin];
	      maxin++;
	    }
	  printf("\n%ld",max);
  }
  else printf("Empty sequence");



  return 0;
}