/*
TASK: WORD
LANG: C
AUTHOR: Pongdanai Chayarun
CENTER: SU
*/
#include<stdio.h>
#include<string.h>
int main()
{ char tab[30][30]={""};
  char win[101][16]={""};
  int x,y,word,i,j,k,l,found=0;
  scanf("%d %d",&y,&x);
  for(i=0;i<y;i++)scanf("%s",tab[i]);
  scanf("%d",&word);
  for(i=0;i<word;i++)scanf("%s",win[i]);
  for(i=0;i<word;i++)
  { for(j=0;j<y;j++)
    {  for(k=0;k<x;k++)
       {
	 if((tab[j][k]==win[i][0]||tab[j][k]-32==win[i][0]||tab[j][k]==win[i][0]-32)&&(tab[j][k+strlen(win[i])-1]==win[i][strlen(win[i])-1]||tab[j][k+strlen(win[i])-1]-32==win[i][strlen(win[i])-1]||tab[j][k+strlen(win[i])-1]==win[i][strlen(win[i])-1]-32))
	 {printf("%d %d\n",j,k);found=1;break;}
	 else if((tab[j][k]==win[i][0]||tab[j][k]-32==win[i][0]||tab[j][k]==win[i][0]-32)&&(tab[j+strlen(win[i])-1][k]==win[i][strlen(win[i])-1]||tab[j+strlen(win[i])-1][k]-32==win[i][strlen(win[i])-1]||tab[j+strlen(win[i])-1][k]==win[i][strlen(win[i])-1]-32))
	 {printf("%d %d\n",j,k);found=1;break;}
       }
       if (found==1)break;
	}
	found=0;
  }



return 0;
}