/*
TASK: SKYLINE
LANG: C
AUTHOR: VEYYAWAT BOONSIN
CENTER: SUT06
*/
#include<stdio.h>
/*struct sky
{
	int l;
	int h;
	int r;
};
sky tow[3000];*/
int tow[3000][3];
int tm[3000];

int i,j,a,b,c,d,e,f;
int num;
int skyline();
int main()
{
	do{
		scanf("%d",&num);
		}while(num > 3000 || num<1);
	for(i=0;i<num;i++)
	{
		scanf("%d %d %d",&tow[i][0],&tow[i][1],&tow[i][2]);
	}
	skyline();
	return 0;
}
int skyline()
{
	int tmp;
	/*for(b=0,tmp=tow[b][0];b<num-1;b++)
		{
			if(tmp>tow[b+1][0])
			{
				tmp=tow[b+1][0];
			}
		}
	printf("%d",tmp);*/
	for(a=0;a<num-1;a++)
	{
		for(c=0;c<num-a-1;c++)
		{
			if(tow[c][0] > tow[c+1][0])
			{
				for(e=0;e<3;e++)
				{
					tmp=tow[c+1][e];
					tow[c+1][e]=tow[c][e];
					tow[c][e]=tmp;
				}
			}
		}
	}
	printf("%d,",tow[0][0]);
	for(j=0;j<num;j++)
	{
		if(tow[j][1]<tow[j+1][1])
			tm[j]=tow[j+1][1];
		if(tow[j][2]<tow[j+1][2])
			tm[j+1]=tow[j+1][2];
	}
	/*for(d=0;d<num;d++)
	{
		for(f=0;f<3;f++)
			printf("%d ",tow[d][f]);
		printf("\n");
	}*/
	return 0;
}