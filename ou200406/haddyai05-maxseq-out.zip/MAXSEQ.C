/*
TASK: MAXSEQ
LANG: C
AUTHOR: Witcharkorn Wongputorn
CENTER: haddyai05
*/
#include<stdio.h>

void main()
{
 int series[2500]={{0}};
 int n,i,j;
 int best_i=-1,best_j=-1;
 int sum=0, maxsum=-1;

 scanf("%d",&n);
 if (n>2500) goto ERR;
 for (i=0;i<n;i++)
   scanf("%d",&series[i]);

 for (i=0;i<n;i++)
 {
   sum=0;
   for (j=i;j<n;j++)
   {
	 sum+=series[j];
	 if (sum>maxsum)
	 {
	   maxsum=sum;
	   best_j=j;
	   best_i=i;
	 }
   }
 }

 if (maxsum>0)
 {
   for (i=best_i;i<=best_j;i++)
   {
	 printf("%d",series[i]);
	 if (i!=best_j) printf(" ");
   }
   printf("\n%d",maxsum);
 }
 else
   printf("Empty sequence");
 goto END;

ERR: 
END:
}