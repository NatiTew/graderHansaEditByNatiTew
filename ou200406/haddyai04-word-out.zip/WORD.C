/*
TASK: WORD
LANG: C
AUTHOR: Rawipas Ungtrakul
CENTER: haddyai04
*/
#include<stdio.h>
#include<ctype.h>
#include<string.h>
void main()
{
 char x[26][26],in[16];
 int i,j,m,n,num,len,k,a,b,s,c,z;

 scanf("%d",&m);
 scanf("%d",&n);

 for(i=0;i<m;i++)
 {
  for(j=0;j<n;j++)
  {
   scanf("%c",&x[i][j]);
   if(x[i][j]=='\n')j--;
   else x[i][j]=tolower(x[i][j]);
  }
 }
 scanf("%d",&num);

for(s=0;s<num;s++)
{
 scanf("%s",in);
 len=strlen(in);

 for(i=0;i<len;i++)
 {
  in[i]=tolower(in[i]);
 }
 c=0;
 while(1)
 {
  z=0;
  for(a=0;a<m;a++)
  {
   for(b=0;b<n;b++)
   {
    if(in[0]==x[a][b]) z++;
    if(in[0]==x[a][b]&&z==c+1)
    {
     c++;break;
    }
   }
   if(in[0]==x[a][b])break;
  }

  i=a;
  j=b;
  for(k=1;k<len;k++)
  {
   if(x[i-1][j-1]!=in[k])break;
   i=i-1;
   j=j-1;
  if(i<0||i==n||j<0||j==n)break;
  }
  if(k==len)break;
  if(i<0||i==n||j<0||j==n)break;

  i=a;
  j=b;
  for(k=1;k<len;k++)
  {
   if(x[i-1][j]!=in[k])break;
   i=i-1;
   if(i<0||i==n||j<0||j==n)break;
  }
  if(k==len)break;
  if(i<0||i==n||j<0||j==n)break;

  i=a;
  j=b;
  for(k=1;k<len;k++)
  {
   if(x[i][j+1]!=in[k])break;
   j=j+1;
   if(i<0||i==n||j<0||j==n)break;
  }
  if(k==len)break;
  if(i<0||i==n||j<0||j==n)break;

  i=a;
  j=b;
  for(k=1;k<len;k++)
  {
   if(x[i+1][j+1]!=in[k])break;
   i=i+1;
   j=j+1;
   if(i<0||i==n||j<0||j==n)break;
  }
  if(k==len)break;
  if(i<0||i==n||j<0||j==n)break;

  i=a;
  j=b;
  for(k=1;k<len;k++)
  {
   if(x[i+1][j]!=in[k])break;
   i=i+1;
   if(i<0||i==n||j<0||j==n)break;
  }
  if(k==len)break;
  if(i<0||i==n||j<0||j==n)break;

  i=a;
  j=b;
  for(k=1;k<len;k++)
  {
   if(x[i+1][j-1]!=in[k])break;
   i++;
   j--;
   if(i<0||i==n||j<0||j==n)break;
  }
  if(k==len)break;
  if(i<0||i==n||j<0||j==n)break;

  i=a;
  j=b;
  for(k=1;k<len;k++)
  {
   if(x[i][j-1]!=in[k])break;
   j--;
   if(i<0||i==n||j<0||j==n)break;
  }
  if(k==len)break;
  if(i<0||i==n||j<0||j==n)break;

  }
  printf("%d %d\n",a,b);
 }        //for

 }//main

