/*
TASK: MAXSEQ
LANG: c
AUTHOR: Phumpong
CENTER: nu03
*/
#include<stdio.h>
int main()
{
	int a,c[20],i,j,k,tmp,lowseq,nseq,sumtmp=0;
	scanf("%d",&a);
	for(i=0;i<a;i++)
	{
		scanf("%d",&c[i]);
	}
	for(i=0;i<a;i++)
	{
		printf("%d ",c[i]);
	}
	printf("\n\n");
	for(i=0;i<a;i++)
	{       tmp=0;
		for(j=a-i;j<i;j++)
		{
		tmp=tmp+c[j];

		}

			if(tmp>sumtmp)
				{
					sumtmp=tmp;
					lowseq=i;
					nseq=j;
				}
	}
	printf("\n%d\n",sumtmp)  ;
	for(i=0;i<nseq;i++)
	{
		printf("%d ",c[lowseq+i]);
	}
	return 0;
}