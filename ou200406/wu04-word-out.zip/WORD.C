/*
TASK: WORD
LANG: C
AUTHOR: Pijak JIrapiwong
CENTER: WU-04
*/
#include <stdio.h>
#include <string.h>

int Find(int m,int n,char *voc,char word[26][26]) {
	int i,j,k,t,len,pass,with;
	char a,b;
	len=strlen(voc);
	for(i=0;i<m;i++) {
		for(j=0;j<n;j++) {
			// back left up
			with=(i>j?j:i);
			if(word[i][j]==voc[0]&&len<=with) {
				t=1;
				for(k=1;k<len;k++) {
					if(word[i-k][j-k]!=voc[k]) break;
					t++;
				}
				if(len==t) { printf("%d %d\n",i,j); return 0; }
			}

			//up
			with=i+1;
			if(word[i][j]==voc[0]&&len<=with) {
				t=1;
				for(k=1;k<len;k++) {
					if(word[i-k][j]!=voc[k]) break;
					t++;
				}
				if(len==t) { printf("%d %d\n",i,j); return 0; }
			}

			//back left down
			with=(i>j?j:i)+1;
			if(word[i][j]==voc[0]&&len<=with) {
				t=1;
				for(k=1;k<len;k++) {
					if(word[i+k][j-k]!=voc[k]) break;
					t++;
				}
				if(len==t) { printf("%d %d\n",i,j); return 0; }
			}

			//front right up
			with=((n-1-j)>i?i:(n-1-j))+1;
			if(word[i][j]==voc[0]&&len<=with) {
				t=1;
				for(k=1;k<len;k++) {
					if(word[i-k][j+k]!=voc[k]) break;
					t++;
				}
				if(len==t) { printf("%d %d\n",i,j); return 0; }
			}

			// right down
			with=((n-j)>(m-i)?(m-i):(n-j));
			if(word[i][j]==voc[0]&&len<=with) {
				t=1;
				for(k=1;k<len;k++) {
					if(word[i+k][j+k]!=voc[k]) break;
					t++;
				}
				if(len==t) { printf("%d %d\n",i,j); return 0; }
			}

			//left
			with=j+1;
			if(word[i][j]==voc[0]&&len<=with) {
				t=1;
				for(k=1;k<len;k++) {
					if(word[i][j-k]!=voc[k]) break;
					t++;
				}
				if(len==t) { printf("%d %d\n",i,j); return 0; }
			}

			//right
			with=n-j;
			if(word[i][j]==voc[0]&&len<=with) {
				t=1;
				for(k=1;k<len;k++) {
					if(word[i][j+k]!=voc[k]) break;
					t++;
				}
				if(len==t) { printf("%d %d\n",i,j); return 0; }
			}

			//down
			with=m-i;
			if(word[i][j]==voc[0]&&len<=with) {
				t=1;
				for(k=1;k<len;k++) {
					if(word[i+k][j]!=voc[k]) break;
					t++;
				}
				if(len==t) { printf("%d %d\n",i,j); return 0; }
			}
		}
	}
	return 1;
}

void main() {
	int a,i,j,m,n,w;
	char c,word[26][26],voc[20],sub[26];
	scanf("%d %d\n",&m,&n);
	for(i=0;i<m;i++) {
		scanf("%s",word[i]);
	}

	for(i=0;i<m;i++) {
		for(j=0;j<n;j++) {
			if(word[i][j]>'Z') word[i][j]-=32;
		}
	}

	scanf("%d\n",&w);
	for(i=0;i<w;i++) {
		scanf("%s",voc);
		strupr(voc);
		a=Find(m,n,voc,word);
	}
}