/*
TASK: DICE
LANG: C
AUTHOR: PANOT CHAIMONGKOL
CENTER: TU01
*/

#include <stdio.h>

void main()
{
	int num,i,j,side[6],tmp;
	char roll[1001];
	scanf("%d",&num);
	for (i=0;i<num;i++)
	{
		side[0]=1;
		side[1]=2;
		side[2]=3;
		side[3]=5;
		side[4]=4;
		side[5]=6;
		j=0;
		scanf("%s",roll);
		while (roll[j]!='\0')
		{
			switch(roll[j])
			{
				case 'F':
					tmp = side[0];
					side[0] = side[3];
					side[3] = side[5];
					side[5] = side[1];
					side[1] = tmp;
					break;
				case 'B':
					tmp = side[0];
					side[0] = side[1];
					side[1] = side[5];
					side[5] = side[3];
					side[3] = tmp;
					break;
				case 'L':
					tmp = side[0];
					side[0] = side[4];
					side[4] = side[5];
					side[5] = side[2];
					side[2] = tmp;
					break;
				case 'R':
					tmp = side[0];
					side[0] = side[2];
					side[2] = side[5];
					side[5] = side[4];
					side[4] = tmp;
					break;
				case 'C':
					tmp = side[1];
					side[1] = side[4];
					side[4] = side[3];
					side[3] = side[2];
					side[2] = tmp;
					break;
				case 'D':
					tmp = side[1];
					side[1] = side[2];
					side[2] = side[3];
					side[3] = side[4];
					side[4] = tmp;
			} //switch
			j++;
		} //while
		printf("%d ",side[1]);
	} //for
} //main