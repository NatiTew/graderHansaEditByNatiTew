/*
TASK: SEGMENT
LANG: C
AUTHOR: Sorawit Boonyathee
CENTER: cmu01
*/

#include <stdio.h>
#include <math.h>

int main()
{
	int num1,num2,i,j,k,x,temp1,temp2,count=0;
	unsigned long cal1=0,cal2=0,result;
	char table[11][4][4];
	char t1[4][100],t2[4][100];
		for(i=0;i<=10;i++)
	{
		for(j=0;j<3;j++)
			for(k=0;k<3;k++)
				table[i][j][k]=' ';
	}
	//create table num
	table[1][1][2]='|';
	table[1][2][2]='|';
	table[2][0][1]='_';
	table[2][1][1]='_';
	table[2][1][2]='|';
	table[2][2][0]='|';
	table[2][2][1]='_';
	table[3][0][1]='_';
	table[3][1][1]='_';
	table[3][1][2]='|';
	table[3][2][1]='_';
	table[3][2][2]='|';
	table[4][1][0]='|';
	table[4][1][1]='_';
	table[4][1][2]='|';
	table[4][2][2]='|';
	table[5][0][1]='_';
	table[5][1][0]='|';
	table[5][1][1]='_';
	table[5][2][1]='_';
	table[5][2][2]='|';
	table[6][0][1]='_';
	table[6][1][0]='|';
	table[6][1][1]='_';
	table[6][2][0]='|';
	table[6][2][1]='_';
	table[6][2][2]='|';
	table[7][0][1]='_';
	table[7][1][2]='|';
	table[7][2][2]='|';
	table[8][0][1]='_';
	table[8][1][0]='|';
	table[8][1][1]='_';
	table[8][1][2]='|';
	table[8][2][0]='|';
	table[8][2][1]='_';
	table[8][2][2]='|';
	table[9][0][1]='_';
	table[9][1][0]='|';
	table[9][1][1]='_';
	table[9][1][2]='|';
	table[9][2][1]='_';
	table[9][2][2]='|';
	table[0][0][1]='_';
	table[0][1][0]='|';
	table[0][1][2]='|';
	table[0][2][0]='|';
	table[0][2][1]='_';
	table[0][2][2]='|';
	scanf("%d",&num1);
	scanf("%d",&num2);
	temp1=num1;
	temp2=num2;
	gets(t1[4]);
	for(i=0;i<3;i++)
	{
		gets(t1[i]);
	}
	for(i=0;i<3;i++)
	{
		gets(t2[i]);
	}
	for(i=0;i<(num1*3)+(num-1);i=i+4,temp1--)
	{
		for(x=0;x<10;x++)
		{
			for(j=0,count=0;j<3;j++)
		{
			for(k=i;k<i+3;k++)
			{
				if(table[x][j][k-i]==t1[j][k])
					count++;
			}
			if(count==9)
				cal1+=(x*(pow(10,temp1-1)));
		}
		}
	}
	for(i=0;i<(num2*3)+(num-1);i=i+4,temp2--)
	{
		for(x=0;x<10;x++)
		{
			for(j=0,count=0;j<3;j++)
		{
			for(k=i;k<i+3;k++)
			{
				if(table[x][j][k-i]==t2[j][k])
					count++;
			}
			if(count==9)
				cal2+=(x*(pow(10,temp2-1)));
		}
		}
	}
	result=cal1+cal2;
	printf("%ld",result);
	return 0;
}