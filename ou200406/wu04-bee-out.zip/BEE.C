/*
TASK: BEE
LANG: C
AUTHOR: Pijak Jirapiwong
CENTER: WU-04
*/
#include <stdio.h>

void clrarr(int year[]) {
	int i;
	for(i=0;i<30;i++) year[i]=0;
}

void Tran(char *com,int year[]) {
	int i,y;
	i=y=0;
	while(com[i]!='-') {
		if(com[i]!=' ') {
			if(com[i+1]!=' ') {
				year[y]=(com[i]-'0')*10+(com[i+1]-'0');
				y++;
				i+=3;
			}
			else {
				year[y]=com[i]-'0';
				y++;
				i+=2;
			}
		}
		else i++;
	}
}

void main() {
	int i,j,n,year[30];
	char com[200];
	long int s,q,w,tms,tmw;
	n=0;
	scanf("%[0123456789- ]s",com);
	clrarr(year);
	Tran(com,year);
	while(year[n]!=0) n++;
	for(i=0;i<n;i++) {
		w=q=1; s=0;
		for(j=1;j<=year[i];j++) {
			tms=s;
			tmw=w;
			s+=tmw;
			w+=tms;
			w+=q;
			s-=tms;

		}
		printf("%ld %ld\n",w,w+q+s);
	}
}