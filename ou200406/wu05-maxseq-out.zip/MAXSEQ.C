/*
TASK: MAXSEQ
LANG: C
AUTHOR: Wachiraphan Charoenwet
CENTER: WU05
*/

#include<stdio.h>

int seq[3000];
int maxseq[3000];

int main(){
int n,i,j,o,k,sum,test,x,count;

	scanf("%d",&n);

	for(i=0;i<n;i++)
		scanf("%d",&seq[i]);

		j=0;
		sum=0;

	for(i=0;i<n;i++){
	    k=0;
	while(i+k<=n){
			j=i;
			k++;
			test=0;
			o=0;
			while(j<=i+k&&j<=n){
			    test=test+seq[j];
			    j++;
			    o++;
			}

			if(test>sum&&test>0){
				count=0;
				sum=test;
				for(x=0;x<=n-i;x++)
					maxseq[x]=0;
				for(x=0;x<o;x++){
					maxseq[x]=seq[i+x];
					count++;
				}
			}
		}
	}
		if(sum>0){
		printf("%d\n",sum);
		for(k=0;k<count;k++)
			printf("%d ",maxseq[k]);
		}
		else

		printf("Empty Sequence");
 return 0;
}