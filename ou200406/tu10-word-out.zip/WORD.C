/*
TASK: WORD
LANG: C
AUTHOR: Passarit Atiworraman
CENTER: tu10
*/

#include<stdio.h>
#include<ctype.h>
#include<string.h>

char str[30][30];
int row,col,len;
int index1,index2;

int checkstring(char *temp);
int compare(char *temp,int i,int j);

int main()
{
    int x,y,input,check;
    char temp[30];
    scanf("%d",&row);
    scanf("%d",&col);
    for(x=0;x<row;x++)
    {
	scanf("%s",temp);
	for(y=0;y<col;y++)
	{
	    temp[y] = tolower(temp[y]);
	    str[x][y] = temp[y];
	}
    }
    scanf("%d",&input);
    for(x=0;x<input;x++)
    {
	check = 0;
	scanf("%s",temp);
	len = strlen(temp);
	for(y=0;y<len;y++)
	    temp[y] = tolower(temp[y]);
	check = checkstring(temp);
	if(check)
	    printf("%d %d\n",index1,index2);
    }
    return 0;
}

int checkstring(char *temp)
{
    int x,y,check;
    for(x=0;x<row;x++)
	for(y=0;y<col;y++)
	    if(str[x][y] == temp[0])
	    {
		check = compare(temp,x,y);
		if(check == 1)
		{
		    index1 = x;
		    index2 = y;
		    return 1;
		}
	    }
    return 0;
}

int compare(char *temp,int i,int j)
{
    int x,y,z,check=1;
    for(x=i,y=j,z=0;x>=0,y>=0,z<len;x--,y--,z++) //left up
    {
	if(str[x][y] != temp[z])
	    check = 0;
    }
    if(check)
	return 1;
    check = 1;
    for(x=i,y=j,z=0;x>=0,y<col,z<len;x--,y++,z++) // right up
    {
	if(str[x][y] != temp[z])
	    check = 0;
    }
    if(check)
	return 1;
    check = 1;
    for(x=i,y=j,z=0;x<row,y>=0,z<len;x++,y--,z++)  // left down
    {
	if(str[x][y] != temp[z])
	    check = 0;
    }
    if(check)
	return 1;
    check = 1;
    for(x=i,y=j,z=0;x<row,y<col,z<len;x++,y++,z++) //right down
    {
	if(str[x][y] != temp[z])
	    check = 0;
    }
    if(check)
	return 1;
    check = 1;
    //horizontal
    x = i;
    z = 0;
    for(y=j;y<j+len;y++)
    {
	if(str[x][y] != temp[z])
	    check = 0;
	z++;
    }
    if(check)
	return 1;
    check = 1;
    x = i;
    z = 0;
    for(y=j;y>j-len;y--)
    {
	if(str[x][y] != temp[z])
	    check = 0;
	z++;
    }
    if(check)
	return 1;
    check = 1;
    //vertical
    y = j;
    z = 0;
    for(x=i;x<i+len;x++)
    {
	if(str[x][y] != temp[z])
	    check = 0;
	z++;
    }
    if(check)
	return 1;
    check = 1;
    y = j;
    z = 0;
    for(x=i;x>i-len;x--)
    {
	if(str[x][y] != temp[z])
	    check = 0;
	z++;
    }
    if(check)
	return 1;

/*    for(x=0;x<row;x++) //vertical
    {
	z = 0;
	for(y=0;y<col;y++)
	{
	   if(str[y][x] != temp[z])
		check = 0;
	   z++;
	}
	if(check)
	    return 1;
    } */
    return check;
}



