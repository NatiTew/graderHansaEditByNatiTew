/*
TASK: MAXSEQ
LANG: C
AUTHOR: SARAN SONGYOD
CENTER: HADDYAI06
*/
#include<stdio.h>

void main()
{ int numq[1500];
  int begin,end,back,temp,tmp_j; //3kb
  int n,i,j,sum,max;

  scanf("%d",&n);

  if((n>=1)&&(i<=2500))
  {  for(i=0;i<n;i++)
       scanf("%d",&numq[i]);
       max = -1;
     for(i=0;i<=n;i++)
      { sum = 0;
	temp =0;
	for(j=i;((j<n)&&(sum>=-1)&&(sum>=0));j++)
	{ sum += numq[j];
	  if(sum>max)
	  {temp=sum;
	   tmp_j=j+1;
	  }
	  else if((sum<=temp)||(sum<0)) break;
	}
       if((sum<temp)&&(temp>max))
       { max= temp;
	 end = tmp_j;
	 begin =i;
       }
//	 sum-=numq[j-1];
       else if((sum>0)&&(sum>max))
       { begin = i;
	 end = j-1;
	 max = sum;
       }
     }
  if(max>0)
  { for(i=begin;i<end;i++)
     { printf("%d",numq[i]);
       if(i<end-1)
	 printf(" ");
       else printf("\n");
     }
     printf("%d",max);
  }
  else printf("Empty sequence");
  }
  else printf("Empty sequence");
}
