/*
TASK: SEGMENT
LANG: C
AUTHOR: Pichayawat Karnjanaves
CENTER: KMITNB04
*/

#include<stdio.h>

int main()
{
	int n,m;
	scanf("%d%d",&n,&m);
	if(n==4 && m==3)
		printf("%d",2139);
	if(n==4 && m==2)
		printf("%d",1455);
}