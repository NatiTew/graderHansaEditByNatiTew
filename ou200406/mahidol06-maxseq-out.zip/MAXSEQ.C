/*
TASK: MAXSEQ
LANG: C
AUTHOR: PIYAWAT MATRAKOOL
CENTER: MAHIDOL06
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
 long a[100][100],max=0;
 int s=1,n,i,j,x=0,y=1,*m;
 scanf("%d",&n);
 m=(int*)calloc(sizeof(int),n);
 scanf("%d",&m[0]);
 a[0][0]=m[0];
 for(i=1;i<n;i++)
  {
   scanf(" %d",&m[i]);
   a[i][i]=m[i];
  }
 for(j=1,i=0;j<n&&i<n-1;j++,i++)
    {
     a[i][j]=m[j]+a[i][j-1];
     if(max<a[i][j])
      {
       max=a[j-i][j];
       x=i;
       y=j;
      }
     if(i!=0&&j==n-1)
      {
       j=s;
       i=-1;
       s++;
      }
    }
 if(max>0)
  {
   printf("%d",a[x][x]);
   for(i=x+1;i<=y;i++)
    {
     printf(" %d",a[i][i]);
    }
   printf("\n%d",max);
  }
 else printf("Empty sequence");
 return 0;
}