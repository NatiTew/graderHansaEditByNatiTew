/*TASK: SEGMENT
LANG: C
AUTHOR: NATTHANON THAMSIRARAK
CENTER: TU14
*/
#include<stdio.h>

long pow(int mh,int p)
{
	long keep=1,loop;
	for(loop=0;loop<p;loop++)
		keep*=mh;
	return keep;
}

void main()
{
	int m,n,loop,loop2,sw=0;
	char temp,dig[11][10];
	long a=0;
	scanf("%d%d",&m,&n);
	for(loop=0;loop<m;loop++)
	{
		for(loop2=0;loop2<9;loop2++)
		dig[loop][loop2]=0;
	}

	for(sw=0;sw<2;m=n)
	{
	for(loop2=0;loop2<3;loop2++)
	for(loop=0;loop<m;loop++)
	{
		scanf("%c%c%c%c",&temp,&dig[loop][loop2*3],&dig[loop][(loop2*3)+1],&dig[loop][(loop2*3)+2]);
	}
	for(loop=0;loop<m;loop++)
	{
		if(dig[loop][1]!='_' && dig[loop][3]=='|')
			a+=4*pow(10,m-loop-1);
		else if(dig[loop][1]!='_')
			a+=pow(10,m-loop-1);
		else if(dig[loop][3]=='|' && dig[loop][4]=='_' && dig[loop][5]=='|' && dig[loop][6]=='|' && dig[loop][7]=='_')
			a+=8*pow(10,m-loop-1);
		else if(dig[loop][3]=='|' && dig[loop][4]=='_' && dig[loop][5]=='|' && dig[loop][6]=='|')
			a+=9*pow(10,m-loop-1);
		else if(dig[loop][3]!='|' && dig[loop][4]=='_' && dig[loop][5]=='|' && dig[loop][6]=='|' && dig[loop][7]=='_' && dig[loop][8]!='|')
			a+=2*pow(10,m-loop-1);
		else if(dig[loop][3]!='|' && dig[loop][4]=='_' && dig[loop][5]=='|' && dig[loop][6]!='|' && dig[loop][7]=='_' && dig[loop][8]=='|')
			a+=3*pow(10,m-loop-1);
		else if(dig[loop][3]=='|' && dig[loop][4]=='_' && dig[loop][5]=='|' && dig[loop][6]!='|' && dig[loop][7]!='_' && dig[loop][8]=='|')
			a+=4*pow(10,m-loop-1);
		else if(dig[loop][3]=='|' && dig[loop][4]=='_' && dig[loop][5]!='|' && dig[loop][6]!='|' && dig[loop][7]=='_' && dig[loop][8]=='|')
			a+=5*pow(10,m-loop-1);
		else if(dig[loop][3]=='|' && dig[loop][4]=='_' && dig[loop][5]!='|')
			a+=6*pow(10,m-loop-1);
		else if(dig[loop][3]!='|')
			a+=7*pow(10,m-loop-1);
	}
	sw++;
	}
	printf("%ld",a);
}