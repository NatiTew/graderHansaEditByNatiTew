/*
TASK: SKYLINE
LANG: C
AUTHOR: Khakhana Thimachai
CENTER: buu02
*/

#include<stdio.h>

typedef struct{
	int l,h,r;
}sky;


int main(void){
	sky in[3000];
	sky tmp;
	int x,max=0;
	int ex;
	int i,j;
	int n;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %d %d",&in[i].l,&in[i].h,&in[i].r);
		printf("%d %d %d\n",in[i].l,in[i].h,in[i].r);
	}
	j=n;
	ex=0;
	while(ex==0){
		ex=1;
		for(i=0;i<j;i++){
			if(in[i].l>in[i+1].l){
				tmp=in[i];
				in[i]=in[i+1];
				in[i+1]=tmp;
				ex=0;
			}
		}
		j--;
	}
	for(i=0;i<n;i++){
		if(in[i].r>max)
			max = in[i].r;
	}
	x=0;
	printf("%d %d ",in[x].l,in[x].h);
	i=in[x].l;
	while(i<max){
		for(j=x;j<n;j++){
			if(in[j].r<i&&in[j].h>in[x].h){
				x=j;
				printf("%d %d ",in[x].l,in[x].h);
				//i=in[x].l;
			}
		}
		if(i==in[x].r){
			printf("%d %d ",in[x].r,in[x+1].h);
			x++;
			i=in[x].l;
		}
		i++;
	}
	printf("%d 0\n",max);
	return 0;
}